# Aurora Docs

基于 **Astro + React + shadcn/ui** 的三栏文档站模板：左侧可折叠导航、中间 MDX 正文、右侧当前页目录，顶部提供面包屑、命令面板搜索与暗色模式切换。

## 初始化

```bash
# 创建骨架（本项目使用的命令）
bun x --bun shadcn@latest init --preset b0 --template astro -n docs

# 安装依赖
bun install
bun add @astrojs/mdx @tailwindcss/typography
```

> Astro 7 要求 Node.js `>= 22.23.4`，低于该版本会在构建阶段直接退出。

## 常用命令

| 命令 | 作用 |
| --- | --- |
| `bun run dev` | 本地开发（默认 http://localhost:4321） |
| `bun run build` | 构建静态产物到 `dist/` |
| `bun run preview` | 预览构建产物 |
| `bun run typecheck` | `astro check` 类型检查 |
| `bun run lint` | ESLint |
| `bun run format` | Prettier 格式化 |

## 目录速览

```
src/
├── components/        # 站点组件（app-sidebar / docs-shell / table-of-contents …）
│   ├── mdx/           # MDX 中可用的 Callout、Steps
│   └── ui/            # shadcn 组件源码
├── config/docs.ts     # 站点元信息 + 侧边栏导航（单一数据源）
├── content/docs/      # 全部 MDX 文档
├── layouts/           # root-layout / docs-layout
├── lib/nav.ts         # 面包屑、上下篇、TOC 派生逻辑
├── pages/             # 路由：落地页 + docs/[...slug]
└── styles/global.css  # Tailwind 入口 + 语义 token
```

## 写一篇新文档

1. 在 `src/content/docs/` 下新建 `.mdx`，frontmatter 至少包含 `title` 与 `description`
2. 把 `{ title, href }` 加进 `src/config/docs.ts` 中对应分组的 `items`
3. 面包屑、上下篇导航、搜索索引会自动包含它

## 两个实现约定

- **外壳是一个 island**：`Sidebar` 依赖 React Context，`SidebarProvider` 与 `SidebarTrigger` 必须处在同一棵 React 树中，因此三栏外壳统一放在 `src/components/docs-shell.tsx` 里以 `client:load` 注入，正文通过 Astro slot 静态渲染
- **颜色只走 token**：组件里不写死色值，全部引用 `global.css` 中的语义变量，暗色模式在 `.dark` 里覆盖同名变量

更多细节见站内文档：运行 `bun run dev` 后从 `/docs` 进入。
