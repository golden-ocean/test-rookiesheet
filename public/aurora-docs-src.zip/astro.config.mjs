// @ts-check

import tailwindcss from "@tailwindcss/vite"
import mdx from "@astrojs/mdx"
import react from "@astrojs/react"
import { defineConfig } from "astro/config"

// https://astro.build/config
export default defineConfig({
  site: "https://aurora-docs.example.com",
  integrations: [react(), mdx()],
  markdown: {
    shikiConfig: {
      // 亮/暗双主题：由 <html class="dark"> 切换，与 shadcn token 保持一致
      themes: { light: "github-light", dark: "github-dark-default" },
      defaultColor: false,
      wrap: false,
    },
  },
  vite: {
    plugins: [tailwindcss()],
  },
})
