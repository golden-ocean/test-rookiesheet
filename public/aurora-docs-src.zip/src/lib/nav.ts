import { docsNav, flatDocsNav } from "@/config/docs"
import type { NavItem } from "@/config/docs"

/**
 * 判断某个导航项是否命中当前路径。
 * 目录页（如 /docs）允许用前缀匹配命中其子页面。
 */
export function isActivePath(pathname: string, href: string): boolean {
  return pathname === href || pathname === `${href}/`
}

/** 去掉结尾斜杠，统一不同写法的路径。 */
export function normalizePath(path: string): string {
  if (path.length > 1 && path.endsWith("/")) return path.slice(0, -1)
  return path
}

/** 面包屑：文档 / 分组名 / 当前页。 */
export function getBreadcrumbTrail(pathname: string): NavItem[] {
  const current = normalizePath(pathname)

  for (const group of docsNav) {
    const item = group.items.find((entry) => isActivePath(current, entry.href))
    if (item) {
      return [
        { title: group.title, href: group.items[0]?.href ?? current },
        item,
      ]
    }
  }

  return []
}

/** 依据侧边栏顺序返回上一篇 / 下一篇。 */
export function getAdjacentDocs(href: string): {
  prev: NavItem | null
  next: NavItem | null
} {
  const current = normalizePath(href)
  const index = flatDocsNav.findIndex((item) =>
    isActivePath(current, item.href)
  )

  if (index === -1) {
    return { prev: null, next: null }
  }

  return {
    prev: index > 0 ? flatDocsNav[index - 1] : null,
    next: index < flatDocsNav.length - 1 ? flatDocsNav[index + 1] : null,
  }
}

/** 把 Markdown 标题数组收敛成 TOC 层级（只保留 h2 / h3）。 */
export type TocEntry = {
  depth: number
  slug: string
  text: string
}

export function buildToc(
  headings: { depth: number; slug: string; text: string }[]
): TocEntry[] {
  return headings
    .filter((heading) => heading.depth === 2 || heading.depth === 3)
    .map((heading) => ({
      depth: heading.depth,
      slug: heading.slug,
      // 去掉 MDX 里可能残留的行内标记
      text: heading.text.replace(/[*_`]/g, ""),
    }))
}
