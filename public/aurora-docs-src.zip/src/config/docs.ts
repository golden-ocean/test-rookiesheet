import type { LucideIcon } from "lucide-react"
import {
  BookOpenIcon,
  BlocksIcon,
  CompassIcon,
  FileCodeIcon,
  HammerIcon,
  LayoutPanelLeftIcon,
  RocketIcon,
  Settings2Icon,
  SparklesIcon,
  TerminalIcon,
} from "lucide-react"

/** 站点级元信息，统一从这里读取，避免散落到各处写死。 */
export const siteConfig = {
  name: "Aurora Docs",
  shortName: "Aurora",
  tagline: "Astro + React + shadcn/ui 文档站模板",
  description:
    "基于 Astro 内容集合与 shadcn/ui 构建的三栏文档站：左侧导航、正文 MDX、右侧目录，支持暗色模式与全文结构导航。",
  repo: "https://github.com/shadcn-ui/ui",
  version: "1.0.0",
  author: "Aurora Team",
} as const

export type NavItem = {
  title: string
  /** 站点内相对路径，统一以 / 开头，结尾不带斜杠。 */
  href: string
  label?: string
  badge?: string
  /** 是否在导航栏/搜索中隐藏。 */
  disabled?: boolean
}

export type NavGroup = {
  title: string
  icon?: LucideIcon
  /** 分组是否默认展开。 */
  defaultOpen?: boolean
  items: NavItem[]
}

/** 主导航：对应左侧 Sidebar 的分组 + 首页卡片入口。 */
export const docsNav: NavGroup[] = [
  {
    title: "开始使用",
    icon: RocketIcon,
    defaultOpen: true,
    items: [
      { title: "文档概览", href: "/docs/introduction" },
      { title: "安装项目", href: "/docs/installation" },
      { title: "目录结构", href: "/docs/project-structure" },
      { title: "路由约定", href: "/docs/routing" },
    ],
  },
  {
    title: "编写文档",
    icon: FileCodeIcon,
    defaultOpen: true,
    items: [
      { title: "内容集合配置", href: "/docs/content-collections" },
      { title: "MDX 语法能力", href: "/docs/mdx" },
      { title: "导航与侧边栏", href: "/docs/navigation", badge: "常用" },
      { title: "右侧目录 TOC", href: "/docs/table-of-contents" },
    ],
  },
  {
    title: "界面设计",
    icon: LayoutPanelLeftIcon,
    defaultOpen: true,
    items: [
      { title: "三栏布局", href: "/docs/layout", label: "新" },
      { title: "主题与暗色模式", href: "/docs/theming" },
      { title: "MDX 自定义组件", href: "/docs/components" },
    ],
  },
  {
    title: "进阶",
    icon: Settings2Icon,
    items: [
      { title: "添加 shadcn 组件", href: "/docs/add-components" },
      { title: "构建与部署", href: "/docs/deployment" },
      { title: "配置参考", href: "/docs/reference", badge: "API" },
    ],
  },
]

/** 首页「从这里开始」卡片，按阅读顺序排列。 */
export const entryCards: {
  title: string
  description: string
  href: string
  icon: LucideIcon
}[] = [
  {
    title: "文档概览",
    description: "了解这套文档模板的能力边界与设计取舍。",
    href: "/docs/introduction",
    icon: BookOpenIcon,
  },
  {
    title: "安装项目",
    description: "一条命令初始化，五分钟跑起来本地开发。",
    href: "/docs/installation",
    icon: TerminalIcon,
  },
  {
    title: "三栏布局",
    description: "左侧导航、正文、右侧目录的栅格实现细节。",
    href: "/docs/layout",
    icon: LayoutPanelLeftIcon,
  },
  {
    title: "MDX 组件",
    description: "Callout、Steps、代码块等在 MDX 中的用法。",
    href: "/docs/components",
    icon: SparklesIcon,
  },
]

/** 顶栏快捷入口（宽屏显示）。 */
export const topNav: NavItem[] = [
  { title: "文档", href: "/docs/introduction" },
  { title: "MDX 语法", href: "/docs/mdx" },
  { title: "添加组件", href: "/docs/add-components" },
  { title: "配置参考", href: "/docs/reference" },
]

/** 侧边栏底部的外链分组。 */
export const externalNav: { title: string; href: string; icon: LucideIcon }[] =
  [
    {
      title: "Astro 文档",
      href: "https://docs.astro.build",
      icon: CompassIcon,
    },
    {
      title: "shadcn/ui 组件",
      href: "https://ui.shadcn.com",
      icon: BlocksIcon,
    },
    {
      title: "本项目仓库",
      href: "https://github.com/shadcn-ui/ui",
      icon: HammerIcon,
    },
  ]

/** 把 /docs/a/b 展平成列表，供搜索与上下篇使用。 */
export const flatDocsNav: NavItem[] = docsNav.flatMap((group) => group.items)
