"use client"

import * as React from "react"
import { ArrowUpRightIcon, ChevronRightIcon, TagIcon } from "lucide-react"
import { cn } from "cn"

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { docsNav, externalNav, siteConfig, type NavGroup } from "@/config/docs"
import { isActivePath } from "@/lib/nav"

type AppSidebarProps = React.ComponentProps<typeof Sidebar> & {
  /** 当前页面路径，用于高亮激活项。 */
  pathname: string
}

export function AppSidebar({ pathname, ...props }: AppSidebarProps) {
  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" render={<a href="/" />}>
              <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-[13px] font-semibold text-sidebar-primary-foreground">
                A
              </div>
              <div className="grid flex-1 text-left leading-tight">
                <span className="truncate text-sm font-semibold">
                  {siteConfig.name}
                </span>
                <span className="truncate text-xs text-sidebar-foreground/70">
                  v{siteConfig.version}
                </span>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent>
        {docsNav.map((group) => (
          <NavSection key={group.title} group={group} pathname={pathname} />
        ))}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          {externalNav.map((item) => (
            <SidebarMenuItem key={item.href}>
              <SidebarMenuButton
                size="sm"
                tooltip={item.title}
                render={
                  <a
                    href={item.href}
                    target="_blank"
                    rel="noreferrer noopener"
                  />
                }
              >
                <item.icon />
                <span>{item.title}</span>
                <ArrowUpRightIcon className="ml-auto size-3 opacity-60" />
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
          <SidebarMenuItem>
            <SidebarMenuButton
              size="sm"
              tooltip="当前版本"
              className="cursor-default"
            >
              <TagIcon />
              <span className="text-sidebar-foreground/70">
                最新版本 v{siteConfig.version}
              </span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}

function NavSection({
  group,
  pathname,
}: {
  group: NavGroup
  pathname: string
}) {
  const containsActive = group.items.some((item) =>
    isActivePath(pathname, item.href)
  )
  const Icon = group.icon

  return (
    <Collapsible
      defaultOpen={group.defaultOpen ?? containsActive}
      className="group/collapsible"
    >
      <SidebarGroup>
        <SidebarGroupLabel
          className={cn(
            "w-full cursor-pointer text-xs tracking-wide uppercase select-none hover:text-sidebar-accent-foreground"
          )}
          render={<CollapsibleTrigger />}
        >
          {Icon ? <Icon /> : null}
          <span className="truncate">{group.title}</span>
          <ChevronRightIcon className="ml-auto transition-transform duration-200 group-data-[collapsible=icon]:hidden group-data-open/collapsible:rotate-90" />
        </SidebarGroupLabel>

        <CollapsibleContent>
          <SidebarGroupContent>
            <SidebarMenu>
              {group.items.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    tooltip={item.title}
                    isActive={isActivePath(pathname, item.href)}
                    render={<a href={item.href} />}
                  >
                    <span className="truncate">{item.title}</span>
                  </SidebarMenuButton>
                  {item.badge ? (
                    <SidebarMenuBadge className="text-[10px] font-normal tracking-wide text-sidebar-foreground/60 uppercase">
                      {item.badge}
                    </SidebarMenuBadge>
                  ) : null}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </CollapsibleContent>
      </SidebarGroup>
    </Collapsible>
  )
}
