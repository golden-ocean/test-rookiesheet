"use client"

import * as React from "react"
import { GitBranchIcon } from "lucide-react"
import { cn } from "cn"

import { DocsSearch } from "@/components/docs-search"
import { ModeToggle } from "@/components/mode-toggle"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { siteConfig, topNav } from "@/config/docs"
import { getBreadcrumbTrail, isActivePath } from "@/lib/nav"

type SiteHeaderProps = {
  pathname: string
}

export function SiteHeader({ pathname }: SiteHeaderProps) {
  const trail = getBreadcrumbTrail(pathname)

  return (
    <header className="sticky top-0 z-30 flex h-14 w-full items-center gap-1 border-b bg-background/85 px-3 backdrop-blur-md md:px-4">
      <SidebarTrigger className="-ml-1" />
      <Separator orientation="vertical" className="mr-1 hidden h-4 sm:block" />

      <Breadcrumb className="hidden sm:block">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink render={<a href="/" />}>
              {siteConfig.shortName}
            </BreadcrumbLink>
          </BreadcrumbItem>
          {trail.map((item, index) => (
            <React.Fragment key={`${item.href}-${item.title}`}>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                {index === trail.length - 1 ? (
                  <BreadcrumbPage>{item.title}</BreadcrumbPage>
                ) : (
                  <BreadcrumbLink render={<a href={item.href} />}>
                    {item.title}
                  </BreadcrumbLink>
                )}
              </BreadcrumbItem>
            </React.Fragment>
          ))}
        </BreadcrumbList>
      </Breadcrumb>

      <nav className="ml-auto hidden items-center gap-1 lg:flex">
        {topNav.map((item) => (
          <Button
            key={item.href}
            variant="ghost"
            size="sm"
            className={cn(
              "text-muted-foreground",
              isActivePath(pathname, item.href) && "text-foreground"
            )}
            render={<a href={item.href} />}
          >
            {item.title}
          </Button>
        ))}
      </nav>

      <div className={cn("flex items-center gap-1", "ml-auto lg:ml-2")}>
        <DocsSearch className="hidden w-44 justify-start md:inline-flex lg:w-56" />
        <Button
          variant="ghost"
          size="icon"
          className="size-8 rounded-md"
          render={
            <a
              href={siteConfig.repo}
              target="_blank"
              rel="noreferrer noopener"
              aria-label="打开项目仓库"
            />
          }
        >
          <GitBranchIcon />
        </Button>
        <ModeToggle />
      </div>
    </header>
  )
}
