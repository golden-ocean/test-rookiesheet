import { ChevronLeftIcon, ChevronRightIcon } from "lucide-react"
import { cn } from "cn"

import type { NavItem } from "@/config/docs"
import { getAdjacentDocs } from "@/lib/nav"

type DocsPagerProps = {
  /** 当前页路径，用于计算上下篇。 */
  href: string
}

/** 正文底部的上一篇 / 下一篇导航，顺序依据 src/config/docs.ts。 */
export function DocsPager({ href }: DocsPagerProps) {
  const { prev, next } = getAdjacentDocs(href)

  if (!prev && !next) {
    return null
  }

  return (
    <nav className="mt-14 grid gap-3 border-t pt-6 sm:grid-cols-2">
      {prev ? (
        <PagerLink item={prev} direction="prev" />
      ) : (
        <span className="hidden sm:block" />
      )}
      {next ? <PagerLink item={next} direction="next" /> : null}
    </nav>
  )
}

function PagerLink({
  item,
  direction,
}: {
  item: NavItem
  direction: "prev" | "next"
}) {
  const isPrev = direction === "prev"

  return (
    <a
      href={item.href}
      className={cn(
        "group flex flex-col gap-1 rounded-xl border bg-card px-4 py-3 transition-colors hover:border-foreground/20 hover:bg-accent/40",
        isPrev ? "items-start" : "items-end sm:col-start-2"
      )}
    >
      <span className="flex items-center gap-1 text-xs text-muted-foreground">
        {isPrev ? <ChevronLeftIcon className="size-3.5" /> : null}
        {isPrev ? "上一篇" : "下一篇"}
        {isPrev ? null : <ChevronRightIcon className="size-3.5" />}
      </span>
      <span className="text-sm font-medium group-hover:text-foreground">
        {item.title}
      </span>
    </a>
  )
}
