"use client"

import * as React from "react"
import { FileTextIcon, SearchIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command"
import { Kbd } from "@/components/ui/kbd"
import { docsNav, externalNav } from "@/config/docs"

/**
 * 文档搜索：基于静态导航数据的轻量命令面板（⌘K / Ctrl+K）。
 * 内容全部来自 src/config/docs.ts，因此不需要额外的索引构建步骤。
 */
export function DocsSearch({ className }: { className?: string }) {
  const [open, setOpen] = React.useState(false)

  React.useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault()
        setOpen((current) => !current)
      }
    }

    document.addEventListener("keydown", onKeyDown)
    return () => document.removeEventListener("keydown", onKeyDown)
  }, [])

  const navigate = (href: string) => {
    setOpen(false)
    window.location.assign(href)
  }

  return (
    <>
      <Button
        type="button"
        variant="outline"
        onClick={() => setOpen(true)}
        className={className}
      >
        <SearchIcon />
        <span className="text-muted-foreground">搜索文档…</span>
        <Kbd className="ml-auto hidden md:inline-flex">⌘K</Kbd>
      </Button>

      <CommandDialog
        open={open}
        onOpenChange={setOpen}
        title="搜索文档"
        description="在所有章节中按标题检索"
      >
        <CommandInput placeholder="输入文档标题…" />
        <CommandList>
          <CommandEmpty>没有找到匹配的页面。</CommandEmpty>

          {docsNav.map((group) => (
            <CommandGroup key={group.title} heading={group.title}>
              {group.items.map((item) => (
                <CommandItem
                  key={item.href}
                  value={`${group.title} ${item.title} ${item.href}`}
                  onSelect={() => navigate(item.href)}
                >
                  <FileTextIcon />
                  <span>{item.title}</span>
                  {item.badge ? (
                    <CommandShortcut>{item.badge}</CommandShortcut>
                  ) : (
                    <CommandShortcut className="text-muted-foreground/70">
                      {item.href.replace("/docs/", "")}
                    </CommandShortcut>
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
          ))}

          <CommandSeparator />

          <CommandGroup heading="外部链接">
            {externalNav.map((item) => (
              <CommandItem
                key={item.href}
                value={`${item.title} ${item.href}`}
                onSelect={() => window.open(item.href, "_blank")}
              >
                <item.icon />
                <span>{item.title}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  )
}
