import { Callout } from "./callout"
import { Step, Steps } from "./steps"

export { Callout, Step, Steps }

/**
 * 传给 <Content components={…} /> 的组件表。
 * MDX 文件中无需 import 即可直接使用 <Callout />、<Steps />、<Step />。
 */
export const mdxComponents = {
  Callout,
  Steps,
  Step,
}
