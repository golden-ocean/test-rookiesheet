import * as React from "react"
import {
  CircleAlertIcon,
  InfoIcon,
  LightbulbIcon,
  TriangleAlertIcon,
  type LucideIcon,
} from "lucide-react"
import { cn } from "cn"

type CalloutType = "note" | "tip" | "warning" | "danger"

const presets: Record<
  CalloutType,
  { icon: LucideIcon; container: string; iconColor: string }
> = {
  note: {
    icon: InfoIcon,
    container: "border-border bg-muted/40",
    iconColor: "text-muted-foreground",
  },
  tip: {
    icon: LightbulbIcon,
    container: "border-primary/20 bg-primary/5",
    iconColor: "text-primary",
  },
  warning: {
    icon: TriangleAlertIcon,
    container: "border-amber-500/30 bg-amber-500/10",
    iconColor: "text-amber-600 dark:text-amber-400",
  },
  danger: {
    icon: CircleAlertIcon,
    container: "border-destructive/30 bg-destructive/10",
    iconColor: "text-destructive",
  },
}

export type CalloutProps = {
  type?: CalloutType
  title?: string
  children: React.ReactNode
}

/** MDX 里的提示块：<Callout type="tip">…</Callout> */
export function Callout({ type = "note", title, children }: CalloutProps) {
  const preset = presets[type]
  const Icon = preset.icon

  return (
    <div
      className={cn(
        "not-prose my-6 flex gap-3 rounded-xl border px-4 py-3 text-sm",
        preset.container
      )}
    >
      <Icon className={cn("mt-0.5 size-4 shrink-0", preset.iconColor)} />
      <div className="min-w-0 flex-1 space-y-1">
        {title ? (
          <p className="text-sm font-medium text-foreground">{title}</p>
        ) : null}
        <div className="space-y-2 text-sm text-muted-foreground [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
          {children}
        </div>
      </div>
    </div>
  )
}
