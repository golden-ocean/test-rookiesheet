import * as React from "react"
import { cn } from "cn"

export type StepsProps = {
  children: React.ReactNode
  className?: string
}

/** MDX 步骤容器：<Steps><Step>…</Step></Steps> */
export function Steps({ children, className }: StepsProps) {
  return (
    <ol
      className={cn(
        "not-prose relative my-6 ml-1 border-l border-border pl-8 [counter-reset:step]",
        className
      )}
    >
      {children}
    </ol>
  )
}

export type StepProps = {
  /** 步骤标题，展示在序号右侧。 */
  title?: string
  children?: React.ReactNode
}

export function Step({ title, children }: StepProps) {
  return (
    <li className="relative pb-6 [counter-increment:step] before:absolute before:-top-1 before:left-[-2rem] before:flex before:size-7 before:-translate-x-1/2 before:items-center before:justify-center before:rounded-full before:border before:border-border before:bg-background before:text-xs before:font-semibold before:tabular-nums before:content-[counter(step)] last:pb-0">
      {title ? (
        <p className="pt-0.5 text-sm font-medium text-foreground">{title}</p>
      ) : null}
      <div className="space-y-2 pt-1 text-sm text-muted-foreground [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
        {children}
      </div>
    </li>
  )
}
