"use client"

import * as React from "react"
/*
 * 这里刻意放宽两条 hook 规则：主题状态需要在挂载后读取 localStorage
 * （SSR 阶段读不到，否则会 hydration 不一致），并在回调里直接操作
 * <html> 元素的 class 与 data 属性 —— 这是避免首屏闪白的唯一可靠做法。
 */
/* eslint-disable react-hooks/set-state-in-effect, react-hooks/immutability -- 见上方说明 */

import { CheckIcon, MonitorIcon, MoonIcon, SunIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export type ThemePreference = "light" | "dark" | "system"

const STORAGE_KEY = "theme"

const OPTIONS: {
  value: ThemePreference
  label: string
  icon: typeof SunIcon
}[] = [
  { value: "light", label: "浅色", icon: SunIcon },
  { value: "dark", label: "深色", icon: MoonIcon },
  { value: "system", label: "跟随系统", icon: MonitorIcon },
]

function resolveTheme(preference: ThemePreference): "light" | "dark" {
  if (preference !== "system") return preference

  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light"
}

export function ModeToggle() {
  const [preference, setPreference] = React.useState<ThemePreference>("system")

  // 首屏样式由 root layout 里的内联脚本处理，这里只负责同步 UI 状态。
  // 故意放在 effect 里读取 localStorage：服务端渲染拿不到存储值，
  // 若在 useState 初始化阶段读取会导致 hydration 不一致。
  React.useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored === "light" || stored === "dark" || stored === "system") {
      setPreference(stored)
    }
  }, [])

  // 跟随系统时需要监听系统主题变化
  React.useEffect(() => {
    if (preference !== "system") return

    const query = window.matchMedia("(prefers-color-scheme: dark)")
    const sync = () =>
      document.documentElement.classList.toggle("dark", query.matches)

    query.addEventListener("change", sync)
    return () => query.removeEventListener("change", sync)
  }, [preference])

  const applyTheme = (next: ThemePreference) => {
    setPreference(next)
    localStorage.setItem(STORAGE_KEY, next)
    const resolved = resolveTheme(next)
    document.documentElement.classList.toggle("dark", resolved === "dark")
    document.documentElement.dataset.theme = resolved
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        render={
          <Button variant="ghost" size="icon" className="size-8 rounded-md" />
        }
      >
        <SunIcon className="size-4 scale-100 rotate-0 transition-transform duration-300 dark:scale-0 dark:-rotate-90" />
        <MoonIcon className="absolute size-4 scale-0 rotate-90 transition-transform duration-300 dark:scale-100 dark:rotate-0" />
        <span className="sr-only">切换主题</span>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="min-w-36">
        <DropdownMenuLabel>外观</DropdownMenuLabel>
        {OPTIONS.map((option) => {
          const Icon = option.icon
          return (
            <DropdownMenuItem
              key={option.value}
              onClick={() => applyTheme(option.value)}
              className="justify-between"
            >
              <span className="flex items-center gap-1.5">
                <Icon />
                {option.label}
              </span>
              {preference === option.value ? (
                <CheckIcon className="text-muted-foreground" />
              ) : null}
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
