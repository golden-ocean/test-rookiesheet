"use client"

import * as React from "react"
import { cn } from "cn"

import type { TocEntry } from "@/lib/nav"

type TableOfContentsProps = {
  toc: TocEntry[]
}

/**
 * 右侧目录：基于 IntersectionObserver 做滚动跟随高亮。
 * 只依赖 href 锚点，服务端渲染时内容已经完整输出，刷新/深链也能定位。
 */
export function TableOfContents({ toc }: TableOfContentsProps) {
  const [activeSlug, setActiveSlug] = React.useState<string | undefined>(
    toc[0]?.slug
  )

  React.useEffect(() => {
    if (toc.length === 0) return

    const targets = toc
      .map((entry) => document.getElementById(entry.slug))
      .filter((element): element is HTMLElement => element !== null)

    if (targets.length === 0) return

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)

        if (visible[0]) {
          setActiveSlug(visible[0].target.id)
        }
      },
      {
        // 顶部留出 sticky header 的高度，底部留出足够辨识区间
        rootMargin: "-88px 0px -65% 0px",
        threshold: [0, 1],
      }
    )

    targets.forEach((target) => observer.observe(target))
    return () => observer.disconnect()
  }, [toc])

  if (toc.length === 0) {
    return null
  }

  return (
    <div className="space-y-3">
      <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
        本页目录
      </p>

      <nav aria-label="页面目录">
        <ul className="grid gap-1 border-l border-border">
          {toc.map((entry) => (
            <li key={entry.slug}>
              <a
                href={`#${entry.slug}`}
                aria-current={activeSlug === entry.slug ? "true" : undefined}
                className={cn(
                  "-ml-px block border-l-2 border-transparent py-1 text-sm leading-snug text-muted-foreground transition-colors hover:text-foreground",
                  entry.depth === 3 ? "pl-6 text-[0.8125rem]" : "pl-3",
                  activeSlug === entry.slug &&
                    "border-foreground font-medium text-foreground"
                )}
              >
                {entry.text}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  )
}
