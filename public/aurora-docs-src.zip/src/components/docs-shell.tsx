"use client"

import * as React from "react"

import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import { TableOfContents } from "@/components/table-of-contents"
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar"
import type { TocEntry } from "@/lib/nav"

type DocsShellProps = {
  /** 当前页路径，用于侧边栏高亮与面包屑。 */
  pathname: string
  /** 当前页 h2/h3 标题集合。 */
  toc: TocEntry[]
  /** Astro slot：MDX 正文内容。 */
  children: React.ReactNode
}

/**
 * 三栏外壳。
 * Sidebar 依赖 React Context（折叠状态），因此 Provider、Sidebar 与 Trigger
 * 必须处在同一棵 React 树里 —— 在 Astro 中意味着要用一个 island 包住它们，
 * 正文通过 children（Astro slot）静态注入，避免整页都参与 hydrate。
 */
export function DocsShell({ pathname, toc, children }: DocsShellProps) {
  return (
    <SidebarProvider defaultOpen>
      <AppSidebar pathname={pathname} />

      <SidebarInset className="min-w-0 flex-col overflow-x-hidden">
        <SiteHeader pathname={pathname} />

        <main id="content" className="flex-1">
          <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-10 md:px-6 lg:grid-cols-[minmax(0,1fr)_15rem] lg:gap-12 xl:max-w-7xl">
            <div className="min-w-0">
              <article className="mx-auto w-full max-w-3xl">{children}</article>
            </div>

            <aside className="hidden lg:block">
              <div className="sticky top-20 max-h-[calc(100svh-7rem)] overflow-y-auto pb-10">
                <TableOfContents toc={toc} />
              </div>
            </aside>
          </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
