import { defineCollection, z } from "astro:content"
import { glob } from "astro/loaders"

/**
 * docs 集合：src/content/docs 下所有 md/mdx 文件。
 * 每个文件的 slug 由文件路径决定（不含扩展名），例如
 * src/content/docs/guides/theming.mdx -> guides/theming
 */
const docs = defineCollection({
  loader: glob({ pattern: "**/*.{md,mdx}", base: "./src/content/docs" }),
  schema: z.object({
    title: z.string(),
    description: z.string().default(""),
    /** 侧边栏分组里的排序权重，越小越靠前。 */
    order: z.number().default(999),
    /** 导航项右上角的小徽标，如 Beta / New。 */
    badge: z.string().optional(),
    /** 更新日期，展示在正文底部。 */
    updated: z.coerce.date().optional(),
    /** 草稿不会构建出页面。 */
    draft: z.boolean().default(false),
  }),
})

export const collections = { docs }
