import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PagerProps {
  prev?: { title: string; href: string };
  next?: { title: string; href: string };
  t: (key: any) => string;
}

/** 上一篇 / 下一篇 */
export function Pager({ prev, next, t }: PagerProps) {
  if (!prev && !next) return null;

  return (
    <nav aria-label="pager" className="mt-12 flex items-stretch justify-between gap-4 border-t border-border pt-8">
      {prev ? (
        <Button asChild variant="outline" className="h-auto min-w-44 flex-col items-start gap-0.5 px-4 py-3 text-left">
          <a href={prev.href}>
            <span className="flex items-center text-xs text-muted-foreground">
              <ChevronLeft className="size-3.5" /> {t("doc.prev")}
            </span>
            <span className="text-sm font-medium text-foreground">{prev.title}</span>
          </a>
        </Button>
      ) : (
        <span />
      )}

      {next ? (
        <Button asChild variant="outline" className="h-auto min-w-44 flex-col items-end gap-0.5 px-4 py-3 text-right">
          <a href={next.href}>
            <span className="flex items-center text-xs text-muted-foreground">
              {t("doc.next")} <ChevronRight className="size-3.5" />
            </span>
            <span className="text-sm font-medium text-foreground">{next.title}</span>
          </a>
        </Button>
      ) : (
        <span />
      )}
    </nav>
  );
}

export default Pager;
