import { Search } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import type { Lang } from "@/i18n/ui";

interface HeaderProps {
  /** 当前界面语言 */
  lang: Lang;
  /** 已翻译的 UI 文案 */
  t: (key: any) => string;
  /** 当前所在编程语言（用于语言标签高亮） */
  currentLang?: string;
  /** 首页 / 文档页高亮 */
  active?: "home" | "docs";
  /** 语言标签项 */
  languages?: { key: string; label: string; href: string }[];
  /** 切换界面语言时的目标地址 */
  alternatePath?: string;
}

export function Header({ lang, t, currentLang, active = "docs", languages = [], alternatePath }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center gap-4 px-6">
        <a href={lang === "zh" ? "/" : `/${lang}/`} className="flex items-center gap-2 font-bold">
          <span className="grid size-7 place-items-center rounded-lg bg-primary font-mono text-[11px] text-primary-foreground">
            {"</>"}
          </span>
          {t("site.name")}
        </a>

        <nav className="ml-6 hidden items-center gap-5 text-sm text-muted-foreground md:flex">
          <a
            href={lang === "zh" ? "/" : `/${lang}/`}
            className={active === "home" ? "font-medium text-foreground" : "transition-colors hover:text-foreground"}
          >
            {t("nav.home")}
          </a>
          <a
            href={lang === "zh" ? "/docs/python/quick-start/" : `/${lang}/docs/python/quick-start/`}
            className={active === "docs" ? "font-medium text-foreground" : "transition-colors hover:text-foreground"}
          >
            {t("nav.docs")}
          </a>
          <a href="#" className="transition-colors hover:text-foreground">{t("nav.practice")}</a>
          <a href="#" className="transition-colors hover:text-foreground">{t("nav.community")}</a>
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <div className="hidden items-center justify-between gap-6 rounded-lg border border-border px-3 py-1.5 text-[13px] text-muted-foreground sm:flex">
            <span className="flex items-center gap-1.5">
              <Search className="size-3.5" />
              {t("nav.search")}
            </span>
            <kbd className="rounded border border-border px-1.5 font-sans text-[11px]">⌘K</kbd>
          </div>
          <LanguageSwitcher lang={lang} alternatePath={alternatePath} />
          <ThemeToggle t={t} />
        </div>
      </div>

      {/* 语言标签栏 */}
      {languages.length > 0 && (
        <div className="hidden border-t border-border/60 bg-muted/30 md:block">
          <div className="mx-auto flex max-w-[1400px] items-center gap-2 overflow-x-auto px-6 py-2">
            {languages.map((l) => (
              <a
                key={l.key}
                href={l.href}
                className={
                  "shrink-0 rounded-full border px-3 py-0.5 text-xs transition-colors " +
                  (l.key === currentLang
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:bg-background hover:text-foreground")
                }
              >
                {l.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

export default Header;
