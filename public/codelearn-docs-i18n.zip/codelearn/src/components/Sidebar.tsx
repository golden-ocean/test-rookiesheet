/**
 * 左侧栏：按 section 分组（入门 / 核心概念 / 进阶），与 plan-a 预览一致
 */
export interface SidebarGroup {
  title: string;
  items: { title: string; href: string; isActive?: boolean }[];
}

interface SidebarProps {
  /** 顶部语言名称，如「Python 教程」 */
  heading: string;
  groups: SidebarGroup[];
  /** 已翻译文案 */
  t: (key: any) => string;
}

export function Sidebar({ heading, groups, t }: SidebarProps) {
  return (
    <aside className="hidden w-[250px] shrink-0 md:block">
      <div className="sticky top-[7.5rem] max-h-[calc(100vh-9rem)] overflow-y-auto pb-8 pr-2">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t("sidebar.label")}
        </p>
        <a
          href="#"
          className="mb-3 block text-sm font-semibold text-foreground hover:underline"
        >
          {heading}
        </a>
        {groups.map((group) => (
          <div key={group.title} className="mt-5 first:mt-0">
            <h4 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {group.title}
            </h4>
            <nav className="space-y-0.5">
              {group.items.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  aria-current={item.isActive ? "page" : undefined}
                  className={
                    "block rounded-md px-2.5 py-[5px] text-sm transition-colors " +
                    (item.isActive
                      ? "bg-muted font-medium text-foreground"
                      : "text-muted-foreground hover:text-foreground")
                  }
                >
                  {item.title}
                </a>
              ))}
            </nav>
          </div>
        ))}
      </div>
    </aside>
  );
}

export default Sidebar;
