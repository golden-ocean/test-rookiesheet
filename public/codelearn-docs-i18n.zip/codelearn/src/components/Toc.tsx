export interface TocItem {
  depth: number;
  slug: string;
  text: string;
}

interface TocProps {
  headings: TocItem[];
  /** 已翻译文案（doc.toc） */
  t: (key: any) => string;
}

/** 右侧目录：h2 为主，h3 缩进（与 plan-a 预览一致） */
export function Toc({ headings, t }: TocProps) {
  const items = headings.filter((h) => h.depth <= 3);
  if (items.length === 0) return null;

  return (
    <nav className="hidden w-[220px] shrink-0 xl:block" aria-label={t("doc.toc")}>
      <div className="sticky top-[7.5rem] max-h-[calc(100vh-9rem)] overflow-y-auto pb-8">
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {t("doc.toc")}
        </p>
        <div className="border-l border-border">
          {items.map((h, i) => (
            <a
              key={h.slug}
              href={`#${h.slug}`}
              data-toc-link
              className={
                "block border-l-2 border-transparent py-1 text-[13px] leading-6 text-muted-foreground transition-colors hover:text-foreground " +
                (h.depth === 2 ? "pl-3.5" : "pl-7")
              }
              style={i === 0 ? { borderLeftColor: "var(--border)" } : undefined}
            >
              {h.text}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}

export default Toc;
