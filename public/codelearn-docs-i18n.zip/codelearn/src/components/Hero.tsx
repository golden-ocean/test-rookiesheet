interface HeroProps {
  /** 主标题（已翻译） */
  title: string;
  /** 主标题高亮部分 */
  highlight: string;
  /** 副标题 */
  subtitle: string;
  /** 语言胶囊标签 */
  langs: { key: string; label: string; href: string; emoji?: string }[];
  activeLang?: string;
}

/** plan-a 顶部 Hero：居中大标题 + 语言胶囊标签 */
export function Hero({ title, highlight, subtitle, langs, activeLang }: HeroProps) {
  return (
    <section className="border-b border-border bg-gradient-to-b from-muted/70 to-background">
      <div className="mx-auto max-w-[1400px] px-6 py-14 text-center">
        <h1 className="text-3xl font-extrabold tracking-tight md:text-[2.6rem] md:leading-tight">
          {title}
          <span className="text-primary">{highlight}</span>
        </h1>
        <p className="mt-3 text-base text-muted-foreground">{subtitle}</p>
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          {langs.map((l) => (
            <a
              key={l.key}
              href={l.href}
              className={
                "rounded-full border px-3.5 py-1 text-[13px] transition-colors " +
                (l.key === activeLang
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-foreground hover:bg-muted")
              }
            >
              {l.emoji && <span className="mr-1">{l.emoji}</span>}
              {l.label}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Hero;
