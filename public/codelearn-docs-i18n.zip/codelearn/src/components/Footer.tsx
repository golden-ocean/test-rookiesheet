interface FooterProps {
  t: (key: any) => string;
}

export function Footer({ t }: FooterProps) {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto max-w-[1400px] px-6 py-6 text-center text-[13px] text-muted-foreground">
        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
          <span>{t("site.name")} · {t("footer.tagline")}</span>
          <span className="hidden sm:inline">© 2026</span>
          <a href="#" className="hover:text-foreground">{t("footer.about")}</a>
          <a href="#" className="hover:text-foreground">{t("footer.github")}</a>
          <a href="#" className="hover:text-foreground">{t("footer.rss")}</a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
