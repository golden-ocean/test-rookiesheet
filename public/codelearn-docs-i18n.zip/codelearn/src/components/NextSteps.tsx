import { ArrowRight } from "lucide-react";

export interface NextCard {
  title: string;
  desc?: string;
  href: string;
}

interface NextStepsProps {
  title: string;
  cards: NextCard[];
}

/** 文末「下一步」卡片，对应 plan-a 的 cardrow */
export function NextSteps({ title, cards }: NextStepsProps) {
  if (cards.length === 0) return null;

  return (
    <div className="mt-8 not-prose">
      <h2 id="next-steps" className="mb-3 scroll-mt-24 text-xl font-bold">
        {title}
      </h2>
      <div className="grid gap-3 sm:grid-cols-2">
        {cards.map((c) => (
          <a
            key={c.href}
            href={c.href}
            className="group rounded-lg border border-border p-3.5 text-[13px] transition-colors hover:bg-muted/50"
          >
            <span className="flex items-center justify-between">
              <b className="text-foreground">{c.title}</b>
              <ArrowRight className="size-3.5 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
            </span>
            {c.desc && <span className="mt-0.5 block text-muted-foreground">{c.desc}</span>}
          </a>
        ))}
      </div>
    </div>
  );
}

export default NextSteps;
