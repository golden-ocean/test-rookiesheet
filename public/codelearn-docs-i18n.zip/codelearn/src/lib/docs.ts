/**
 * 文档站数据查询工具
 * 内容集合结构（参考 Astro 官方 i18n recipe）：
 *   src/content/docs/<lang>/<programming-language>/<slug>.md
 *   src/content/languages/<lang>/<programming-language>.md
 */
import { getCollection, type CollectionEntry } from "astro:content";
import { defaultLang, languageList, type Lang } from "@/i18n/ui";
import type { SidebarGroup } from "@/components/Sidebar";

export type DocEntry = CollectionEntry<"docs">;
export type LangEntry = CollectionEntry<"languages">;

const isLang = (s: string): s is Lang => s in { zh: 1, en: 1 };

/** 解析 entry id：<lang>/<language>/<slug> */
export function parseDocId(id: string) {
  const [lang, language, ...rest] = id.split("/");
  return { lang: isLang(lang) ? lang : defaultLang, language, slug: rest.join("/") };
}

/** 解析 languages entry id：<lang>/<language> */
export function parseLangId(id: string) {
  const [lang, language] = id.split("/");
  return { lang: isLang(lang) ? lang : defaultLang, language };
}

export interface LanguageMeta {
  key: string;
  name: string;
  emoji: string;
  color: string;
  description: string;
  order: number;
  hot: boolean;
}

/** 某界面语言下所有编程语言的元信息（按 order 排序） */
export async function getLanguages(lang: Lang): Promise<LanguageMeta[]> {
  const entries = await getCollection("languages");
  return entries
    .map((e) => ({ entry: e, meta: parseLangId(e.id) }))
    .filter((x) => x.meta.lang === lang)
    .map(({ entry, meta }) => ({
      key: meta.language,
      name: entry.data.name,
      emoji: entry.data.emoji,
      color: entry.data.color,
      description: entry.data.description,
      order: entry.data.order,
      hot: entry.data.hot,
    }))
    .sort((a, b) => a.order - b.order);
}

/** 某界面语言的文档 */
export async function getDocs(lang: Lang): Promise<DocEntry[]> {
  const all = await getCollection("docs", ({ data }) => !data.draft);
  return all.filter((d) => parseDocId(d.id).lang === lang);
}

export interface DocLinkItem {
  title: string;
  href: string;
  isActive?: boolean;
}

export interface DocContext {
  entry: DocEntry;
  languageName: string;
  sidebarGroups: SidebarGroup[];
  prev?: { title: string; href: string };
  next?: { title: string; href: string };
  nextStepCards: { title: string; href: string; desc?: string }[];
  alternatePath?: string;
  langTabs: { key: string; label: string; href: string; emoji?: string }[];
}

const SECTION_ORDER = ["入门", "核心概念", "进阶", "Getting started", "Core concepts", "Advanced"];

/** 构建文档页所需全部上下文：侧边栏分组、上下篇、下一步卡片、语言切换链接 */
export function buildDocContext(
  entry: DocEntry,
  docsOfLang: DocEntry[],
  languages: LanguageMeta[],
  routePrefix = ""
): DocContext {
  const { language, slug } = parseDocId(entry.id);
  const languagesOfSite = languages.map((l) => ({
    key: l.key,
    label: l.name,
    emoji: l.emoji,
    href: `${routePrefix}/docs/${l.key}/introduction/`,
  }));

  const languageName = languages.find((l) => l.key === language)?.name ?? language;

  // 侧边栏：只显示当前编程语言的分组
  const current = docsOfLang
    .filter((d) => d.data.language === language)
    .sort((a, b) => {
      const sa = SECTION_ORDER.indexOf(a.data.section);
      const sb = SECTION_ORDER.indexOf(b.data.section);
      return (sa === -1 ? 99 : sa) - (sb === -1 ? 99 : sb) || a.data.order - b.data.order;
    });

  const groupMap = new Map<string, DocLinkItem[]>();
  for (const doc of current) {
    const key = doc.data.section;
    if (!groupMap.has(key)) groupMap.set(key, []);
    groupMap.get(key)!.push({
      title: doc.data.title,
      href: `${routePrefix}/docs/${doc.data.language}/${parseDocId(doc.id).slug}/`,
      isActive: doc.id === entry.id,
    });
  }
  const sidebarGroups: SidebarGroup[] = [...groupMap.entries()].map(([title, items]) => ({
    title,
    items,
  }));

  // 上下篇（同一编程语言内，按章节顺序）
  const idx = current.findIndex((d) => d.id === entry.id);
  const link = (d: DocEntry) => ({
    title: d.data.title,
    href: `${routePrefix}/docs/${d.data.language}/${parseDocId(d.id).slug}/`,
  });
  const prev = idx > 0 ? link(current[idx - 1]) : undefined;
  const next = idx >= 0 && idx < current.length - 1 ? link(current[idx + 1]) : undefined;

  // 文末「下一步」卡片：取后两篇
  const nextStepCards = current
    .slice(idx + 1, idx + 3)
    .map((d) => ({ ...link(d), desc: d.data.description }));

  // 另一界面语言的对应页面
  const other = languageList.find((l) => l.code !== parseDocId(entry.id).lang);
  const alternatePath =
    other && other.code !== defaultLang
      ? `/${other.code}/docs/${language}/${slug}/`
      : `/docs/${language}/${slug}/`;

  return {
    entry,
    languageName,
    sidebarGroups,
    prev,
    next,
    nextStepCards,
    alternatePath,
    langTabs: languagesOfSite,
  };
}
