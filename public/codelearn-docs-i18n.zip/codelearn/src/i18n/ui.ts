/**
 * i18n 字典 —— 参考 Astro 官方 i18n recipe：src/i18n/ui.ts
 * key 均为 astro/ui 中定义的站点 UI 文案，首次出现未翻译时自动回退默认语言。
 */
export const languages = {
  zh: "简体中文",
  en: "English",
} as const;

export type Lang = keyof typeof languages;

export const defaultLang: Lang = "zh";

/** 展示在 Header 语言切换器中的语言 */
export const languageList = [
  { code: "zh", short: "中文", label: "简体中文" },
  { code: "en", short: "EN", label: "English" },
] as const;

export const ui = {
  zh: {
    "site.name": "CodeLearn",
    "site.tagline": "学习编程语言，从文档开始",
    "site.description": "结构化教程 · 可运行示例 · 循序渐进",

    "nav.home": "首页",
    "nav.docs": "文档",
    "nav.practice": "练习",
    "nav.community": "社区",
    "nav.search": "搜索文档…",

    "sidebar.label": "目录",
    "sidebar.back": "返回首页",

    "doc.toc": "本页目录",
    "doc.updated": "更新于",
    "doc.minutes": "预计阅读 {n} 分钟",
    "doc.prev": "上一篇",
    "doc.next": "下一篇",
    "doc.notice": "提示",
    "doc.nextStep": "下一步",
    "doc.onThisPage": "本页目录",

    "home.hero.tags": "热门语言",
    "home.langs.title": "选择一门语言",
    "home.langs.desc": "每门语言都有从入门到进阶的完整文档",
    "home.langs.count": "{n} 篇文档",
    "home.langs.minutes": "约 {n} 分钟",
    "home.langs.enter": "进入教程",
    "home.start": "开始学习",
    "home.browse": "浏览语言",

    "footer.tagline": "基于 Astro + shadcn/ui 构建",
    "footer.about": "关于",
    "footer.github": "GitHub",
    "footer.rss": "RSS",

    "theme.toggle": "切换主题",
    "theme.light": "浅色",
    "theme.dark": "深色",
    "theme.system": "跟随系统",
  },
  en: {
    "site.name": "CodeLearn",
    "site.tagline": "Learn a language, starting from the docs",
    "site.description": "Structured tutorials · Runnable examples · Step by step",

    "nav.home": "Home",
    "nav.docs": "Docs",
    "nav.practice": "Practice",
    "nav.community": "Community",
    "nav.search": "Search docs…",

    "sidebar.label": "Contents",
    "sidebar.back": "Back home",

    "doc.toc": "On this page",
    "doc.updated": "Updated",
    "doc.minutes": "{n} min read",
    "doc.prev": "Previous",
    "doc.next": "Next",
    "doc.notice": "Note",
    "doc.nextStep": "Next steps",
    "doc.onThisPage": "On this page",

    "home.hero.tags": "Popular",
    "home.langs.title": "Pick a language",
    "home.langs.desc": "Every language ships with a complete guide",
    "home.langs.count": "{n} docs",
    "home.langs.minutes": "~{n} min",
    "home.langs.enter": "Start reading",
    "home.start": "Get started",
    "home.browse": "Browse languages",

    "footer.tagline": "Built with Astro + shadcn/ui",
    "footer.about": "About",
    "footer.github": "GitHub",
    "footer.rss": "RSS",

    "theme.toggle": "Toggle theme",
    "theme.light": "Light",
    "theme.dark": "Dark",
    "theme.system": "System",
  },
} as const;

export type UIKey = keyof (typeof ui)[typeof defaultLang];
