---
title: 快速开始
description: 示例文档
group: 开始
order: 1
---

这是一篇示例文档，用来检验**排版、代码高亮、目录联动**。

## 为什么记笔记

好的笔记应当 *易读、易记、易复习*。

> 把知识讲给未来的自己听。

### 一个小清单

- 先写结论
- 再写例子
- 最后写题目

## 代码示例

```ts
export function add(a: number, b: number): number {
  return a + b;
}
```

行内代码如 `bun run dev`，表格如下：

| 命令 | 作用 |
| --- | --- |
| `bun run dev` | 启动开发服务器 |
| `bun run build` | 构建站点 |

## 小结

左侧导航与右侧目录都固定在视口内，只有正文滚动。
