# 使用方法

```bash
bunx --bun shadcn@latest init --preset b0 --base aria --template astro
cd <项目目录>
bun add @tailwindcss/typography
# 然后把本压缩包里的 src/ 合并进项目；再替换 astro.config.mjs 里的 markdown 配置：
```

astro.config.mjs 中加入：

```js
export default defineConfig({
  // ...shadcn 模板已有配置保持不变
  markdown: {
    shikiConfig: {
      themes: { light: "github-light", dark: "github-dark" },
      defaultColor: false,
    },
  },
});
```

然后 `bun run dev`。
