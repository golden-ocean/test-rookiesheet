/** 从文章 h2/h3 自动生成右栏目录，并做滚动高亮 */
const article = document.querySelector<HTMLElement>('[data-toc-root]');
const nav = document.querySelector<HTMLElement>('[data-toc]');

if (article && nav) {
  const heads = Array.from(article.querySelectorAll<HTMLHeadingElement>('h2, h3')).filter(
    (h) => h.id,
  );

  if (!heads.length) {
    nav.innerHTML = '<p class="px-2 py-3 text-xs opacity-40">本节无小标题</p>';
  } else {
    nav.innerHTML = `
      <ul class="space-y-0.5">
        ${heads
          .map(
            (h) => `
          <li>
            <a href="#${h.id}" class="relative block truncate rounded px-2 py-1 hover:bg-base-200 ${
              h.tagName === 'H3' ? 'pl-5 opacity-75' : 'font-medium'
            }" data-toc-link="${h.id}">${h.textContent?.replace('#', '') ?? ''}</a>
          </li>`,
          )
          .join('')}
      </ul>`;

    const links = new Map<string, HTMLAnchorElement>();
    nav.querySelectorAll<HTMLAnchorElement>('[data-toc-link]').forEach((a) => {
      links.set(a.dataset.tocLink!, a);
    });

    const visible = new Set<string>();
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) visible.add(e.target.id);
          else visible.delete(e.target.id);
        }
        const current = heads.find((h) => visible.has(h.id)) ?? heads[0];
        links.forEach((a, id) => a.classList.toggle('active', id === current?.id));
      },
      { rootMargin: '-72px 0px -68% 0px', threshold: 0 },
    );
    heads.forEach((h) => observer.observe(h));
  }
}
