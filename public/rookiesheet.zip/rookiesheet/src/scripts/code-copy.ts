/** 给每个 Shiki 代码块加「复制」按钮 */
document.querySelectorAll<HTMLPreElement>('pre.astro-code').forEach((pre) => {
  if (pre.querySelector('.rs-copy-btn')) return;

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'rs-copy-btn';
  btn.textContent = '📋 复制';

  btn.addEventListener('click', async () => {
    const code = pre.querySelector('code')?.innerText ?? pre.innerText;
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      // 回退方案
      const ta = document.createElement('textarea');
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    btn.textContent = '✓ 已复制';
    setTimeout(() => (btn.textContent = '📋 复制'), 1500);
  });

  pre.appendChild(btn);
});
