/** TryIt 组件：把代码写进 iframe srcdoc 实时运行 */

const HTML_WRAPPER = (code: string) =>
  code.trim().toLowerCase().startsWith('<!doctype') || code.includes('<html')
    ? code
    : `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:system-ui;margin:12px;line-height:1.6}</style></head><body>${code}</body></html>`;

const CSS_WRAPPER = (css: string, demo: string) => `<!doctype html><html><head><meta charset="utf-8">
<style>
  body{font-family:system-ui;margin:12px;line-height:1.6}
  .box{padding:12px;margin:8px 0;border:1px dashed #999}
  ${css}
</style></head><body>${demo}</body></html>`;

const JS_WRAPPER = (code: string) => `<!doctype html><html><head><meta charset="utf-8">
<style>
  body{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;line-height:1.7;margin:0;padding:12px;white-space:pre-wrap;word-break:break-word}
  .log{color:#1f2937}.err{color:#dc2626}.warn{color:#d97706}
</style></head><body><div id="out"></div>
<script>
(function(){
  var out=document.getElementById('out');
  function print(level,args){
    var line=document.createElement('div');
    line.className=level;
    line.textContent=args.map(function(a){
      try{return typeof a==='object'?JSON.stringify(a):String(a)}catch(e){return String(a)}
    }).join(' ');
    out.appendChild(line);
  }
  ['log','info','debug'].forEach(function(k){console[k]=function(){print('log',[].slice.call(arguments))}});
  console.warn=function(){print('warn',[].slice.call(arguments))};
  console.error=function(){print('err',[].slice.call(arguments))};
  window.onerror=function(msg,src,line){print('err',['Error: '+msg+' (line '+line+')'])};
  try{
    var __result;
    (function(){
${code.replace(/<\/script/gi, '<\\/script')}
    })();
  }catch(e){print('err',[e.name+': '+e.message])}
})();
<\/script></body></html>`;

function run(root: HTMLElement) {
  const lang = root.dataset.lang || 'html';
  const codeEl = root.querySelector<HTMLTextAreaElement>('[data-code]');
  const frame = root.querySelector<HTMLIFrameElement>('[data-result]');
  if (!codeEl || !frame) return;

  const code = codeEl.value;
  let srcdoc: string;
  if (lang === 'js') srcdoc = JS_WRAPPER(code);
  else if (lang === 'css') {
    const demoTpl = root.querySelector<HTMLTemplateElement>('[data-demo]');
    const demo = demoTpl?.dataset.demo ?? '';
    srcdoc = CSS_WRAPPER(code, demo);
  } else srcdoc = HTML_WRAPPER(code);

  frame.srcdoc = srcdoc;
}

document.querySelectorAll<HTMLElement>('.rs-tryit').forEach((root) => {
  root.querySelector('[data-run]')?.addEventListener('click', () => run(root));
  run(root);
});
