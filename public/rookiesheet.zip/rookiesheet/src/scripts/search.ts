/** 纯前端静态搜索：过滤内嵌的语法/命令索引 */
interface SearchRow {
  track: string;
  trackTitle: string;
  kind: string;
  title: string;
  desc: string;
  href: string;
  keywords: string;
}

const page = document.querySelector<HTMLElement>('[data-search-page]');
if (page) {
  const input = document.querySelector<HTMLInputElement>('[data-search-input]');
  const box = document.querySelector<HTMLElement>('[data-search-results]');
  const counter = document.querySelector<HTMLElement>('[data-search-count]');
  const dataEl = document.querySelector<HTMLScriptElement>('[data-search-index]');
  const rows: SearchRow[] = dataEl ? JSON.parse(dataEl.textContent || '[]') : [];

  function escapeHtml(s: string) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function highlight(text: string, q: string) {
    const safe = escapeHtml(text);
    if (!q) return safe;
    const escQ = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return safe.replace(new RegExp(`(${escQ})`, 'gi'), '<mark class="rounded bg-warning/30 px-0.5">$1</mark>');
  }

  function card(r: SearchRow, q: string) {
    const badge =
      r.kind === '命令'
        ? '<span class="badge badge-primary badge-xs">命令</span>'
        : '<span class="badge badge-secondary badge-xs">课时</span>';
    return `
      <a href="${r.href}" class="card card-compact border border-base-300 bg-base-100 p-4 transition hover:-translate-y-0.5 hover:border-primary hover:shadow-md">
        <div class="flex items-center gap-2">
          ${badge}
          <span class="badge badge-ghost badge-xs">${r.trackTitle}</span>
        </div>
        <p class="mt-2 font-mono text-[15px] font-bold text-secondary">${highlight(r.title, q)}</p>
        <p class="mt-1 text-sm opacity-75">${highlight(r.desc, q)}</p>
      </a>`;
  }

  function render(qRaw: string) {
    const q = qRaw.trim().toLowerCase();
    if (!box) return;

    if (!q) {
      counter!.textContent = `共 ${rows.length} 条可查内容`;
      const tips = rows.filter((r) => r.kind === '课时').slice(0, 9);
      box.innerHTML =
        '<p class="mb-3 text-sm opacity-60">试试这些热门查询，或直接输入关键词：</p>' +
        `<div class="grid gap-3 sm:grid-cols-2">${tips.map((r) => card(r, '')).join('')}</div>` +
        `<div class="mt-4 flex flex-wrap gap-2">
          <span class="text-sm opacity-60">快捷词：</span>
          ${['select', 'flex', 'for 循环', '函数', 'grep', 'input', '列表', 'margin']
            .map(
              (w) =>
                `<button type="button" class="btn btn-outline btn-xs" data-suggest="${w}">${w}</button>`,
            )
            .join('')}
        </div>`;
      box.querySelectorAll<HTMLButtonElement>('[data-suggest]').forEach((b) =>
        b.addEventListener('click', () => {
          input!.value = b.dataset.suggest!;
          render(b.dataset.suggest!);
        }),
      );
      return;
    }

    const terms = q.split(/\s+/);
    const matched = rows
      .map((r) => ({ r, score: scoreRow(r, terms) }))
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 48);

    counter!.textContent = `找到 ${matched.length} 条与「${qRaw.trim()}」相关的结果`;
    box.innerHTML = matched.length
      ? `<div class="grid gap-3 sm:grid-cols-2">${matched.map((x) => card(x.r, q)).join('')}</div>`
      : `<div class="card border border-dashed border-base-300 p-8 text-center">
           <p class="text-4xl">🔍</p>
           <p class="mt-2 font-semibold">没有找到「${escapeHtml(qRaw)}」</p>
           <p class="mt-1 text-sm opacity-60">换个更基础的词试试，例如：标签、循环、选择器、SELECT</p>
         </div>`;
  }

  function scoreRow(r: SearchRow, terms: string[]): number {
    const title = r.title.toLowerCase();
    const hay = r.keywords.toLowerCase();
    let score = 0;
    for (const t of terms) {
      if (title.includes(t)) score += 5;
      else if (hay.includes(t)) score += 2;
      else return 0;
    }
    if (r.kind === '命令') score += 1;
    return score;
  }

  input?.addEventListener('input', () => render(input.value));
  const params = new URLSearchParams(location.search);
  const initial = params.get('q') || '';
  if (initial && input) input.value = initial;
  render(initial);
}
