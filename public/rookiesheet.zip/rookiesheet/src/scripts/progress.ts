import confetti from 'canvas-confetti';

/**
 * 学习进度（localStorage）
 * - 左导航课时后的 ✓ 标记
 * - 轨道页进度条
 * - 课时页「标记已学完」按钮（带小撒花）
 */
const KEY = 'rs-progress';

function read(): Record<string, number> {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '{}');
  } catch {
    return {};
  }
}
function write(data: Record<string, number>) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* ignore */
  }
}

function render() {
  const done = read();

  // 左导航标记
  document.querySelectorAll<HTMLElement>('[data-done-item]').forEach((el) => {
    const id = el.dataset.doneItem!;
    const mark = el.querySelector('[data-done-mark]');
    const idx = el.querySelector('[data-index]');
    if (done[id]) {
      mark?.classList.remove('hidden');
      idx?.classList.add('border-success', 'bg-success', 'text-white');
      idx!.textContent = '✓';
    } else {
      mark?.classList.add('hidden');
      idx?.classList.remove('border-success', 'bg-success', 'text-white');
    }
  });

  // 轨道进度条
  document.querySelectorAll<HTMLElement>('[data-track-progress]').forEach((el) => {
    const track = el.dataset.trackProgress!;
    const items = Array.from(
      document.querySelectorAll<HTMLElement>(`[data-done-item][data-track="${track}"]`),
    );
    const finished = items.filter((i) => done[i.dataset.doneItem!]).length;
    const pct = items.length ? Math.round((finished / items.length) * 100) : 0;
    const bar = el.querySelector<HTMLElement>('[data-progress-bar]');
    const label = el.querySelector<HTMLElement>('[data-progress-label]');
    if (bar) bar.style.width = pct + '%';
    if (label) label.textContent = items.length ? `${finished}/${items.length} · ${pct}%` : '';
  });
}

document.querySelectorAll<HTMLButtonElement>('[data-mark-done]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const id = btn.dataset.markDone!;
    const data = read();
    if (data[id]) return;
    data[id] = Date.now();
    write(data);
    render();
    btn.disabled = true;
    btn.textContent = '✅ 已学完，进度已保存';
    btn.classList.add('btn-success');
    confetti({
      particleCount: 60,
      spread: 80,
      startVelocity: 35,
      origin: { y: 0.8 },
      colors: ['#16a34a', '#22c55e', '#0ea5e9', '#f59e0b'],
      disableForReducedMotion: true,
    });
  });
});

render();
