import confetti from 'canvas-confetti';

const COLORS = ['#16a34a', '#22c55e', '#0ea5e9', '#f59e0b', '#84cc16'];

interface QuizQuestion {
  q: string;
  options: string[];
  answer: number;
  explain?: string;
}

/** 答对单题：小撒花 */
function smallBurst() {
  confetti({
    particleCount: 36,
    spread: 75,
    startVelocity: 32,
    scalar: 0.9,
    ticks: 180,
    origin: { y: 0.72 },
    colors: COLORS,
    disableForReducedMotion: true,
  });
}

/** 通关/全对：两侧礼炮 + 中央大爆发 */
function grandFinale() {
  const end = Date.now() + 1400;
  (function frame() {
    confetti({ particleCount: 6, angle: 60, spread: 60, startVelocity: 55, origin: { x: 0, y: 0.7 }, colors: COLORS });
    confetti({ particleCount: 6, angle: 120, spread: 60, startVelocity: 55, origin: { x: 1, y: 0.7 }, colors: COLORS });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
  confetti({
    particleCount: 150,
    spread: 110,
    startVelocity: 42,
    origin: { y: 0.55 },
    colors: COLORS,
    disableForReducedMotion: true,
  });
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

const LETTERS = ['A', 'B', 'C', 'D'];

function mount(root: HTMLElement) {
  const body = root.querySelector<HTMLElement>('[data-quiz-body]');
  if (!body || body.dataset.ready) return;
  body.dataset.ready = '1';

  const questions: QuizQuestion[] = JSON.parse(body.dataset.quizJson || '[]');
  if (!questions.length) return;

  const state = questions.map(() => ({ answered: false, correct: false }));
  const total = questions.length;

  body.innerHTML =
    questions
      .map((q, qi) => {
        const opts = q.options
          .map(
            (opt, oi) => `
          <button type="button" class="rs-opt flex w-full items-start gap-3 rounded-lg border border-base-300 bg-base-100 px-3.5 py-2.5 text-left text-sm" data-qi="${qi}" data-oi="${oi}">
            <span class="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-current text-[11px] font-bold">${LETTERS[oi]}</span>
            <span>${escapeHtml(opt)}</span>
          </button>`,
          )
          .join('');
        return `
        <div class="rounded-box border border-base-300 p-4" data-question="${qi}">
          <p class="font-semibold leading-relaxed">
            <span class="badge badge-outline badge-sm mr-2">第 ${qi + 1} 题</span>${escapeHtml(q.q)}
          </p>
          <div class="mt-3 grid gap-2">${opts}</div>
          <div class="mt-2 text-sm" data-explain="${qi}"></div>
        </div>`;
      })
      .join('') + `<div data-quiz-foot class="mt-1"></div>`;

  function answeredCount() {
    return state.filter((s) => s.answered).length;
  }
  function correctCount() {
    return state.filter((s) => s.correct).length;
  }

  function renderFoot() {
    const foot = body.querySelector<HTMLElement>('[data-quiz-foot]');
    if (!foot) return;
    const done = answeredCount();
    const score = correctCount();

    if (done < total) {
      foot.innerHTML = `
        <div class="flex items-center justify-between gap-3 rounded-box bg-base-200/70 px-4 py-3 text-sm">
          <span>已作答 <b>${done}</b> / ${total} · 答对 <b class="text-success">${score}</b></span>
          <div class="join" aria-hidden="false">
            ${state
              .map(
                (s) =>
                  `<span class="h-2 w-6 rounded-full ${s.answered ? (s.correct ? 'bg-success' : 'bg-error') : 'bg-base-300'}"></span>`,
              )
              .join('')}
          </div>
        </div>`;
    } else {
      const ratio = score / total;
      const pass = ratio >= 0.8;
      const all = score === total;
      foot.innerHTML = `
        <div class="rs-pop overflow-hidden rounded-box border-2 ${pass ? 'border-success/60 bg-success/10' : 'border-error/40 bg-error/5'} p-5 text-center">
          <p class="text-3xl">${all ? '🎉🎉🎉' : pass ? '🎉' : '💪'}</p>
          <p class="mt-1 text-lg font-extrabold">
            ${all ? '全对啦！菜鸟逆袭成功！' : pass ? '恭喜通过！再冲一次全对吧' : `拿到 ${score} / ${total} 分，还差一点点`}
          </p>
          <p class="mt-1 text-sm opacity-80">${
            pass ? '撒花欢呼，知识点已经牢牢记住啦～' : '看看下面的解析，重新挑战一次！'
          }</p>
          <button type="button" class="btn ${pass ? 'btn-success' : 'btn-primary'} btn-sm mt-3" data-reset>🔄 重新挑战</button>
        </div>`;
      foot.querySelector('[data-reset]')?.addEventListener('click', () => mountFresh());
    }
  }

  function mountFresh() {
    delete body.dataset.ready;
    body.innerHTML = '';
    mount(root);
  }

  body.querySelectorAll<HTMLButtonElement>('.rs-opt').forEach((btn) => {
    btn.addEventListener('click', () => {
      const qi = Number(btn.dataset.qi);
      const oi = Number(btn.dataset.oi);
      const st = state[qi];
      if (st.answered) return;
      st.answered = true;

      const q = questions[qi];
      st.correct = oi === q.answer;

      const card = body.querySelector<HTMLElement>(`[data-question="${qi}"]`)!;
      card.querySelectorAll<HTMLButtonElement>('.rs-opt').forEach((b) => {
        b.disabled = true;
        const idx = Number(b.dataset.oi);
        if (idx === q.answer) b.classList.add('is-correct');
        else if (idx === oi) b.classList.add('is-wrong');
      });

      const explainBox = card.querySelector<HTMLElement>(`[data-explain="${qi}"]`);
      if (st.correct) {
        explainBox!.innerHTML = `<p class="flex items-center gap-1.5 font-semibold text-success">✅ 回答正确！</p>${
          q.explain ? `<p class="mt-1 opacity-80">${escapeHtml(q.explain)}</p>` : ''
        }`;
        smallBurst();
      } else {
        explainBox!.innerHTML = `<p class="font-semibold text-error">❌ 正确答案是 ${LETTERS[q.answer]}</p>${
          q.explain ? `<p class="mt-1 opacity-80">${escapeHtml(q.explain)}</p>` : ''
        }`;
      }

      const wasFinal = answeredCount() === total;
      renderFoot();
      if (wasFinal) {
        const ratio = correctCount() / total;
        if (ratio >= 0.8) setTimeout(grandFinale, 250);
      }
    });
  });

  renderFoot();
}

document.querySelectorAll<HTMLElement>('[data-quiz]').forEach(mount);
