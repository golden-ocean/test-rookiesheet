const KEY = 'rs-theme';
const btn = document.querySelector<HTMLButtonElement>('[data-theme-toggle]');

function syncIcon() {
  const dark = document.documentElement.dataset.theme === 'rookiedark';
  document.querySelector('[data-icon-sun')?.classList.toggle('hidden', !dark);
  document.querySelector('[data-icon-moon]')?.classList.toggle('hidden', dark);
}

btn?.addEventListener('click', () => {
  const next =
    document.documentElement.dataset.theme === 'rookiedark' ? 'rookielight' : 'rookiedark';
  document.documentElement.dataset.theme = next;
  try {
    localStorage.setItem(KEY, next);
  } catch (e) {
    /* 忽略隐私模式写入失败 */
  }
  syncIcon();
});

syncIcon();
