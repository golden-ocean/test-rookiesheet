export const SITE = {
  name: 'RookieSheet',
  domain: 'rookiesheet.com',
  title: 'RookieSheet 菜鸟速查表 — 编程语法与命令快速查询',
  description:
    '面向零基础菜鸟的编程学习站：HTML、CSS、JavaScript、Python、SQL、Linux 命令的语法速查、重点讲解与随堂测试，由易到难，看完就会。',
  slogan: '菜鸟的编程命令速查表',
};

export const NAV_LINKS = [
  { href: '/', label: '首页' },
  { href: '/learn/html/', label: 'HTML' },
  { href: '/learn/css/', label: 'CSS' },
  { href: '/learn/javascript/', label: 'JavaScript' },
  { href: '/learn/python/', label: 'Python' },
  { href: '/learn/sql/', label: 'SQL' },
  { href: '/learn/bash/', label: 'Linux 命令' },
  { href: '/search/', label: '速查搜索' },
];
