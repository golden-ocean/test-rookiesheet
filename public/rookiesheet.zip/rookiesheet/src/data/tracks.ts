// 课程轨道与课时元数据 —— 学习顺序即「由易到难」
// file 字段对应 src/content/learn/ 下的 mdx 条目 id

export type Level = 1 | 2 | 3;

export interface LessonMeta {
  slug: string;
  file: string;
  title: string;
  level: Level;
  minutes: number;
  summary: string;
  /** 本节重点（右栏记忆卡片） */
  points: string[];
}

export interface Track {
  slug: string;
  title: string;
  emoji: string;
  /** 一句话定位 */
  tagline: string;
  description: string;
  lessons: LessonMeta[];
}

export const LEVEL_LABEL: Record<Level, string> = {
  1: '入门',
  2: '基础',
  3: '进阶',
};

export const tracks: Track[] = [
  {
    slug: 'html',
    title: 'HTML',
    emoji: '📄',
    tagline: '网页的骨架：标签搭页面',
    description:
      'HTML 用一个个「标签」告诉浏览器：这里是标题、那里是图片、按钮在哪里。零编程基础也能立刻上手，是所有 Web 学习的第一步。',
    lessons: [
      {
        slug: 'intro',
        file: 'html/01-intro',
        title: '初识 HTML：第一个网页',
        level: 1,
        minutes: 8,
        summary: '认识标签、元素与 HTML 页面的基本结构，动手写出第一个网页。',
        points: [
          'HTML 用标签 <标签名> 描述内容',
          '页面骨架：<!DOCTYPE html> + html/head/body',
          '<h1>~<h6> 是标题，<p> 是段落',
          '保存为 .html 文件，双击用浏览器打开',
        ],
      },
      {
        slug: 'text-link-img',
        file: 'html/02-text-link-img',
        title: '文本、链接与图片',
        level: 1,
        minutes: 10,
        summary: '排版文字、插入超链接和图片，掌握最常用的三个标签与属性写法。',
        points: [
          '<a href="网址"> 用来跳转，target="_blank" 新窗口打开',
          '<img src="图片地址" alt="替代文字"> 是自闭合标签',
          '属性写在开始标签里：名="值"',
          '<strong> 加粗强调，<br> 换行，<hr> 分隔线',
        ],
      },
      {
        slug: 'lists-tables',
        file: 'html/03-lists-tables',
        title: '列表与表格',
        level: 2,
        minutes: 10,
        summary: '用 ul/ol 组织清单，用 table 行列展示数据。',
        points: [
          '<ul> 无序、<ol> 有序，列表项都是 <li>',
          '表格四件套：table > tr > th / td',
          'colspan / rowspan 让单元格跨列跨行',
          '展示数据用表格，做布局用 CSS（别再用表格排版）',
        ],
      },
      {
        slug: 'forms',
        file: 'html/04-forms',
        title: '表单与输入控件',
        level: 2,
        minutes: 12,
        summary: 'input、button、select 等收集用户输入的核心标签。',
        points: [
          '<form action method> 负责提交数据',
          '<input type="...">：text/password/checkbox/radio/submit',
          'name 属性决定提交数据的键名',
          '<label for> 关联输入框，placeholder 只是提示文字',
        ],
      },
      {
        slug: 'semantic',
        file: 'html/05-semantic',
        title: '语义化标签与页面结构',
        level: 3,
        minutes: 9,
        summary: 'header/nav/main/section/article/footer 让页面结构清晰可读。',
        points: [
          '语义化 = 用含义正确的标签，而非全用 div',
          '常见结构：header / nav / main / article / aside / footer',
          '<div> 无语义分组，<span> 行内无语义分组',
          '语义化对 SEO、无障碍和团队协作都友好',
        ],
      },
    ],
  },
  {
    slug: 'css',
    title: 'CSS',
    emoji: '🎨',
    tagline: '网页的外衣：选择器与布局',
    description:
      'CSS 决定网页长什么样：颜色、大小、间距与排版。从选择器到 Flex / Grid，学完就能做出整齐美观的页面。',
    lessons: [
      {
        slug: 'intro',
        file: 'css/01-intro',
        title: '选择器与三种引入方式',
        level: 1,
        minutes: 9,
        summary: 'CSS 基本语法、行内/内部/外部样式表，以及最常用的选择器。',
        points: [
          '规则 = 选择器 { 属性: 值; }',
          '三种引入：行内 style、<style>、外部 <link>',
          '基础选择器：标签、.class、#id',
          '后代选择器用空格，群组选择器用逗号',
        ],
      },
      {
        slug: 'box-text',
        file: 'css/02-box-text',
        title: '盒模型与文本样式',
        level: 2,
        minutes: 11,
        summary: 'content/padding/border/margin 与常用文字、颜色属性。',
        points: [
          '盒子由内到外：content → padding → border → margin',
          'box-sizing: border-box 让宽高包含内边距和边框',
          'color 文字色，background 背景色',
          'font-size / font-weight / text-align / line-height',
        ],
      },
      {
        slug: 'flex',
        file: 'css/03-flex',
        title: 'Flex 弹性布局',
        level: 2,
        minutes: 12,
        summary: '一维布局神器，轻松实现居中、均分、两端对齐。',
        points: [
          '父容器 display: flex 即开启弹性布局',
          'justify-content 管主轴（横向）对齐',
          'align-items 管交叉轴（纵向）对齐',
          '居中就记：justify + align 都 center；gap 设间距',
        ],
      },
      {
        slug: 'grid',
        file: 'css/04-grid',
        title: 'Grid 网格布局',
        level: 3,
        minutes: 11,
        summary: '二维布局系统，几行代码划出规整的行列网格。',
        points: [
          'display: grid + grid-template-columns 定义列',
          'repeat(3, 1fr) 三等分；fr 是剩余空间单位',
          'gap 设置行列间距',
          '一维排列用 Flex，二维网格用 Grid',
        ],
      },
      {
        slug: 'responsive',
        file: 'css/05-responsive',
        title: '媒体查询与响应式',
        level: 3,
        minutes: 10,
        summary: '@media 让同一套页面在手机和电脑上都好看。',
        points: [
          '@media (max-width: 768px) { … } 屏窄时生效',
          '移动优先：先写小屏样式，再用 min-width 增强',
          '图片/容器用 max-width: 100% 防止溢出',
          '常用断点：768px（平板）、1024px（桌面）',
        ],
      },
    ],
  },
  {
    slug: 'javascript',
    title: 'JavaScript',
    emoji: '⚡',
    tagline: '网页的大脑：让页面动起来',
    description:
      'JavaScript 让网页能交互：点击响应、数据计算、动态更新。本轨道按变量→类型→分支→循环→函数→数据结构循序渐进。',
    lessons: [
      {
        slug: 'intro',
        file: 'js/01-intro',
        title: '变量与输出',
        level: 1,
        minutes: 10,
        summary: 'let / const 声明变量，用 console.log 看到程序输出。',
        points: [
          'let 声明可改变的变量，const 声明常量',
          'var 是老写法，新代码统一用 let / const',
          'console.log() 在控制台打印输出',
          '字符串用引号："双" 或 \'单\'，保持统一',
        ],
      },
      {
        slug: 'types',
        file: 'js/02-types',
        title: '数据类型与运算符',
        level: 2,
        minutes: 11,
        summary: '数字、字符串、布尔、null/undefined 与常用运算。',
        points: [
          '基本类型：number / string / boolean / null / undefined',
          'typeof x 查看类型',
          '+ 既算加法又能拼接字符串',
          '== 会转型，=== 严格相等 —— 永远优先用 ===',
        ],
      },
      {
        slug: 'condition',
        file: 'js/03-condition',
        title: '条件与分支',
        level: 2,
        minutes: 11,
        summary: 'if / else if / else 与 switch 让程序学会判断。',
        points: [
          'if (条件) { … } else { … }',
          '条件结果只有 true / false',
          '多分支用 else if；等值多路分发可用 switch',
          '逻辑与 &&、或 ||、非 ! 可组合条件',
        ],
      },
      {
        slug: 'loop',
        file: 'js/04-loop',
        title: '循环',
        level: 2,
        minutes: 11,
        summary: 'for、while 让重复的事情自动做。',
        points: [
          'for (初始化; 条件; 更新) { 重复执行 }',
          'while (条件) 适合次数不确定的循环',
          'break 跳出循环，continue 跳过本次',
          '小心条件永远为 true 的死循环',
        ],
      },
      {
        slug: 'function',
        file: 'js/05-function',
        title: '函数',
        level: 2,
        minutes: 12,
        summary: '把一段逻辑封装起来反复调用：参数、返回值与作用域。',
        points: [
          'function 名字(参数) { … return 结果; }',
          'return 把结果交回调用处，函数立即结束',
          '箭头函数：const f = (x) => x * 2',
          '函数内声明的变量，外部访问不到（作用域）',
        ],
      },
      {
        slug: 'array-object',
        file: 'js/06-array-object',
        title: '数组与对象',
        level: 3,
        minutes: 13,
        summary: '数组存一串数据，对象存一组「键值对」，配合常用方法。',
        points: [
          '数组：[1, 2, 3]，下标从 0 开始，length 看长度',
          'push / pop 末尾增删，map / filter 处理数组',
          '对象：{ name: "菜鸟", age: 18 }，点语法取值',
          '数组用 [] 配数字下标，对象用 {} 配键名',
        ],
      },
    ],
  },
  {
    slug: 'python',
    title: 'Python',
    emoji: '🐍',
    tagline: '语法最接近英语的全能语言',
    description:
      'Python 以简洁易读著称，是自动化、数据分析、人工智能的第一语言。同样按基础语法循序渐进，缩进是它的标志性规则。',
    lessons: [
      {
        slug: 'intro',
        file: 'py/01-intro',
        title: '变量与输出',
        level: 1,
        minutes: 9,
        summary: 'print() 输出、直接赋值变量、注释写法。',
        points: [
          'print(内容) 输出到屏幕',
          '变量直接赋值：name = "菜鸟"，不需要声明关键字',
          '# 开头是单行注释',
          'Python 靠缩进（4 个空格）表示代码块',
        ],
      },
      {
        slug: 'types',
        file: 'py/02-types',
        title: '数据类型与字符串',
        level: 2,
        minutes: 11,
        summary: 'int/float/str/bool 与 f-string 格式化。',
        points: [
          'int 整数、float 小数、str 字符串、bool 布尔',
          'type(x) 查看类型',
          'f"姓名：{name}" 直接嵌入变量，最推荐',
          'input() 读到的永远是字符串，计算前要 int() 转换',
        ],
      },
      {
        slug: 'condition',
        file: 'py/03-condition',
        title: '条件判断',
        level: 2,
        minutes: 10,
        summary: 'if / elif / else 与 Python 特有的冒号缩进写法。',
        points: [
          'if 条件: 换行 + 缩进写执行语句',
          '多分支是 elif（不是 else if）',
          '比较：== != > < >= <=；逻辑 and / or / not',
          '同一级缩进的语句属于同一个代码块',
        ],
      },
      {
        slug: 'loop',
        file: 'py/04-loop',
        title: '循环',
        level: 2,
        minutes: 11,
        summary: 'for...in 与 range、while 循环。',
        points: [
          'for i in range(n): 重复 n 次，i 从 0 开始',
          'range(1, 10) 含头不含尾（1 到 9）',
          'while 条件: 适合次数不确定',
          'break 跳出，continue 跳过本次',
        ],
      },
      {
        slug: 'function',
        file: 'py/05-function',
        title: '函数',
        level: 2,
        minutes: 11,
        summary: 'def 定义函数、参数与 return 返回值。',
        points: [
          'def 函数名(参数): 换行缩进写函数体',
          'return 把结果返回；没有 return 得到 None',
          '默认参数：def greet(name="菜鸟")',
          '函数要先定义、后调用',
        ],
      },
      {
        slug: 'list-dict',
        file: 'py/06-list-dict',
        title: '列表与字典',
        level: 3,
        minutes: 13,
        summary: 'list 有序集合与 dict 键值对，Python 最常用的两种数据结构。',
        points: [
          '列表 nums = [1, 2, 3]，下标从 0 开始',
          'append 增、len 长度、切片 nums[0:2]',
          '字典 user = {"name": "菜鸟"}，user["name"] 取值',
          'for k, v in d.items() 同时遍历键值',
        ],
      },
    ],
  },
  {
    slug: 'sql',
    title: 'SQL',
    emoji: '🗃️',
    tagline: '跟数据库对话：查数据、改数据',
    description:
      'SQL 是操作数据库的标准语言，用接近英语的句子完成增删改查。做后端、数据分析都绕不开它。',
    lessons: [
      {
        slug: 'select',
        file: 'sql/01-select',
        title: 'SELECT 基础查询',
        level: 1,
        minutes: 9,
        summary: 'SELECT ... FROM 取出表中的列与数据。',
        points: [
          'SELECT 列 FROM 表; 是最基础的查询',
          'SELECT * 表示所有列（练习可以，生产少用）',
          'AS 给列起别名，DISTINCT 去重',
          'SQL 语句以分号结尾，关键字习惯大写',
        ],
      },
      {
        slug: 'where-order',
        file: 'sql/02-where-order',
        title: 'WHERE 条件与排序分页',
        level: 2,
        minutes: 11,
        summary: '条件过滤、ORDER BY 排序、LIMIT 分页。',
        points: [
          'WHERE 筛行：=、!=、>、<、BETWEEN、IN、LIKE',
          'AND / OR 组合多个条件',
          'ORDER BY 列 ASC 升序 / DESC 降序',
          'LIMIT n 取前 n 条，LIMIT 偏移, 数量 分页',
        ],
      },
      {
        slug: 'insert-update-delete',
        file: 'sql/03-write',
        title: '增删改 INSERT / UPDATE / DELETE',
        level: 2,
        minutes: 11,
        summary: '写入、修改、删除数据的三条核心语句。',
        points: [
          'INSERT INTO 表 (列) VALUES (值)',
          'UPDATE 表 SET 列=值 WHERE 条件',
          'DELETE FROM 表 WHERE 条件',
          '改删数据必须带 WHERE，否则全表遭殃！',
        ],
      },
      {
        slug: 'aggregate-join',
        file: 'sql/04-aggregate-join',
        title: '聚合函数与多表连接',
        level: 3,
        minutes: 13,
        summary: 'COUNT/SUM/GROUP BY 统计，JOIN 把多张表连起来查。',
        points: [
          '聚合：COUNT、SUM、AVG、MAX、MIN',
          'GROUP BY 按列分组，HAVING 过滤分组结果',
          'JOIN ... ON 关联两表，最常用 LEFT JOIN',
          'WHERE 过滤行（分组前），HAVING 过滤组（分组后）',
        ],
      },
    ],
  },
  {
    slug: 'bash',
    title: 'Linux 命令',
    emoji: '⌨️',
    tagline: '终端速查：玩转文件与系统',
    description:
      '最常用的 Linux / 终端命令：目录导航、文件处理、查看系统状态。程序员日常与服务器运维的基本功。',
    lessons: [
      {
        slug: 'files',
        file: 'bash/01-files',
        title: '目录与文件操作',
        level: 1,
        minutes: 9,
        summary: 'pwd / cd / ls / mkdir / cp / mv / rm 八条命令走天下。',
        points: [
          'pwd 我在哪、cd 去哪、ls 有什么',
          'mkdir 建目录，touch 建空文件',
          'cp 复制、mv 移动/重命名、rm 删除',
          '. 当前目录、.. 上一级、~ 家目录',
        ],
      },
      {
        slug: 'text',
        file: 'bash/02-text',
        title: '查看与处理文本',
        level: 2,
        minutes: 11,
        summary: 'cat / less / head / tail / grep / 管道符的组合用法。',
        points: [
          'cat 全部输出，less 翻页查看（q 退出）',
          'head -n / tail -n 看开头或结尾，tail -f 实时跟踪',
          'grep "关键词" 文件 按行过滤',
          '管道 | 把前一个命令的输出交给后一个',
        ],
      },
      {
        slug: 'system',
        file: 'bash/03-system',
        title: '系统、进程与权限',
        level: 3,
        minutes: 12,
        summary: 'ps / kill / chmod / sudo 与环境变量速查。',
        points: [
          'ps aux | grep 名 找进程，kill PID 结束进程',
          'top/htop 看资源占用，df -h 看磁盘，free -h 看内存',
          'chmod 修改权限：r=4 w=2 x=1，如 755',
          'sudo 以管理员身份执行，别滥用',
        ],
      },
    ],
  },
];

export function getTrack(slug: string): Track | undefined {
  return tracks.find((t) => t.slug === slug);
}

export interface LessonContext {
  track: Track;
  lesson: LessonMeta;
  index: number;
  prev?: { track: string; slug: string; title: string };
  next?: { track: string; slug: string; title: string };
}

/** 按 file 条目 id（如 html/01-intro）找到课时上下文 */
export function findLessonByFile(fileId: string): LessonContext | undefined {
  for (const track of tracks) {
    const index = track.lessons.findIndex((l) => l.file === fileId);
    if (index === -1) continue;
    const lesson = track.lessons[index];
    const ctx: LessonContext = { track, lesson, index };
    const prevLesson = track.lessons[index - 1];
    const nextLesson = track.lessons[index + 1];
    if (prevLesson)
      ctx.prev = { track: track.slug, slug: prevLesson.slug, title: prevLesson.title };
    if (nextLesson)
      ctx.next = { track: track.slug, slug: nextLesson.slug, title: nextLesson.title };
    return ctx;
  }
}

export function getLessonContext(
  trackSlug: string,
  lessonSlug: string,
): LessonContext | undefined {
  const track = getTrack(trackSlug);
  if (!track) return;
  const index = track.lessons.findIndex((l) => l.slug === lessonSlug);
  if (index === -1) return;
  const lesson = track.lessons[index];
  return findLessonByFile(lesson.file);
}

export const totalLessons = tracks.reduce((n, t) => n + t.lessons.length, 0);
