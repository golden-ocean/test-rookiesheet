export interface CmdItem {
  /** 命令 / 语法本体 */
  cmd: string;
  /** 一句话说明 */
  desc: string;
  /** 最小可运行示例 */
  example?: string;
  /** 搜索辅助关键词（不含也能搜 cmd/desc） */
  tags?: string[];
}
