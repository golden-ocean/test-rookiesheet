import type { CmdItem } from './types';

export const pythonCommands: CmdItem[] = [
  {
    cmd: 'print()',
    desc: '输出内容到屏幕',
    example: "print('你好，菜鸟！')",
    tags: ['输出', '打印', 'hello', '显示'],
  },
  {
    cmd: '# 注释',
    desc: '单行注释，运行时会被忽略',
    example: '# 计算面积\nwidth = 5',
    tags: ['注释', 'comment', '说明'],
  },
  {
    cmd: '变量赋值 =',
    desc: '直接赋值，不需要声明关键字',
    example: 'name = "菜鸟"\nage = 18',
    tags: ['变量', '赋值', 'variable', 'let'],
  },
  {
    cmd: 'type()',
    desc: '查看一个值的类型',
    example: "type(3.14)  # <class 'float'>",
    tags: ['类型', 'type', 'int', 'float', 'str', 'bool'],
  },
  {
    cmd: 'int() / float() / str() / bool()',
    desc: '在整数、小数、字符串、布尔之间转换类型',
    example: "age = int('18')   # 字符串转整数",
    tags: ['类型转换', 'int', 'str', 'float', 'bool', '转换'],
  },
  {
    cmd: "f'...{变量}...'",
    desc: 'f-string 格式化字符串，花括号嵌入变量',
    example: "f'姓名：{name}，年龄：{age}'",
    tags: ['f-string', '格式化', '字符串', 'format', '拼接'],
  },
  {
    cmd: 'input()',
    desc: '读取键盘输入，返回值永远是字符串',
    example: "age = int(input('请输入年龄：'))",
    tags: ['输入', 'input', '键盘', '读取'],
  },
  {
    cmd: 'if / elif / else',
    desc: '条件分支：冒号后换行缩进，elif 不是 else if',
    example:
      'if score >= 90:\n    print("优秀")\nelif score >= 60:\n    print("及格")\nelse:\n    print("不及格")',
    tags: ['条件', 'if', 'elif', 'else', '分支', '判断'],
  },
  {
    cmd: '== != > < >= <= / and or not',
    desc: '比较运算与逻辑运算（相等用两个等号）',
    example: 'age >= 18 and age < 60',
    tags: ['比较', 'and', 'or', 'not', '逻辑', '运算符'],
  },
  {
    cmd: 'for ... in range()',
    desc: '按次数循环，range 含头不含尾',
    example: 'for i in range(1, 10):\n    print(i)   # 1 到 9',
    tags: ['循环', 'for', 'range', '遍历', 'in'],
  },
  {
    cmd: 'while / break / continue',
    desc: '条件循环；break 跳出整个循环，continue 跳过本轮',
    example: 'while n < 10:\n    n += 1',
    tags: ['循环', 'while', 'break', 'continue', '死循环'],
  },
  {
    cmd: 'def / return / 默认参数',
    desc: '定义函数、返回值与默认参数',
    example: 'def greet(name="菜鸟"):\n    return f"你好，{name}"',
    tags: ['函数', 'def', 'return', '参数', 'function', 'None'],
  },
  {
    cmd: '列表 [] / append() / len() / 切片',
    desc: '有序集合：追加、长度、按下标取值与切片',
    example: 'nums = [1, 2, 3]\nnums.append(4)\nnums[0:2]   # [1, 2]',
    tags: ['列表', 'list', 'append', 'len', '切片', '下标', '数组'],
  },
  {
    cmd: '字典 {} / 取值 / items()',
    desc: '键值对存储，按键取值，items 同时遍历键和值',
    example: 'user = {"name": "菜鸟", "age": 18}\nuser["name"]   # 菜鸟',
    tags: ['字典', 'dict', '键值对', 'items', 'get', 'map'],
  },
  {
    cmd: 'split() / join() / replace()',
    desc: '字符串常用方法：拆分、合并、替换',
    example: '"a,b,c".split(",")   # ["a", "b", "c"]',
    tags: ['字符串', 'split', 'join', 'replace', '方法'],
  },
  {
    cmd: 'import',
    desc: '引入模块，复用别人写好的功能',
    example: 'import random\nprint(random.randint(1, 6))',
    tags: ['模块', 'import', '导入', '库', 'random'],
  },
];
