import type { CmdItem } from './types';

export const cssCommands: CmdItem[] = [
  {
    cmd: '标签选择器',
    desc: '直接用标签名，选中页面上所有该标签',
    example: 'p { color: #333; }',
    tags: ['选择器', '标签', 'selector'],
  },
  {
    cmd: '.class 类选择器',
    desc: '点号开头，选中所有 class 相同的元素，最常用',
    example: '.btn { background: blue; }',
    tags: ['选择器', 'class', '类'],
  },
  {
    cmd: '#id 选择器',
    desc: '井号开头，选中页面中 id 唯一的那个元素',
    example: '#logo { width: 80px; }',
    tags: ['选择器', 'id'],
  },
  {
    cmd: '后代选择器（空格）',
    desc: '选择器之间用空格，选中「前者里面的」后者',
    example: '.nav a { color: red; }',
    tags: ['选择器', '后代', '空格'],
  },
  {
    cmd: '群组选择器（逗号）',
    desc: '选择器之间用逗号，多个选择器共用一套样式',
    example: 'h1, h2, h3 { font-weight: bold; }',
    tags: ['选择器', '群组', '逗号'],
  },
  {
    cmd: ':hover 伪类',
    desc: '鼠标悬停在元素上时生效的状态样式',
    example: 'a:hover { color: tomato; }',
    tags: ['伪类', 'hover', '鼠标', '状态'],
  },
  {
    cmd: 'color / background-color',
    desc: '设置文字颜色 / 背景颜色',
    example: '.tip { color: white; background-color: #16a34a; }',
    tags: ['颜色', 'color', '背景', 'background'],
  },
  {
    cmd: 'font-size / font-weight / text-align / line-height',
    desc: '字号 / 粗细 / 水平对齐 / 行高 四件套',
    example: 'p { font-size: 16px; font-weight: bold; text-align: center; line-height: 1.8; }',
    tags: ['字体', '文本', '字号', '加粗', '对齐', '行高'],
  },
  {
    cmd: 'margin / padding',
    desc: '外边距（盒子间距）/ 内边距（内容到边框），四值按上右下左',
    example: '.box { margin: 0 auto; padding: 10px 20px; }',
    tags: ['盒模型', '外边距', '内边距', '间距'],
  },
  {
    cmd: 'border',
    desc: '边框，按「粗细 线型 颜色」书写',
    example: '.card { border: 1px solid #ccc; }',
    tags: ['盒模型', '边框', 'border'],
  },
  {
    cmd: 'border-radius / box-shadow',
    desc: '圆角半径 / 盒子投影',
    example: '.card { border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }',
    tags: ['圆角', '阴影', 'border-radius', 'box-shadow'],
  },
  {
    cmd: 'display',
    desc: '元素显示方式：block / inline / none / flex / grid',
    example: '.nav { display: flex; }',
    tags: ['显示', 'display', 'none', '块级'],
  },
  {
    cmd: 'position',
    desc: '定位方式：relative / absolute / fixed，配合 top/left 使用',
    example: '.back-top { position: fixed; right: 20px; bottom: 20px; }',
    tags: ['定位', 'position', 'fixed', 'absolute'],
  },
  {
    cmd: 'justify-content / align-items',
    desc: 'Flex/Grid 中主轴对齐 / 交叉轴对齐，都设 center 即居中',
    example: '.box { display: flex; justify-content: center; align-items: center; }',
    tags: ['flex', '对齐', '居中', '主轴', '交叉轴'],
  },
  {
    cmd: 'gap',
    desc: '设置 Flex/Grid 项目之间的间距，首尾不留白',
    example: '.nav { display: flex; gap: 16px; }',
    tags: ['flex', 'grid', '间距', 'gap'],
  },
  {
    cmd: 'flex: 1',
    desc: '写在 Flex 子项目上，自动伸展平分剩余空间',
    example: '.main { flex: 1; }',
    tags: ['flex', '弹性', '自适应', '子项目'],
  },
  {
    cmd: 'grid-template-columns: repeat() / fr',
    desc: '定义 Grid 列宽，repeat 配合 fr 实现等分网格',
    example: '.wall { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }',
    tags: ['grid', '网格', '列', 'repeat', 'fr', '等分'],
  },
  {
    cmd: '@media',
    desc: '媒体查询，按屏幕宽度等条件应用样式，做响应式',
    example: '@media (max-width: 768px) { .cards { grid-template-columns: 1fr; } }',
    tags: ['响应式', '媒体查询', 'media', '断点', '移动端'],
  },
];
