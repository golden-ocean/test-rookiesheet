import type { CmdItem } from './types';

export const javascriptCommands: CmdItem[] = [
  {
    cmd: 'let / const',
    desc: '声明变量：let 可重新赋值，const 声明常量',
    example: "let age = 18;\nconst name = '菜鸟';",
    tags: ['变量', '声明', '赋值', 'var', 'let', 'const'],
  },
  {
    cmd: 'console.log()',
    desc: '在控制台打印输出，调试第一神器',
    example: "console.log('你好 ' + name);",
    tags: ['输出', '打印', '日志', '调试', 'log', 'console'],
  },
  {
    cmd: 'typeof',
    desc: '查看值的类型（注意 typeof null 返回 object）',
    example: "typeof '菜鸟'; // 'string'",
    tags: ['类型', 'typeof', 'number', 'string', 'boolean'],
  },
  {
    cmd: '+ - * / %',
    desc: '算术运算符：加、减、乘、除、取余',
    example: 'let r = 10 % 3; // 1',
    tags: ['算术', '运算符', '加减乘除', '取余', 'math'],
  },
  {
    cmd: '=== / !== / > < >= <=',
    desc: '比较运算符，优先用严格相等 ===，不要用 ==',
    example: "'1' === 1; // false，类型不同",
    tags: ['比较', '相等', '严格相等', '===', '==', '运算符'],
  },
  {
    cmd: '&& / || / !',
    desc: '逻辑运算符：与、或、非，用来组合条件',
    example: 'age >= 18 && hasTicket',
    tags: ['逻辑', '与或非', '并且', '或者', '取反', '条件'],
  },
  {
    cmd: 'if...else / 三元 ?: ',
    desc: '条件分支；简单二选一可用三元 条件 ? 值1 : 值2',
    example: "let r = score >= 60 ? '及格' : '不及格';",
    tags: ['条件', '分支', 'if', 'else', '三元', '判断'],
  },
  {
    cmd: 'for',
    desc: '次数确定的循环：初始化; 条件; 更新',
    example: 'for (let i = 0; i < 5; i++) { console.log(i); }',
    tags: ['循环', 'for', '遍历', '重复'],
  },
  {
    cmd: 'while',
    desc: '条件成立就继续，适合次数不确定的循环',
    example: 'while (count > 0) { count--; }',
    tags: ['循环', 'while', '条件循环'],
  },
  {
    cmd: 'break / continue',
    desc: 'break 跳出整个循环；continue 跳过本轮进入下一轮',
    example: 'if (i === 3) break;',
    tags: ['循环', '跳出', '跳过', 'break', 'continue'],
  },
  {
    cmd: 'function',
    desc: '声明函数：参数占坑，可被反复调用',
    example: 'function add(a, b) { return a + b; }',
    tags: ['函数', '声明', '参数', 'function', '复用'],
  },
  {
    cmd: '(x) => x',
    desc: '箭头函数：更简洁的函数写法，一行自动返回',
    example: 'const double = (x) => x * 2;',
    tags: ['函数', '箭头函数', 'arrow', 'lambda', '=>'],
  },
  {
    cmd: 'return',
    desc: '把结果返回给调用处，函数立即结束',
    example: 'function sq(x) { return x * x; }',
    tags: ['函数', '返回值', 'return', '结果'],
  },
  {
    cmd: '数组 .length / .push() / .pop()',
    desc: '数组长度、末尾添加、末尾删除（下标从 0 开始）',
    example: "let a = [1, 2];\na.push(3); // [1, 2, 3]",
    tags: ['数组', 'array', '长度', '添加', '删除', 'push', 'pop'],
  },
  {
    cmd: '.map() / .filter() / .forEach()',
    desc: '数组三件套：变换、筛选、逐个遍历',
    example: '[1, 2, 3].map((x) => x * 2); // [2, 4, 6]',
    tags: ['数组', 'map', 'filter', 'forEach', '遍历', '高阶函数'],
  },
  {
    cmd: '对象 .键 / ["键"]',
    desc: '对象存键值对，用点语法或中括号取值、改值',
    example: "let u = { name: '菜鸟', age: 18 };\nu.name; // '菜鸟'",
    tags: ['对象', 'object', '键值对', '属性', '取值'],
  },
  {
    cmd: 'JSON.stringify() / JSON.parse()',
    desc: '对象转 JSON 文本 / JSON 文本转回对象',
    example: 'JSON.stringify({ a: 1 }); // \'{"a":1}\'',
    tags: ['JSON', '序列化', '转换', 'stringify', 'parse', '对象'],
  },
  {
    cmd: 'Math / Date',
    desc: '数学工具与日期：取整、随机数、当前时间等',
    example: 'Math.floor(Math.random() * 10);\nnew Date().getFullYear();',
    tags: ['Math', 'Date', '随机数', '取整', '日期', '时间', '数学'],
  },
];
