import type { CmdItem } from './types';

export const sqlCommands: CmdItem[] = [
  {
    cmd: 'SELECT ... FROM',
    desc: '查询指定的列：先说要什么列，再说从哪张表',
    example: 'SELECT name, age FROM students;',
    tags: ['查询', 'select', 'from', '列', '基础'],
  },
  {
    cmd: 'SELECT *',
    desc: '查询所有列（练习方便，正式环境少用）',
    example: 'SELECT * FROM students;',
    tags: ['查询', 'select', '所有列', '星号'],
  },
  {
    cmd: 'AS / DISTINCT',
    desc: '给列起别名 / 对结果去重',
    example: 'SELECT DISTINCT city AS 城市 FROM students;',
    tags: ['别名', 'as', '去重', 'distinct'],
  },
  {
    cmd: 'WHERE 比较条件',
    desc: '按条件筛选行，相等用单个 =',
    example: "WHERE age >= 18 AND city = '北京'",
    tags: ['条件', 'where', '过滤', '筛选', '比较'],
  },
  {
    cmd: 'AND / OR',
    desc: '并且 / 或者，组合多个条件',
    example: "WHERE age >= 18 OR city = '上海'",
    tags: ['and', 'or', '逻辑', '组合条件'],
  },
  {
    cmd: 'IN / BETWEEN / LIKE',
    desc: '在清单中 / 在区间内 / 模糊匹配（% 任意字符，_ 单个字符）',
    example: "WHERE name LIKE '张%' AND age BETWEEN 18 AND 22",
    tags: ['in', 'between', 'like', '模糊', '通配符', '区间'],
  },
  {
    cmd: 'IS NULL',
    desc: '判断空值，NULL 不能用 = 比较',
    example: 'WHERE email IS NULL;',
    tags: ['null', '空值', 'is null', '判空'],
  },
  {
    cmd: 'ORDER BY ... ASC / DESC',
    desc: '排序：ASC 升序（默认），DESC 降序',
    example: 'ORDER BY age DESC, name ASC;',
    tags: ['排序', 'order by', 'asc', 'desc', '升降序'],
  },
  {
    cmd: 'LIMIT n / LIMIT 偏移, 条数',
    desc: '只取前 n 条；逗号写法用于分页',
    example: 'LIMIT 10;        -- 前 10 条\nLIMIT 20, 10;    -- 跳过 20 条再取 10 条',
    tags: ['limit', '分页', '限制', '条数', 'offset'],
  },
  {
    cmd: 'INSERT INTO ... VALUES',
    desc: '向表中插入一行新数据',
    example: "INSERT INTO students (name, age) VALUES ('菜鸟', 18);",
    tags: ['插入', '新增', 'insert', 'values', '增'],
  },
  {
    cmd: 'UPDATE ... SET ... WHERE',
    desc: '修改数据，务必带 WHERE 限定范围',
    example: 'UPDATE students SET age = 19 WHERE id = 1;',
    tags: ['修改', '更新', 'update', 'set', '改'],
  },
  {
    cmd: 'DELETE FROM ... WHERE',
    desc: '删除符合条件的数据行，务必带 WHERE',
    example: 'DELETE FROM students WHERE id = 3;',
    tags: ['删除', 'delete', '删数据', 'where'],
  },
  {
    cmd: 'COUNT / SUM / AVG / MAX / MIN',
    desc: '聚合统计：计数 / 求和 / 平均 / 最大 / 最小',
    example: 'SELECT city, COUNT(*) FROM students GROUP BY city;',
    tags: ['聚合', 'count', 'sum', 'avg', 'max', 'min', '统计'],
  },
  {
    cmd: 'GROUP BY',
    desc: '按列分组，对每组分别做聚合',
    example: 'SELECT subject, AVG(score) FROM scores GROUP BY subject;',
    tags: ['分组', 'group by', '聚合', '统计'],
  },
  {
    cmd: 'HAVING',
    desc: '过滤分组聚合后的结果（WHERE 不能放聚合函数）',
    example: 'GROUP BY city HAVING COUNT(*) > 5;',
    tags: ['having', '分组过滤', '聚合条件'],
  },
  {
    cmd: 'JOIN ... ON / LEFT JOIN',
    desc: '内连接（只留匹配行）/ 左连接（左表全保留）',
    example:
      'SELECT s.name, c.score\nFROM students s\nLEFT JOIN scores c ON s.id = c.student_id;',
    tags: ['连接', 'join', 'left join', 'on', '多表', '关联'],
  },
];
