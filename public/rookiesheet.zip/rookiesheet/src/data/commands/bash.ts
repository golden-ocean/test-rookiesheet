import type { CmdItem } from './types';

export const bashCommands: CmdItem[] = [
  {
    cmd: 'pwd',
    desc: '显示当前所在目录的完整路径（我在哪）',
    example: 'pwd',
    tags: ['路径', '当前目录', '位置', 'print working directory'],
  },
  {
    cmd: 'cd',
    desc: '切换目录；. 当前、.. 上一级、~ 家目录',
    example: 'cd ~/Documents && cd ..',
    tags: ['切换目录', '进入', '回家', '路径', 'change directory'],
  },
  {
    cmd: 'ls / ls -la',
    desc: '列出目录内容；-l 详细信息，-a 含隐藏文件',
    example: 'ls -la /home',
    tags: ['列表', '文件', '隐藏文件', '权限', 'list'],
  },
  {
    cmd: 'mkdir / touch',
    desc: 'mkdir 建目录（-p 建多层），touch 建空文件',
    example: 'mkdir -p a/b/c\ntouch index.html',
    tags: ['创建', '新建', '目录', '文件夹', '空文件', 'make directory'],
  },
  {
    cmd: 'cp',
    desc: '复制文件或目录；复制目录必须加 -r',
    example: 'cp -r photos photos_backup',
    tags: ['复制', '拷贝', 'copy', '备份', '-r'],
  },
  {
    cmd: 'mv',
    desc: '移动文件或重命名（操作目录不用加 -r）',
    example: 'mv old.txt new.txt',
    tags: ['移动', '重命名', '剪切', 'move', 'rename'],
  },
  {
    cmd: 'rm',
    desc: '删除文件；-r 删目录、-f 强制，删除不进回收站',
    example: 'rm -r old_folder',
    tags: ['删除', 'remove', '危险', '-rf', '清理'],
  },
  {
    cmd: 'cat / less',
    desc: 'cat 一次性输出全文；less 分页查看，q 退出、/ 搜索',
    example: 'less /var/log/syslog',
    tags: ['查看', '阅读', '全文', '分页', 'cat', 'less'],
  },
  {
    cmd: 'head / tail',
    desc: '看开头 / 结尾若干行；tail -f 实时跟踪新内容',
    example: 'tail -n 20 -f app.log',
    tags: ['查看', '开头', '结尾', '日志', '实时', 'head', 'tail', 'follow'],
  },
  {
    cmd: 'grep',
    desc: '按关键词过滤出行；-n 行号、-i 忽略大小写、-v 反选',
    example: 'grep -n "error" app.log',
    tags: ['搜索', '查找', '过滤', '关键词', 'grep', 'search'],
  },
  {
    cmd: '| 管道',
    desc: '把前一个命令的输出交给后一个命令处理',
    example: 'cat app.log | grep error | head -n 10',
    tags: ['管道', '组合', 'pipe', '竖线', '过滤'],
  },
  {
    cmd: 'echo',
    desc: '输出一段文本，常配合重定向写文件',
    example: 'echo "Hello Linux" > hello.txt',
    tags: ['输出', '打印', '写文件', '文本', 'echo'],
  },
  {
    cmd: 'find',
    desc: '按条件查找文件，可按名字、类型、大小搜索',
    example: 'find . -name "*.log"',
    tags: ['查找', '搜索文件', 'find', '按名查找'],
  },
  {
    cmd: 'ps aux / kill',
    desc: '查看所有进程找 PID；kill PID 结束，-9 强杀',
    example: 'ps aux | grep nginx\nkill 1234',
    tags: ['进程', 'PID', '结束进程', 'ps', 'kill', '任务'],
  },
  {
    cmd: 'top / df -h / free -h',
    desc: 'top 实时看资源；df -h 看磁盘；free -h 看内存',
    example: 'df -h\nfree -h\ntop',
    tags: ['资源', '监控', 'CPU', '内存', '磁盘', 'top', 'df', 'free'],
  },
  {
    cmd: 'chmod',
    desc: '修改权限：r=4 w=2 x=1，如 755 = rwxr-xr-x',
    example: 'chmod 755 script.sh',
    tags: ['权限', '可读可写可执行', '755', '644', 'permission'],
  },
  {
    cmd: 'sudo',
    desc: '以管理员身份执行这一条命令，别滥用',
    example: 'sudo apt update',
    tags: ['管理员', 'root', '提权', '超级用户', 'sudo'],
  },
  {
    cmd: 'tar',
    desc: '打包/解压；-czf 打包压缩，-xzf 解包',
    example: 'tar -czf site.tar.gz site/\ntar -xzf site.tar.gz',
    tags: ['压缩', '解压', '打包', '归档', 'tar', 'gz'],
  },
];
