import type { CmdItem } from './types';

export const htmlCommands: CmdItem[] = [
  {
    cmd: '<h1> ~ <h6>',
    desc: '标题，h1 最大、h6 最小',
    example: '<h1>一级标题</h1>',
    tags: ['标题', 'heading', 'text'],
  },
  {
    cmd: '<p>',
    desc: '段落',
    example: '<p>这是一段文字。</p>',
    tags: ['段落', 'paragraph', 'text'],
  },
  {
    cmd: '<a href="">',
    desc: '超链接，href 写目标地址',
    example: '<a href="https://rookiesheet.com">菜鸟速查</a>',
    tags: ['链接', 'a', 'link', '跳转'],
  },
  {
    cmd: '<img src="" alt="">',
    desc: '插入图片，alt 写替代文字',
    example: '<img src="logo.png" alt="RookieSheet">',
    tags: ['图片', 'img', 'image'],
  },
  {
    cmd: '<ul> / <ol> / <li>',
    desc: '无序/有序列表，li 是列表项',
    example: '<ul><li>苹果</li><li>香蕉</li></ul>',
    tags: ['列表', 'list'],
  },
  {
    cmd: '<table> <tr> <th> <td>',
    desc: '表格 / 行 / 表头 / 单元格',
    example: '<table><tr><th>姓名</th></tr><tr><td>菜鸟</td></tr></table>',
    tags: ['表格', 'table'],
  },
  {
    cmd: '<div> / <span>',
    desc: '无语义块级 / 行内容器',
    example: '<div class="box">内容</div>',
    tags: ['容器', '布局', 'div'],
  },
  {
    cmd: '<form action="" method="">',
    desc: '表单，action 是提交地址，method 用 get/post',
    example: '<form action="/login" method="post">…</form>',
    tags: ['表单', 'form', '提交'],
  },
  {
    cmd: '<input type="">',
    desc: '输入框：text/password/checkbox/radio/submit 等',
    example: '<input type="text" name="username" placeholder="用户名">',
    tags: ['输入框', 'input', '表单'],
  },
  {
    cmd: '<button>',
    desc: '按钮',
    example: '<button type="submit">提交</button>',
    tags: ['按钮', 'button'],
  },
  {
    cmd: '<label for="">',
    desc: '关联输入框的文字说明（for 对应 input 的 id）',
    example: '<label for="user">用户名</label><input id="user">',
    tags: ['label', '表单', '无障碍'],
  },
  {
    cmd: '<select> / <option>',
    desc: '下拉选择框',
    example: '<select name="city"><option>北京</option></select>',
    tags: ['下拉', 'select', '表单'],
  },
  {
    cmd: '<header> <nav> <main> <footer>',
    desc: '语义化结构：页头 / 导航 / 主体 / 页脚',
    example: '<main><article>正文</article></main>',
    tags: ['语义化', '布局', '结构'],
  },
  {
    cmd: '<br> / <hr>',
    desc: '换行 / 水平分隔线（自闭合）',
    example: '第一行<br>第二行<hr>',
    tags: ['换行', '分隔线'],
  },
  {
    cmd: '<strong> / <em>',
    desc: '加粗强调 / 斜体强调',
    example: '<strong>重点</strong>，<em>注意</em>',
    tags: ['加粗', '斜体', 'text'],
  },
];
