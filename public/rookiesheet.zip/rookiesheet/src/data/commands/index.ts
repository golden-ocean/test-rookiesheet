import type { CmdItem } from './types';
import { htmlCommands } from './html';
import { cssCommands } from './css';
import { javascriptCommands } from './javascript';
import { pythonCommands } from './python';
import { sqlCommands } from './sql';
import { bashCommands } from './bash';

export type { CmdItem } from './types';

export const commandsByTrack: Record<string, CmdItem[]> = {
  html: htmlCommands,
  css: cssCommands,
  javascript: javascriptCommands,
  python: pythonCommands,
  sql: sqlCommands,
  bash: bashCommands,
};

export interface SearchItem {
  track: string;
  trackTitle: string;
  kind: '命令' | '课时';
  title: string;
  desc: string;
  href: string;
  keywords: string;
}

/** 全站搜索索引（命令 + 课时），供 /search 静态内嵌 */
export function buildSearchIndex(tracks: {
  slug: string;
  title: string;
  lessons: { slug: string; title: string; summary: string }[];
}[]): SearchItem[] {
  const items: SearchItem[] = [];
  for (const track of tracks) {
    for (const cmd of commandsByTrack[track.slug] ?? []) {
      items.push({
        track: track.slug,
        trackTitle: track.title,
        kind: '命令',
        title: cmd.cmd,
        desc: cmd.desc,
        href: `/cheatsheet/${track.slug}/`,
        keywords: [cmd.cmd, cmd.desc, ...(cmd.tags ?? [])].join(' '),
      });
    }
    for (const lesson of track.lessons) {
      items.push({
        track: track.slug,
        trackTitle: track.title,
        kind: '课时',
        title: lesson.title,
        desc: lesson.summary,
        href: `/learn/${track.slug}/${lesson.slug}/`,
        keywords: `${lesson.title} ${lesson.summary}`,
      });
    }
  }
  return items;
}
