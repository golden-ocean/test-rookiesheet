import type { QuizBank } from './types';

export const htmlQuiz: QuizBank = {
  'html/01-intro': [
    {
      q: 'HTML 主要用来做什么？',
      options: [
        '给网页设置颜色和字体',
        '用标签描述网页的内容和结构',
        '操作数据库里的数据',
        '让电脑运行得更快',
      ],
      answer: 1,
      explain: 'HTML 负责「结构」，CSS 负责「样式」，JavaScript 负责「行为」。',
    },
    {
      q: '下面哪个标签表示最大号的标题？',
      options: ['<head>', '<h6>', '<h1>', '<header>'],
      answer: 2,
      explain: '<h1>~<h6> 是标题，<h1> 最大、<h6> 最小；<head> 是页面配置区，不是标题。',
    },
    {
      q: '网页中能在浏览器窗口里看到的内容，应该写在哪个标签内？',
      options: ['<head>', '<body>', '<title>', '<meta>'],
      answer: 1,
      explain: '<body> 里是页面主体（可见内容）；<head> 里放标题、编码、引入的样式等配置。',
    },
  ],
  'html/02-text-link-img': [
    {
      q: '想让文字链接跳转到 https://rookiesheet.com，正确写法是？',
      options: [
        '<link>https://rookiesheet.com</link>',
        '<a url="https://rookiesheet.com">菜鸟速查</a>',
        '<a href="https://rookiesheet.com">菜鸟速查</a>',
        '<a src="https://rookiesheet.com">菜鸟速查</a>',
      ],
      answer: 2,
      explain: '超链接用 <a>，地址写在 href 属性里；src 是图片等资源用的属性。',
    },
    {
      q: '图片加载不出来时，显示给用户看的替代文字用哪个属性？',
      options: ['title', 'alt', 'name', 'placeholder'],
      answer: 1,
      explain: 'alt 是图片的替代文字，加载失败或读屏软件都会用到，对无障碍也很重要。',
    },
    {
      q: '让链接在新标签页打开，需要给 <a> 添加什么？',
      options: [
        'target="_blank"',
        'window="new"',
        'open="_new"',
        'href="new-tab"',
      ],
      answer: 0,
      explain: 'target="_blank" 表示在新的浏览器标签页中打开链接。',
    },
  ],
  'html/03-lists-tables': [
    {
      q: '做一个「第一步、第二步、第三步」有先后顺序的清单，应使用？',
      options: ['<ul> + <li>', '<ol> + <li>', '<dl> + <dd>', '<select> + <option>'],
      answer: 1,
      explain: '<ol> 是有序列表（ordered list），自动编号；<ul> 是无序列表，显示圆点。',
    },
    {
      q: '在表格中，表头单元格和普通数据单元格分别用什么标签？',
      options: ['<th> 和 <td>', '<thead> 和 <tbody>', '<tr> 和 <td>', '<th> 和 <tr>'],
      answer: 0,
      explain: '<th> = table head 表头，<td> = table data 数据；它们都放在行 <tr> 里面。',
    },
    {
      q: '让一个单元格横向占 3 列，应该用？',
      options: ['span="3"', 'colspan="3"', 'rowspan="3"', 'width="3"'],
      answer: 1,
      explain: 'colspan 跨列（column span），rowspan 跨行（row span）。',
    },
  ],
  'html/04-forms': [
    {
      q: '让用户输入登录密码（内容显示为圆点），input 的 type 应该是？',
      options: ['text', 'hidden', 'password', 'secret'],
      answer: 2,
      explain: 'type="password" 输入内容会被遮挡；hidden 是连输入框都不显示。',
    },
    {
      q: '表单提交时，决定这条数据「叫什么名字（键名）」的是？',
      options: ['id 属性', 'name 属性', 'placeholder 属性', 'label 的文字'],
      answer: 1,
      explain: 'name="username" 提交的数据才会是 username=输入内容；id 主要给 JS/CSS 用。',
    },
    {
      q: '下面哪组标签是搭配在一起、点击文字也能聚焦输入框的正确写法？',
      options: [
        '<label text="user"> + <input id="user">',
        '<label for="user">用户名</label> + <input id="user">',
        '<label id="user"> + <input for="user">',
        '<label name="user"> + <input name="user">',
      ],
      answer: 1,
      explain: 'label 的 for 与 input 的 id 相同即可关联；placeholder 只是灰色提示，不是 label。',
    },
  ],
  'html/05-semantic': [
    {
      q: '网页最顶部的站点 Logo 和主导航，最适合放在哪个语义标签里？',
      options: ['<head>', '<top>', '<header>', '<div id="top">'],
      answer: 2,
      explain: '<header> 表示页头/区块头部；<head> 是浏览器配置区，用户看不到。',
    },
    {
      q: '下面哪个标签是无语义的纯容器，只用于分组和加样式？',
      options: ['<article>', '<section>', '<div>', '<nav>'],
      answer: 2,
      explain: '<div>（块级）和 <span>（行内）是无语义容器；其余三个都有明确含义。',
    },
    {
      q: '一篇可以独立阅读、独立分发的文章正文，最合适用？',
      options: ['<main>', '<article>', '<section>', '<aside>'],
      answer: 1,
      explain: '<article> 强调内容可独立成篇（文章/帖子/卡片）；<main> 表示页面唯一的主体区域。',
    },
  ],
  __test__: [
    {
      q: '下列标签中，自闭合（不需要结束标签）的是？',
      options: ['<p>', '<img>', '<a>', '<li>'],
      answer: 1,
      explain: '<img>、<br>、<hr>、<input> 等属于自闭合/空元素。',
    },
    {
      q: '<ol> 列表中，每一项用什么标签？',
      options: ['<item>', '<li>', '<dd>', '<row>'],
      answer: 1,
    },
    {
      q: '想在页面中画一条水平分隔线，用？',
      options: ['<br>', '<line>', '<hr>', '<separator>'],
      answer: 2,
    },
    {
      q: 'radio 单选框要实现「多选一」，多个 input 的什么属性必须相同？',
      options: ['id', 'name', 'value', 'type 之外都不用相同'],
      answer: 1,
      explain: '同名 name 的 radio 自动组成一组，同一时间只能选中一个。',
    },
    {
      q: '页面底部的版权信息最适合放在？',
      options: ['<bottom>', '<footer>', '<section>', '<foot>'],
      answer: 1,
      explain: '<footer> 表示页脚；HTML 里并没有 <bottom> 或 <foot> 标签。',
    },
    {
      q: '<strong>菜鸟速查</strong> 的默认效果是？',
      options: ['斜体', '加粗', '下划线', '删除线'],
      answer: 1,
    },
    {
      q: '提交表单的按钮，type 应该是？',
      options: ['button', 'submit', 'reset', 'send'],
      answer: 1,
    },
    {
      q: '下列关于 HTML 的说法，正确的是？',
      options: [
        '标签名大小写都允许，习惯用小写',
        '所有标签都必须写成自闭合',
        '属性必须写在结束标签里',
        '一个页面只能有一个 <div>',
      ],
      answer: 0,
      explain: 'HTML 不区分大小写，但业界统一推荐小写。',
    },
  ],
};
