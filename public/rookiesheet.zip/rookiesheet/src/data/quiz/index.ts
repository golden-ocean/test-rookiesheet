import type { QuizBank, QuizQuestion } from './types';
import { htmlQuiz } from './html';
import { cssQuiz } from './css';
import { javascriptQuiz } from './javascript';
import { pythonQuiz } from './python';
import { sqlQuiz } from './sql';
import { bashQuiz } from './bash';

const banks: Record<string, QuizBank> = {
  html: htmlQuiz,
  css: cssQuiz,
  javascript: javascriptQuiz,
  python: pythonQuiz,
  sql: sqlQuiz,
  bash: bashQuiz,
};

/** 取课时随堂测验，key 形如 html/01-intro */
export function getLessonQuiz(track: string, lessonFile: string): QuizQuestion[] {
  return banks[track]?.[lessonFile] ?? [];
}

/** 取轨道结业测验 */
export function getTrackTest(track: string): QuizQuestion[] {
  return banks[track]?.__test__ ?? [];
}
