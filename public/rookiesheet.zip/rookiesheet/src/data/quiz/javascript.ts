import type { QuizBank } from './types';

export const javascriptQuiz: QuizBank = {
  'js/01-intro': [
    {
      q: '想声明一个「之后还会被重新赋值」的变量 score，现代 JavaScript 推荐怎么写？',
      options: ['const score = 0;', 'let score = 0;', 'static score = 0;', 'score := 0;'],
      answer: 1,
      explain: '会改变的变量用 let；const 声明的是不能重新赋值的常量；var 是老写法。',
    },
    {
      q: '用 const 声明一个变量后，再给它赋一个新值，会发生什么？',
      options: [
        '静默失败，变量变成 null',
        '正常修改成功',
        '变量自动改回用 let 声明',
        '报错 TypeError，赋值失败',
      ],
      answer: 3,
      explain: 'const 声明的绑定不可重新赋值，执行赋值语句会抛出 TypeError。',
    },
    {
      q: '想在浏览器控制台打印一行文字，应该使用？',
      options: ["print('你好')", "echo '你好'", "console.log('你好')", "log.write('你好')"],
      answer: 2,
      explain: 'console.log() 是 JS 在控制台输出内容的标准方法。',
    },
  ],
  'js/02-types': [
    {
      q: '表达式 typeof null 的结果是什么？',
      options: ["'null'", "'object'", "'undefined'", "'number'"],
      answer: 1,
      explain:
        "这是 JavaScript 诞生之初的历史遗留 bug，typeof null 返回 'object'，一直保留至今。",
    },
    {
      q: "console.log('3' + 2) 会输出什么？",
      options: ['5', "'5'", "'32'", '报类型错误'],
      answer: 2,
      explain: '加号一边是字符串时执行拼接，数字 2 先转成字符串，结果是 "32"。',
    },
    {
      q: '下列比较表达式中，结果为 true 的是？',
      options: ["'1' === 1", '1 === true', "'0' === 0", "'1' == 1"],
      answer: 3,
      explain:
        '== 会做隐式类型转换，字符串 "1" 被转成数字 1，所以成立；=== 要求类型和值都相同，均为 false。新代码应一律使用 ===。',
    },
  ],
  'js/03-condition': [
    {
      q: 'if (条件) 语句中，所谓「条件成立」指的是条件求值结果为？',
      options: ['1', "字符串 'yes'", 'true', '任意非空值都算'],
      answer: 2,
      explain: '条件的结果是布尔值，只有 true（真）和 false（假）。',
    },
    {
      q: '要求「年龄满 18 岁 并且 持有门票」两个条件同时满足才能入场，正确写法是？',
      options: [
        'age >= 18 || hasTicket',
        'age >= 18 ! hasTicket',
        'age >= 18 ?? hasTicket',
        'age >= 18 && hasTicket',
      ],
      answer: 3,
      explain: '&& 是逻辑与，两边都为真结果才为真；|| 是或者，?? 是空值合并。',
    },
    {
      q: 'switch 语句中，为了防止执行完一个 case 后「穿透」继续执行后面的分支，通常要写？',
      options: ['continue', 'exit', 'break', 'stop'],
      answer: 2,
      explain: 'break 让程序跳出整个 switch；漏掉 break 会发生 case 穿透。',
    },
  ],
  'js/04-loop': [
    {
      q: 'for (let i = 0; i < 5; i++) { ... } 的循环体一共执行几次？',
      options: ['4 次', '6 次', '无限次', '5 次'],
      answer: 3,
      explain: 'i 取 0、1、2、3、4 时条件成立，共 5 次；i 变成 5 时 i < 5 不成立，循环结束。',
    },
    {
      q: '想立刻结束整个循环、不再执行后续任何一轮，应该使用？',
      options: ['continue', 'stop', 'break', 'return 0'],
      answer: 2,
      explain: 'break 直接跳出整个循环；continue 只跳过本轮剩余语句，还会进入下一轮。',
    },
    {
      q: '下列哪种场景最适合使用 while 循环？',
      options: [
        '已知要精确循环 10 次',
        '循环次数不确定，只知道「继续下去的条件」',
        '只需要执行一次的代码',
        '声明一个常量',
      ],
      answer: 1,
      explain: 'while 只判断条件真假，适合等待某个状态改变、次数未知的场景。',
    },
  ],
  'js/05-function': [
    {
      q: '函数中 return 语句的作用是？',
      options: [
        '仅打印一个值，函数继续执行',
        '声明一个函数参数',
        '跳过本轮循环',
        '把结果交回调用处，并立即结束函数',
      ],
      answer: 3,
      explain: 'return 后面的表达式就是函数的返回值；return 一执行，函数立即结束。',
    },
    {
      q: 'const double = (x) => x * 2; 调用 double(4) 的结果是？',
      options: ['4', '8', '16', 'undefined'],
      answer: 1,
      explain: '这是箭头函数，接收 x 并返回 x * 2，double(4) 即 4 * 2 = 8。',
    },
    {
      q: '在函数内部用 let 声明的变量，在函数外部访问时会？',
      options: [
        '正常访问到',
        '得到 undefined 但不报错',
        '自动变成全局变量',
        '报 ReferenceError，访问不到',
      ],
      answer: 3,
      explain: '函数内声明的变量属于函数作用域，外部无法访问，这是作用域的隔离作用。',
    },
  ],
  'js/06-array-object': [
    {
      q: "let arr = ['a', 'b', 'c']; 表达式 arr[0] 的值是？",
      options: ["'b'", "'a'", "'c'", 'undefined'],
      answer: 1,
      explain: '数组下标从 0 开始，arr[0] 是第一个元素。',
    },
    {
      q: '想在数组 nums 的末尾添加一个元素 99，应使用？',
      options: ['nums.pop(99)', 'nums.add(99)', 'nums.last(99)', 'nums.push(99)'],
      answer: 3,
      explain: 'push 在末尾添加，pop 删除末尾元素；JavaScript 数组没有 add / last 方法。',
    },
    {
      q: "let user = { name: '菜鸟', age: 18 }; 如何读取 name 属性？",
      options: ['user->name', 'user(name)', 'user.name', 'user::name'],
      answer: 2,
      explain: '对象用点语法取值：user.name；也可以写 user["name"]。',
    },
  ],
  __test__: [
    {
      q: "console.log('2' + 3 + 1) 的输出是？",
      options: ["'24'", '6', '231（数字）', "'231'"],
      answer: 3,
      explain:
        '加号从左向右结合："2" + 3 先拼成 "23"，再 + 1 拼成 "231"。若想先算算术，要加括号。',
    },
    {
      q: 'const arr = [1, 2, 3]; arr.push(4); 执行后结果是？',
      options: [
        '报错，const 数组不能改变',
        '正常执行，arr 变为 [1, 2, 3, 4]',
        'arr 变为 [4, 1, 2, 3]',
        'arr 仍为 [1, 2, 3]',
      ],
      answer: 1,
      explain:
        'const 只禁止「重新赋值」（arr = 别的东西），并不禁止修改数组内容，push 照常生效。',
    },
    {
      q: '[1, 2, 3, 4].filter((x) => x > 2) 的结果是？',
      options: ['[1, 2]', '[true, true]', '[2, 3, 4]', '[3, 4]'],
      answer: 3,
      explain: 'filter 保留让条件为 true 的元素，大于 2 的是 3 和 4。',
    },
    {
      q: '[1, 2, 3].map((x) => x * 2) 的结果是？',
      options: ['[2, 4, 6]', '[1, 2, 3, 1, 2, 3]', '6', '12'],
      answer: 0,
      explain: 'map 对每个元素做变换并返回等长的新数组：每个数都乘以 2。',
    },
    {
      q: '下列运算符中，表示「严格相等、不做类型转换」的是？',
      options: ['==', '=', '!=', '==='],
      answer: 3,
      explain: '=== 比较类型和值；== 会隐式转型；单个 = 是赋值。',
    },
    {
      q: '一个函数执行完但没有写 return，调用它得到的返回值是？',
      options: ['null', '0', 'undefined', '空字符串'],
      answer: 2,
      explain: 'JavaScript 中没有 return（或 return 后无值）的函数返回 undefined。',
    },
    {
      q: 'let user = { age: 18 }; 想把年龄改为 19，正确的是？',
      options: ['age = 19', 'user.age = 19', 'user = 19', 'user["age"] == 19'],
      answer: 1,
      explain: '修改对象属性用 对象.键 = 新值；最后一项是比较而非赋值。',
    },
    {
      q: '下列关于循环的说法，正确的是？',
      options: [
        'break 的作用是跳过本轮、继续下一轮',
        'while 的条件如果永远为 true，且没有 break，会造成死循环',
        'for 循环的下标默认从 1 开始',
        'continue 会立刻结束整个循环',
      ],
      answer: 1,
      explain:
        '条件恒真且无 break 即死循环；跳过本轮的是 continue；for 的下标通常从 0 开始。',
    },
  ],
};
