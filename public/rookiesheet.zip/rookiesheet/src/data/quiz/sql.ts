import type { QuizBank } from './types';

export const sqlQuiz: QuizBank = {
  'sql/01-select': [
    {
      q: '查询 students 表中的所有列，应使用？',
      options: [
        'SELECT all FROM students;',
        'SELECT * FROM students;',
        'GET * FROM students;',
        'SELECT students;',
      ],
      answer: 1,
      explain: '星号 * 代表所有列；基础句型是 SELECT 列 FROM 表。',
    },
    {
      q: '想让查询结果中某列的重复值只出现一次，用哪个关键字？',
      options: ['UNIQUE', 'DISTINCT', 'GROUP', 'DEDUP'],
      answer: 1,
      explain: 'DISTINCT 对结果去重，如 SELECT DISTINCT city FROM students。',
    },
    {
      q: '给列起一个临时别名让结果更好看，使用？',
      options: ['AS', 'NAME', 'ALIAS', 'LIKE'],
      answer: 0,
      explain: 'AS 起别名，如 SELECT name AS 姓名 FROM students；别名不改变真实列名。',
    },
  ],
  'sql/02-where-order': [
    {
      q: "LIKE 模式中，代表「任意多个字符」的通配符是？",
      options: ['_（下划线）', '%（百分号）', '*（星号）', '?（问号）'],
      answer: 1,
      explain: '% 匹配任意个（含 0 个）字符，_ 只匹配恰好一个字符。',
    },
    {
      q: 'ORDER BY age DESC 表示？',
      options: ['按 age 升序排列', '按 age 降序排列', '随机排列', '只保留成年人'],
      answer: 1,
      explain: 'ASC 升序（默认），DESC 降序（从大到小）。',
    },
    {
      q: 'LIMIT 5, 10 的含义是？',
      options: [
        '只取前 5 条',
        '取第 5 条到第 10 条，共 6 条',
        '跳过前 5 条，再取 10 条',
        '每页 5 条，共 10 页',
      ],
      answer: 2,
      explain: '逗号写法是 LIMIT 偏移量, 条数：先跳过 5 行，再返回 10 行。',
    },
  ],
  'sql/03-write': [
    {
      q: '向 users 表新增一行，正确语句是？',
      options: [
        'INSERT INTO users (name) VALUES ("菜鸟");',
        'ADD users ("菜鸟");',
        'INSERT users VALUES name="菜鸟";',
        'CREATE ROW users ("菜鸟");',
      ],
      answer: 0,
      explain: '插入句型是 INSERT INTO 表 (列) VALUES (值)。',
    },
    {
      q: '把 users 表中 id 为 1 的用户名字改成「大鸟」，正确写法是？',
      options: [
        'UPDATE users SET name="大鸟" WHERE id=1;',
        'UPDATE users name="大鸟" WHERE id=1;',
        'SET users.name="大鸟" WHERE id=1;',
        'MODIFY users SET name="大鸟" WHERE id=1;',
      ],
      answer: 0,
      explain: 'UPDATE 用 SET 指定新值，用 WHERE 限定要改的行。',
    },
    {
      q: '执行 DELETE FROM users;（没有 WHERE）会发生什么？',
      options: [
        '删除第一张表',
        '表中所有数据行被清空，但表结构还在',
        '数据库报错，什么都不删',
        '只删除第一行',
      ],
      answer: 1,
      explain: '不带 WHERE 的 DELETE 会清空全表数据且通常无法撤销，执行前务必确认。',
    },
  ],
  'sql/04-aggregate-join': [
    {
      q: '统计 orders 表一共有多少行，使用？',
      options: ['COUNT(rows)', 'COUNT(*)', 'SUM(*)', 'TOTAL()'],
      answer: 1,
      explain: 'COUNT(*) 统计行数；SUM 是对某列数值求和。',
    },
    {
      q: '分组之后还想筛选「人数超过 5 的城市」，应该用？',
      options: ['WHERE', 'HAVING', 'LIMIT', 'DISTINCT'],
      answer: 1,
      explain: 'WHERE 在分组前筛选行；条件里有聚合函数、要筛选分组结果时用 HAVING。',
    },
    {
      q: '用 LEFT JOIN 连接两张表时，查询结果中？',
      options: [
        '只保留两表都能匹配上的行',
        '左表的行全部保留，右表匹配不到则补 NULL',
        '右表的行全部保留，左表匹配不到则补 NULL',
        '两表数据各取一半',
      ],
      answer: 1,
      explain: 'LEFT JOIN 以左表为准全部保留，右表无匹配的列显示 NULL。',
    },
  ],
  __test__: [
    {
      q: '删除表中符合条件的数据行，使用哪条语句？',
      options: ['DELETE', 'REMOVE', 'DROP', 'DESTROY'],
      answer: 0,
      explain: '删数据用 DELETE FROM ... WHERE；DROP TABLE 是连表带结构一起删除。',
    },
    {
      q: '查询 email 列为空（没有值）的行，正确条件是？',
      options: ['email = NULL', 'email IS NULL', 'email = ""', 'email == NULL'],
      answer: 1,
      explain: 'NULL 不能用 = 比较，只能用 IS NULL 或 IS NOT NULL。',
    },
    {
      q: 'WHERE 子句在分组聚合查询中的过滤时机是？',
      options: ['分组聚合之后', '分组聚合之前，先筛选行', '排序完成之后', '结果返回之后'],
      answer: 1,
      explain: 'WHERE 在 GROUP BY 之前先筛行；分组之后筛组要用 HAVING。',
    },
    {
      q: "WHERE name LIKE '张%' 能匹配到哪些名字？",
      options: [
        '名字里任意位置含「张」',
        '以「张」开头的名字',
        '恰好两个字且姓张的名字',
        '所有名字',
      ],
      answer: 1,
      explain: '% 代表任意多个字符，张% 即「张」开头；任意位置含张应写 %张%。',
    },
    {
      q: '计算 salary 列平均值的聚合函数是？',
      options: ['MEAN(salary)', 'AVG(salary)', 'AVERAGE(salary)', 'COUNT(salary)'],
      answer: 1,
      explain: '五个聚合函数：COUNT、SUM、AVG、MAX、MIN。',
    },
    {
      q: 'JOIN 两张表时，指定关联条件使用哪个关键字？',
      options: ['WHERE', 'ON', 'BY', 'LINK'],
      answer: 1,
      explain: 'JOIN ... ON 条件，如 ON students.id = scores.student_id。',
    },
    {
      q: 'ORDER BY 后面既不写 ASC 也不写 DESC 时，默认是？',
      options: ['升序 ASC', '降序 DESC', '随机顺序', '不排序直接返回'],
      answer: 0,
      explain: '默认升序 ASC，所以 ORDER BY age 等价于 ORDER BY age ASC。',
    },
    {
      q: 'UPDATE 语句忘记写 WHERE，后果是？',
      options: [
        '只有第一行被修改',
        '整张表每一行的该列都被更新',
        '数据库报错拒绝执行',
        '只有最后一行被修改',
      ],
      answer: 1,
      explain: '改删必带 WHERE：漏掉 WHERE 的 UPDATE 会更新全表，且通常无法撤销。',
    },
  ],
};
