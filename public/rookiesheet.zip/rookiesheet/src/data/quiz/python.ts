import type { QuizBank } from './types';

export const pythonQuiz: QuizBank = {
  'py/01-intro': [
    {
      q: '想让 Python 在屏幕上显示一行文字，使用哪个函数？',
      options: ['print()', 'echo()', 'console.log()', 'printf()'],
      answer: 0,
      explain: 'print() 是 Python 的输出函数；console.log() 是 JavaScript 的写法。',
    },
    {
      q: '在 Python 中把字符串「菜鸟」存入变量 name，正确写法是？',
      options: ['name = "菜鸟"', 'let name = "菜鸟"', 'string name = "菜鸟"', 'name := "菜鸟"'],
      answer: 0,
      explain: 'Python 变量直接赋值即可，不需要 let、string 之类的声明关键字。',
    },
    {
      q: 'Python 中同一个代码块的层级归属，靠什么来表示？',
      options: ['大括号 { }', '缩进（通常 4 个空格）', '行尾的分号', 'begin 和 end'],
      answer: 1,
      explain: 'Python 用缩进表示代码归属，缩进不一致会报 IndentationError。',
    },
  ],
  'py/02-types': [
    {
      q: 'input() 从键盘读到的内容，类型永远是？',
      options: ['int 整数', 'str 字符串', 'bool 布尔', '由输入内容自动决定'],
      answer: 1,
      explain: 'input() 一律返回字符串：输入 18 得到的是 "18"，计算前要用 int() 转换。',
    },
    {
      q: 'type(3.14) 的结果是？',
      options: ["<class 'int'>", "<class 'float'>", "<class 'str'>", "<class 'bool'>"],
      answer: 1,
      explain: '带小数点的数是 float 浮点数；整数才是 int。',
    },
    {
      q: '已知 name = "菜鸟"，下面哪个是 f-string 的正确写法？',
      options: [
        'f"你好，{name}"',
        '"你好，{name}"',
        'f"你好，[name]"',
        '"你好，$name"',
      ],
      answer: 0,
      explain: 'f 字符串以 f 开头，用花括号 {} 嵌入变量，是最推荐的格式化方式。',
    },
  ],
  'py/03-condition': [
    {
      q: 'Python 中表示「否则如果」的多分支关键字是？',
      options: ['elseif', 'else if', 'elif', 'elsif'],
      answer: 2,
      explain: 'Python 把 else if 缩写成 elif：冒号换行加缩进。',
    },
    {
      q: '判断变量 score 是否等于 100，应写成？',
      options: ['score = 100', 'score == 100', 'score := 100', 'score equals 100'],
      answer: 1,
      explain: '单个 = 是赋值，判断相等要用两个等号 ==。',
    },
    {
      q: '表示「年龄大于等于 18 并且小于 60」，正确的条件是？',
      options: [
        'age >= 18 && age < 60',
        'age >= 18 and age < 60',
        'age >= 18 or age < 60',
        '18 <= age !< 60',
      ],
      answer: 1,
      explain: 'Python 的逻辑与用单词 and（不是 &&），或用 or，非用 not。',
    },
  ],
  'py/04-loop': [
    {
      q: '语句 for i in range(5): 中，i 依次取哪些值？',
      options: ['1, 2, 3, 4, 5', '0, 1, 2, 3, 4', '0 到 5 共 6 个数', '5, 4, 3, 2, 1'],
      answer: 1,
      explain: 'range(5) 从 0 开始产生 5 个数：0、1、2、3、4。',
    },
    {
      q: 'range(1, 10) 生成的整数范围是？',
      options: ['1 到 10', '0 到 9', '1 到 9', '0 到 10'],
      answer: 2,
      explain: 'range 含头不含尾：包含起始值 1，不包含结束值 10。',
    },
    {
      q: '在循环中想「立刻结束整个循环」，使用？',
      options: ['break', 'continue', 'exit', 'stop'],
      answer: 0,
      explain: 'break 立即跳出整个循环；continue 只跳过本轮剩余语句，继续下一轮。',
    },
  ],
  'py/05-function': [
    {
      q: 'Python 中定义函数使用哪个关键字？',
      options: ['function', 'def', 'func', 'define'],
      answer: 1,
      explain: '定义函数写作 def 函数名(参数):，换行后缩进写函数体。',
    },
    {
      q: '函数里没有写 return，调用它会得到什么？',
      options: ['0', '空字符串', 'None', '直接报错'],
      answer: 2,
      explain: '没有 return 的函数默认返回 None，表示「什么都没有」。',
    },
    {
      q: 'def greet(name="菜鸟"): 定义后直接调用 greet()，name 的值是？',
      options: ['报错，必须传参', '"菜鸟"', 'None', '空字符串'],
      answer: 1,
      explain: '默认参数在调用时不传参就自动使用默认值 "菜鸟"。',
    },
  ],
  'py/06-list-dict': [
    {
      q: '列表 nums = [10, 20, 30]，nums[0] 的值是？',
      options: ['10', '20', '30', '报错'],
      answer: 0,
      explain: 'Python 下标从 0 开始，nums[0] 是第一个元素 10。',
    },
    {
      q: 'nums = [1, 2, 3, 4]，nums[0:2] 得到的是？',
      options: ['[1, 2]', '[1, 2, 3]', '[2, 3]', '[0, 1]'],
      answer: 0,
      explain: '切片含头不含尾：取下标 0 和 1，不到下标 2。',
    },
    {
      q: 'user = {"name": "菜鸟", "age": 18}，如何取出姓名？',
      options: ['user("name")', 'user["name"]', 'user->name', 'user.name'],
      answer: 1,
      explain: '字典用「变量[键]」取值；普通字典不能用点语法取值。',
    },
  ],
  __test__: [
    {
      q: 'Python 中单行注释以什么开头？',
      options: ['#', '//', '--', '/*'],
      answer: 0,
      explain: '# 后面是注释，运行时会被忽略；// 和 -- 是其他语言的注释符。',
    },
    {
      q: '表达式 "3" + "5" 的结果是？',
      options: ['8（整数）', '"35"（字符串拼接）', '35（整数）', '类型报错'],
      answer: 1,
      explain: '两个字符串相加是拼接而不是加法；要算数先 int() 转换。',
    },
    {
      q: 'print(len([10, 20, 30])) 输出什么？',
      options: ['2', '3', '30', '报错'],
      answer: 1,
      explain: 'len() 返回列表元素个数，这个列表有 3 个元素。',
    },
    {
      q: 'nums = [10, 20, 30]，nums[-1] 表示？',
      options: ['第一个元素 10', '最后一个元素 30', '倒数第二个元素 20', '语法错误'],
      answer: 1,
      explain: '负数下标从后往前数，-1 就是最后一个元素。',
    },
    {
      q: 'range(0, 10, 2) 依次产生哪些数？',
      options: ['0, 2, 4, 6, 8', '2, 4, 6, 8, 10', '0 到 9 的全部整数', '0, 2, 4, 6, 8, 10'],
      answer: 0,
      explain: '第三个参数是步长；range 仍含头不含尾，所以没有 10。',
    },
    {
      q: '下面哪个不是 Python 的合法变量名？',
      options: ['user_name', '_age', '2name', 'name2'],
      answer: 2,
      explain: '变量名不能以数字开头，2name 不合法。',
    },
    {
      q: '执行 int("7") + 3 的结果是？',
      options: ['"73"', '10（整数）', '"10"', '73'],
      answer: 1,
      explain: 'int("7") 把字符串转成整数 7，再加 3 得 10。',
    },
    {
      q: '关于 while 循环，下面说法正确的是？',
      options: [
        'while 循环至少会执行一次',
        '条件为 True 时反复执行，循环体要让条件最终变 False',
        'while 不能和 break 一起使用',
        'while 只能用来遍历数字',
      ],
      answer: 1,
      explain: 'while 条件成立就继续；条件永远为 True 且没有 break 会变成死循环。',
    },
  ],
};
