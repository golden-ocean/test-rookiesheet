export interface QuizQuestion {
  /** 题干 */
  q: string;
  /** 选项（4 个，answer 为正确项下标） */
  options: [string, string, string, string];
  answer: 0 | 1 | 2 | 3;
  /** 解析（答题后展示） */
  explain?: string;
}

/** key = 课时条目 id（如 html/01-intro）或 '__test__' 轨道测验 */
export type QuizBank = Record<string, QuizQuestion[]>;
