import type { QuizBank } from './types';

export const bashQuiz: QuizBank = {
  'bash/01-files': [
    {
      q: '想知道自己当前处于哪个目录，应执行哪条命令？',
      options: ['cd', 'ls', 'pwd', 'whoami'],
      answer: 2,
      explain: 'pwd（print working directory）打印当前工作目录的完整路径。',
    },
    {
      q: '想回到当前目录的上一级目录，正确命令是？',
      options: ['cd .', 'cd ..', 'cd /', 'cd --'],
      answer: 1,
      explain: '.. 表示上一级目录，. 表示当前目录，~ 表示家目录。',
    },
    {
      q: '把文件夹 dir1 整个复制为 dir2，正确的命令是？',
      options: ['cp -r dir1 dir2', 'mv dir1 dir2', 'cp dir1 dir2', 'copy dir1 dir2'],
      answer: 0,
      explain: '复制目录必须加 -r（recursive 递归），把目录内所有内容一起复制。',
    },
  ],
  'bash/02-text': [
    {
      q: '文件很大，想翻页查看内容并支持搜索关键词，最合适的命令是？',
      options: ['cat big.log', 'touch big.log', 'mkdir big.log', 'less big.log'],
      answer: 3,
      explain: 'less 是分页阅读器，按 / 搜索、按 q 退出；cat 会一次性全部输出。',
    },
    {
      q: '在 less 浏览界面中，想退出回到命令行，应按哪个键？',
      options: ['Esc', 'x', 'q', 'w'],
      answer: 2,
      explain: '按 q（quit）退出 less；其他常用键还有空格翻页、/ 搜索。',
    },
    {
      q: '想持续盯着日志文件、有新内容追加时实时显示，应使用？',
      options: ['cat app.log', 'head app.log', 'ls -f app.log', 'tail -f app.log'],
      answer: 3,
      explain: 'tail -f 会 follow 文件变化，实时输出新增内容，按 Ctrl + C 停止。',
    },
  ],
  'bash/03-system': [
    {
      q: '想查找名为 nginx 的进程并拿到它的 PID，常用命令是？',
      options: ['ls nginx', 'find nginx --pid', 'ps aux | grep nginx', 'cd nginx'],
      answer: 2,
      explain: 'ps aux 列出所有进程，再通过管道交给 grep 过滤出含 nginx 的行，第二列即 PID。',
    },
    {
      q: 'chmod 755 script.sh 中，数字 7（第一位）表示什么权限？',
      options: ['读写执行 rwx', '只读 r--', '只写 -w-', '只执行 --x'],
      answer: 0,
      explain: 'r=4、w=2、x=1，7 = 4+2+1 即 rwx；三个数字依次对应属主、属组、其他人。',
    },
    {
      q: 'sudo 命令的作用是？',
      options: [
        '删除一个文件',
        '切换到上一级目录',
        '查看文件内容',
        '以管理员（root）身份执行这一条命令',
      ],
      answer: 3,
      explain: 'sudo 临时提权执行单条命令，执行系统级操作时才需要，不应滥用。',
    },
  ],
  __test__: [
    {
      q: '想以长格式列出当前目录所有文件（含隐藏文件），应使用？',
      options: ['ls', 'ls -h', 'ls -la', 'pwd -a'],
      answer: 2,
      explain: '-l 显示详细信息，-a 显示以 . 开头的隐藏文件，可合写为 -la。',
    },
    {
      q: '表示当前用户「家目录」的特殊符号是？',
      options: ['.', '~', '..', '/'],
      answer: 1,
      explain: '~ 是家目录；. 是当前目录，.. 是上一级，/ 是系统根目录。',
    },
    {
      q: '想删除一个非空目录 olddir 及其内部所有内容，应使用？',
      options: ['rm olddir', 'delete olddir', 'mv olddir /dev/null', 'rm -r olddir'],
      answer: 3,
      explain: 'rm 加 -r 递归删除目录；操作前务必确认路径，命令行删除不进回收站。',
    },
    {
      q: '管道符（把前一个命令的输出交给后一个命令处理）是哪个符号？',
      options: ['>', '|', '//', '&&'],
      answer: 1,
      explain: '竖线 | 是管道符，例如 cat a.log | grep error。',
    },
    {
      q: '查看磁盘各分区使用情况（带易读单位），命令是？',
      options: ['df -h', 'free -h', 'du -h', 'top -h'],
      answer: 0,
      explain: 'df -h 报告磁盘分区占用；free -h 看内存；top 看进程实时资源。',
    },
    {
      q: '在 Linux 权限的数字表示中，可执行权限 x 对应数字几？',
      options: ['4', '2', '0', '1'],
      answer: 3,
      explain: 'r=4、w=2、x=1，一组权限的数字相加即得，如 r-x = 5。',
    },
    {
      q: 'mkdir -p a/b/c 的作用是？',
      options: [
        '删除 a/b/c 目录',
        '给目录设置 755 权限',
        '一次性递归创建多层嵌套目录',
        '查看 a/b/c 的内容',
      ],
      answer: 2,
      explain: '-p（parents）会自动补全路径中尚不存在的父目录。',
    },
    {
      q: '普通 kill PID 无法结束一个卡死的进程时，可使用的强制手段是？',
      options: ['stop PID', 'kill -9 PID', 'exit PID', 'rm -f PID'],
      answer: 1,
      explain: 'kill -9 发送 SIGKILL 信号强制终止进程，但不给保存数据的机会，应作为最后手段。',
    },
  ],
};
