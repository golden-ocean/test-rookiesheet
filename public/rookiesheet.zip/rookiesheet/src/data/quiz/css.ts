import type { QuizBank } from './types';

export const cssQuiz: QuizBank = {
  'css/01-intro': [
    {
      q: '在 CSS 代码 h1 { color: red; } 中，h1 的作用是？',
      options: [
        '声明一个属性名',
        '选中要修改的元素（选择器）',
        '给出属性的值',
        '引入外部样式表',
      ],
      answer: 1,
      explain: 'h1 是选择器，选中所有一级标题；color 是属性，red 是值。',
    },
    {
      q: '正式项目中把样式写在单独的 style.css 文件里，HTML 应该如何引入？',
      options: [
        '<style src="style.css"></style>',
        '<link rel="stylesheet" href="style.css">',
        '<css href="style.css"></css>',
        '在每个标签上加 css="style.css"',
      ],
      answer: 1,
      explain: '外部样式表用 <link> 引入，rel="stylesheet" 是固定写法。',
    },
    {
      q: 'CSS 中 .nav a { color: red; }（.nav 和 a 之间有空格）会选中谁？',
      options: [
        '页面上所有 a 元素和所有 .nav 元素',
        'class 为 nav 的元素内部的所有 a 元素',
        '同时具有 nav 类的 a 元素',
        'class 为 nav 的元素后面的第一个 a 元素',
      ],
      answer: 1,
      explain: '空格是后代选择器，表示「……里面的」；逗号才是群组选择器。',
    },
  ],
  'css/02-box-text': [
    {
      q: 'CSS 盒模型由内向外的正确排列顺序是？',
      options: [
        'content → padding → border → margin',
        'content → border → padding → margin',
        'margin → padding → border → content',
        'content → margin → border → padding',
      ],
      answer: 0,
      explain: '由内向外依次是内容区、内边距 padding、边框 border、外边距 margin。',
    },
    {
      q: 'padding: 5px 10px 15px 20px; 中，元素左侧的内边距是多少？',
      options: ['5px', '10px', '15px', '20px'],
      answer: 3,
      explain: '四个值按顺时针「上、右、下、左」排列，左边对应第 4 个值 20px。',
    },
    {
      q: '设置 box-sizing: border-box 后，width: 200px 表示什么？',
      options: [
        '内容区宽 200px，padding 和 border 会额外把盒子撑大',
        '盒子最终总宽 200px，padding 和 border 往里占、不撑大盒子',
        '边框的宽度固定为 200px',
        '连外边距 margin 也算进 200px 之内',
      ],
      answer: 1,
      explain: 'border-box 下 width 包含内容、padding 和 border；margin 永远不计入宽度。',
    },
  ],
  'css/03-flex': [
    {
      q: '开启 Flex 弹性布局的正确做法是？',
      options: [
        '在父容器上设置 display: flex',
        '在每个子元素上设置 flex: true',
        '在父容器上设置 position: flex',
        '在子元素上设置 float: flex',
      ],
      answer: 0,
      explain: '在父容器写 display: flex，其直接子元素就成为弹性项目并自动横排。',
    },
    {
      q: '让 Flex 容器中的子块在容器内水平垂直都居中，容器应写？',
      options: [
        'justify-content: center; align-items: center;',
        'text-align: center; vertical-align: middle;',
        'margin: auto 0;',
        'float: center;',
      ],
      answer: 0,
      explain: 'justify-content 管主轴（默认水平），align-items 管交叉轴（默认垂直），都设 center 即双向居中。',
    },
    {
      q: '在 Flex 子项目上设置 flex: 1 的效果是？',
      options: [
        '项目固定占 1px 宽',
        '项目被隐藏不显示',
        '项目弹性伸展，平分剩余空间',
        '项目被挤到第二行',
      ],
      answer: 2,
      explain: 'flex: 1 让项目自动伸展吃掉剩余空间；两个 flex: 1 各占一半，三个就三等分。',
    },
  ],
  'css/04-grid': [
    {
      q: 'grid-template-columns: repeat(3, 1fr); 表示什么？',
      options: [
        '3 行，每行高度为 1fr',
        '3 列等宽，平分容器宽度',
        '3 列，每列固定宽 1px',
        '只有第 3 列宽 1fr，其余列宽为 0',
      ],
      answer: 1,
      explain: 'repeat(3, 1fr) 表示重复 3 个 1fr，即三列等宽；fr 是剩余空间的份额。',
    },
    {
      q: 'Grid 布局中 fr 单位的含义是？',
      options: [
        '一个固定像素值',
        '相对于根元素字号的单位',
        '剩余空间的份额（比例单位）',
        '屏幕分辨率的计量单位',
      ],
      answer: 2,
      explain: 'fr 是 fraction（份额），按比例分配容器剩余空间，如 2fr 1fr 即 2:1。',
    },
    {
      q: '要做一个同时有多行多列的产品卡片墙，最合适的布局方式是？',
      options: ['Grid 网格布局', 'float 浮动', 'table 表格', '只写一个 Flex 容器'],
      answer: 0,
      explain: '一维排列用 Flex，二维网格用 Grid；卡片墙是典型的行列二维布局。',
    },
  ],
  'css/05-responsive': [
    {
      q: '@media (max-width: 768px) { ... } 中的规则什么时候生效？',
      options: [
        '屏幕宽度大于 768px 时',
        '屏幕宽度不超过 768px 时',
        '任何时候都生效',
        '只在打印网页时生效',
      ],
      answer: 1,
      explain: 'max-width: 768px 表示宽度上限 768px，即屏宽 ≤ 768px 的窄屏才生效。',
    },
    {
      q: '「移动优先（Mobile First）」推荐的写法是？',
      options: [
        '先写大屏样式，再用 max-width 回头适配小屏',
        '先写小屏默认样式，再用 min-width 逐步为大屏增强',
        '手机和电脑各写一份完全独立的 CSS 文件',
        '用 JavaScript 判断手机型号再换样式',
      ],
      answer: 1,
      explain: '移动优先：默认样式服务最小屏幕，再用 min-width 断点一层层为更宽的屏幕增强。',
    },
    {
      q: '让大图在手机上不撑破容器、按比例缩小，最简单有效的是？',
      options: [
        'img { max-width: 100%; height: auto; }',
        'img { width: 1920px; }',
        'img { display: none; }',
        '给图片设置固定的 margin',
      ],
      answer: 0,
      explain: 'max-width: 100% 让图片最多占满容器宽度，height: auto 保持比例，可防止横向溢出。',
    },
  ],
  __test__: [
    {
      q: '三种 CSS 引入方式中，优先级最高、且只作用于当前这一个元素的是？',
      options: ['外部样式表 <link>', '内部样式表 <style>', '行内样式 style 属性', '三者完全一样'],
      answer: 2,
      explain: '行内样式写在元素的 style 属性里，优先级最高，但只影响该元素，难以维护。',
    },
    {
      q: '#logo { width: 80px; } 中的 #logo 属于哪种选择器？',
      options: ['标签选择器', 'class 选择器', 'id 选择器', '伪类选择器'],
      answer: 2,
      explain: '# 开头选 id，. 开头选 class，光写名字选标签；id 在一个页面中应唯一。',
    },
    {
      q: '想让链接在鼠标悬停时变成红色，应该使用哪个伪类？',
      options: [
        'a:hover { color: red; }',
        'a:click { color: red; }',
        'a.mouse { color: red; }',
        'hover(a) { color: red; }',
      ],
      answer: 0,
      explain: ':hover 表示鼠标悬停状态，是最常用的伪类之一。',
    },
    {
      q: '上方块 margin-bottom: 20px，下方块 margin-top: 30px，它们之间的实际间距是？',
      options: ['50px', '30px', '20px', '10px'],
      answer: 1,
      explain: '相邻块级元素的上下外边距会折叠，取较大值 30px，而不是相加。',
    },
    {
      q: '在 Flex 或 Grid 容器中设置相邻项目间距、且首尾不产生额外空隙，用哪个属性？',
      options: ['gap', 'margin', 'padding', 'space'],
      answer: 0,
      explain: 'gap 只在项目之间产生间距；margin 会在首尾也留出空隙，CSS 中没有 space 属性。',
    },
    {
      q: 'Grid 项目设置 grid-column: span 2 的含义是？',
      options: ['横跨 2 列', '纵跨 2 行', '宽度固定为 2px', '跳过前面的 2 个格子'],
      answer: 0,
      explain: 'span 2 表示跨越 2 个格子；grid-column 控制横向，grid-row 控制纵向。',
    },
    {
      q: '响应式开发中，768px 这个断点通常用来区分什么？',
      options: [
        '手机/小平板 与 更宽的屏幕',
        '黑白屏幕与彩色屏幕',
        '横屏显示与打印输出',
        '鼠标用户与键盘用户',
      ],
      answer: 0,
      explain: '常用断点是 768px（平板分界）和 1024px（桌面分界）。',
    },
    {
      q: '下列关于 CSS 布局的说法，正确的是？',
      options: [
        '一维排列用 Flex，二维网格用 Grid',
        '手机页面应把容器写死 width: 1200px',
        '相邻块级元素的上下 margin 一定会相加',
        '同一个 class 在一个页面里只能使用一次',
      ],
      answer: 0,
      explain: 'Flex 管一维、Grid 管二维；固定大宽度会在手机上溢出，margin 会折叠，class 可复用。',
    },
  ],
};
