// MDX 内容专用组件入口：
// import { Callout, Quiz, TryIt } from '../../kit';
export { default as Callout } from '../components/Callout.astro';
export { default as Quiz } from '../components/Quiz.astro';
export { default as TryIt } from '../components/TryIt.astro';
