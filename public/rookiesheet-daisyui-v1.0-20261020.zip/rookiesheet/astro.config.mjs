import { defineConfig } from 'astro/config';
import tailwindcss from '@tailwindcss/vite';
import react from '@astrojs/react';
import mdx from '@astrojs/mdx';
import sitemap from '@astrojs/sitemap';

// https://astro.build/config
export default defineConfig({
  // 站点域名：rookiesheet
  site: 'https://rookiesheet.com',
  // 输出纯静态站点
  output: 'static',
  integrations: [react(), mdx(), sitemap()],
  vite: {
    plugins: [tailwindcss()],
  },
  // i18n 配置：默认中文，支持中英双语
  i18n: {
    defaultLocale: 'zh',
    locales: ['zh', 'en'],
    routing: {
      prefixDefaultLocale: false,
    },
  },
  markdown: {
    // Shiki 代码高亮：代码区始终深色，对比清晰
    shikiConfig: {
      theme: 'github-dark-default',
      wrap: true,
    },
  },
});
