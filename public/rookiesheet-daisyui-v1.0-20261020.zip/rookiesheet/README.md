# RookieSheet

> 面向菜鸟的编程语言快速命令查询与用法讲解站点。像查字典一样查命令，学完立刻测，答对撒花。

基于 **Astro + Tailwind CSS 4 + daisyUI 5** 构建，全站静态化，支持 **中英双语（i18n）**、**深浅主题切换**、**Shiki 代码高亮** 与 **canvas-confetti 撒花特效**。

---

## ✨ 核心特性

| 特性 | 说明 |
| --- | --- |
| **左中右三栏排版** | 左侧语言目录导航（按难度 L1–L4 标注）、中间教程正文、右侧速查卡（本页导航 / 记忆要点 / 易错点 / 去测验） |
| **由易到难的路径** | 每门语言按 `入门基础 → 控制流程 → 数据结构 → 进阶技巧` 分组，编号递进，不迷路 |
| **重点语法高亮** | 荧光标记（`.hl-mark`）+ 右侧记忆卡 + 易错点清单，三重强化记忆 |
| **代码高亮** | Astro 内置 Shiki，代码区**始终深色**（`github-dark-default`），正文可浅可深 |
| **随堂测验 + 撒花** | 每章配单选测验，答对即时 `canvas-confetti` 撒花，满分触发星星雨 + 双侧彩炮 |
| **中英双语 i18n** | 默认中文（无前缀 `/`），英文走 `/en`；顶部一键切换，SEO 带 `hreflang` |
| **深浅主题** | daisyUI `data-theme` 机制 + 首帧前注入防闪烁脚本，偏好持久化到 `localStorage`，代码块不受影响 |
| **学习进度** | 「标记为已学会」写入本地，左栏进度条与计数实时更新 |
| **内容用 MDX 管理** | 教程存于 `src/content/docs/{lang}/{language}/*.mdx`，改内容无需碰代码 |
| **全静态输出** | `astro build` 产出纯静态 HTML，可直接托管到任何 CDN / 静态空间 |

---

## 🧱 技术栈

- **Astro 7**（`output: 'static'`，内置 Content Collections + Shiki）
- **Tailwind CSS 4**（CSS-first 配置，无需 `tailwind.config.js`）
- **daisyUI 5** 组件层 + 内置 `light` / `dark` 双主题（`data-theme` 切换）
- **React 19** 岛（仅交互组件：主题切换、测验、语言切换）
- **lucide-react** 图标 · **canvas-confetti** 撒花
- **@astrojs/mdx**、**@astrojs/sitemap**

---

## 📁 目录结构

```
src/
├─ components/
│  ├─ layout/          # header / footer / sidebar / quick-panel / 主题与语言切换
│  ├─ learn/           # doc-page（文档渲染）/ docs-index / home / code-block
│  ├─ quiz/            # quiz.tsx（测验岛）+ confetti.ts（撒花特效）
│  └─ ui/              # shadcn 风格基础组件：button / card / badge / slot
├─ content/
│  ├─ docs/{zh,en}/javascript/*.mdx   # 教程正文（前端元数据驱动导航与速查卡）
│  ├─ quizzes/index.ts                 # 中英双语题库
│  └─ cheatsheet.ts                    # 速查表数据
├─ i18n/               # config.ts / ui.ts（词条）/ languages.ts（语言元数据）
├─ layouts/            # base-layout / doc-layout（三栏）
├─ lib/                # utils（cn）/ content（导航、TOC、解析）
└─ pages/              # index / docs/[language]/[slug] / cheatsheet / en/* / 404
```

---

## 🚀 本地开发

```bash
pnpm install       # 安装依赖
pnpm dev           # 开发服务器 http://localhost:4321
pnpm build         # 构建静态站点到 dist/
pnpm preview       # 本地预览构建产物
```

---

## ✍️ 新增一篇教程

在 `src/content/docs/zh/javascript/` 下新建 `12-xxx.mdx`（英文同步放 `en/javascript/`）：

```mdx
---
title: 标题
description: 一句话说明
language: javascript
group: 进阶技巧        # 决定左侧导航分组
order: 12             # 组内与全局排序
level: 3              # 1 入门 / 2 基础 / 3 进阶 / 4 高级
readTime: 6
keyPoints:            # 右侧速查卡
  - label: 要点名
    value: 语法片段
    note: 补充说明
highlights:           # 右侧「记忆要点」
  - 一句需要记住的结论
pitfalls:             # 右侧「易错点」
  - 常见错误提示
---

## 小节标题

正文……（代码块用 ```js 自动高亮）
```

**加测验**：在 `src/content/quizzes/index.ts` 增加 `'zh/javascript/12-xxx'` 键，值为题目数组（`question / options / answer 索引 / explanation`）。答对即自动触发撒花。

---

## 🎨 主题与配色

设计令牌集中在 `src/styles/global.css` 的 `:root` 与 `.dark` 中，改主色只需调整 `--primary`。代码块深色常量在 `tailwind.config.mjs` 的 `colors.code`。

---

## 📦 构建产物

`pnpm build` 输出：

- `dist/index.html`、`dist/en/index.html` — 中英文首页
- `dist/docs/javascript/*/`、`dist/en/docs/javascript/*/` — 22 篇教程页
- `dist/cheatsheet/`、`dist/en/cheatsheet/` — 速查表
- `dist/sitemap-index.xml`、`dist/404.html`

共 **29 个静态页面**。

---

## 📄 License

MIT
