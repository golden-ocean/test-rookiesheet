import { getCollection, type CollectionEntry } from 'astro:content';
import type { Lang } from '@/i18n/config';
import { localizePath } from '@/i18n/config';

export interface DocMeta {
  slug: string;
  lang: Lang;
  language: string;
  title: string;
  description?: string;
  group: string;
  order: number;
  level: number;
  readTime: number;
  href: string;
}

/** 解析 content id：zh/javascript/01-hello-world → { lang, language, slug } */
export function parseDocId(id: string) {
  const parts = id.split('/');
  const lang = parts[0] as Lang;
  const language = parts[1];
  const slug = parts.slice(2).join('/');
  return { lang, language, slug };
}

/** 取某语言 + 某编程语言的全部文档 */
export async function getDocs(lang: Lang, language = 'javascript'): Promise<DocMeta[]> {
  const entries = await getCollection('docs', (e) => !e.data.draft);
  return entries
    .map((e: CollectionEntry<'docs'>) => {
      const { lang: l, language: lg, slug } = parseDocId(e.id);
      return {
        slug,
        lang: l,
        language: lg,
        title: e.data.title,
        description: e.data.description,
        group: e.data.group,
        order: e.data.order,
        level: e.data.level,
        readTime: e.data.readTime,
        href: localizePath(`/docs/${lg}/${slug}`, l),
      } satisfies DocMeta;
    })
    .filter((d) => d.lang === lang && d.language === language)
    .sort((a, b) => a.order - b.order);
}

/** 把文档按 group 分组，用于左侧导航 */
export function groupDocs(docs: DocMeta[], currentSlug?: string) {
  const map = new Map<string, DocMeta[]>();
  for (const d of docs) {
    if (!map.has(d.group)) map.set(d.group, []);
    map.get(d.group)!.push(d);
  }
  return [...map.entries()].map(([group, items]) => ({
    group,
    items: items.map((d) => ({
      title: d.title,
      href: d.href,
      order: d.order,
      level: d.level,
      active: d.slug === currentSlug,
    })),
  }));
}

/** 提取 markdown 正文的 h2/h3 作为右侧 TOC */
export function extractToc(body: string) {
  const lines = body.split('\n');
  const toc: { depth: number; slug: string; text: string }[] = [];
  let inCode = false;
  for (const line of lines) {
    if (line.trim().startsWith('```')) {
      inCode = !inCode;
      continue;
    }
    if (inCode) continue;
    const m = /^(#{2,3})\s+(.*)$/.exec(line);
    if (m) {
      const depth = m[1].length;
      const text = m[2].replace(/[`*_]/g, '').trim();
      const slug = slugifyHeading(m[2].trim());
      toc.push({ depth, slug, text });
    }
  }
  return toc;
}

/** 与 Astro 默认标题锚点规则保持一致 */
export function slugifyHeading(text: string) {
  return text
    .toLowerCase()
    .replace(/[`*_[\]()]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\p{L}\p{N}-]/gu, '');
}

/** 粗略统计代码示例数量（用于首页展示） */
export function countCodeBlocks(body: string) {
  return (body.match(/```/g)?.length ?? 0) / 2;
}
