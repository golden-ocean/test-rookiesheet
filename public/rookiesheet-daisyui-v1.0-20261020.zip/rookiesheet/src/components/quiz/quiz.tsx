import * as React from 'react';
import { Check, X, RotateCcw, ChevronRight, Sparkles, Trophy, Lightbulb } from 'lucide-react';
import { cn } from '@/lib/utils';
import { celebrate, smallCheer } from './confetti';

export interface QuizQuestion {
  id: string;
  /** 题干 */
  question: string;
  /** 单选选项 */
  options: string[];
  /** 正确选项索引 */
  answer: number;
  /** 解析 */
  explanation?: string;
  /** 代码片段（可选，用于阅读型题目） */
  code?: string;
}

interface Props {
  questions: QuizQuestion[];
  labels: {
    title: string;
    subtitle: string;
    question: string;
    of: string;
    check: string;
    next: string;
    retry: string;
    correct: string;
    correctMsg: string;
    wrong: string;
    wrongMsg: string;
    explanation: string;
    score: string;
    finished: string;
    finishedMsg: string;
    restart: string;
    selectHint: string;
    perfect: string;
    good: string;
    keepGoing: string;
  };
}

export function Quiz({ questions, labels }: Props) {
  const [index, setIndex] = React.useState(0);
  const [selected, setSelected] = React.useState<number | null>(null);
  const [checked, setChecked] = React.useState(false);
  const [correctCount, setCorrectCount] = React.useState(0);
  const [done, setDone] = React.useState(false);
  const [shake, setShake] = React.useState(false);
  const btnRef = React.useRef<HTMLButtonElement>(null);
  const wrapRef = React.useRef<HTMLDivElement>(null);

  const total = questions.length;
  const q = questions[index];

  if (!total) {
    return (
      <div className="rounded-box border border-dashed border-base-300 p-6 text-center text-sm text-base-content/50">
        {labels.title}
      </div>
    );
  }

  const isCorrect = checked && selected === q.answer;

  const handleCheck = () => {
    if (selected === null) {
      setShake(true);
      setTimeout(() => setShake(false), 450);
      return;
    }
    setChecked(true);
    if (selected === q.answer) {
      setCorrectCount((c) => c + 1);
      smallCheer(btnRef.current ?? wrapRef.current);
    }
  };

  const handleNext = () => {
    if (index + 1 >= total) {
      setDone(true);
      setTimeout(() => celebrate(correctCount, total), 60);
      return;
    }
    setIndex((i) => i + 1);
    setSelected(null);
    setChecked(false);
  };

  const handleRetry = () => {
    setSelected(null);
    setChecked(false);
  };

  const handleRestart = () => {
    setIndex(0);
    setSelected(null);
    setChecked(false);
    setCorrectCount(0);
    setDone(false);
  };

  // ---------- 完成页 ----------
  if (done) {
    const ratio = correctCount / total;
    const msg = ratio === 1 ? labels.perfect : ratio >= 0.6 ? labels.good : labels.keepGoing;
    return (
      <div
        ref={wrapRef}
        className="animate-pop bg-base-100 rounded-box border border-base-300 p-6 text-center"
      >
        <div className="bg-success/15 mx-auto mb-3 grid size-14 place-items-center rounded-full">
          <Trophy className="text-success size-7" />
        </div>
        <h3 className="text-lg font-bold">{labels.finished}</h3>
        <p className="mt-1 text-sm text-base-content/60">
          {labels.finishedMsg
            .replace('{correct}', String(correctCount))
            .replace('{total}', String(total))}
        </p>

        <div
          className="radial-progress text-primary mx-auto my-4 font-black tabular-nums"
          style={{
            '--value': Math.round(ratio * 100),
            '--size': '5.5rem',
            '--thickness': '6px',
          } as React.CSSProperties}
          role="progressbar"
          aria-valuenow={Math.round(ratio * 100)}
        >
          {Math.round(ratio * 100)}%
        </div>

        <p className="text-sm font-medium">{msg}</p>
        <div className="mt-5 flex justify-center gap-2">
          <button type="button" className="btn btn-outline btn-sm gap-1.5" onClick={handleRestart}>
            <RotateCcw className="size-4" />
            {labels.restart}
          </button>
          <button
            type="button"
            className="btn btn-primary btn-sm gap-1.5"
            onClick={() => celebrate(correctCount, total)}
          >
            <Sparkles className="size-4" />
            {labels.correct}
          </button>
        </div>
      </div>
    );
  }

  // ---------- 答题页 ----------
  const pct = Math.round(((index + (checked ? 1 : 0)) / total) * 100);

  return (
    <div
      ref={wrapRef}
      className={cn(
        'bg-base-100 overflow-hidden rounded-box border border-base-300',
        shake && 'animate-shake'
      )}
    >
      {/* 头部：进度 */}
      <div className="bg-base-200/60 border-b border-base-300 px-5 py-3.5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Sparkles className="text-primary size-4" />
            {labels.title}
          </div>
          <div className="text-xs font-medium tabular-nums text-base-content/55">
            {labels.question.replace('{n}', String(index + 1))} ·{' '}
            {labels.of.replace('{total}', String(total))}
          </div>
        </div>
        <progress
          className="progress progress-primary mt-2.5 h-1.5 w-full"
          value={pct}
          max={100}
        ></progress>
      </div>

      <div className="p-5">
        <p className="text-[15px] leading-relaxed font-medium">{q.question}</p>

        {q.code && (
          <pre className="mt-3 overflow-x-auto rounded-lg border border-[#1f2937] bg-[#0d1117] p-3 font-mono text-[13px] text-gray-100">
            <code>{q.code}</code>
          </pre>
        )}

        <div className="mt-4 grid gap-2">
          {q.options.map((opt, i) => {
            const chosen = selected === i;
            const showRight = checked && i === q.answer;
            const showWrong = checked && chosen && i !== q.answer;
            return (
              <button
                key={i}
                type="button"
                disabled={checked}
                onClick={() => setSelected(i)}
                className={cn(
                  'flex items-center gap-3 rounded-lg border px-3.5 py-2.5 text-left text-sm transition-all',
                  'border-base-300 bg-base-100 hover:border-primary/50 hover:bg-primary/5',
                  chosen && !checked && 'border-primary bg-primary/8 ring-1 ring-primary/30',
                  showRight && 'border-success bg-success/12',
                  showWrong && 'border-error bg-error/12',
                  checked && !showRight && !showWrong && 'opacity-55'
                )}
              >
                <span
                  className={cn(
                    'grid size-5 shrink-0 place-items-center rounded-full border text-[11px] font-bold transition-colors',
                    'border-base-300 text-base-content/50',
                    chosen && !checked && 'border-primary bg-primary text-primary-content',
                    showRight && 'border-success bg-success text-success-content',
                    showWrong && 'border-error bg-error text-error-content'
                  )}
                >
                  {showRight ? (
                    <Check className="size-3" />
                  ) : showWrong ? (
                    <X className="size-3" />
                  ) : (
                    String.fromCharCode(65 + i)
                  )}
                </span>
                <span className="font-mono text-[13.5px] leading-6">{opt}</span>
              </button>
            );
          })}
        </div>

        {/* 结果与解析 */}
        {checked && (
          <div
            className={cn(
              'animate-fade-up mt-4 rounded-lg border p-3.5 text-sm',
              isCorrect ? 'border-success/40 bg-success/10' : 'border-error/40 bg-error/10'
            )}
          >
            <div className="flex flex-wrap items-center gap-2 font-semibold">
              {isCorrect ? (
                <>
                  <Check className="text-success size-4" />
                  <span className="text-success">{labels.correct}</span>
                  <span className="font-normal text-base-content/55">— {labels.correctMsg}</span>
                </>
              ) : (
                <>
                  <X className="text-error size-4" />
                  <span className="text-error">{labels.wrong}</span>
                  <span className="font-normal text-base-content/55">— {labels.wrongMsg}</span>
                </>
              )}
            </div>
            {q.explanation && (
              <div className="mt-2 flex gap-2 text-base-content/65">
                <Lightbulb className="text-warning mt-0.5 size-3.5 shrink-0" />
                <p className="leading-relaxed">
                  <span className="font-medium text-base-content">{labels.explanation}：</span>
                  {q.explanation}
                </p>
              </div>
            )}
          </div>
        )}

        {/* 操作区 */}
        <div className="mt-4 flex items-center justify-between">
          <div className="text-xs text-base-content/50">
            {labels.score}:{' '}
            <span className="font-semibold text-base-content">{correctCount}</span>/{total}
          </div>
          <div className="flex gap-2">
            {!checked ? (
              <button
                ref={btnRef}
                type="button"
                className="btn btn-primary btn-sm gap-1.5"
                onClick={handleCheck}
              >
                <Check className="size-4" />
                {labels.check}
              </button>
            ) : isCorrect ? (
              <button type="button" className="btn btn-primary btn-sm gap-1.5" onClick={handleNext}>
                {index + 1 >= total ? labels.finished : labels.next}
                <ChevronRight className="size-4" />
              </button>
            ) : (
              <button
                type="button"
                className="btn btn-outline btn-sm gap-1.5"
                onClick={handleRetry}
              >
                <RotateCcw className="size-4" />
                {labels.retry}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
