import confetti from 'canvas-confetti';

/**
 * 撒花庆祝特效（canvas-confetti）
 * 提供多种预设，答对时随机/叠加触发，营造"欢呼"感。
 */

const RookieColors = ['#3b82f6', '#22c55e', '#facc15', '#f97316', '#ec4899', '#8b5cf6'];

function reducedMotion() {
  return (
    typeof window !== 'undefined' &&
    window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  );
}

/** 基础爆炸 */
export function burst(origin: { x: number; y: number } = { x: 0.5, y: 0.6 }) {
  if (reducedMotion()) return;
  confetti({
    particleCount: 90,
    spread: 78,
    startVelocity: 42,
    origin,
    colors: RookieColors,
    scalar: 1,
    zIndex: 9999,
  });
}

/** 两侧同时喷射 */
export function sideCannons() {
  if (reducedMotion()) return;
  const base = { particleCount: 60, spread: 60, colors: RookieColors, zIndex: 9999 };
  confetti({ ...base, angle: 60, origin: { x: 0, y: 0.7 } });
  confetti({ ...base, angle: 120, origin: { x: 1, y: 0.7 } });
}

/** 从元素位置绽放（在按钮附近撒花） */
export function burstFromElement(el: HTMLElement | null, opts?: { count?: number }) {
  if (reducedMotion() || !el) {
    burst();
    return;
  }
  const rect = el.getBoundingClientRect();
  const x = (rect.left + rect.width / 2) / window.innerWidth;
  const y = (rect.top + rect.height / 2) / window.innerHeight;
  burst({ x, y });
}

/** 持续 1.2 秒的星星雨，用于"完美通关" */
export function starRain(duration = 1200) {
  if (reducedMotion()) return;
  const end = Date.now() + duration;
  const colors = ['#facc15', '#fde68a', '#fbbf24', '#ffffff'];
  (function frame() {
    confetti({
      particleCount: 4,
      angle: 90,
      spread: 360,
      startVelocity: 22,
      gravity: 0.9,
      ticks: 140,
      origin: { x: 0.15 + Math.random() * 0.7, y: -0.05 },
      colors,
      shapes: ['star', 'circle'],
      scalar: 0.9,
      zIndex: 9999,
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}

/** 大通关：多重效果叠加 */
export function celebrate(correct = 1, total = 1) {
  if (reducedMotion()) return;
  burst({ x: 0.5, y: 0.55 });
  sideCannons();
  if (correct === total && total > 0) {
    setTimeout(() => starRain(1400), 160);
  }
  setTimeout(() => burst({ x: 0.35, y: 0.4 }), 260);
  setTimeout(() => burst({ x: 0.68, y: 0.42 }), 420);
}

/** 小型反馈（答对但非满分，用于单题） */
export function smallCheer(el?: HTMLElement | null) {
  if (reducedMotion()) return;
  if (el) burstFromElement(el, { count: 60 });
  else burst({ x: 0.5, y: 0.6 });
}
