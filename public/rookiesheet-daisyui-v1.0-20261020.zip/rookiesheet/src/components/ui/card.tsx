import * as React from 'react';
import { cn } from '@/lib/utils';

/**
 * daisyUI 5 卡片封装。
 * 正文需包在 `card-body` 内，否则 padding 节奏会不对。
 */
export function Card({
  className,
  bordered,
  compact,
  side,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & {
  bordered?: boolean;
  compact?: boolean;
  side?: boolean;
}) {
  return (
    <div
      className={cn(
        'card bg-base-100',
        bordered && 'card-border',
        compact && 'card-compact',
        side && 'card-side',
        className
      )}
      {...props}
    />
  );
}

export function CardBody({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card-body', className)} {...props} />;
}

export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h2 className={cn('card-title', className)} {...props} />;
}

export function CardActions({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card-actions justify-end', className)} {...props} />;
}
