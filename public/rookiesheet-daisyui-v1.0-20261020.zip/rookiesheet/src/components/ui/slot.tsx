import * as React from 'react';

/**
 * 轻量 Slot 实现（替代 @radix-ui/react-slot）
 * 将 className / 事件等 props 合并到唯一子元素上。
 */
export interface SlotProps extends React.HTMLAttributes<HTMLElement> {
  children?: React.ReactNode;
}

export const Slot = React.forwardRef<HTMLElement, SlotProps>(
  ({ children, className, ...props }, ref) => {
    if (!React.isValidElement(children)) return null;
    const child = children as React.ReactElement<any>;
    const childProps = child.props ?? {};
    const mergedProps: any = {
      ...props,
      ...childProps,
      className: [className, childProps.className].filter(Boolean).join(' ') || undefined,
      ref,
    };
    return React.cloneElement(child, mergedProps);
  }
);
Slot.displayName = 'Slot';
