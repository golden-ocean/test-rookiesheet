import * as React from 'react';
import { Slot } from './slot';
import { cn } from '@/lib/utils';

/**
 * daisyUI 5 按钮封装。
 * 变体直接映射到 daisyUI 的 `btn-*` 修饰类，尺寸走 `btn-xs/sm/md/lg`。
 */
export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'accent'
  | 'neutral'
  | 'info'
  | 'success'
  | 'warning'
  | 'error'
  | 'ghost'
  | 'outline'
  | 'link'
  | 'soft';

export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg';

const VARIANT_CLASS: Record<ButtonVariant, string> = {
  primary: 'btn-primary',
  secondary: 'btn-secondary',
  accent: 'btn-accent',
  neutral: 'btn-neutral',
  info: 'btn-info',
  success: 'btn-success',
  warning: 'btn-warning',
  error: 'btn-error',
  ghost: 'btn-ghost',
  outline: 'btn-outline',
  link: 'btn-link',
  soft: 'btn-soft btn-primary',
};

const SIZE_CLASS: Record<ButtonSize, string> = {
  xs: 'btn-xs',
  sm: 'btn-sm',
  md: '',
  lg: 'btn-lg',
};

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** 正方形图标按钮 */
  square?: boolean;
  /** 胶囊形 */
  pill?: boolean;
  asChild?: boolean;
}

export function buttonClass(opts: {
  variant?: ButtonVariant;
  size?: ButtonSize;
  square?: boolean;
  pill?: boolean;
  className?: string;
} = {}) {
  const { variant = 'primary', size = 'md', square, pill, className } = opts;
  return cn(
    'btn',
    VARIANT_CLASS[variant] ?? '',
    SIZE_CLASS[size] ?? '',
    square && 'btn-square',
    pill && 'btn-pill',
    className
  );
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant = 'primary', size = 'md', square, pill, asChild = false, ...props },
    ref
  ) => {
    const Comp: any = asChild ? Slot : 'button';
    return (
      <Comp
        className={buttonClass({ variant, size, square, pill, className })}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = 'Button';

export { Button };
