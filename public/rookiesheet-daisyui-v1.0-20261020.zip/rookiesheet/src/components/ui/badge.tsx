import * as React from 'react';
import { cn } from '@/lib/utils';

/**
 * daisyUI 5 徽章封装。
 * soft 变体 = daisyUI 的 `badge-soft badge-<color>`，用于难度等级等弱提示。
 */
export type BadgeVariant =
  | 'primary'
  | 'secondary'
  | 'accent'
  | 'neutral'
  | 'info'
  | 'success'
  | 'warning'
  | 'error'
  | 'outline'
  | 'ghost';

export type BadgeSize = 'xs' | 'sm' | 'md' | 'lg';

const VARIANT_CLASS: Record<BadgeVariant, string> = {
  primary: 'badge-primary',
  secondary: 'badge-secondary',
  accent: 'badge-accent',
  neutral: 'badge-neutral',
  info: 'badge-info',
  success: 'badge-success',
  warning: 'badge-warning',
  error: 'badge-error',
  outline: 'badge-outline',
  ghost: 'badge-ghost',
};

const SIZE_CLASS: Record<BadgeSize, string> = {
  xs: 'badge-xs',
  sm: 'badge-sm',
  md: '',
  lg: 'badge-lg',
};

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  size?: BadgeSize;
  /** 使用 daisyUI 的 soft 配色（浅底 + 同色文字） */
  soft?: boolean;
  /** 方形徽章（无圆角） */
  square?: boolean;
}

export function badgeClass(opts: {
  variant?: BadgeVariant;
  size?: BadgeSize;
  soft?: boolean;
  square?: boolean;
  className?: string;
} = {}) {
  const { variant = 'primary', size = 'sm', soft, square, className } = opts;
  return cn(
    'badge',
    soft ? 'badge-soft' : '',
    VARIANT_CLASS[variant] ?? '',
    SIZE_CLASS[size] ?? '',
    square && 'badge-square',
    className
  );
}

export function Badge({
  className,
  variant = 'primary',
  size = 'sm',
  soft,
  square,
  ...props
}: BadgeProps) {
  return (
    <span className={badgeClass({ variant, size, soft, square, className })} {...props} />
  );
}

/** 难度等级 → daisyUI 颜色映射 */
export const LEVEL_VARIANT: Record<number, BadgeVariant> = {
  1: 'success',
  2: 'info',
  3: 'warning',
  4: 'error',
};
