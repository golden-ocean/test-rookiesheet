import * as React from 'react';
import { Copy, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Props {
  code: string;
  copyLabel: string;
  copiedLabel: string;
  /** 语言标识，用于显示角标 */
  lang?: string;
  title?: string;
  className?: string;
}

/**
 * 代码块容器：始终深色高亮（Shiki 由 Astro 预渲染，这里负责工具栏与复制）
 * 与 <Code> (astro 组件) 配合使用。
 */
export function CodeBlock({
  code,
  copyLabel,
  copiedLabel,
  lang,
  title,
  className,
}: Props) {
  const [copied, setCopied] = React.useState(false);

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      /* 忽略 */
    }
  };

  return (
    <div className={cn('group relative', className)}>
      <div className="absolute top-2 right-2 z-10 flex items-center gap-2 opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
        {title && (
          <span className="hidden rounded-md bg-white/10 px-2 py-1 text-[11px] font-medium text-gray-300 sm:inline">
            {title}
          </span>
        )}
        <button
          type="button"
          onClick={onCopy}
          aria-label={copyLabel}
          className="flex items-center gap-1 rounded-md bg-white/10 px-2 py-1 text-[11px] font-medium text-gray-200 backdrop-blur transition-colors hover:bg-white/20"
        >
          {copied ? (
            <>
              <Check className="text-success size-3" />
              {copiedLabel}
            </>
          ) : (
            <>
              <Copy className="size-3" />
              {copyLabel}
            </>
          )}
        </button>
      </div>
      <div dangerouslySetInnerHTML={{ __html: code }} />
    </div>
  );
}
