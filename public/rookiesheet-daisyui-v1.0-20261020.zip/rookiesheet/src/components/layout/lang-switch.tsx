import { Languages } from 'lucide-react';
import { type Lang } from '@/i18n/config';

interface Props {
  current: Lang;
  /** 另一种语言下的同页路径 */
  altHref: string;
  label: string;
}

/** 语言切换：服务端渲染 <a>，保证静态站点可跳转 */
export function LangSwitch({ current, altHref, label }: Props) {
  const other: Lang = current === 'zh' ? 'en' : 'zh';
  return (
    <a
      href={altHref}
      aria-label={label}
      title={label}
      className="btn btn-ghost btn-sm gap-1.5 px-2"
    >
      <Languages className="size-[18px]" />
      <span className="text-xs font-semibold uppercase">{other}</span>
    </a>
  );
}
