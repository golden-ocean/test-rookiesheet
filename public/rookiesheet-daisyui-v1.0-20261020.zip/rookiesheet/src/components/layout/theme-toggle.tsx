import * as React from 'react';
import { Moon, Sun } from 'lucide-react';

type Theme = 'light' | 'dark';

/**
 * daisyUI 5 主题切换：通过 `<html data-theme="...">` 生效。
 * 与 base-layout 中的防闪烁内联脚本共用 localStorage 键 `rs-theme`。
 */
export function ThemeToggle({
  labels,
}: {
  labels: { light: string; dark: string; toggle: string };
}) {
  const [theme, setTheme] = React.useState<Theme>('light');
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    const stored = localStorage.getItem('rs-theme') as Theme | null;
    const current = document.documentElement.getAttribute('data-theme');
    const initial: Theme =
      stored ?? (current === 'dark' || current === 'light' ? current : 'light');
    setTheme(initial);
    setMounted(true);
  }, []);

  const apply = (next: Theme) => {
    setTheme(next);
    const root = document.documentElement;
    // 抑制切换瞬间的全局过渡抖动
    root.classList.add('rs-theme-switching');
    root.setAttribute('data-theme', next);
    root.style.colorScheme = next;
    localStorage.setItem('rs-theme', next);
    window.setTimeout(() => root.classList.remove('rs-theme-switching'), 60);
  };

  const isDark = theme === 'dark';

  return (
    <button
      type="button"
      className="btn btn-ghost btn-square btn-sm relative"
      aria-label={labels.toggle}
      title={isDark ? labels.light : labels.dark}
      onClick={() => apply(isDark ? 'light' : 'dark')}
    >
      <Sun
        className={`size-[18px] transition-all duration-300 ${
          mounted && isDark ? 'rotate-90 scale-0 opacity-0' : 'rotate-0 scale-100 opacity-100'
        }`}
      />
      <Moon
        className={`absolute size-[18px] transition-all duration-300 ${
          mounted && isDark ? 'rotate-0 scale-100 opacity-100' : '-rotate-90 scale-0 opacity-0'
        }`}
      />
    </button>
  );
}
