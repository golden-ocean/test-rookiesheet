import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

/**
 * 文档集合：content/docs/{lang}/{language}/{slug}.md(x)
 * - lang: zh | en
 * - 通过 id 前缀区分语言，便于 i18n 路由
 */
const docs = defineCollection({
  loader: glob({ pattern: '**/*.{md,mdx}', base: './src/content/docs' }),
  schema: z.object({
    title: z.string(),
    description: z.string().optional(),
    /** 所属编程语言，如 javascript */
    language: z.string().default('javascript'),
    /** 章节分组，用于左侧导航分组 */
    group: z.string(),
    /** 组内排序 */
    order: z.number().default(0),
    /** 难度 1-4 */
    level: z.number().min(1).max(4).default(1),
    /** 预计阅读时长(分钟) */
    readTime: z.number().default(3),
    /** 右侧速查卡要点（记忆卡） */
    keyPoints: z
      .array(
        z.object({
          label: z.string(),
          value: z.string(),
          note: z.string().optional(),
        })
      )
      .default([]),
    /** 本页重点语法（用于强调记忆） */
    highlights: z.array(z.string()).default([]),
    /** 常见坑/易错点 */
    pitfalls: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

export const collections = { docs };
