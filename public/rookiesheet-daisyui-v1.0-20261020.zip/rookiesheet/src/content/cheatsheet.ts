import type { Lang } from '@/i18n/config';

export interface CheatItem {
  /** 命令 / 语法 */
  code: string;
  /** 说明 */
  desc: Record<Lang, string>;
}
export interface CheatGroup {
  title: Record<Lang, string>;
  items: CheatItem[];
}

export const CHEATSHEET: CheatGroup[] = [
  {
    title: { zh: '变量与类型', en: 'Variables & Types' },
    items: [
      { code: 'const x = 1', desc: { zh: '声明不可重新赋值的常量', en: 'Declare a constant (no reassign)' } },
      { code: 'let y = 2', desc: { zh: '声明可重新赋值的变量', en: 'Declare a mutable variable' } },
      { code: 'typeof value', desc: { zh: '获取值的类型字符串', en: 'Get the type as a string' } },
      { code: '`Hi ${name}`', desc: { zh: '模板字符串，嵌入变量', en: 'Template string with interpolation' } },
      { code: 'Number("42")', desc: { zh: '字符串转数字', en: 'Convert a string to a number' } },
    ],
  },
  {
    title: { zh: '运算符', en: 'Operators' },
    items: [
      { code: 'a === b', desc: { zh: '严格相等（推荐）', en: 'Strict equality (recommended)' } },
      { code: 'a !== b', desc: { zh: '严格不等', en: 'Strict inequality' } },
      { code: 'a && b', desc: { zh: '逻辑与，都为真才为真', en: 'Logical AND' } },
      { code: 'a || b', desc: { zh: '逻辑或，短路求值', en: 'Logical OR, short-circuits' } },
      { code: 'a ?? b', desc: { zh: '仅当 a 为 null/undefined 时用 b', en: 'Default when a is null/undefined' } },
      { code: 'cond ? a : b', desc: { zh: '三元表达式', en: 'Ternary expression' } },
    ],
  },
  {
    title: { zh: '数组方法', en: 'Array Methods' },
    items: [
      { code: 'arr.map(fn)', desc: { zh: '逐项转换，返回新数组', en: 'Transform each item into a new array' } },
      { code: 'arr.filter(fn)', desc: { zh: '筛选匹配元素', en: 'Keep matching items' } },
      { code: 'arr.find(fn)', desc: { zh: '返回第一个匹配元素', en: 'Return the first match' } },
      { code: 'arr.findIndex(fn)', desc: { zh: '返回匹配的下标，无则 -1', en: 'Index of first match, -1 if none' } },
      { code: 'arr.reduce((a,c)=>a+c, 0)', desc: { zh: '归约成一个值（求和等）', en: 'Collapse into one value (e.g. sum)' } },
      { code: 'arr.includes(v)', desc: { zh: '是否包含某个值', en: 'Whether the value exists' } },
      { code: 'arr.some(fn) / arr.every(fn)', desc: { zh: '是否存在 / 是否全部满足', en: 'Any match / all match' } },
      { code: 'arr.push(v) / arr.pop()', desc: { zh: '尾部添加 / 删除', en: 'Add / remove at the end' } },
      { code: 'arr.slice(1, 3)', desc: { zh: '截取子数组，不改原数组', en: 'Slice a subarray, original intact' } },
      { code: '[...new Set(arr)]', desc: { zh: '数组去重', en: 'Deduplicate an array' } },
      { code: 'arr.sort((a,b)=>a-b)', desc: { zh: '数字升序排序', en: 'Sort numbers ascending' } },
      { code: 'arr.join(", ")', desc: { zh: '拼接为字符串', en: 'Join into a string' } },
    ],
  },
  {
    title: { zh: '对象操作', en: 'Objects' },
    items: [
      { code: 'const { a, b } = obj', desc: { zh: '解构取属性', en: 'Destructure properties' } },
      { code: 'const { a = 1 } = obj', desc: { zh: '解构带默认值', en: 'Destructure with default' } },
      { code: '{ ...obj, key: 1 }', desc: { zh: '展开合并，生成新对象', en: 'Spread merge into a new object' } },
      { code: 'obj?.a?.b', desc: { zh: '可选链，安全访问', en: 'Optional chaining, safe access' } },
      { code: 'Object.keys(obj)', desc: { zh: '键名数组', en: 'Array of keys' } },
      { code: 'Object.values(obj)', desc: { zh: '值数组', en: 'Array of values' } },
      { code: 'Object.entries(obj)', desc: { zh: '键值对数组', en: 'Array of [key, value] pairs' } },
      { code: 'Object.fromEntries(pairs)', desc: { zh: '键值对数组转对象', en: 'Build an object from pairs' } },
    ],
  },
  {
    title: { zh: '字符串', en: 'Strings' },
    items: [
      { code: 'str.slice(0, 4)', desc: { zh: '截取，支持负索引', en: 'Slice, supports negatives' } },
      { code: 'str.includes("a")', desc: { zh: '是否包含子串', en: 'Contains a substring' } },
      { code: 'str.split(",")', desc: { zh: '按分隔符拆成数组', en: 'Split by a separator' } },
      { code: 'str.replaceAll("a","b")', desc: { zh: '全部替换', en: 'Replace every occurrence' } },
      { code: 'str.trim()', desc: { zh: '去掉首尾空白', en: 'Trim surrounding whitespace' } },
      { code: 'str.toUpperCase()', desc: { zh: '转大写', en: 'To uppercase' } },
    ],
  },
  {
    title: { zh: '流程控制', en: 'Control Flow' },
    items: [
      { code: 'if (cond) { } else { }', desc: { zh: '条件分支', en: 'Conditional branch' } },
      { code: 'for (const x of arr) { }', desc: { zh: '遍历数组（推荐）', en: 'Iterate an array (preferred)' } },
      { code: 'for (let i=0; i<n; i++) { }', desc: { zh: '经典计数循环', en: 'Classic counted loop' } },
      { code: 'arr.forEach(fn)', desc: { zh: '遍历，无法中断', en: 'Iterate (cannot break)' } },
      { code: 'break / continue', desc: { zh: '终止循环 / 跳过本轮', en: 'Exit loop / skip iteration' } },
      { code: 'switch (v) { case x: }', desc: { zh: '多分支选择', en: 'Multi-branch selection' } },
    ],
  },
  {
    title: { zh: '函数', en: 'Functions' },
    items: [
      { code: 'function fn(a, b) { }', desc: { zh: '函数声明', en: 'Function declaration' } },
      { code: '(a, b) => a + b', desc: { zh: '箭头函数，单表达式', en: 'Arrow function, single expression' } },
      { code: 'function f(a = 1) { }', desc: { zh: '默认参数', en: 'Default parameter' } },
      { code: 'function f(...args) { }', desc: { zh: '剩余参数收集', en: 'Rest parameters' } },
      { code: 'return value', desc: { zh: '返回值，无则 undefined', en: 'Return a value; otherwise undefined' } },
    ],
  },
  {
    title: { zh: '异步', en: 'Async' },
    items: [
      { code: 'async function f() { }', desc: { zh: '声明异步函数', en: 'Declare an async function' } },
      { code: 'const r = await p', desc: { zh: '等待 Promise 结果', en: 'Await a Promise result' } },
      { code: 'try { } catch (e) { }', desc: { zh: '捕获错误', en: 'Catch errors' } },
      { code: 'await Promise.all([p1,p2])', desc: { zh: '并发执行多个 Promise', en: 'Run Promises concurrently' } },
      { code: 'await Promise.allSettled([...])', desc: { zh: '全部结果，失败不中断', en: 'All results, failures included' } },
    ],
  },
  {
    title: { zh: 'DOM 与模块', en: 'DOM & Modules' },
    items: [
      { code: 'document.querySelector(".x")', desc: { zh: '查询第一个匹配元素', en: 'Query the first match' } },
      { code: 'el.textContent = "hi"', desc: { zh: '设置纯文本内容', en: 'Set plain text content' } },
      { code: 'el.classList.add("x")', desc: { zh: '添加 class', en: 'Add a class' } },
      { code: 'el.addEventListener("click", fn)', desc: { zh: '监听事件', en: 'Listen for an event' } },
      { code: 'export const a = 1', desc: { zh: '命名导出', en: 'Named export' } },
      { code: 'import { a } from "./m.js"', desc: { zh: '导入模块成员', en: 'Import a module member' } },
    ],
  },
];
