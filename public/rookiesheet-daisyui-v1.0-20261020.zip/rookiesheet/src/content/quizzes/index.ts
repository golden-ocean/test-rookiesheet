import type { Lang } from '@/i18n/config';
import type { QuizQuestion } from '@/components/quiz/quiz';

/**
 * 测验题库：按语言 + 文档 slug 组织，中英双语
 * key = `${lang}/${language}/${slug}`
 */
export const QUIZZES: Record<string, QuizQuestion[]> = {
  /* ================= 中文 ================= */
  'zh/javascript/01-hello-world': [
    {
      id: 'zh-j1-1',
      question: '哪个方法可以把内容打印到浏览器控制台？',
      options: ['print()', 'console.log()', 'echo()', 'document.write()'],
      answer: 1,
      explanation: 'console.log() 是 JS 最基础的输出方法，用于调试和查看变量值。',
    },
    {
      id: 'zh-j1-2',
      question: '下面这行代码会输出什么？',
      code: 'console.log("2" + 3);',
      options: ['5', '"23"', '23', '报错'],
      answer: 1,
      explanation: '字符串 "2" 与数字 3 相加时，数字被转成字符串，结果拼接为字符串 "23"。',
    },
    {
      id: 'zh-j1-3',
      question: '写多行注释应该用哪种语法？',
      options: ['// 注释 //', '<!-- 注释 -->', '/* 注释 */', '# 注释'],
      answer: 2,
      explanation: '/* ... */ 是多行注释；// 只能注释单行。',
    },
  ],

  'zh/javascript/02-variables': [
    {
      id: 'zh-j2-1',
      question: '下面哪种声明方式声明的变量不能重新赋值？',
      options: ['let', 'var', 'const', 'value'],
      answer: 2,
      explanation: 'const 声明的是常量，重新赋值会抛出 TypeError。',
    },
    {
      id: 'zh-j2-2',
      question: 'typeof null 的结果是什么？',
      options: ['"null"', '"object"', '"undefined"', '"boolean"'],
      answer: 1,
      explanation: '这是 JS 的历史遗留 bug，typeof null 返回 "object"，判断 null 应直接用 === null。',
    },
    {
      id: 'zh-j2-3',
      question: '想输出「你好，小明」，下面哪个写法正确？',
      options: [
        'console.log("你好，" + name)',
        'console.log(`你好，${name}`)',
        'console.log("你好，{name}")',
        'console.log("你好，" + ${name})',
      ],
      answer: 1,
      explanation: '模板字符串用反引号包裹，变量用 ${} 嵌入，是推荐写法。',
    },
  ],

  'zh/javascript/03-operators': [
    {
      id: 'zh-j3-1',
      question: '下面哪个比较运算符是推荐使用的？',
      options: ['==', '===', '=', '=!'],
      answer: 1,
      explanation: '=== 同时比较值和类型，不会隐式转换，是新手应始终使用的严格相等。',
    },
    {
      id: 'zh-j3-2',
      question: '空值合并运算符 ?? 在什么时候生效？',
      options: ['值为假值时', '值为 0 或空字符串时', '值为 null 或 undefined 时', '任何时候'],
      answer: 2,
      explanation: '?? 只在左侧为 null 或 undefined 时返回右侧默认值，比 || 更精确。',
    },
    {
      id: 'zh-j3-3',
      question: '判断一个值是否等于「数字 18」，正确的写法是？',
      options: ['age = 18', 'age == "18"', 'age === 18', 'age !== 18'],
      answer: 2,
      explanation: '用 === 严格比较，避免 "18" == 18 这种隐式转换带来的误判。',
    },
  ],

  'zh/javascript/04-loops': [
    {
      id: 'zh-j4-1',
      question: '遍历数组元素，下面哪种写法最推荐？',
      options: ['for...in', 'for...of', 'while(true)', 'do...while'],
      answer: 1,
      explanation: 'for...of 直接拿到值，语义清晰；for...in 遍历的是键名，不适合数组。',
    },
    {
      id: 'zh-j4-2',
      question: '下面代码执行后输出什么？',
      code: 'for (let i = 1; i <= 5; i++) {\n  if (i === 3) continue;\n  if (i === 5) break;\n  console.log(i);\n}',
      options: ['1 2 3 4 5', '1 2 4', '1 2 4 5', '1 2'],
      answer: 1,
      explanation: 'continue 跳过 3，break 在 5 时终止，所以输出 1、2、4。',
    },
  ],

  'zh/javascript/05-functions': [
    {
      id: 'zh-j5-1',
      question: '箭头函数 `(a, b) => a + b` 等价于下面哪个？',
      options: [
        'function(a, b) { a + b }',
        'function(a, b) { return a + b }',
        'function() { return a + b }',
        'function(a, b) { return; }',
      ],
      answer: 1,
      explanation: '箭头函数写成单表达式时，可省略花括号和 return，返回该表达式的结果。',
    },
    {
      id: 'zh-j5-2',
      question: '函数没有写 return 时，调用它会得到什么？',
      options: ['null', '0', 'undefined', '报错'],
      answer: 2,
      explanation: '没有 return 的函数隐式返回 undefined。',
    },
    {
      id: 'zh-j5-3',
      question: '下面哪个写法能给参数设置默认值？',
      options: [
        'function greet(name = "游客") {}',
        'function greet(name || "游客") {}',
        'function greet(name default "游客") {}',
        'function greet(default name) {}',
      ],
      answer: 0,
      explanation: 'ES6 默认参数语法为 参数名 = 默认值。',
    },
  ],

  'zh/javascript/06-arrays': [
    {
      id: 'zh-j6-1',
      question: '哪个方法会把数组每个元素转换后返回一个新数组？',
      options: ['forEach', 'map', 'find', 'some'],
      answer: 1,
      explanation: 'map 对每个元素执行函数并收集返回值，生成新数组且不修改原数组。',
    },
    {
      id: 'zh-j6-2',
      question: '下面代码输出什么？',
      code: 'const ages = [12, 18, 25];\nconsole.log(ages.filter(a => a >= 18));',
      options: ['[12]', '[18, 25]', '[25]', 'true'],
      answer: 1,
      explanation: 'filter 保留满足条件的元素，18 和 25 都 >= 18。',
    },
    {
      id: 'zh-j6-3',
      question: '对数字数组正确排序应该怎么写？',
      options: ['arr.sort()', 'arr.sort((a, b) => a - b)', 'arr.order()', 'arr.sort("asc")'],
      answer: 1,
      explanation: 'sort() 默认按字符串排序，数字排序必须传入比较函数 (a, b) => a - b。',
    },
    {
      id: 'zh-j6-4',
      question: 'reduce((acc, cur) => acc + cur, 0) 的作用是？',
      options: ['筛选元素', '累加求和', '查找元素', '去重'],
      answer: 1,
      explanation: 'reduce 用初始值 0 依次累加每个元素，实现求和。',
    },
  ],

  'zh/javascript/07-objects': [
    {
      id: 'zh-j7-1',
      question: '安全访问可能不存在的深层属性，用哪个运算符？',
      options: ['?.', '!.', '&.', '#.'],
      answer: 0,
      explanation: '可选链 ?. 在中间值为 null/undefined 时返回 undefined，而不会报错。',
    },
    {
      id: 'zh-j7-2',
      question: 'const { name = "匿名" } = user 中，默认值什么时候生效？',
      options: [
        'user.name 为任何假值时',
        'user 没有 name 属性或为 undefined 时',
        'name 为 null 时',
        '永远不会生效',
      ],
      answer: 1,
      explanation: '解构默认值只在对应属性为 undefined（或不存在）时生效。',
    },
    {
      id: 'zh-j7-3',
      question: 'const b = { ...a, x: 1 } 会怎样？',
      options: ['修改原对象 a', '创建一个新对象，a 不变', '报错', '把 a 变成数组'],
      answer: 1,
      explanation: '展开运算符创建浅拷贝的新对象，原对象 a 不受影响。',
    },
  ],

  'zh/javascript/08-strings': [
    {
      id: 'zh-j8-1',
      question: '"JavaScript".slice(-6) 的结果是？',
      options: ['"Java"', '"Script"', '"ript"', '"JavaScript"'],
      answer: 1,
      explanation: '负索引从末尾计数，slice(-6) 取最后 6 个字符，即 "Script"。',
    },
    {
      id: 'zh-j8-2',
      question: '要把字符串中所有 "a" 都替换成 "b"，应该用？',
      options: ['replace("a", "b")', 'replaceAll("a", "b")', 'replaceFirst', 'switch'],
      answer: 1,
      explanation: 'replace 只替换第一个匹配，replaceAll 替换全部（或使用 /a/g 正则）。',
    },
    {
      id: 'zh-j8-3',
      question: '"a,b,c".split(",") 的结果是？',
      options: ['"a b c"', '["a", "b", "c"]', '"abc"', '[a, b, c]'],
      answer: 1,
      explanation: 'split 按分隔符拆分字符串，返回字符串数组。',
    },
  ],

  'zh/javascript/09-async': [
    {
      id: 'zh-j9-1',
      question: 'async 函数的返回值是什么？',
      options: ['原始值', 'Promise', 'undefined', '数组'],
      answer: 1,
      explanation: 'async 函数总是返回一个 Promise，即使内部 return 的是普通值。',
    },
    {
      id: 'zh-j9-2',
      question: '要让多个互不依赖的请求并发执行，应该用？',
      options: ['await 依次调用', 'Promise.all([p1, p2])', 'forEach 里 await', 'setTimeout 嵌套'],
      answer: 1,
      explanation: 'Promise.all 会同时发出多个 Promise 并等待全部完成，比串行快得多。',
    },
    {
      id: 'zh-j9-3',
      question: '为什么不应该在 forEach 里使用 await？',
      options: [
        '语法错误',
        'forEach 不会等待异步完成',
        '会有性能警告',
        '其实没问题，推荐这样写',
      ],
      answer: 1,
      explanation: 'forEach 不会等待回调里的 await，循环会立刻结束。需要顺序等待请用 for...of。',
    },
  ],

  'zh/javascript/10-dom': [
    {
      id: 'zh-j10-1',
      question: '查询页面中第一个 class 为 box 的元素，用哪个方法？',
      options: [
        'document.getElementById("box")',
        'document.querySelector(".box")',
        'document.getElementsByClassName("box")',
        'document.find(".box")',
      ],
      answer: 1,
      explanation: 'querySelector 支持 CSS 选择器，返回第一个匹配元素。',
    },
    {
      id: 'zh-j10-2',
      question: '给元素添加一个 class，应该怎么写？',
      options: [
        'el.class = "active"',
        'el.classList.add("active")',
        'el.addClass("active")',
        'el.style.class = "active"',
      ],
      answer: 1,
      explanation: 'classList 提供 add / remove / toggle / contains 等操作 class 的方法。',
    },
    {
      id: 'zh-j10-3',
      question: '插入用户输入的内容时，为安全起见应该用？',
      options: ['innerHTML', 'textContent', 'outerHTML', 'document.write'],
      answer: 1,
      explanation: 'textContent 按纯文本处理，不会执行 HTML，能避免 XSS 攻击。',
    },
  ],

  'zh/javascript/11-es6-plus': [
    {
      id: 'zh-j11-1',
      question: '数组去重最简洁的写法是？',
      options: [
        'arr.filter((v, i) => arr.indexOf(v) === i)',
        '[...new Set(arr)]',
        'arr.unique()',
        'arr.dedupe()',
      ],
      answer: 1,
      explanation: 'Set 自动去重，配合展开运算符 [...new Set(arr)] 一行搞定。',
    },
    {
      id: 'zh-j11-2',
      question: '一个模块中最多可以有几个 default export？',
      options: ['0 个', '1 个', '2 个', '不限'],
      answer: 1,
      explanation: '每个模块只能有一个默认导出，命名导出可以有多个。',
    },
    {
      id: 'zh-j11-3',
      question: 'class Dog extends Animal 中，子类构造函数里调用父类构造函数用？',
      options: ['this()', 'parent()', 'super()', 'Animal()'],
      answer: 2,
      explanation: 'super() 调用父类构造函数，必须在使用 this 之前调用。',
    },
  ],

  /* ================= English ================= */
  'en/javascript/01-hello-world': [
    {
      id: 'en-j1-1',
      question: 'Which method prints output to the browser console?',
      options: ['print()', 'console.log()', 'echo()', 'document.write()'],
      answer: 1,
      explanation: 'console.log() is the most basic JS output method used for debugging.',
    },
    {
      id: 'en-j1-2',
      question: 'What does this line output?',
      code: 'console.log("2" + 3);',
      options: ['5', '"23"', '23', 'An error'],
      answer: 1,
      explanation: 'When a string meets a number, + concatenates: the result is the string "23".',
    },
    {
      id: 'en-j1-3',
      question: 'Which syntax writes a multi-line comment?',
      options: ['// comment //', '<!-- comment -->', '/* comment */', '# comment'],
      answer: 2,
      explanation: '/* ... */ is a multi-line comment; // only covers one line.',
    },
  ],

  'en/javascript/02-variables': [
    {
      id: 'en-j2-1',
      question: 'Which declaration creates a variable you cannot reassign?',
      options: ['let', 'var', 'const', 'value'],
      answer: 2,
      explanation: 'const declares a constant; reassigning throws a TypeError.',
    },
    {
      id: 'en-j2-2',
      question: 'What is typeof null?',
      options: ['"null"', '"object"', '"undefined"', '"boolean"'],
      answer: 1,
      explanation: 'A historic JS bug: typeof null returns "object". Check with === null instead.',
    },
    {
      id: 'en-j2-3',
      question: 'Which prints "Hi, Tom" correctly using a variable name?',
      options: [
        'console.log("Hi, " + name)',
        'console.log(`Hi, ${name}`)',
        'console.log("Hi, {name}")',
        'console.log("Hi, " + ${name})',
      ],
      answer: 1,
      explanation: 'Template strings use backticks and embed variables with ${}.',
    },
  ],

  'en/javascript/03-operators': [
    {
      id: 'en-j3-1',
      question: 'Which comparison operator should a rookie always use?',
      options: ['==', '===', '=', '=!'],
      answer: 1,
      explanation: '=== compares value and type with no coercion — the strict, safe choice.',
    },
    {
      id: 'en-j3-2',
      question: 'When does the nullish coalescing operator ?? kick in?',
      options: [
        'On any falsy value',
        'On 0 or an empty string',
        'On null or undefined only',
        'Always',
      ],
      answer: 2,
      explanation: '?? only falls back when the left side is null or undefined — more precise than ||.',
    },
    {
      id: 'en-j3-3',
      question: 'Which correctly tests whether a value equals the number 18?',
      options: ['age = 18', 'age == "18"', 'age === 18', 'age !== 18'],
      answer: 2,
      explanation: 'Use === to avoid the coercion trap of "18" == 18.',
    },
  ],

  'en/javascript/04-loops': [
    {
      id: 'en-j4-1',
      question: 'Which loop is recommended for iterating array values?',
      options: ['for...in', 'for...of', 'while(true)', 'do...while'],
      answer: 1,
      explanation: 'for...of gives you the values directly and reads clearly.',
    },
    {
      id: 'en-j4-2',
      question: 'What does this code print?',
      code: 'for (let i = 1; i <= 5; i++) {\n  if (i === 3) continue;\n  if (i === 5) break;\n  console.log(i);\n}',
      options: ['1 2 3 4 5', '1 2 4', '1 2 4 5', '1 2'],
      answer: 1,
      explanation: 'continue skips 3, break stops at 5 — so it prints 1, 2, 4.',
    },
  ],

  'en/javascript/05-functions': [
    {
      id: 'en-j5-1',
      question: 'The arrow function `(a, b) => a + b` equals which of these?',
      options: [
        'function(a, b) { a + b }',
        'function(a, b) { return a + b }',
        'function() { return a + b }',
        'function(a, b) { return; }',
      ],
      answer: 1,
      explanation: 'A single-expression arrow omits braces and return, returning that expression.',
    },
    {
      id: 'en-j5-2',
      question: 'What does a function return if it has no return statement?',
      options: ['null', '0', 'undefined', 'It throws'],
      answer: 2,
      explanation: 'Functions without return implicitly return undefined.',
    },
    {
      id: 'en-j5-3',
      question: 'Which syntax sets a default parameter value?',
      options: [
        'function greet(name = "Guest") {}',
        'function greet(name || "Guest") {}',
        'function greet(name default "Guest") {}',
        'function greet(default name) {}',
      ],
      answer: 0,
      explanation: 'ES6 default parameters use the form param = value.',
    },
  ],

  'en/javascript/06-arrays': [
    {
      id: 'en-j6-1',
      question: 'Which method transforms each element and returns a new array?',
      options: ['forEach', 'map', 'find', 'some'],
      answer: 1,
      explanation: 'map runs a function on each element, collecting results into a new array.',
    },
    {
      id: 'en-j6-2',
      question: 'What does this print?',
      code: 'const ages = [12, 18, 25];\nconsole.log(ages.filter(a => a >= 18));',
      options: ['[12]', '[18, 25]', '[25]', 'true'],
      answer: 1,
      explanation: 'filter keeps elements matching the condition: 18 and 25.',
    },
    {
      id: 'en-j6-3',
      question: 'How do you sort an array of numbers correctly?',
      options: ['arr.sort()', 'arr.sort((a, b) => a - b)', 'arr.order()', 'arr.sort("asc")'],
      answer: 1,
      explanation: 'sort() defaults to string order — pass a comparator for numbers.',
    },
    {
      id: 'en-j6-4',
      question: 'What does reduce((acc, cur) => acc + cur, 0) do?',
      options: ['Filters items', 'Sums values', 'Finds an item', 'Dedupes'],
      answer: 1,
      explanation: 'reduce accumulates each element starting from 0 — a sum.',
    },
  ],

  'en/javascript/07-objects': [
    {
      id: 'en-j7-1',
      question: 'Which operator safely accesses possibly-missing nested properties?',
      options: ['?.', '!.', '&.', '#.'],
      answer: 0,
      explanation: 'Optional chaining ?. returns undefined instead of throwing when a link is null.',
    },
    {
      id: 'en-j7-2',
      question: 'In const { name = "Anon" } = user, when does the default apply?',
      options: [
        'When user.name is any falsy value',
        'When user has no name or it is undefined',
        'When name is null',
        'Never',
      ],
      answer: 1,
      explanation: 'Destructuring defaults apply only when the property is undefined or missing.',
    },
    {
      id: 'en-j7-3',
      question: 'What does const b = { ...a, x: 1 } do?',
      options: ['Mutates a', 'Creates a new object, leaving a unchanged', 'Throws', 'Turns a into an array'],
      answer: 1,
      explanation: 'Spread creates a shallow copy; the original object a is untouched.',
    },
  ],

  'en/javascript/08-strings': [
    {
      id: 'en-j8-1',
      question: 'What is "JavaScript".slice(-6)?',
      options: ['"Java"', '"Script"', '"ript"', '"JavaScript"'],
      answer: 1,
      explanation: 'Negative indices count from the end: slice(-6) takes the last 6 chars.',
    },
    {
      id: 'en-j8-2',
      question: 'To replace every "a" with "b" in a string, use?',
      options: ['replace("a", "b")', 'replaceAll("a", "b")', 'replaceFirst', 'switch'],
      answer: 1,
      explanation: 'replace swaps only the first match; replaceAll handles all (or use /a/g).',
    },
    {
      id: 'en-j8-3',
      question: 'What is "a,b,c".split(",")?',
      options: ['"a b c"', '["a", "b", "c"]', '"abc"', '[a, b, c]'],
      answer: 1,
      explanation: 'split breaks a string by a separator and returns an array.',
    },
  ],

  'en/javascript/09-async': [
    {
      id: 'en-j9-1',
      question: 'What does an async function always return?',
      options: ['A primitive', 'A Promise', 'undefined', 'An array'],
      answer: 1,
      explanation: 'async functions always return a Promise, even when returning a plain value.',
    },
    {
      id: 'en-j9-2',
      question: 'How do you run independent requests concurrently?',
      options: ['await them one by one', 'Promise.all([p1, p2])', 'await inside forEach', 'Nested setTimeout'],
      answer: 1,
      explanation: 'Promise.all starts them together and waits for all — much faster than sequential.',
    },
    {
      id: 'en-j9-3',
      question: 'Why should you not use await inside forEach?',
      options: [
        'It is a syntax error',
        'forEach does not wait for async work',
        'It logs a warning',
        'It is fine and recommended',
      ],
      answer: 1,
      explanation: 'forEach ignores the returned promises and finishes immediately; use for...of.',
    },
  ],

  'en/javascript/10-dom': [
    {
      id: 'en-j10-1',
      question: 'Which method selects the first element with class "box"?',
      options: [
        'document.getElementById("box")',
        'document.querySelector(".box")',
        'document.getElementsByClassName("box")',
        'document.find(".box")',
      ],
      answer: 1,
      explanation: 'querySelector accepts a CSS selector and returns the first match.',
    },
    {
      id: 'en-j10-2',
      question: 'How do you add a class to an element?',
      options: [
        'el.class = "active"',
        'el.classList.add("active")',
        'el.addClass("active")',
        'el.style.class = "active"',
      ],
      answer: 1,
      explanation: 'classList offers add / remove / toggle / contains.',
    },
    {
      id: 'en-j10-3',
      question: 'For safety, which should you use to insert user input?',
      options: ['innerHTML', 'textContent', 'outerHTML', 'document.write'],
      answer: 1,
      explanation: 'textContent treats content as plain text and avoids XSS.',
    },
  ],

  'en/javascript/11-es6-plus': [
    {
      id: 'en-j11-1',
      question: 'What is the cleanest way to dedupe an array?',
      options: [
        'arr.filter((v, i) => arr.indexOf(v) === i)',
        '[...new Set(arr)]',
        'arr.unique()',
        'arr.dedupe()',
      ],
      answer: 1,
      explanation: 'Set auto-dedupes; spread it back with [...new Set(arr)].',
    },
    {
      id: 'en-j11-2',
      question: 'How many default exports can a module have?',
      options: ['0', '1', '2', 'Unlimited'],
      answer: 1,
      explanation: 'A module has at most one default export; named exports can be many.',
    },
    {
      id: 'en-j11-3',
      question: 'In class Dog extends Animal, what calls the parent constructor?',
      options: ['this()', 'parent()', 'super()', 'Animal()'],
      answer: 2,
      explanation: 'super() calls the parent constructor and must run before using this.',
    },
  ],
};

/** 取某篇文档的测验题 */
export function getQuiz(lang: Lang, language: string, slug: string): QuizQuestion[] {
  return QUIZZES[`${lang}/${language}/${slug}`] ?? [];
}
