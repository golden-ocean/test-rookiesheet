import type { Lang } from './config';

export interface LanguageMeta {
  /** 语言标识，与 content 中 language 字段一致 */
  id: string;
  /** 显示名 */
  name: string;
  /** 各语言下的显示名 */
  nameI18n: Record<Lang, string>;
  /** 简短说明 */
  desc: Record<Lang, string>;
  /** 图标简写 / logo 文本 */
  badge: string;
  /** 主题色(hex) */
  color: string;
  /** 是否已上线 */
  available: boolean;
}

export const LANGUAGES: LanguageMeta[] = [
  {
    id: 'javascript',
    name: 'JavaScript',
    nameI18n: { zh: 'JavaScript', en: 'JavaScript' },
    desc: {
      zh: '网页交互的核心语言，前端必学第一门',
      en: 'The language of the web — your essential first step',
    },
    badge: 'JS',
    color: '#f7df1e',
    available: true,
  },
  {
    id: 'python',
    name: 'Python',
    nameI18n: { zh: 'Python', en: 'Python' },
    desc: {
      zh: '最易上手的通用语言，数据分析与 AI 首选',
      en: 'The friendliest general-purpose language for data & AI',
    },
    badge: 'PY',
    color: '#3776ab',
    available: false,
  },
  {
    id: 'sql',
    name: 'SQL',
    nameI18n: { zh: 'SQL', en: 'SQL' },
    desc: {
      zh: '和数据库对话的标准语言',
      en: 'The standard way to talk to databases',
    },
    badge: 'SQL',
    color: '#e38c00',
    available: false,
  },
  {
    id: 'shell',
    name: 'Linux / Shell',
    nameI18n: { zh: 'Linux / Shell', en: 'Linux / Shell' },
    desc: {
      zh: '命令行操作与脚本自动化必备',
      en: 'Essential command-line skills and scripting',
    },
    badge: '$',
    color: '#4eaa25',
    available: false,
  },
];

export function getLanguage(id: string): LanguageMeta | undefined {
  return LANGUAGES.find((l) => l.id === id);
}
