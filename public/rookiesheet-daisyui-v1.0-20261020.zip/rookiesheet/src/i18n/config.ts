export const languages = {
  zh: '简体中文',
  en: 'English',
} as const;

export const defaultLang = 'zh';

export type Lang = keyof typeof languages;

/** 从 URL 路径推导当前语言 */
export function getLangFromUrl(url: URL): Lang {
  const [, seg] = url.pathname.split('/');
  if (seg in languages) return seg as Lang;
  return defaultLang;
}

/** 把路径转换为指定语言的路径。zh 为默认语言不加前缀 */
export function localizePath(path: string, lang: Lang): string {
  const clean = '/' + path.replace(/^\/+|\/+$/g, '');
  if (lang === defaultLang) return clean === '/' ? '/' : clean;
  return clean === '/' ? `/${lang}` : `/${lang}${clean}`;
}

/** 当前页面对应的另一种语言路径 */
export function getAlternateLang(lang: Lang): Lang {
  return lang === 'zh' ? 'en' : 'zh';
}
