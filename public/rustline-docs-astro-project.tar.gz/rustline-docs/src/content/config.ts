import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const docs = defineCollection({
  loader: glob({ pattern: '**/*.mdx', base: './src/content/docs' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    /** 侧栏分组名，如「快速开始」「语言基础」 */
    group: z.string(),
    /** 组内排序 */
    order: z.number(),
    /** 分组排序 */
    groupOrder: z.number().default(99),
    tags: z.array(z.string()).default([]),
    updated: z.coerce.date().optional(),
  }),
});

export const collections = { docs };
