import { getCollection } from 'astro:content';

export interface SidebarItem {
  /** 内容集合 entry.id，如 language-basics/ownership */
  id: string;
  title: string;
  href: string;
  order: number;
}

export interface SidebarGroup {
  name: string;
  order: number;
  items: SidebarItem[];
}

/** 构建期派生侧栏目录树（按 frontmatter.group 分组，order 排序） */
export async function getSidebar(): Promise<SidebarGroup[]> {
  const docs = await getCollection('docs');
  const groups = new Map<string, SidebarGroup>();

  for (const doc of docs) {
    const { title, group, order, groupOrder = 99 } = doc.data;
    if (!groups.has(group)) {
      groups.set(group, { name: group, order: groupOrder, items: [] });
    }
    groups.get(group)!.items.push({
      id: doc.id,
      title,
      href: `/docs/${doc.id}/`,
      order,
    });
  }

  return [...groups.values()]
    .sort((a, b) => a.order - b.order)
    .map((g) => ({ ...g, items: g.items.sort((a, b) => a.order - b.order) }));
}

/** 构建期计算上一篇 / 下一篇（按分组顺序扁平化） */
export async function getPrevNext(currentId: string) {
  const sidebar = await getSidebar();
  const flat = sidebar.flatMap((g) => g.items);
  const idx = flat.findIndex((i) => i.id === currentId);
  return {
    prev: idx > 0 ? flat[idx - 1] : null,
    next: idx >= 0 && idx < flat.length - 1 ? flat[idx + 1] : null,
  };
}

/** 序列化给搜索岛的轻量索引 */
export type SearchDoc = { title: string; href: string; group: string };
export function toSearchDocs(sidebar: SidebarGroup[]): SearchDoc[] {
  return sidebar.flatMap((g) => g.items.map((i) => ({ title: i.title, href: i.href, group: g.name })));
}
