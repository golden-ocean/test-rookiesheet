import * as React from 'react';
import { Moon, Sun } from 'lucide-react';
import { Button } from '../ui/button';

/**
 * 主题切换岛（client:idle）。
 * 初始主题由 DocLayout 中 head 内联脚本设置（防 FOUC），
 * 这里只负责切换 .dark 类并持久化到 localStorage。
 */
export default function ThemeToggle() {
  const [dark, setDark] = React.useState(false);

  React.useEffect(() => {
    setDark(document.documentElement.classList.contains('dark'));
  }, []);

  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle('dark', next);
    localStorage.setItem('theme', next ? 'dark' : 'light');
  };

  return (
    <Button variant="ghost" size="icon" onClick={toggle} title="切换主题" aria-label="切换主题">
      {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </Button>
  );
}
