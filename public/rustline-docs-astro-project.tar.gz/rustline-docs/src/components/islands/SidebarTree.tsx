import * as React from 'react';
import { ChevronDown, FileText, FolderOpen } from 'lucide-react';
import { cn } from '../../lib/utils';
import type { SidebarGroup } from '../../lib/sidebar';

interface Props {
  tree: SidebarGroup[];
  currentHref: string;
}

/**
 * 侧栏目录树岛（client:idle）。
 * 修正原型问题：缩进由层级统一计算（不再手工 border-left 错位），
 * 折叠状态自管并带 aria-expanded，当前页由构建期传入的 currentHref 标记（零运行时 JS 判定）。
 */
export default function SidebarTree({ tree, currentHref }: Props) {
  // 当前页所在分组默认展开，其余收起
  const [open, setOpen] = React.useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    for (const g of tree) init[g.name] = g.items.some((i) => i.href === currentHref);
    return init;
  });

  return (
    <nav aria-label="文档目录">
      <p className="px-2 mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        文档目录
      </p>
      {tree.map((group) => {
        const expanded = !!open[group.name];
        return (
          <div key={group.name} className="mb-3">
            <button
              onClick={() => setOpen((s) => ({ ...s, [group.name]: !s[group.name] }))}
              aria-expanded={expanded}
              className="flex items-center gap-1.5 w-full px-2 py-1.5 text-[13px] font-semibold rounded-md
                         hover:bg-accent cursor-pointer text-left"
            >
              <ChevronDown
                className={cn('h-4 w-4 text-muted-foreground transition-transform', !expanded && '-rotate-90')}
              />
              <FolderOpen className="h-4 w-4 text-muted-foreground" />
              {group.name}
            </button>
            {expanded && (
              <ul className="ml-[19px] pl-3 border-l border-border">
                {group.items.map((item) => {
                  const active = item.href === currentHref;
                  return (
                    <li key={item.id}>
                      <a
                        href={item.href}
                        aria-current={active ? 'page' : undefined}
                        className={cn(
                          'flex items-center gap-1.5 my-px px-2 py-[5px] text-[13px] rounded-md transition-colors',
                          active
                            ? 'bg-secondary text-foreground font-semibold'
                            : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                        )}
                      >
                        <FileText className="h-3.5 w-3.5 shrink-0" />
                        {item.title}
                      </a>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        );
      })}
    </nav>
  );
}
