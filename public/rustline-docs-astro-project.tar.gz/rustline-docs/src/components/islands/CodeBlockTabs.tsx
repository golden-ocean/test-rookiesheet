import * as React from 'react';
import { Check, Copy } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface CodeTab {
  label: string;
  code: string;
  lang?: string;
}

interface Props {
  tabs: CodeTab[];
}

/** 轻量语法着色：关键字 / 字符串 / 注释 / 数字 / 宏与函数名 */
const KEYWORDS = /\b(fn|let|mut|const|struct|enum|impl|trait|pub|use|return|if|else|for|while|match|unsafe|move|String|str)\b/g;

function highlight(code: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  // 逐行处理，注释优先，避免跨 token 误染
  code.split('\n').forEach((line, li) => {
    if (li > 0) nodes.push(<br key={`br-${li}`} />);
    const commentIdx = line.indexOf('//');
    const body = commentIdx >= 0 ? line.slice(0, commentIdx) : line;
    const comment = commentIdx >= 0 ? line.slice(commentIdx) : '';

    let last = 0;
    const tokenRe = /("[^"]*")|(\b\d+\b)|\b(fn|let|mut|const|struct|enum|impl|trait|pub|use|return|if|else|for|while|match|unsafe|move)\b|([a-zA-Z_][a-zA-Z0-9_]*!)/g;
    let m: RegExpExecArray | null;
    while ((m = tokenRe.exec(body))) {
      if (m.index > last) nodes.push(body.slice(last, m.index));
      if (m[1]) nodes.push(<span key={`${li}-${m.index}`} className="text-green-700 dark:text-green-400">{m[1]}</span>);
      else if (m[2]) nodes.push(<span key={`${li}-${m.index}`} className="text-orange-600 dark:text-orange-400">{m[2]}</span>);
      else if (m[3]) nodes.push(<span key={`${li}-${m.index}`} className="text-fuchsia-700 dark:text-fuchsia-400">{m[3]}</span>);
      else if (m[4]) nodes.push(<span key={`${li}-${m.index}`} className="text-blue-700 dark:text-blue-400">{m[4]}</span>);
      last = m.index + m[0].length;
    }
    if (last < body.length) nodes.push(body.slice(last));
    if (comment) nodes.push(<span key={`${li}-cm`} className="text-zinc-400 italic">{comment}</span>);
  });
  return nodes;
}

/**
 * 代码块 Tab 岛（client:idle），同时注册为 MDX 组件（经 CodeTabs.astro 包装）。
 * 代码以字符串 props 传入，构建期即序列化进 HTML 数据，无运行时请求。
 */
export default function CodeBlockTabs({ tabs }: Props) {
  const [active, setActive] = React.useState(0);
  const [copied, setCopied] = React.useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(tabs[active].code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* 剪贴板不可用时静默 */
    }
  };

  return (
    <div className="my-6 rounded-md border border-border overflow-hidden bg-zinc-50 dark:bg-zinc-900">
      <div className="flex items-center gap-0.5 px-2.5 pt-1.5 bg-muted border-b border-border">
        {tabs.map((t, i) => (
          <button
            key={t.label}
            onClick={() => setActive(i)}
            className={cn(
              'px-3.5 py-1.5 text-[12.5px] font-medium rounded-t-md cursor-pointer transition-colors border-b-2',
              i === active
                ? 'text-foreground bg-zinc-50 dark:bg-zinc-900 border-foreground'
                : 'text-muted-foreground hover:text-foreground border-transparent'
            )}
          >
            {t.label}
          </button>
        ))}
        <button
          onClick={copy}
          className="ml-auto mb-1.5 p-1.5 rounded text-muted-foreground hover:bg-accent hover:text-foreground cursor-pointer"
          aria-label="复制代码"
        >
          {copied ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
        </button>
      </div>
      <pre className="p-4 text-[13px] leading-7 overflow-x-auto font-mono">
        <code>{highlight(tabs[active].code)}</code>
      </pre>
    </div>
  );
}
