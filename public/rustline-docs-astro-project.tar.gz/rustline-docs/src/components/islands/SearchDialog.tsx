import * as React from 'react';
import { Command } from 'cmdk';
import { Search } from 'lucide-react';
import type { SearchDoc } from '../../lib/sidebar';

interface Props {
  docs: SearchDoc[];
}

/**
 * ⌘K 搜索岛（client:visible）。
 * 搜索索引在构建期由 lib/sidebar.ts 派生并以 props 序列化传入，运行时零请求。
 * 后续可平滑替换为 Pagefind / shadcn Command Dialog 完整形态。
 */
export default function SearchDialog({ docs }: Props) {
  const [open, setOpen] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((v) => !v);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  React.useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 0);
  }, [open]);

  return (
    <>
      {/* 触发器：外观与 shadcn 搜索框一致 */}
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 w-60 h-[34px] px-2.5 text-[13px] text-muted-foreground
                   border border-input rounded-md bg-background hover:border-ring transition-colors cursor-pointer"
      >
        <Search className="h-4 w-4 shrink-0" />
        搜索文档…
        <span className="ml-auto flex gap-0.5">
          <kbd className="text-[11px] px-1.5 border border-border rounded bg-muted">⌘</kbd>
          <kbd className="text-[11px] px-1.5 border border-border rounded bg-muted">K</kbd>
        </span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[200] bg-black/50 flex items-start justify-center pt-[20vh]"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-lg rounded-lg border border-border bg-background shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <Command label="搜索文档">
              <div className="flex items-center gap-2 px-3 border-b border-border">
                <Search className="h-4 w-4 text-muted-foreground shrink-0" />
                <Command.Input
                  ref={inputRef}
                  placeholder="输入关键词搜索…"
                  className="w-full h-11 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                />
              </div>
              <Command.List className="max-h-72 overflow-y-auto p-2">
                <Command.Empty className="py-6 text-center text-sm text-muted-foreground">
                  未找到相关文档
                </Command.Empty>
                {['快速开始', '语言基础', '进阶主题', '标准库与生态'].map((groupName) => (
                  <Command.Group
                    key={groupName}
                    heading={groupName}
                    className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:text-muted-foreground"
                  >
                    {docs
                      .filter((d) => d.group === groupName)
                      .map((d) => (
                        <Command.Item
                          key={d.href}
                          value={`${d.group} ${d.title}`}
                          onSelect={() => {
                            window.location.href = d.href;
                          }}
                          className="px-2 py-1.5 text-sm rounded-md cursor-pointer aria-selected:bg-accent"
                        >
                          {d.title}
                        </Command.Item>
                      ))}
                  </Command.Group>
                ))}
              </Command.List>
            </Command>
          </div>
        </div>
      )}
    </>
  );
}
