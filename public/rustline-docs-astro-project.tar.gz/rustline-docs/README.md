# Rustline Docs — Astro + shadcn/ui 文档学习站

基于路线 A（Astro 静态壳 + React 岛）实现的编程语言文档学习站，全部页面 SSG 静态输出，仅 4 个交互岛需要 hydration。

## 运行

```bash
npm install
npm run dev      # http://localhost:4321
npm run build    # 静态产物输出到 dist/
```

## 架构速览

- **汇聚点**：所有组件最终组装于 `src/layouts/DocLayout.astro`
- **静态（.astro）**：Header / Sidebar / Toc / Breadcrumb / Alert / DocPager / ProgressCard
- **交互岛（.tsx）**：仅 4 个
  | 岛 | hydration | 职责 |
  |----|-----------|------|
  | `ThemeToggle.tsx` | client:idle | 明暗主题切换（head 内联脚本防 FOUC） |
  | `SearchDialog.tsx` | client:visible | ⌘K 搜索（cmdk，索引构建期序列化传入） |
  | `CodeBlockTabs.tsx` | client:idle | 代码块 Tab + 复制 + 轻量高亮 |
  | `SidebarTree.tsx` | client:idle | 目录树折叠（层级缩进统一计算，修复原型错位） |
- **内容源**：`src/content/docs/**/*.mdx`，schema 见 `src/content/config.ts`
- **目录树 / 上下篇 / 搜索索引**：`src/lib/sidebar.ts` 构建期派生，运行时零请求
- **主题令牌**：Tailwind + shadcn CSS 变量（Zinc 色板，`.dark` 类切换），见 `src/styles/globals.css`

## 新增一篇文档

在 `src/content/docs/<分组目录>/` 下新建 `.mdx`，frontmatter 必填：

```yaml
---
title: 页面标题
description: 一句话简介
group: 语言基础      # 侧栏分组名
groupOrder: 2        # 分组排序
order: 3             # 组内排序
tags: [入门]
---
```

正文可直接使用 `<Alert title="...">` 与 `<CodeTabs tabs={[{label, code}]} />`。

## 后续可选升级

- 用 `npx shadcn@latest init` + `add` 替换手写 ui 基础件（获得 Radix 无障碍完整实现）
- 搜索接入 Pagefind（构建期生成索引，保持全静态）
- 代码高亮换用 Shiki（Astro 内置支持，构建期着色、零客户端 JS）

---

内容由 AI 生成
