# 设计文档：Rustline 文档学习站（Astro + shadcn/ui 路线 A）

- 日期：2026-10-20
- 状态：已获用户确认（"好的，就按路线a走"）
- 来源原型：prototype-html/prototype-programming-docs-v1.html

## 选型结论

- 路线 A：Astro 静态壳 + React 岛（shadcn/ui 风格），交互岛统一 `client:idle` / `client:visible`
- 内容源：Astro Content Collections（MDX），构建期全部 SSG，运行时零数据请求
- 样式：Tailwind CSS + shadcn CSS 变量令牌，`.dark` 类切换明暗主题
- 所有组件最终汇聚到 `src/layouts/DocLayout.astro`

## 组件拆分与文件结构

```
src/
├── layouts/DocLayout.astro          # 唯一汇聚点（含防 FOUC 主题脚本）
├── components/
│   ├── chrome/                      # 骨架，全 .astro 静态
│   │   ├── Header.astro             # 顶栏壳（内嵌 SearchDialog / ThemeToggle 岛）
│   │   ├── Sidebar.astro            # 侧栏壳（ProgressCard + SidebarTree 岛）
│   │   ├── Toc.astro                # 右侧目录（headings 生成 + IntersectionObserver 高亮）
│   │   └── Breadcrumb.astro
│   ├── docs/                        # 正文级组件（可在 MDX 中经 components 映射使用）
│   │   ├── Alert.astro              # info / warn
│   │   ├── CodeTabs.astro           # 包装 CodeBlockTabs 岛，供 MDX 使用
│   │   ├── DocPager.astro           # 上一篇/下一篇
│   │   └── ProgressCard.astro       # 学习进度卡（localStorage 原生脚本）
│   ├── islands/                     # React tsx 岛（仅 4 个）
│   │   ├── ThemeToggle.tsx          # client:idle
│   │   ├── SearchDialog.tsx         # cmdk Command，client:visible
│   │   ├── CodeBlockTabs.tsx        # 代码 Tab，client:idle
│   │   └── SidebarTree.tsx          # Collapsible 目录树，client:idle
│   └── ui/button.tsx                # shadcn 基础件（cva）
├── content/config.ts                # docs 集合 schema
├── content/docs/**/*.mdx
├── lib/                             # sidebar.ts（树/prev-next 构建期派生）、utils.ts（cn）
├── styles/globals.css               # Tailwind + shadcn 令牌（zinc 色板）
└── pages/
    ├── index.astro                  # 重定向到首篇文档
    └── docs/[...slug].astro         # getStaticPaths 全静态
```

## astro vs tsx 判定原则

- .astro：渲染后无需响应用户输入的一切（骨架、侧栏 HTML、TOC、面包屑、分页、Alert、表格）
- .tsx 岛：仅有真实状态切换的 4 个组件；TOC 高亮、进度卡等微交互用原生 `is:inline` 脚本，不建岛

## Sidebar 错位与层级修正

1. 树数据带层级字段，缩进由 `depth * indent` 统一生成，弃用手工 border-left
2. 折叠交互由 SidebarTree 岛的 Collapsible 状态驱动，caret 随 data-state 旋转，自带 aria
3. 激活态由 `[...slug].astro` 构建期传入当前 href 标记，零运行时 JS

## 数据流

content/docs/*.mdx → getStaticPaths（构建期算好目录树、prev/next、headings、搜索索引）
→ DocLayout.astro props → Header / Sidebar / <Content /> / Toc。搜索索引以 props 序列化给 SearchDialog 岛。

---

内容由 AI 生成
