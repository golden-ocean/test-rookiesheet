---
title: Async programming
description: Goroutines, channels and context for safe concurrency.
language: go
section: Advanced
order: 7
updated: 2026-10-18
minutes: 11
tags: [advanced, concurrency, goroutine]
notice: Concurrency is not parallelism; the goal here is safe communication.
---

Go follows the CSP model: do not communicate by sharing memory; share memory by communicating.

## Goroutines

```go
func worker(id int, wg *sync.WaitGroup) {
	defer wg.Done()
	time.Sleep(100 * time.Millisecond)
	fmt.Printf("worker %d done\n", id)
}

func main() {
	var wg sync.WaitGroup
	for i := 1; i <= 3; i++ {
		wg.Add(1)
		go worker(i, &wg)
	}
	wg.Wait()
}
```

> When `main` returns, every pending goroutine is killed. Always wait via `WaitGroup`, a channel or a `context`.

## Channels

```go
func producer(ch chan<- int, n int) {
	for i := 0; i < n; i++ {
		ch <- i
	}
	close(ch) // the sender closes
}

func consumer(ch <-chan int) int {
	total := 0
	for v := range ch {
		total += v
	}
	return total
}

ch := make(chan int, 4) // buffered
go producer(ch, 10)
fmt.Println(consumer(ch))
```

| Operation | nil channel | closed channel |
|---|---|---|
| send | blocks forever | panics |
| receive | blocks forever | returns zero value |

## select and timeouts

```go
select {
case result := <-jobs:
	fmt.Println("got", result)
case <-time.After(2 * time.Second):
	fmt.Println("timeout")
}
```

## context for cancellation

```go
ctx, cancel := context.WithTimeout(context.Background(), 300*time.Millisecond)
defer cancel()

select {
case <-ctx.Done():
	fmt.Println(ctx.Err()) // context deadline exceeded
case <-done:
}
```

## Mutexes

Channels are not always the answer. A mutex is clearer for guarding a counter:

```go
type Counter struct {
	mu sync.Mutex
	n  int
}

func (c *Counter) Inc() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.n++
}
```

## Race detector

```bash
go test -race ./...
go run -race main.go
```

Run it whenever goroutines touch shared state. It points directly at the conflicting accesses.
