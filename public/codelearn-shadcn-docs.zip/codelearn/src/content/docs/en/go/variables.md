---
title: Variables & types
description: Declarations, basic and composite types, and how zero values work.
language: go
section: Core concepts
order: 3
updated: 2026-10-18
minutes: 9
tags: [core, types]
---

Go is statically typed, but the compiler infers most types for you. Understanding zero values and value semantics is essential.

## Declarations

```go
var a int        // zero value 0
var b = 3.14     // float64
c := "hello"     // short declaration, functions only

const (
	StatusOK = iota // 0
	StatusErr       // 1
)
```

## Basic types

| Type | Notes | Zero value |
|---|---|---|
| `bool` | boolean | `false` |
| `int`, `int64` | integers, `int` is platform sized | `0` |
| `float64` | floating point | `0` |
| `string` | immutable UTF-8 bytes | `""` |
| `rune` | alias for `int32`, one code point | `0` |

```go
s := "héllo"
fmt.Println(len(s))         // 6 bytes
fmt.Println(len([]rune(s))) // 5 runes
```

> Iterate strings with `for _, r := range s` to get runes rather than bytes.

## Composite types

```go
nums := []int{1, 2, 3}
nums = append(nums, 4)

scores := make(map[string]int) // must be made before writing
scores["go"] = 100

value, ok := scores["rust"] // comma-ok idiom
fmt.Println(value, ok)      // 0 false

type Point struct{ X, Y int }
p := Point{X: 1}
q := p
q.X = 100
fmt.Println(p.X, q.X) // 1 100 — structs are copied
```

## Pointers

Arguments are passed by value. Use pointers to mutate the caller's data or avoid copying large structs.

```go
func inc(n *int) { *n++ }

x := 1
inc(&x)
fmt.Println(x) // 2
```

Slices, maps and channels already hold references; appending or re-assigning them inside a function does not affect the caller's variable.
