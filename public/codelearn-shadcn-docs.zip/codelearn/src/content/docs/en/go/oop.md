---
title: Object orientation
description: Structs, methods and interfaces as Go's take on abstraction.
language: go
section: Core concepts
order: 6
updated: 2026-10-18
minutes: 9
tags: [core, interfaces]
---

Go has no classes and no inheritance. Structs, methods and interfaces give you the same abstractions with composition instead of hierarchy.

## Structs and methods

```go
type Account struct {
	ID      string
	Balance float64
}

// value receiver: read-only, copies the value
func (a Account) Describe() string {
	return fmt.Sprintf("account %s balance %.2f", a.ID, a.Balance)
}

// pointer receiver: can mutate
func (a *Account) Deposit(amount float64) error {
	if amount <= 0 {
		return fmt.Errorf("invalid amount: %v", amount)
	}
	a.Balance += amount
	return nil
}
```

> Pick one receiver style per type and stick to it.

## Interfaces are satisfied implicitly

```go
type Depositor interface {
	Deposit(float64) error
}

func transfer(to Depositor, amount float64) error {
	return to.Deposit(amount)
}
```

`Account` implements `Depositor` simply by having the method. No `implements` keyword exists.

## Embedding

```go
type Logger struct{}

func (Logger) Log(msg string) { fmt.Println("[log]", msg) }

type Service struct {
	Logger // promoted methods
	Name   string
}

s := Service{Name: "user-service"}
s.Log("starting")
```

Embedding is composition, not inheritance: `Service` does not become an `Account`, it just reuses behaviour.

## Type assertions

```go
var v any = &Account{ID: "A1"}

if a, ok := v.(*Account); ok {
	fmt.Println("account", a.ID)
}

switch t := v.(type) {
case *Account:
	fmt.Println("account", t.Balance)
case nil:
	fmt.Println("nil interface")
default:
	fmt.Printf("other %T\n", t)
}
```

Only introduce an interface when there is a real second implementation or a genuine need to decouple.
