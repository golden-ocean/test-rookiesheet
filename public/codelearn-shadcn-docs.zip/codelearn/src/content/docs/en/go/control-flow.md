---
title: Control flow
description: Idiomatic if, for, switch and defer.
language: go
section: Core concepts
order: 4
updated: 2026-10-18
minutes: 7
tags: [core, syntax]
notice: Every snippet runs as-is on Go 1.22+.
---

Go has very few control keywords. There is no `while` loop and no ternary operator.

## if with an initializer

```go
if result, err := divide(10, 2); err != nil {
	fmt.Println("failed:", err)
} else {
	fmt.Println("result:", result) // 5
}
```

The variable declared in the initializer is scoped to the `if`/`else` block.

## for in three shapes

```go
for i := 0; i < 3; i++ { /* classic */ }

n := 3
for n > 0 { n-- } // acts as while

items := []string{"a", "b"}
for idx, item := range items {
	fmt.Println(idx, item)
}
```

Use labels to break out of nested loops:

```go
outer:
for i := 0; i < 3; i++ {
	for j := 0; j < 3; j++ {
		if i*j == 2 {
			break outer
		}
	}
}
```

## switch

Cases do not fall through, and the switch expression is optional.

```go
func label(day string) string {
	switch day {
	case "sat", "sun":
		return "weekend"
	case "mon":
		return "monday"
	default:
		return "weekday"
	}
}

score := 85
switch {
case score >= 90:
	fmt.Println("A")
case score >= 80:
	fmt.Println("B")
}
```

## defer

Deferred calls run when the function returns, in LIFO order.

```go
f, err := os.Create(path)
if err != nil {
	return err
}
defer f.Close()
```

> Arguments to a deferred call are evaluated at registration time, which matters inside loops.

| Keyword | Purpose |
|---|---|
| `if` | branching with initializer |
| `for` | the only loop |
| `switch` | no implicit fallthrough |
| `defer` | cleanup, LIFO |
