---
title: Functions
description: Multiple return values, variadics, closures and function types.
language: go
section: Core concepts
order: 5
updated: 2026-10-18
minutes: 8
tags: [core, functions]
---

Functions are Go's only unit of reuse. There is no overloading and no default parameters, yet multiple return values cover most needs.

## Signatures

```go
// grouped parameters, results after the parameter list
func divmod(a, b int) (int, int) {
	return a / b, a % b
}

func parsePositive(s string) (n int, err error) {
	n, err = strconv.Atoi(s)
	if err != nil {
		return 0, fmt.Errorf("invalid number: %w", err)
	}
	if n <= 0 {
		return 0, errors.New("must be positive")
	}
	return n, nil
}
```

> Named results are handy for documentation but easy to shadow with `:=`. Use them sparingly.

## Variadic functions

```go
func sum(nums ...int) int {
	total := 0
	for _, n := range nums {
		total += n
	}
	return total
}

sum(1, 2, 3)
nums := []int{4, 5}
sum(nums...) // spread a slice
```

## Functions as values, and closures

```go
type Operator func(int, int) int

func newCounter() func() int {
	count := 0
	return func() int { // captures count
		count++
		return count
	}
}

func apply(op Operator, a, b int) int { return op(a, b) }
```

## Built-ins worth knowing

| Built-in | Purpose |
|---|---|
| `len`, `cap` | length and capacity |
| `append` | grow a slice |
| `make` | create slices, maps, channels |
| `delete` | remove a map key |
| `panic`, `recover` | unrecoverable failures only |

```go
func safeRun(fn func()) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("panic: %v", r)
		}
	}()
	fn()
	return nil
}
```

Give functions one job and keep them short. A function that takes more than four parameters usually wants a config struct.
