---
title: Best practices
description: Project layout, error conventions, testing and performance habits.
language: go
section: Advanced
order: 9
updated: 2026-10-18
minutes: 10
tags: [advanced, engineering]
notice: Most of these are community conventions rather than compiler rules.
---

Go code looks similar across companies because the community converged on a small set of idioms. These are the ones that matter most.

## Project layout

```text
myapp/
├── go.mod
├── cmd/server/main.go     # entry point
├── internal/user/service.go
└── Makefile
```

`internal/` is enforced by the compiler: outside modules cannot import it. Keep package names short and lowercase.

## Error conventions

```go
var ErrNotFound = errors.New("not found")

func (s *Store) Get(id string) (*User, error) {
	u, ok := s.data[id]
	if !ok {
		return nil, fmt.Errorf("get user %s: %w", id, ErrNotFound)
	}
	return u, nil
}
```

| Situation | Approach |
|---|---|
| Expected failure | return `error` |
| Add context | `fmt.Errorf("...: %w", err)` |
| Inspect | `errors.Is` / `errors.As` |
| Unrecoverable | `panic`, only during init |

## Testing

Table-driven tests are the norm:

```go
func TestParsePort(t *testing.T) {
	tests := []struct {
		name    string
		in      string
		want    int
		wantErr bool
	}{
		{"valid", "8080", 8080, false},
		{"too big", "70000", 0, true},
		{"not a number", "abc", 0, true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := parsePort(tt.in)
			if (err != nil) != tt.wantErr {
				t.Fatalf("err = %v, wantErr %v", err, tt.wantErr)
			}
			if got != tt.want {
				t.Errorf("got %d, want %d", got, tt.want)
			}
		})
	}
}
```

## Performance habits

```go
result := make([]int, 0, len(input)) // preallocate

var sb strings.Builder
for _, s := range parts {
	sb.WriteString(s)
}

sem := make(chan struct{}, 10) // bounded concurrency
for _, task := range tasks {
	sem <- struct{}{}
	go func(t Task) {
		defer func() { <-sem }()
		run(t)
	}(task)
}
```

> Measure before optimizing: `go test -bench . -benchmem`.

## Pre-commit checklist

- [ ] `gofmt -l .` prints nothing
- [ ] `go vet ./...` passes
- [ ] `go test -race ./...` passes
- [ ] `go mod tidy` leaves no stray dependencies
