---
title: Standard library
description: A practical tour of strings, strconv, time, os, encoding/json and more.
language: go
section: Advanced
order: 8
updated: 2026-10-18
minutes: 9
tags: [advanced, stdlib]
---

Go's standard library is deliberately broad. Many production services run with zero third-party dependencies.

## Strings and conversions

```go
s := "  Go, Is, Fun  "
strings.TrimSpace(s)          // "Go, Is, Fun"
strings.Split("a,b,c", ",")   // [a b c]
strings.Contains("gopher", "go") // true
strings.ToUpper("go")         // GO

n, err := strconv.Atoi("42")
if err != nil {
	panic(err)
}
strconv.Itoa(n * 2)                     // "84"
strconv.FormatFloat(1.5, 'f', 2, 64)    // "1.50"
```

## Time

```go
now := time.Now()
now.Format("2006-01-02 15:04:05")
now.Add(48 * time.Hour)
now.Before(now.Add(time.Minute)) // true
```

> Layouts use the reference time `2006-01-02 15:04:05`, not `yyyy-MM-dd`.

## Files

```go
data, err := os.ReadFile(path) // Go 1.16+
if err != nil {
	return err
}
_ = os.WriteFile(path, data, 0o644)
```

## JSON

```go
type User struct {
	Name  string `json:"name"`
	Email string `json:"email,omitempty"`
	Age   int    `json:"-"`
}

b, _ := json.Marshal(User{Name: "Tom"})
// {"name":"Tom"}

var u User
_ = json.Unmarshal(b, &u)
```

## Sorting

```go
sort.Ints(nums)
sort.Slice(nums, func(i, j int) bool { return nums[i] > nums[j] })
```

## Cheat sheet

| Package | Use |
|---|---|
| `fmt` | formatted I/O and errors |
| `strings`, `bytes` | text and byte handling |
| `strconv` | string/number conversion |
| `time` | clocks, timers, formatting |
| `os`, `io`, `bufio` | files and streams |
| `encoding/json` | JSON |
| `sort`, `slices` | ordering and slice helpers |
| `errors` | `Is`, `As`, `Join` |
| `sync`, `context` | concurrency control |
| `net/http` | HTTP client and server |
| `testing` | tests and benchmarks |
