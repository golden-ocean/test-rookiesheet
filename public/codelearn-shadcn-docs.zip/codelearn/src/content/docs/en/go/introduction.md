---
title: Introduction
description: Why Go exists, and how to install the toolchain and verify it works.
language: go
section: Getting started
order: 1
updated: 2026-10-18
minutes: 7
tags: [beginner, installation, environment]
notice: These notes assume Go 1.22 or newer; loop variable semantics changed in that release.
---

Go is a statically typed, compiled language open sourced by Google in 2009. It aims to make concurrent server software simple to write and simple to maintain, and it powers much of the cloud-native stack (Docker, Kubernetes, etcd).

## Design philosophy

- **Simplicity first**: no inheritance, no method overloading, no exceptions.
- **Explicit errors**: failures are returned as `error` values.
- **Concurrency built in**: `goroutine` and `channel` are language primitives.
- **One toolchain**: `gofmt`, `go test` and `go mod` ship with the compiler.

> "Less is more" is the community motto. If a pattern feels convoluted, it is usually not idiomatic Go.

## Installation

| Platform | Command |
|---|---|
| macOS | `brew install go` |
| Linux | download the tarball to `/usr/local` |
| Windows | run the official MSI installer |
| Any | `go install golang.org/dl/go1.22.0@latest` |

```bash
go version
# go version go1.22.0 linux/amd64
```

## Your first module

```bash
mkdir hello && cd hello
go mod init example.com/hello
```

```go
// main.go
package main

import "fmt"

func main() {
	fmt.Println("Hello, Go")
}
```

```bash
go run main.go
# Hello, Go
```

## Command cheat sheet

```bash
go run .          # compile and run the current package
go build -o app . # build a binary
go test ./...     # run all tests
go vet ./...      # static checks
gofmt -w .        # format code
go mod tidy       # prune and fetch dependencies
```

Configure your editor to run `gofmt` on save. Consistent formatting is expected in every Go codebase.
