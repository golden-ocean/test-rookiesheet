---
title: Quick start
description: Write your first real Go program, including error handling done right.
language: go
section: Getting started
order: 2
updated: 2026-10-18
minutes: 8
tags: [beginner, syntax]
---

This walkthrough builds a tiny CLI tool to show the structure of a Go program: packages, imports, functions and errors.

## Program structure

```go
// main.go
package main

import (
	"fmt"
	"os"
)

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		fmt.Println("usage: hello <name>")
		os.Exit(1)
	}
	fmt.Printf("Hello, %s!\n", args[0])
}
```

```bash
go run main.go Gopher
# Hello, Gopher!
```

## Short declarations

```go
name := "Gopher" // inferred as string
var age int32 = 12
var score float64 // zero value 0
fmt.Println(name, age, score)
```

> Go never converts types implicitly. Adding an `int32` to an `int` requires an explicit conversion.

## Handling errors

```go
func parsePort(s string) (int, error) {
	port, err := strconv.Atoi(s)
	if err != nil {
		return 0, fmt.Errorf("invalid port: %w", err) // %w keeps the chain
	}
	if port <= 0 || port > 65535 {
		return 0, fmt.Errorf("port %d out of range", port)
	}
	return port, nil
}
```

Rules of thumb:

1. Handle errors where they occur.
2. Never report a normal branch as an error.
3. Wrap with `%w` so callers can use `errors.Is` and `errors.As`.
