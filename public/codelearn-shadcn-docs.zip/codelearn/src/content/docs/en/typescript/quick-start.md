---
title: Quick start
description: Annotations, interfaces, unions and narrowing in one small module.
language: typescript
section: Getting started
order: 2
updated: 2026-10-18
minutes: 8
tags: [beginner, syntax]
---

A small order calculator that shows annotations, interfaces, unions and narrowing.

## Annotations

```ts
const title: string = 'TypeScript basics';
let count: number = 0;

const tags: string[] = ['ts', 'types'];
const pair: [string, number] = ['age', 30];

function formatPrice(amount: number, currency = 'USD'): string {
  return `${currency} ${amount.toFixed(2)}`;
}

const double = (n: number) => n * 2; // return type inferred
```

> Do not annotate what the compiler already infers. Annotate parameters, public APIs and tricky return types.

## Interfaces and unions

```ts
interface Product {
  id: string;
  name: string;
  price: number;
}

type OrderStatus = 'pending' | 'paid' | 'shipped' | 'cancelled';

interface Order {
  id: string;
  status: OrderStatus;
  items: Array<{ product: Product; qty: number }>;
}
```

A union of literals makes invalid states unrepresentable.

## Narrowing

```ts
function total(order: Order): number {
  return order.items.reduce(
    (sum, { product, qty }) => sum + product.price * qty,
    0,
  );
}

function statusLabel(status: OrderStatus): string {
  switch (status) {
    case 'pending':
      return 'Awaiting payment';
    case 'paid':
      return 'Paid';
    case 'shipped':
      return 'Shipped';
    case 'cancelled':
      return 'Cancelled';
  }
}

const order: Order = {
  id: 'o1',
  status: 'paid',
  items: [{ product: { id: 'p1', name: 'Keyboard', price: 99 }, qty: 2 }],
};

console.log(total(order), statusLabel(order.status)); // 198 Paid
```

## unknown instead of any

```ts
function parse(input: unknown): string {
  if (typeof input === 'string') {
    return input.trim(); // narrowed to string
  }
  throw new Error('expected a string');
}
```

| Concept | Syntax |
|---|---|
| Interface | `interface User { id: string }` |
| Union | `'a' \| 'b'` |
| Optional | `name?: string` |
| Read-only | `readonly id: string` |
| External data | `unknown` + narrowing |
