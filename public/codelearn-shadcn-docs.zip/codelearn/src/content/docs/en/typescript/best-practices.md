---
title: Best practices
description: Strict config, avoiding any, domain modelling and module hygiene.
language: typescript
section: Advanced
order: 9
updated: 2026-10-18
minutes: 9
tags: [advanced, engineering]
notice: Most rules here are enforced by typescript-eslint in practice.
---

Good TypeScript is not about writing types everywhere. It is about letting types catch real mistakes.

## Configuration first

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noFallthroughCasesInSwitch": true,
    "verbatimModuleSyntax": true
  }
}
```

| Flag | Prevents |
|---|---|
| `strict` | the whole family of unsound defaults |
| `noUncheckedIndexedAccess` | assuming index access is safe |
| `noImplicitOverride` | accidental overrides |
| `verbatimModuleSyntax` | type imports leaking into runtime |

## Avoid any

```ts
// bad: any spreads through the call chain
function parseBad(json: string): any {
  return JSON.parse(json);
}

// good: unknown plus validation
function parseConfig(json: string): { port: number } {
  const raw: unknown = JSON.parse(json);
  if (
    typeof raw !== 'object' ||
    raw === null ||
    typeof (raw as { port?: unknown }).port !== 'number'
  ) {
    throw new Error('invalid config');
  }
  return raw as { port: number };
}
```

`as` assertions are equally dangerous: only use them after a runtime check that proves the type.

## Model the domain

```ts
type AccountId = string & { readonly __brand: 'AccountId' };
type Money = number & { readonly __brand: 'Money' };

function asAccountId(v: string): AccountId {
  if (!/^A\d{6}$/.test(v)) throw new Error('invalid account');
  return v as AccountId;
}

function transfer(from: AccountId, to: AccountId, amount: Money): void {
  console.log(from, '->', to, amount);
}

transfer(asAccountId('A000001'), asAccountId('A000002'), 100 as Money);
// transfer(asAccountId('A000001'), 'B2', 100 as Money); // compile error
```

Branded types stop you from passing any old `string` where an ID is expected.

## Modules

- Prefer named exports; they refactor and tree-shake better.
- Write `import type { User } from './types.js'` for types only.
- Split files by domain, not by a giant `types.ts`.

```ts
export type Status = 'idle' | 'loading' | 'success' | 'error';

import type { Status } from './types.js';

export function label(s: Status): string {
  return { idle: 'Idle', loading: 'Loading', success: 'Done', error: 'Failed' }[s];
}
```

## Before you push

1. `npx tsc --noEmit` passes.
2. `npx eslint .` is clean.
3. Every `as any` or `@ts-ignore` has an explaining comment.
