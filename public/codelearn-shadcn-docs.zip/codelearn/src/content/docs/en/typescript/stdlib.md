---
title: Standard library
description: lib settings, built-in utility types and the ES/Node APIs you use daily.
language: typescript
section: Advanced
order: 8
updated: 2026-10-18
minutes: 9
tags: [advanced, stdlib, utility-types]
---

TypeScript's "standard library" is two things: the ES and DOM declarations shipped via `lib`, and the utility types built into the compiler.

## lib configuration

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"]
  }
}
```

Drop `DOM` for server-only code so browser APIs become compile errors. `@types/node` supplies `process`, `Buffer` and `fs`.

## Utility types

```ts
interface User {
  id: string;
  name: string;
  email?: string;
}

type PartialUser = Partial<User>;
type RequiredUser = Required<User>;
type ReadonlyUser = Readonly<User>;
type PublicUser = Pick<User, 'id' | 'name'>;
type Contact = Omit<User, 'id'>;
type Dict = Record<string, number>;
type Email = NonNullable<User['email']>;
```

| Utility | Purpose |
|---|---|
| `ReturnType<F>` | function return type |
| `Parameters<F>` | parameter tuple |
| `Awaited<T>` | unwrap nested promises |
| `InstanceType<C>` | class instance type |
| `Exclude<T, U>` | remove from a union |
| `Extract<T, U>` | keep from a union |

## Array and object APIs

```ts
const nums = [3, 1, 2];

nums.toSorted((a, b) => a - b); // new array, ES2023
nums.find((n) => n > 1);        // number | undefined

const scores = new Map<string, number>([['alice', 90]]);
scores.set('bob', 75);

const uniq = [...new Set([1, 1, 2])]; // number[]
```

## Formatting

```ts
const fmt = new Intl.DateTimeFormat('en-US', { dateStyle: 'medium' });
console.log(fmt.format(new Date()));

const price = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
}).format(1234.5);
```

## Node modules

```ts
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

async function readJson<T>(name: string): Promise<T> {
  const text = await readFile(path.join(here, name), 'utf8');
  return JSON.parse(text) as T; // still validate at runtime
}
```

> Always use the `node:` prefix for built-ins; it avoids collisions and makes intent obvious.
