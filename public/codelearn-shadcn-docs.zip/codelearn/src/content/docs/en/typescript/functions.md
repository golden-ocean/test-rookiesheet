---
title: Functions
description: Signatures, overloads, generics and higher-order function types.
language: typescript
section: Core concepts
order: 5
updated: 2026-10-18
minutes: 9
tags: [core, functions, generics]
---

Typing functions is the daily work in TypeScript. A good signature tells callers how to use a function without reading the body.

## Signatures

```ts
function createUser(
  name: string,
  age?: number,
  role: 'admin' | 'member' = 'member',
): { name: string; age: number | null; role: string } {
  return { name, age: age ?? null, role };
}

type Comparator<T> = (a: T, b: T) => number;

const byLength: Comparator<string> = (a, b) => a.length - b.length;
```

## Generics

```ts
function first<T>(arr: readonly T[]): T | undefined {
  return arr[0];
}

function longest<T extends { length: number }>(a: T, b: T): T {
  return a.length >= b.length ? a : b;
}

function get<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

const user = { id: '1', age: 30 };
const age = get(user, 'age'); // number
```

> Prefer descriptive type parameter names when they carry meaning; single letters are fine for tiny helpers.

## Overloads

```ts
function parseInput(input: string): string[];
function parseInput(input: number): number;
function parseInput(input: string | number): string[] | number {
  return typeof input === 'string' ? input.split(',') : input;
}

const a = parseInput('x,y'); // string[]
const b = parseInput(1);     // number
```

Reserve overloads for public APIs; internal code often reads better with a union and a conditional return type.

## Higher-order functions

```ts
function debounce<A extends unknown[]>(
  fn: (...args: A) => void,
  delay: number,
): (...args: A) => void {
  let timer: ReturnType<typeof setTimeout> | undefined;
  return (...args: A) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}
```

## Reference

| Form | Meaning |
|---|---|
| `(...args: string[])` | variadic |
| `readonly T[]` | immutable array |
| `fn?: () => void` | optional callback |
| `never` | never returns |
| `Promise<void>` | async, no value |

```ts
type Handler = (event: { type: string }) => void;

function on(type: string, handler: Handler): void {
  handler({ type });
}
```
