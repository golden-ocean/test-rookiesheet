---
title: Variables & types
description: Inference, literal types, type vs interface and why strict mode matters.
language: typescript
section: Core concepts
order: 3
updated: 2026-10-18
minutes: 9
tags: [core, types]
notice: Assumes strict mode is enabled in tsconfig.
---

TypeScript is structurally typed: any value with the right shape is assignable, no explicit `implements` needed.

## Inference

```ts
let a = 1;            // number
const b = 1;          // 1 (literal type)
const c = [1, 2];     // number[]
let mixed = 'a';      // string

const ROUTES = {
  home: '/',
  about: '/about',
} as const;            // all properties become literal types

type RouteKey = keyof typeof ROUTES; // 'home' | 'about'
```

## type vs interface

```ts
interface User {
  id: string;
  name: string;
}

type ID = string | number;             // unions need type
type Point = { x: number; y: number };

interface Admin extends User {
  permissions: string[];
}

type Named = User & { nickname?: string };
```

| Aspect | interface | type |
|---|---|---|
| Extension | `extends` | `&` |
| Declaration merging | yes | no |
| Unions and conditionals | no | yes |

## Unions and intersections

```ts
type Result<T> =
  | { ok: true; value: T }
  | { ok: false; error: string };

function unwrap<T>(r: Result<T>): T {
  if (r.ok) return r.value;
  throw new Error(r.error);
}

type AB = { a: string } & { b: number };
```

## Assertions and guards

```ts
function isUser(v: unknown): v is User {
  return typeof v === 'object' && v !== null && 'id' in v && 'name' in v;
}

const input: unknown = JSON.parse('{"id":"1","name":"Ada"}');
if (isUser(input)) {
  console.log(input.name.toUpperCase());
}

// assertions are unsafe: the compiler trusts you
const len = (input as string).length;
```

## Strict flags

```json
{
  "strict": true,
  "noUncheckedIndexedAccess": true,
  "exactOptionalPropertyTypes": true
}
```

- `strictNullChecks` makes `null` and `undefined` distinct.
- `noUncheckedIndexedAccess` marks index access as possibly `undefined`.
- `noImplicitAny` rejects untyped parameters.

> Never silence the compiler with `as any`. Write a guard or fix the type instead.
