---
title: Object orientation
description: Classes, access modifiers, abstract classes and structural typing.
language: typescript
section: Core concepts
order: 6
updated: 2026-10-18
minutes: 8
tags: [core, class, interfaces]
notice: Decorators are intentionally out of scope; they belong to framework-level usage.
---

Classes in TypeScript are JavaScript classes plus compile-time checks: access modifiers, parameter properties and abstract classes.

## Classes

```ts
class Account {
  constructor(
    public readonly id: string,
    private balance: number = 0,
    protected currency: string = 'USD',
  ) {}

  deposit(amount: number): void {
    if (amount <= 0) throw new RangeError('amount must be positive');
    this.balance += amount;
  }

  get amount(): number {
    return this.balance;
  }

  static zero(id: string): Account {
    return new Account(id);
  }
}

const acc = Account.zero('A1');
acc.deposit(100);
console.log(acc.amount, acc.id); // 100 A1
```

| Modifier | Visible to |
|---|---|
| `public` | everywhere (default) |
| `protected` | class and subclasses |
| `private` | compile-time only |
| `readonly` | not reassignable |
| `#field` | truly private at runtime |

## Abstract classes

```ts
abstract class Shape {
  abstract area(): number;

  describe(): string {
    return `area ${this.area().toFixed(2)}`;
  }
}

class Circle extends Shape {
  constructor(private radius: number) {
    super();
  }

  area(): number {
    return Math.PI * this.radius ** 2;
  }
}

new Circle(2).describe(); // area 12.57
// new Shape();           // error: abstract class
```

## implements and structural typing

```ts
interface Serializable {
  toJSON(): unknown;
}

class TypedPoint implements Serializable {
  constructor(private x: number) {}

  toJSON() {
    return { x: this.x };
  }
}

// any object of the right shape satisfies the interface
const obj: Serializable = { toJSON: () => ({}) };
```

> `implements` is a compile-time assertion; it adds no runtime behaviour. Use abstract classes or composition to share implementation.

## When not to use classes

- Model plain data with `interface` and object literals.
- Export functions rather than `class Utils` with only static methods.
- Use a class only when state and behaviour belong together and invariants need protection.
