---
title: Introduction
description: How TypeScript relates to JavaScript, and how to set up a typed project.
language: typescript
section: Getting started
order: 1
updated: 2026-10-18
minutes: 7
tags: [beginner, installation, environment]
notice: Examples use TypeScript 5.4 with strict mode; some syntax fails on older compilers.
---

TypeScript is a superset of JavaScript: valid JS is valid TS, plus an optional static type system. Types exist only at compile time and are erased at runtime.

## Why TypeScript

| Capability | Benefit |
|---|---|
| Static checking | Catch typos and mismatches in the editor |
| Inference | You rarely annotate everything |
| Refactoring | The IDE knows object shapes precisely |
| Typed contracts | Types double as executable documentation |

> Types cannot replace tests. They prove shape, not behaviour.

## Install

```bash
mkdir ts-demo && cd ts-demo
npm init -y
npm install -D typescript tsx @types/node
npx tsc --init
```

A sensible starting `tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "outDir": "dist"
  },
  "include": ["src"]
}
```

## First program

```ts
// src/hello.ts
interface Greeting {
  name: string;
  times?: number;
}

function greet({ name, times = 1 }: Greeting): string {
  return `Hello, ${name}!`.repeat(times);
}

console.log(greet({ name: 'TypeScript', times: 2 }));
```

```bash
npx tsx src/hello.ts   # run directly
npx tsc                # compile to dist/
```

## Types as contracts

```ts
greet({ name: 'Ada' }); // OK
greet({ name: 42 });    // error: number is not string
greet({});              // error: name is missing
```

The compiler rejects bad calls before the code ever runs. That is the main reason typed codebases are easier to change safely.
