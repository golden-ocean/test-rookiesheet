---
title: Async programming
description: Typed Promises, async/await and the cost of any-typed JSON.
language: typescript
section: Advanced
order: 7
updated: 2026-10-18
minutes: 9
tags: [advanced, async, promises]
notice: This article focuses on types; read the JavaScript async article for the event loop.
---

TypeScript does not change JavaScript's async model. It does let you describe the resolved value and catch missing `await`s.

## Promise types

```ts
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function loadConfig(): Promise<Record<string, string>> {
  await delay(100);
  return { env: 'production' };
}

type ResultOf<T> = T extends Promise<infer U> ? U : T;
type Config = ResultOf<ReturnType<typeof loadConfig>>; // Record<string, string>
```

## async / await

```ts
interface User {
  id: number;
  name: string;
}

async function fetchUser(id: number): Promise<User> {
  const res = await fetch(`https://api.example.com/users/${id}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const data: unknown = await res.json(); // json() returns any
  if (!isUser(data)) throw new Error('unexpected payload');
  return data;
}

function isUser(v: unknown): v is User {
  const u = v as User;
  return typeof u?.id === 'number' && typeof u?.name === 'string';
}
```

> `unknown` plus a guard is the standard way to handle external data: HTTP responses, `JSON.parse` and `localStorage`.

## Concurrency with discriminated results

```ts
type Settled<T> =
  | { status: 'fulfilled'; value: T }
  | { status: 'rejected'; reason: unknown };

async function loadAll(ids: number[]): Promise<Settled<User>[]> {
  const results = await Promise.allSettled(ids.map(fetchUser));

  return results.map((r) =>
    r.status === 'fulfilled'
      ? { status: 'fulfilled', value: r.value }
      : { status: 'rejected', reason: r.reason },
  );
}

const users = await loadAll([1, 2, 3]);
for (const u of users) {
  if (u.status === 'fulfilled') {
    console.log(u.value.name);
  }
}
```

## Bounded concurrency

```ts
async function pool<T>(
  tasks: Array<() => Promise<T>>,
  limit = 5,
): Promise<T[]> {
  const results: T[] = [];
  let cursor = 0;

  async function run(): Promise<void> {
    while (cursor < tasks.length) {
      const index = cursor++;
      results[index] = await tasks[index]();
    }
  }

  await Promise.all(Array.from({ length: limit }, () => run()));
  return results;
}
```

## Pitfalls

- `res.json()` is typed `any` and silently disables checking.
- `void someAsync()` may produce unhandled rejections.
- `return promise` inside `try/catch` does not catch its rejection unless you `await` it.
