---
title: Control flow
description: Narrowing, discriminated unions and exhaustiveness checking.
language: typescript
section: Core concepts
order: 4
updated: 2026-10-18
minutes: 8
tags: [core, narrowing]
---

Control flow itself matches JavaScript. What TypeScript adds is tracking the type of a value in every branch, which removes most assertions.

## Narrowing techniques

```ts
function describe(value: string | number | null): string {
  if (value === null) return 'empty';
  if (typeof value === 'number') {
    return `number ${value.toFixed(2)}`;
  }
  return `string ${value.trim()}`;
}
```

| Technique | Example |
|---|---|
| `typeof` | `typeof x === 'string'` |
| Truthiness | `if (x)` removes `null`/`undefined` |
| Equality | `if (status === 'paid')` |
| `in` | `'id' in obj` |
| `instanceof` | `err instanceof Error` |
| Custom guard | `function isX(v): v is X` |

## Discriminated unions

A shared literal field lets `switch` narrow each variant.

```ts
type Shape =
  | { kind: 'circle'; radius: number }
  | { kind: 'rect'; width: number; height: number }
  | { kind: 'triangle'; base: number; height: number };

function area(shape: Shape): number {
  switch (shape.kind) {
    case 'circle':
      return Math.PI * shape.radius ** 2;
    case 'rect':
      return shape.width * shape.height;
    case 'triangle':
      return (shape.base * shape.height) / 2;
    default:
      return assertNever(shape);
  }
}

function assertNever(x: never): never {
  throw new Error(`unhandled: ${JSON.stringify(x)}`);
}
```

> Adding a new variant without handling it becomes a compile error thanks to `assertNever`.

## Loops

```ts
const entries: Array<[string, number]> = [['a', 1], ['b', 2]];

for (const [key, value] of entries) {
  console.log(key, value.toFixed(0));
}

const nums = [10, 20];
for (const i of nums.keys()) {
  console.log(nums[i]); // number | undefined under noUncheckedIndexedAccess
}
```

## Early returns

```ts
function firstPositive(nums: readonly number[]): number | undefined {
  for (const n of nums) {
    if (n > 0) return n;
  }
  return undefined;
}
```

Declare parameters as `readonly number[]` to make accidental mutation a compile error.
