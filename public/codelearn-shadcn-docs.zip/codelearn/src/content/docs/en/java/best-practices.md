---
title: Best practices
description: Immutability, naming, exceptions, testing, and build hygiene.
language: java
section: Advanced
order: 9
updated: 2026-10-18
minutes: 10
tags: [advanced, best practices, testing]
---

## Prefer immutability

```java
public record Money(long cents, String currency) {
    public Money {
        if (cents < 0) {
            throw new IllegalArgumentException("amount must not be negative");
        }
    }

    public Money plus(Money other) {
        if (!currency.equals(other.currency)) {
            throw new IllegalArgumentException("currency mismatch");
        }
        return new Money(cents + other.cents, currency); // a new object
    }

    public static void main(String[] args) {
        var a = new Money(1000, "CNY");
        System.out.println(a.plus(new Money(500, "CNY")));
    }
}
```

Records generate `equals`, `hashCode`, and `toString` for you.

## Naming and structure

- `UpperCamelCase` for classes, `lowerCamelCase` for methods and variables
- `UPPER_SNAKE_CASE` for constants
- One responsibility per class; split past ~300 lines or ~7 fields
- Package by feature (`order`, `payment`), not by layer (`dao`, `service`)

## Exceptions

| Situation | Response |
|---|---|
| Programming bug | `IllegalArgumentException` / `IllegalStateException` |
| Recoverable business failure | Custom checked exception, or encode in the return type |
| Low-level I/O failure | Wrap in a domain exception, keep the cause |
| Nothing useful to do | Do not catch |

```java
public class Retry {
    static int attempts = 0;

    static String fetch() {
        attempts++;
        if (attempts < 3) {
            throw new IllegalStateException("transient failure");
        }
        return "ok";
    }

    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            try {
                System.out.println(fetch());
                break;
            } catch (IllegalStateException e) {
                System.err.println("attempt " + (i + 1) + ": " + e.getMessage());
            }
        }
    }
}
```

## Testing

```java
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class MoneyTest {
    @Test
    void adds_same_currency() {
        var result = new Money(100, "CNY").plus(new Money(50, "CNY"));
        assertEquals(150, result.cents());
    }

    @Test
    void rejects_mixed_currency() {
        assertThrows(IllegalArgumentException.class,
                () -> new Money(100, "CNY").plus(new Money(1, "USD")));
    }
}
```

- Name tests after behavior
- One assertion per concept
- Test pure logic; isolate I/O behind interfaces

## Build and runtime

> Pin the JDK in CI and run `mvn -B verify` (or `gradle build`) so compile warnings, static analysis, and tests all gate the merge.

- Centralize versions with `dependencyManagement` (Maven) or version catalogs (Gradle)
- Use `jpackage` or `jlink` to shrink container images
- Set `-Xmx` below the container limit to avoid OOM kills

## Common traps

- Override `equals` and `hashCode` together
- Use `BigDecimal` for money, never `double` with `==`
- Always use `PreparedStatement`
- Avoid static references to large objects — they leak memory
