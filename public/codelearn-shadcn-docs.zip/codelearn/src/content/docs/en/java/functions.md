---
title: Functions
description: Method signatures, overloading, lambdas, and streams.
language: java
section: Core concepts
order: 5
updated: 2026-10-18
minutes: 9
tags: [core concepts, methods, lambda]
---

## Methods

A "function" in Java is a method belonging to a class:

```java
public class Calc {
    public static int add(int a, int b) {
        return a + b;
    }

    private int base;
    public Calc(int base) {
        this.base = base;
    }
    public int addToBase(int x) {
        return this.base + x;
    }

    public static void log(String msg) {
        System.out.println("[log] " + msg);
    }

    public static void main(String[] args) {
        var c = new Calc(10);
        log("result = " + Calc.add(c.addToBase(5), 1));
    }
}
```

## Overloading and varargs

```java
public class Overload {
    static String join(String sep, String... parts) {
        return String.join(sep, parts);
    }

    static void print(int x) {
        System.out.println("int " + x);
    }

    static void print(long x) {
        System.out.println("long " + x);
    }

    public static void main(String[] args) {
        System.out.println(join("-", "a", "b", "c"));
        print(1);  // int overload
        print(1L); // long overload
    }
}
```

> Too many overloads hurt readability. A bare `boolean` parameter is a smell — prefer an enum or a distinct method name.

## Lambdas and functional interfaces

An interface with exactly one abstract method can be implemented with a lambda:

```java
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Lambdas {
    public static void main(String[] args) {
        Function<Integer, Integer> square = x -> x * x;
        Predicate<String> notBlank = s -> !s.isBlank();

        var words = List.of("rust", "", " java ", "go");
        words.stream()
                .filter(notBlank)
                .map(String::trim)        // method reference
                .map(String::toUpperCase)
                .forEach(w -> System.out.println(square.apply(w.length())));
    }
}
```

Key interfaces: `Function`, `Predicate`, `Supplier`, `Consumer`, `BiFunction`.

## Streams

```java
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

record Order(String customer, int amount) {}

public class Streams {
    public static void main(String[] args) {
        var orders = List.of(
                new Order("Ada", 120),
                new Order("Ada", 80),
                new Order("Bob", 200));

        Map<String, Integer> totals = orders.stream()
                .collect(Collectors.groupingBy(
                        Order::customer,
                        Collectors.summingInt(Order::amount)));
        System.out.println(totals); // {Bob=200, Ada=200}

        int big = orders.stream()
                .mapToInt(Order::amount)
                .filter(a -> a > 100)
                .sum();
        System.out.println(big);
    }
}
```

Streams cannot `break`; use a plain loop when control flow gets complex.

## Design tips

- Keep methods under ~30 lines
- Cap parameters at four; group the rest into an object
- Return `Optional` or an empty collection instead of `null`
- `static` for stateless helpers, instance methods for stateful behavior
