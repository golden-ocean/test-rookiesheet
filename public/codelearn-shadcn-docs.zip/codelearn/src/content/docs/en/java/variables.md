---
title: Variables & types
description: Primitives, references, boxing, strings, and Optional.
language: java
section: Core concepts
order: 3
updated: 2026-10-18
minutes: 9
tags: [core concepts, types, strings]
---

## Primitives vs references

Eight **primitive** types store values directly; everything else is a **reference**.

| Primitive | Size | Wrapper | Default |
|---|---|---|---|
| `byte` | 8 bit | `Byte` | 0 |
| `short` / `int` / `long` | 16 / 32 / 64 bit | `Short` / `Integer` / `Long` | 0 |
| `float` / `double` | 32 / 64 bit | `Float` / `Double` | 0.0 |
| `char` | 16 bit | `Character` | `\u0000` |
| `boolean` | — | `Boolean` | `false` |

Fields get defaults; **local variables must be initialized**.

```java
public class Types {
    int count;          // default 0
    static double rate; // default 0.0

    public static void main(String[] args) {
        int x = 42;
        long big = 9_000_000_000L; // L suffix required
        float f = 0.5f;            // f suffix required
        System.out.println(x + " " + big + " " + f + " " + new Types().count);
    }
}
```

## Boxing and equality

`==` compares references, so wrappers must use `equals`:

```java
public class Boxing {
    public static void main(String[] args) {
        Integer a = 1000;
        Integer b = 1000;
        System.out.println(a == b);      // false
        System.out.println(a.equals(b)); // true

        Integer c = 127, d = 127;
        System.out.println(c == d);      // true: cached range -128..127
    }
}
```

> An unboxed `null` throws `NullPointerException`; collections and generics always use wrappers.

## Strings

`String` is immutable; use `StringBuilder` for loops:

```java
public class Strings {
    public static void main(String[] args) {
        String s = "Hello";
        s += ", Java";                 // creates a new String
        System.out.println(s.length());
        System.out.println(s.substring(7));

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(i).append(',');
        }
        System.out.println(sb);

        // text blocks (JDK 15+)
        String json = """
                {"name": "Ada", "lang": "Java"}
                """;
        System.out.println(json.isBlank());
    }
}
```

## Casting and precision

```java
public class Casting {
    public static void main(String[] args) {
        double d = 3.99;
        System.out.println((int) d);   // 3: truncation

        System.out.println(0.1 + 0.2); // 0.30000000000000004
        var exact = java.math.BigDecimal.valueOf(0.1)
                .add(java.math.BigDecimal.valueOf(0.2));
        System.out.println(exact);     // 0.3

        System.out.println(Integer.MAX_VALUE + 1); // overflow, no exception
    }
}
```

Use `BigDecimal` for money, constructed from strings or `valueOf`.

## Optional

```java
import java.util.Optional;

public class OptionalDemo {
    static Optional<String> findName(int id) {
        return id == 1 ? Optional.of("Ada") : Optional.empty();
    }

    public static void main(String[] args) {
        String name = findName(1).orElse("anonymous");
        int len = findName(2).map(String::length).orElse(0);
        System.out.println(name + " " + len);
    }
}
```

Use `Optional` for return types, not for fields or parameters.
