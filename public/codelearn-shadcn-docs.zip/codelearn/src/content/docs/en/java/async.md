---
title: Async programming
description: Thread pools, CompletableFuture, and virtual threads.
language: java
section: Advanced
order: 7
updated: 2026-10-18
minutes: 11
tags: [advanced, concurrency, completablefuture]
notice: Virtual threads require JDK 21+; on older versions stick to the thread pool examples.
---

## Threads and pools

```java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class PoolDemo {
    public static void main(String[] args) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(4);
        try {
            for (int i = 0; i < 8; i++) {
                int id = i;
                pool.submit(() -> System.out.println("task " + id));
            }
        } finally {
            pool.shutdown();
            pool.awaitTermination(1, TimeUnit.SECONDS);
        }
    }
}
```

| Pool | Best for | Risk |
|---|---|---|
| `newFixedThreadPool` | CPU-bound work | Unbounded queue |
| `newCachedThreadPool` | Many short tasks | Unbounded threads |
| `newVirtualThreadPerTaskExecutor` | Heavy blocking I/O | Needs JDK 21+ |

## CompletableFuture

```java
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CfDemo {
    static String fetchUser(long id) throws InterruptedException {
        Thread.sleep(100);
        return "user-" + id;
    }

    public static void main(String[] args) {
        ExecutorService io = Executors.newFixedThreadPool(8);

        CompletableFuture<String> future = CompletableFuture
                .supplyAsync(() -> {
                    try { return fetchUser(7); }
                    catch (InterruptedException e) { throw new RuntimeException(e); }
                }, io)
                .thenApply(String::toUpperCase)
                .exceptionally(ex -> "fallback");

        System.out.println(future.join());
        io.shutdown();
    }
}
```

- `thenApply` — transform, same thread
- `thenApplyAsync` — transform on the pool
- `thenCompose` — chain another async step without nesting
- `thenCombine` — merge two independent results
- `allOf` / `anyOf` — wait for all / any

> Never call `join()` on one future inside another future's chain; you will starve the pool. Use `thenCompose`.

## Virtual threads

```java
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class VirtualThreads {
    public static void main(String[] args) throws Exception {
        var start = Instant.now();
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            IntStream.range(0, 10_000).forEach(i ->
                    executor.submit(() -> {
                        Thread.sleep(Duration.ofMillis(10));
                        return i;
                    }));
        } // close waits for all tasks
        System.out.println(Duration.between(start, Instant.now()).toMillis() + "ms");
    }
}
```

Ten thousand virtual threads are cheap; the same number of platform threads is not.

## Thread safety

- Prefer `ConcurrentHashMap` and `CopyOnWriteArrayList`
- Use `AtomicInteger` / `LongAdder` for counters
- Keep critical sections small
- Avoid long `synchronized` blocks inside virtual threads; prefer `ReentrantLock`
