---
title: Introduction
description: Meet Java, the JVM ecosystem, and how to install a JDK.
language: java
section: Getting started
order: 1
updated: 2026-10-18
minutes: 7
tags: [getting started, install, jvm]
---

## Java and the JVM

Java is a statically typed, object-oriented language. Source is compiled to bytecode (`.class`), and a JVM executes it — handling garbage collection and JIT compilation so the same bytecode runs on Windows, Linux, and macOS.

LTS releases include 8, 11, 17, and 21. New projects should use **JDK 21** or later for records, pattern matching, and virtual threads.

| Component | Role |
|---|---|
| JVM | Executes bytecode, runs GC and JIT |
| JRE | JVM + core libraries, runs programs only |
| JDK | JRE + `javac` and debugging tools |

## Installing a JDK

Use a package manager or an open distribution such as Temurin or Corretto:

```bash
# macOS (Homebrew)
brew install --cask temurin@21

# Ubuntu / Debian
sudo apt install openjdk-21-jdk

java -version
javac -version
```

If `javac` is missing, you installed a JRE rather than a JDK.

## First program

Create `Hello.java` — the file name must match the public class:

```java
public class Hello {
    public static void main(String[] args) {
        String name = args.length > 0 ? args[0] : "Java";
        System.out.println("Hello, " + name + "!");
    }
}
```

```bash
javac Hello.java   # produces Hello.class
java Hello world   # no .class suffix
```

Since JDK 11 you can also run the file directly with `java Hello.java`.

## Build tools

| Tool | File | Strength |
|---|---|---|
| Maven | `pom.xml` | Convention over configuration |
| Gradle | `build.gradle(.kts)` | Fast incremental builds, flexible DSL |

A minimal `pom.xml`:

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.example</groupId>
  <artifactId>hello</artifactId>
  <version>1.0.0</version>
  <properties>
    <maven.compiler.release>21</maven.compiler.release>
  </properties>
</project>
```

> Pin the JDK version with `maven.compiler.release` or `--release` so the team compiles against the same target.

Next: *Quick start*.
