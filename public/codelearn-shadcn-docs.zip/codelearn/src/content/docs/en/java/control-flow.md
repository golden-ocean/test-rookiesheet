---
title: Control flow
description: if, switch expressions, loops, and safe removal while iterating.
language: java
section: Core concepts
order: 4
updated: 2026-10-18
minutes: 8
tags: [core concepts, control flow, switch]
---

## Conditions

```java
public class Conditions {
    static String grade(int score) {
        if (score >= 90) {
            return "A";
        } else if (score >= 60) {
            return "B";
        }
        return "C";
    }

    public static void main(String[] args) {
        System.out.println(grade(85));
        String level = grade(95).equals("A") ? "excellent" : "keep going";
        System.out.println(level);
    }
}
```

Conditions must be `boolean`; integers are not truthy.

## switch expressions

Arrow syntax (JDK 14+) has no fall-through and produces a value:

```java
public class SwitchDemo {
    enum Level { LOW, MEDIUM, HIGH }

    static int weight(Level level) {
        return switch (level) {
            case LOW -> 1;
            case MEDIUM -> 5;
            case HIGH -> 10;
        };
    }

    static String describe(Object o) {
        return switch (o) {
            case Integer i when i < 0 -> "negative int " + i;
            case Integer i -> "int " + i;
            case String s -> "string " + s;
            case null -> "null";
            default -> "other";
        };
    }

    public static void main(String[] args) {
        System.out.println(weight(Level.HIGH));
        System.out.println(describe(-3));
    }
}
```

## Loops

```java
import java.util.List;

public class Loops {
    public static void main(String[] args) {
        var names = List.of("Ada", "Linus", "Grace");

        for (int i = 0; i < 3; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (String name : names) {
            System.out.print(name + " ");
        }
        System.out.println();

        int n = 3;
        while (n > 0) {
            n--;
        }
        do {
            n++;
        } while (n < 3);

        outer:
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (i * j > 2) {
                    break outer; // labelled break
                }
            }
        }
        System.out.println("n=" + n);
    }
}
```

## Removing while iterating

```java
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class RemoveWhileIterating {
    public static void main(String[] args) {
        var nums = new ArrayList<>(List.of(1, 2, 3, 4, 5));

        for (Iterator<Integer> it = nums.iterator(); it.hasNext(); ) {
            if (it.next() % 2 == 0) {
                it.remove();
            }
        }
        System.out.println(nums); // [1, 3, 5]

        nums.removeIf(x -> x > 3);
        System.out.println(nums); // [1, 3]
    }
}
```

> `List.of(...)` is immutable; `add` and `remove` throw `UnsupportedOperationException`. Wrap it in `new ArrayList<>(...)` when you need mutation.
