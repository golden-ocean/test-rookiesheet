---
title: Standard library
description: Collections, map APIs, exceptions, and the java.time API.
language: java
section: Advanced
order: 8
updated: 2026-10-18
minutes: 10
tags: [advanced, stdlib, collections]
---

## Choosing a collection

| Type | Characteristics | Typical use |
|---|---|---|
| `ArrayList` | Array-backed, O(1) random access | Default list |
| `LinkedList` | Doubly linked | As a `Deque` |
| `HashMap` | Hash table, O(1) average | Default map |
| `LinkedHashMap` | Preserves insertion order | Ordered iteration, LRU caches |
| `TreeMap` | Red-black tree, sorted keys | Range queries |
| `ArrayDeque` | Circular array | Stack and queue |

```java
import java.util.*;

public class Collections {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("b", "a", "c"));
        list.sort(Comparator.naturalOrder());
        System.out.println(list);

        Map<String, List<Integer>> byFirstChar = new HashMap<>();
        for (String s : List.of("apple", "avocado", "banana")) {
            byFirstChar.computeIfAbsent(s.substring(0, 1), k -> new ArrayList<>()).add(s.length());
        }
        System.out.println(byFirstChar);

        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(1);
        stack.push(2);
        System.out.println(stack.pop());
    }
}
```

## Map APIs worth knowing

```java
Map<String, Integer> stock = new HashMap<>();
stock.put("apple", 10);
stock.merge("apple", 5, Integer::sum);
stock.putIfAbsent("pear", 3);
stock.computeIfPresent("pear", (k, v) -> v + 1);
stock.remove("pear", 4);
System.out.println(stock);
```

These make check-then-act atomic, and are thread-safe on `ConcurrentHashMap`.

## Exceptions

| Kind | Must handle | Example |
|---|---|---|
| `Error` | No | `OutOfMemoryError` |
| Checked exception | Yes | `IOException` |
| Unchecked exception | No | `NullPointerException` |

```java
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Exceptions {
    static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("not a number: " + s, e); // keep the cause
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println(parse("42"));
        System.out.println(Files.readAllLines(Path.of("pom.xml")).size());
    }
}
```

> Never leave an empty `catch`. Wrap and rethrow with the original cause attached.

## java.time

```java
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimeDemo {
    public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        System.out.println(today.plusWeeks(1));

        LocalDateTime ts = LocalDateTime.parse("2026-10-18T09:30:00");
        System.out.println(ts.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));

        Duration d = Duration.between(ts, ts.plusHours(3));
        System.out.println(d.toMinutes());
    }
}
```

- `LocalDate` for dates, `ZonedDateTime` when a zone matters, `Instant` for transport
- Always specify `ZoneId` explicitly for cross-zone math

## Other utilities

- `Objects.requireNonNull`, `Objects.equals`, `hash`
- `Optional` for nullable return values
- `Files` for reading, writing, walking directories
- Precompile `Pattern` when a regex is reused in a loop
