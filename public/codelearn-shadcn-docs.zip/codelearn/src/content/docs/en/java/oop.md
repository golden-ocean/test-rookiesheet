---
title: Object orientation
description: Classes, interfaces, inheritance, polymorphism, and generics.
language: java
section: Core concepts
order: 6
updated: 2026-10-18
minutes: 11
tags: [core concepts, oop, generics]
notice: The sealed interface and record examples require JDK 17 or later.
---

## Classes

```java
public class Account {
    private final String owner;
    private long balance; // cents

    public Account(String owner, long balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public long getBalance() { return balance; }

    public void deposit(long amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("amount must be positive");
        }
        balance += amount;
    }

    @Override
    public String toString() {
        return "Account(" + owner + ", " + balance + ")";
    }
}
```

`private` fields plus public methods are the basis of encapsulation; `final` fields must be set in the constructor.

## Inheritance and polymorphism

```java
abstract class Shape {
    abstract double area();

    String describe() {
        return getClass().getSimpleName() + " area " + String.format("%.2f", area());
    }
}

class Circle extends Shape {
    private final double r;
    Circle(double r) { this.r = r; }
    @Override double area() { return Math.PI * r * r; }
}

class Rect extends Shape {
    private final double w, h;
    Rect(double w, double h) { this.w = w; this.h = h; }
    @Override double area() { return w * h; }
}

public class Shapes {
    public static void main(String[] args) {
        Shape[] shapes = { new Circle(1), new Rect(2, 3) };
        for (Shape s : shapes) {
            System.out.println(s.describe());
        }
    }
}
```

Use `@Override` so the compiler verifies the signature really overrides.

## Interfaces and default methods

```java
interface Payable {
    long amount();

    default String receipt() {
        return "pay " + amount() + " cents";
    }

    static Payable fixed(long v) {
        return () -> v; // a single-abstract-method interface is a lambda
    }
}

public class DefaultDemo {
    public static void main(String[] args) {
        System.out.println(Payable.fixed(1999).receipt());
    }
}
```

Interfaces allow multiple inheritance of type, which is usually a better fit than deep class trees.

## sealed and record

```java
sealed interface Result permits Ok, Err {}
record Ok<T>(T value) implements Result {}
record Err(String message) implements Result {}

public class SealedDemo {
    static String render(Result r) {
        return switch (r) {
            case Ok<?> ok -> "OK: " + ok.value();
            case Err err -> "ERR: " + err.message();
        };
    }

    public static void main(String[] args) {
        System.out.println(render(new Ok<>(42)));
        System.out.println(render(new Err("timeout")));
    }
}
```

## Generics

Generics are erased at runtime, so `new T[]` and `instanceof T` are not allowed:

```java
import java.util.ArrayList;
import java.util.List;

public class GenericBox<T> {
    private final List<T> items = new ArrayList<>();

    public void add(T item) { items.add(item); }

    public <R> List<R> map(java.util.function.Function<? super T, ? extends R> fn) {
        var out = new ArrayList<R>();
        for (T item : items) {
            out.add(fn.apply(item));
        }
        return out;
    }

    public static void main(String[] args) {
        var box = new GenericBox<String>();
        box.add("abc");
        System.out.println(box.map(String::length));
    }
}
```

> Inheritance expresses a stable "is-a" relationship. For code reuse alone, prefer composition behind an interface.
