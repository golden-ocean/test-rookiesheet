---
title: Quick start
description: A complete Java program with input and output, plus the Maven layout.
language: java
section: Getting started
order: 2
updated: 2026-10-18
minutes: 8
tags: [getting started, syntax]
notice: Examples target JDK 17+; drop record and var if you are on an older release.
---

## The Maven layout

```
hello/
├── pom.xml
└── src/
    ├── main/java/com/example/App.java
    └── test/java/com/example/AppTest.java
```

`mvn compile` builds, `mvn package` produces a jar.

## A complete program

```java
package com.example;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        try (Scanner in = new Scanner(System.in)) { // auto-close
            System.out.print("Name: ");
            String name = in.nextLine();
            System.out.printf("Hello, %s!%n", name);
        }
    }
}
```

`println` appends a newline; `printf` uses `%s`, `%d`, `%f`, `%n`.

## Input and conversion

```java
import java.util.Scanner;

public class Sum {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = Integer.parseInt(in.next());
        int b = in.nextInt(); // parses an int directly
        System.out.println("sum = " + (a + b));
    }
}
```

`nextInt` throws `InputMismatchException` on bad input; check with `hasNextInt()`.

## Arguments and exit codes

```java
public class ExitCode {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("usage: ExitCode <file>");
            System.exit(2); // non-zero means failure
        }
        System.out.println("processing " + args[0]);
    }
}
```

## var and record

```java
record Point(int x, int y) {
    // constructor, accessors, equals, hashCode, toString generated
    double distance() {
        return Math.hypot(x, y);
    }
}

public class Demo {
    public static void main(String[] args) {
        var p = new Point(3, 4);
        System.out.println(p);            // Point[x=3, y=4]
        System.out.println(p.distance()); // 5.0
    }
}
```

> `var` works only for initialized local variables. When the right-hand side is not obvious, write the type.

## Running

- `mvn exec:java -Dexec.mainClass=com.example.App`
- `java -Xmx512m -jar app.jar` caps the heap
- `jps` and `jstack` inspect processes and threads

Next: *Variables & types*.
