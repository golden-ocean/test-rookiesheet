---
title: Object orientation
description: No inheritance in Rust — object-oriented design with structs and traits.
language: rust
section: Core concepts
order: 6
updated: 2026-10-18
minutes: 10
tags: [core concepts, traits, oop]
notice: Rust has no class inheritance; this article favors composition over inheritance.
---

## How Rust sees OOP

You can encapsulate data in a `struct`, add methods with `impl`, and define interfaces with `trait`. What Rust deliberately omits is **inheritance**. Traditional OOP responsibilities are split across two concepts:

| Classic OOP | Rust equivalent | Notes |
|---|---|---|
| Class fields + methods | `struct` + `impl` | Data and behavior declared separately |
| Interface / abstract class | `trait` | Behavior contract, with default methods |
| Inheritance | none | Composition and trait objects instead |
| Polymorphism | `dyn Trait` or generics | Dynamic or static dispatch |

## Encapsulation with struct and impl

```rust
pub struct Account {
    owner: String,
    balance: i64, // in cents
}

impl Account {
    pub fn new(owner: impl Into<String>, balance: i64) -> Self {
        Self { owner: owner.into(), balance }
    }

    pub fn deposit(&mut self, amount: i64) -> Result<(), String> {
        if amount <= 0 {
            return Err("amount must be positive".into());
        }
        self.balance += amount;
        Ok(())
    }

    pub fn balance(&self) -> i64 {
        self.balance
    }
}

fn main() {
    let mut acc = Account::new("Alex", 0);
    acc.deposit(1000).unwrap();
    println!("{}: {}", acc.owner, acc.balance());
}
```

Private fields are only reachable within the module, so external code must go through public methods.

## Interfaces with traits

```rust
trait Shape {
    fn area(&self) -> f64;
    fn name(&self) -> &'static str;

    fn describe(&self) -> String {
        format!("{} with area {:.2}", self.name(), self.area())
    }
}

struct Circle { r: f64 }
struct Rect { w: f64, h: f64 }

impl Shape for Circle {
    fn area(&self) -> f64 { std::f64::consts::PI * self.r * self.r }
    fn name(&self) -> &'static str { "circle" }
}

impl Shape for Rect {
    fn area(&self) -> f64 { self.w * self.h }
    fn name(&self) -> &'static str { "rect" }
}

fn main() {
    let shapes: Vec<Box<dyn Shape>> = vec![
        Box::new(Circle { r: 1.0 }),
        Box::new(Rect { w: 2.0, h: 3.0 }),
    ];
    for s in &shapes {
        println!("{}", s.describe());
    }
}
```

`dyn Shape` dispatches through a vtable at runtime. A generic `T: Shape` monomorphizes at compile time: faster, but a single collection cannot hold mixed types.

## Differences from inheritance

Inheritance expresses "is-a" and tends to create deep, fragile hierarchies. Rust prefers "has-a" composition:

```rust
trait Renderer {
    fn render(&self, text: &str) -> String;
}

struct Markdown;
impl Renderer for Markdown {
    fn render(&self, text: &str) -> String { format!("<p>{text}</p>") }
}

struct Page<R: Renderer> {
    renderer: R,
    title: String,
}

impl<R: Renderer> Page<R> {
    fn html(&self) -> String {
        self.renderer.render(&self.title)
    }
}

fn main() {
    let page = Page { renderer: Markdown, title: "hello".into() };
    println!("{}", page.html());
}
```

> Rule of thumb: when you want to "reuse the parent's code", extract a small trait or a standalone struct instead. Deep hierarchies simply do not exist here.
