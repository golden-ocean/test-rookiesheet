---
title: Variables & types
description: Rust's type system, ownership, borrowing, and Option.
language: rust
section: Core concepts
order: 3
updated: 2026-10-18
minutes: 9
tags: [core concepts, types, ownership]
---

## Primitive types

Types are fully known at compile time and numeric conversions are never implicit.

| Kind | Types | Notes |
|---|---|---|
| Integers | `i8`…`i128`, `u8`…`u128`, `isize`, `usize` | Default `i32`; indexing uses `usize` |
| Floats | `f32`, `f64` | Default `f64` |
| Boolean | `bool` | `true` / `false` |
| Character | `char` | 4-byte Unicode scalar value |
| Strings | `&str`, `String` | Borrowed slice and growable heap string |

```rust
fn main() {
    let n: i64 = 42;
    let ratio: f64 = n as f64 / 4.0; // explicit cast required
    println!("{n} {ratio} {}", true);
}
```

## Bindings, mutability, shadowing

```rust
fn main() {
    let x = 5;
    let x = x * 2;      // a new binding, not an assignment
    let x = x.to_string(); // type changes from integer to String
    println!("{x}");

    const MAX: u32 = 1_000;
    println!("{MAX}");
}
```

`const` requires an explicit type and a compile-time value.

## Compound types

```rust
fn main() {
    let pair: (i32, &str) = (1, "one");
    let (num, name) = pair; // destructuring
    println!("{num} -> {name}");

    let arr = [10, 20, 30];
    let slice = &arr[1..];
    println!("{:?}", slice);
}
```

Use `Vec<T>` when the length varies at runtime.

## Ownership and borrowing

Every value has exactly one owner, and it is dropped when the owner goes out of scope.

```rust
fn main() {
    let s1 = String::from("hello");
    let s2 = s1; // move: s1 is no longer valid
    println!("{s2}");

    let s3 = s2.clone(); // deep copy
    borrow(&s3);         // lend an immutable reference
    println!("{s2} {s3}");
}

fn borrow(s: &String) -> usize {
    s.len()
}
```

- Many `&T` at once are fine
- Only one `&mut T` at a time, and never alongside `&T`
- Checked statically, so there is no runtime lock

> Prefer `&str` over `&String` for read-only parameters: both `String` and literals coerce to it.

## Option instead of null

```rust
fn find_first_even(nums: &[i32]) -> Option<i32> {
    nums.iter().copied().find(|n| n % 2 == 0)
}

fn main() {
    let v = vec![1, 3, 6, 8];
    if let Some(n) = find_first_even(&v) {
        println!("first even: {n}");
    }
    println!("{}", find_first_even(&v).unwrap_or(0));
}
```

`Option<T>` forces you to handle the empty case before using the value.
