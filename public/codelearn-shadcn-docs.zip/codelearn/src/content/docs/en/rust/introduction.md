---
title: Introduction
description: Rust's design goals, toolchain, and how to install it.
language: rust
section: Getting started
order: 1
updated: 2026-10-18
minutes: 7
tags: [getting started, install, toolchain]
notice: After installing, run rustc --version and cargo --version to verify the toolchain works.
---

## What is Rust

Rust is a systems programming language focused on **memory safety**, **zero-cost abstractions**, and **fearless concurrency**. It has no garbage collector; instead, the compiler's ownership and borrow rules catch a large class of runtime bugs before your program ever runs.

Typical use cases:

- Command-line tools and system utilities
- Network services and proxies (the Tokio ecosystem)
- WebAssembly
- Embedded and operating-system components

> Being rejected by the borrow checker is normal at first. The compiler's error messages are one of Rust's most valuable learning resources.

## Releases and toolchains

Rust ships a new minor version every six weeks and keeps backward compatibility. There are three channels:

| Channel | Role | When to use |
|---|---|---|
| stable | Default | Production and daily work |
| beta | Preview of the next release | Testing upgrades early |
| nightly | Daily builds | Unstable features |

`rustup` is the recommended installer and manager. It also handles `clippy`, `rustfmt`, and other components.

## Installing

On Linux and macOS:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

On Windows, download `rustup-init.exe` or use Winget. Reopen your terminal, then check:

```bash
rustc --version
cargo --version
rustup show
```

`cargo` is the build tool and package manager bundled with the toolchain.

## Your first program

```bash
cargo new hello_rust
cd hello_rust
cargo run
```

The generated `src/main.rs`:

```rust
fn main() {
    // println! is a macro, not a function: the trailing bang is required
    let name = "Rust";
    println!("Hello, {}!", name);
}
```

`cargo run` compiles and executes. `cargo build --release` produces an optimized binary.

## Common commands

- `cargo check` — type-check only, fastest feedback loop
- `cargo fmt` — format with the official style
- `cargo clippy` — lint for common mistakes
- `cargo doc --open` — build and open documentation

Next, read *Quick start* for variables, functions, and modules.
