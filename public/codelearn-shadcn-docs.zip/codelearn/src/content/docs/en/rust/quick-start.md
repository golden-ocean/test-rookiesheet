---
title: Quick start
description: Write your first Rust program and understand the cargo layout.
language: rust
section: Getting started
order: 2
updated: 2026-10-18
minutes: 8
tags: [getting started, syntax]
notice: This article assumes Rust 1.80+; check with rustc --version.
---

## Project layout

`cargo new` generates:

```
hello_rust/
├── Cargo.toml
├── Cargo.lock
└── src/
    └── main.rs
```

- `Cargo.toml` — package metadata and dependencies
- `Cargo.lock` — pins resolved versions; commit it
- `src/main.rs` — binary entry point

A minimal manifest:

```toml
[package]
name = "hello_rust"
version = "0.1.0"
edition = "2021"

[dependencies]
```

## Mutability and formatting

Variables are immutable by default; add `mut` when you need to change one:

```rust
fn main() {
    let mut count = 0;
    count += 1; // fails to compile without mut
    println!("count = {count}"); // inline variable capture

    let pi = 3.14159;
    println!("pi ~= {pi:.2}");
}
```

`{}` uses the `Display` trait, `{:?}` uses `Debug`, which you will use constantly for structs.

## Errors with Result

Rust has no exceptions. Recoverable errors are values. `main` may return a `Result`:

```rust
use std::fs;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let text = fs::read_to_string("Cargo.toml")?; // early return on error
    println!("Cargo.toml has {} lines", text.lines().count());
    Ok(())
}
```

The `?` operator converts the error into the function's error type and returns immediately, which keeps call sites flat.

## Modules and dependencies

```rust
mod math {
    pub fn square(x: i32) -> i32 {
        x * x
    }
}

fn main() {
    println!("{}", math::square(7));
}
```

External crates go in `Cargo.toml`:

```toml
[dependencies]
serde = { version = "1", features = ["derive"] }
```

> Put semver requirements in `Cargo.toml`; `Cargo.lock` pins exact versions so teammates and CI build identically.

Next: *Variables & types*.
