---
title: Async programming
description: async/await, the Future model, and the Tokio runtime.
language: rust
section: Advanced
order: 7
updated: 2026-10-18
minutes: 11
tags: [advanced, async, tokio]
---

## The model

`async fn` returns a value implementing `Future`, but **a Future does nothing on its own** — it must be polled by a runtime. The standard library only defines `Future`; Tokio is the most common executor.

| Piece | Provided by | Role |
|---|---|---|
| `Future`, `async`, `await` | std | Language syntax and contract |
| Runtime, timers, I/O | Tokio | Actually drives futures |
| Combinators | `futures` / `tokio` | `join!`, `select!`, timeouts |

```toml
[dependencies]
tokio = { version = "1", features = ["full"] }
```

## First async program

```rust
use tokio::time::{sleep, Duration};

async fn fetch_user(id: u32) -> String {
    sleep(Duration::from_millis(50)).await; // simulate latency
    format!("user-{id}")
}

#[tokio::main]
async fn main() {
    let name = fetch_user(7).await;
    println!("{name}");
}
```

`#[tokio::main]` expands to "build a runtime and block on the future".

## Running tasks concurrently

Sequential `.await` runs one by one; use `join!` to overlap:

```rust
use tokio::time::{sleep, Duration, Instant};

async fn task(name: &str, ms: u64) -> String {
    sleep(Duration::from_millis(ms)).await;
    format!("{name} done after {ms}ms")
}

#[tokio::main]
async fn main() {
    let start = Instant::now();
    let (a, b) = tokio::join!(task("A", 100), task("B", 100));
    println!("{a} / {b} in {:?}", start.elapsed());
    // about 100ms, not 200ms
}
```

`try_join!` short-circuits on the first `Err`.

## Sharing state

```rust
use std::sync::Arc;
use tokio::sync::Mutex;

#[tokio::main]
async fn main() {
    let counter = Arc::new(Mutex::new(0));
    let mut handles = Vec::new();

    for _ in 0..10 {
        let c = Arc::clone(&counter);
        handles.push(tokio::spawn(async move {
            let mut guard = c.lock().await; // async lock: no thread blocking
            *guard += 1;
        }));
    }

    for h in handles {
        h.await.unwrap();
    }
    println!("{}", *counter.lock().await);
}
```

`tokio::spawn` requires `Send + 'static` futures.

> Never hold a `std::sync::Mutex` guard across `.await`; use `tokio::sync::Mutex` when the critical section touches async code.

## Timeouts and cancellation

```rust
use tokio::time::{timeout, Duration};

async fn slow() -> &'static str {
    tokio::time::sleep(Duration::from_secs(5)).await;
    "finished"
}

#[tokio::main]
async fn main() {
    match timeout(Duration::from_millis(100), slow()).await {
        Ok(v) => println!("{v}"),
        Err(_) => println!("timed out; task cancelled"),
    }
}
```

Dropping a future is cancellation in Rust. Clean up resources in `Drop` guards.
