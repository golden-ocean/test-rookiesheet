---
title: Functions
description: Signatures, generics, closures, and lifetime annotations.
language: rust
section: Core concepts
order: 5
updated: 2026-10-18
minutes: 9
tags: [core concepts, functions, generics]
notice: These examples use lifetime annotations; read the borrowing section of Variables & types first.
---

## Basic signatures

Parameters and return types are always explicit. The last expression is the return value:

```rust
fn add(a: i32, b: i32) -> i32 {
    a + b // no semicolon: this expression is returned
}

fn log(msg: &str) {
    println!("[log] {msg}");
}

fn main() {
    log(&add(1, 2).to_string());
}
```

A trailing semicolon makes the function return `()`, which fails to compile if a return type is declared.

## Generic functions

Generics need trait bounds that describe what the parameters can do:

```rust
use std::fmt::Display;

fn largest<T: PartialOrd + Copy>(items: &[T]) -> Option<T> {
    let mut max = *items.first()?;
    for &item in items.iter().skip(1) {
        if item > max {
            max = item;
        }
    }
    Some(max)
}

fn show<T: Display>(label: &str, value: T) {
    println!("{label}: {value}");
}

fn main() {
    show("max", largest(&[3, 9, 4]).unwrap());
}
```

## Closures

Closures capture their environment; the compiler infers whether they are `Fn`, `FnMut`, or `FnOnce`:

```rust
fn main() {
    let factor = 3;
    let triple = |x: i32| x * factor;

    let nums = vec![1, 2, 3];
    let doubled: Vec<i32> = nums.iter().map(|n| triple(*n)).collect();
    println!("{:?}", doubled);
}
```

Use `move` when the closure must outlive the current scope, for example when handed to `thread::spawn`.

## Lifetime annotations

Lifetimes tell the compiler how long a returned reference lives relative to its inputs. Most cases are elided; returning a reference usually needs an explicit annotation:

```rust
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() >= y.len() { x } else { y }
}

fn main() {
    let a = String::from("abc");
    println!("{}", longest(&a, "defgh"));
}
```

> Lifetimes do not change generated code. They only describe relationships the borrow checker verifies. Ask "how long does this reference really need to live?" before annotating.

## Conventions

- Do one thing per function; return `Result` rather than logging and swallowing errors
- Libraries use concrete error types; binaries can use `Box<dyn Error>` or `anyhow`
- Group many parameters into a config struct
