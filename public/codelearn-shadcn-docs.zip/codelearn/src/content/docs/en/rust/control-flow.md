---
title: Control flow
description: if expressions, match, and the three kinds of loops.
language: rust
section: Core concepts
order: 4
updated: 2026-10-18
minutes: 8
tags: [core concepts, control flow, match]
---

## if is an expression

There is no ternary operator because `if` yields a value:

```rust
fn grade(score: u32) -> &'static str {
    if score >= 90 {
        "A"
    } else if score >= 60 {
        "B"
    } else {
        "C"
    } // no semicolon: this if is the return value
}

fn main() {
    println!("{}", grade(95));
}
```

Conditions must be `bool`; integers are not truthy.

## match and pattern matching

`match` must be exhaustive, and the compiler enforces it:

```rust
fn describe(code: u16) -> String {
    match code {
        200 => "OK".to_string(),
        301 | 302 => "redirect".to_string(),
        400..=499 => "client error".to_string(),
        500..=599 => "server error".to_string(),
        other => format!("unknown status {other}"),
    }
}

fn main() {
    println!("{}", describe(404));
}
```

Patterns destructure enums and structs:

```rust
enum Shape {
    Circle(f64),
    Rect { w: f64, h: f64 },
}

fn area(s: &Shape) -> f64 {
    match s {
        Shape::Circle(r) => std::f64::consts::PI * r * r,
        Shape::Rect { w, h } => w * h,
    }
}

fn main() {
    println!("{:.2}", area(&Shape::Rect { w: 3.0, h: 4.0 }));
}
```

## Loops

| Loop | Use it when |
|---|---|
| `loop` | Infinite loop; `break` can carry a value |
| `while` | Condition-driven |
| `for` | Iterating ranges or iterators; most common |

```rust
fn main() {
    let mut attempts = 0;
    let result = loop {
        attempts += 1;
        if attempts == 3 {
            break attempts * 10; // break returns a value
        }
    };
    println!("{attempts} attempts, result {result}");

    for i in 0..3 {
        print!("{i} ");
    }
    println!();
}
```

`0..3` excludes 3; use `0..=3` to include it.

## Guard clauses

Handle edge cases first with early return to reduce nesting:

```rust
fn safe_div(a: i32, b: i32) -> Option<i32> {
    if b == 0 {
        return None;
    }
    Some(a / b)
}

fn main() {
    assert_eq!(safe_div(10, 2), Some(5));
    assert_eq!(safe_div(1, 0), None);
}
```

> Prefer `for` over `while let Some(x) = iter.next()` — `for` cannot forget to advance the iterator.
