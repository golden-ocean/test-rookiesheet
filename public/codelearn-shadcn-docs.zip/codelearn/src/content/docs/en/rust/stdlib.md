---
title: Standard library
description: Collections, strings, I/O, iterators, and everyday std modules.
language: rust
section: Advanced
order: 8
updated: 2026-10-18
minutes: 9
tags: [advanced, stdlib, collections]
---

## Module map

| Module | Highlights | Purpose |
|---|---|---|
| `std::collections` | `Vec`, `HashMap`, `BTreeMap`, `HashSet` | Dynamic collections |
| `std::string` | `String`, `str` | UTF-8 strings |
| `std::fs` / `std::io` | `File`, `BufReader`, `Read`/`Write` | Files and I/O |
| `std::path` | `Path`, `PathBuf` | Portable paths |
| `std::thread` / `std::sync` | `spawn`, `Mutex`, `Arc`, `mpsc` | Threads and sync |
| `std::time` | `Duration`, `Instant` | Timing |

## Collections

```rust
use std::collections::{HashMap, HashSet};

fn main() {
    let mut scores: HashMap<String, u32> = HashMap::new();
    scores.insert("Alex".into(), 90);
    scores.entry("Sam".into()).or_insert(80); // insert if missing
    for (name, score) in &scores {
        println!("{name}: {score}");
    }

    let tags: HashSet<&str> = ["a", "b", "a"].into_iter().collect();
    println!("{} unique", tags.len());
}
```

The `entry` API avoids a double lookup, the standard pattern for counting.

## Strings

`String` is UTF-8, so you cannot index by character:

```rust
fn main() {
    let s = String::from("Hello, world");
    println!("bytes {}", s.len());
    println!("chars {}", s.chars().count());

    let parts: Vec<&str> = s.split(", ").collect();
    println!("{parts:?}");
    println!("{}", s.contains("world"));
}
```

Use `.chars().nth(i)` for character access, or collect into `Vec<char>`.

## Iterators

```rust
fn main() {
    let nums = vec![1, 2, 3, 4, 5, 6];

    let sum_of_squares: i32 = nums
        .iter()
        .filter(|n| *n % 2 == 0)
        .map(|n| n * n)
        .sum();
    println!("sum of even squares: {sum_of_squares}");

    let grouped: Vec<_> = nums.chunks(2).collect();
    println!("{:?}", grouped);
}
```

Adapters: `map`, `filter`, `fold`, `take`, `skip`, `zip`, `enumerate`. Consumers: `collect`, `sum`, `count`, `any`, `all`.

## Files and paths

```rust
use std::fs;
use std::io::{self, BufRead};
use std::path::Path;

fn read_lines(path: &Path) -> io::Result<Vec<String>> {
    let file = fs::File::open(path)?;
    let reader = io::BufReader::new(file);
    reader.lines().collect()
}

fn main() -> io::Result<()> {
    let lines = read_lines(Path::new("Cargo.toml"))?;
    println!("{} lines", lines.len());
    Ok(())
}
```

> Always use `Path` / `PathBuf` instead of concatenating `/`.
