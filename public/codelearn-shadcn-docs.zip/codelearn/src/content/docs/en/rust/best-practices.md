---
title: Best practices
description: Error handling, API design, testing, and project hygiene.
language: rust
section: Advanced
order: 9
updated: 2026-10-18
minutes: 10
tags: [advanced, best practices, tooling]
notice: These are widely accepted community conventions, not hard rules; adapt them to your team.
---

## Layering errors

| Kind | Handling | Examples |
|---|---|---|
| Recoverable | Return `Result<T, E>` | Missing file, parse failure, timeout |
| Bugs | `panic!` / `assert!` | Broken invariant, out-of-bounds access |

```rust
use std::num::ParseIntError;

#[derive(Debug)]
pub enum ConfigError {
    InvalidPort(ParseIntError),
}

impl From<ParseIntError> for ConfigError {
    fn from(e: ParseIntError) -> Self {
        ConfigError::InvalidPort(e)
    }
}

pub fn parse_port(raw: &str) -> Result<u16, ConfigError> {
    Ok(raw.trim().parse()?)
}

fn main() {
    println!("{:?}", parse_port("8080"));
    println!("{:?}", parse_port("abc"));
}
```

Libraries should own their error enums; binaries can use `anyhow`.

## API design

- Take `&str` and `&[T]`, not `&String` and `&Vec<T>`
- `&self` to read, `&mut self` to mutate, `self` to consume
- Implement `Debug` on public types, plus `PartialEq` / `Eq` / `Hash` when needed
- Use newtypes so a user ID cannot be passed as an order ID

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct UserId(u64);

pub fn find_user(ids: &[UserId], target: UserId) -> Option<UserId> {
    ids.iter().copied().find(|id| *id == target)
}

fn main() {
    let ids = [UserId(1), UserId(2)];
    println!("{:?}", find_user(&ids, UserId(2)));
}
```

## Testing

```rust
#[cfg(test)]
mod tests {
    fn add(a: i32, b: i32) -> i32 { a + b }

    #[test]
    fn adds_positive_numbers() {
        assert_eq!(add(2, 3), 5);
    }

    #[test]
    #[should_panic(expected = "division by zero")]
    fn panics_on_zero() {
        let d = 0;
        assert!(d != 0, "division by zero");
    }
}
```

Run everything with `cargo test`; add `-- --nocapture` to see printed output.

## Hygiene checklist

> Before pushing, run `cargo fmt && cargo clippy -- -D warnings && cargo test` and put the same command in CI.

- Consider `#![deny(unsafe_code)]` in crates that need none
- Audit dependencies with `cargo tree` and `cargo audit`
- Document public APIs with `///`; doc examples are compiled and tested
- Binaries: keep logic in `lib.rs`, keep `main.rs` thin
