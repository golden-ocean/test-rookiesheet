---
title: Introduction
description: What JavaScript is, where it runs, and how to get started with Node.js.
language: javascript
section: Getting started
order: 1
updated: 2026-10-18
minutes: 6
tags: [beginner, installation, environment]
notice: Examples target Node.js 20+ and ES2023 syntax and also run in a browser console.
---

JavaScript started in 1995 as a way to add small interactions to web pages. Today it runs in browsers, on servers via Node.js, on the desktop with Electron, and at the edge.

## Key characteristics

| Feature | Description |
|---|---|
| Dynamic typing | Types are resolved at runtime |
| Single-threaded | Async work is driven by the event loop |
| Prototypal inheritance | Objects share behaviour through prototypes |
| First-class functions | Functions can be passed and returned |
| Multi-paradigm | Procedural, OO and functional styles all work |

> JavaScript and Java share a name and little else. The standard name is ECMAScript, or ES.

## Installing Node.js

Press F12 in any browser to try code in the console. For local scripts you need Node.js.

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
nvm install 20
node -v   # v20.x.x
npm -v    # 10.x.x
```

## First script

```js
// hello.js
const name = process.argv[2] ?? 'World';
console.log(`Hello, ${name}!`);
```

```bash
node hello.js developer
# Hello, developer!
```

## Modules

Modern code uses ES modules. Add `"type": "module"` to `package.json`:

```js
// math.js
export function add(a, b) {
  return a + b;
}
```

```js
// main.js
import { add } from './math.js';
console.log(add(1, 2));
```

Do not mix ES modules and CommonJS `require` in the same file.
