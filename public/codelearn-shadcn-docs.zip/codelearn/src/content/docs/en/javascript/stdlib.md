---
title: Standard library
description: "Built-in objects worth knowing: Array, Object, String, Map, Set, JSON and Intl."
language: javascript
section: Advanced
order: 8
updated: 2026-10-18
minutes: 8
tags: [advanced, stdlib]
---

JavaScript has no separate standard library; the globals are the library. These are the parts you will use daily.

## Array

```js
const nums = [1, 2, 3, 4, 5];

nums.map((n) => n * 2);              // [2, 4, 6, 8, 10]
nums.filter((n) => n % 2 === 1);     // [1, 3, 5]
nums.find((n) => n > 3);             // 4
nums.some((n) => n > 4);             // true
nums.every((n) => n > 0);            // true
nums.flatMap((n) => [n, n]);
nums.reduce((sum, n) => sum + n, 0); // 15

Array.from({ length: 3 }, (_, i) => i); // [0, 1, 2]
```

> ES2023 added `toSorted`, `toReversed`, `toSpliced` and `with`, which return new arrays instead of mutating.

## Object

```js
Object.entries(scores).sort(([, a], [, b]) => b - a);
Object.assign({}, scores, { carol: 88 });
Object.fromEntries([['x', 1], ['y', 2]]);
Object.create(null); // prototype-free dictionary
```

## String

```js
const s = '  Hello World  ';

s.trim();
s.startsWith('  He');
s.replaceAll('l', 'L');
s.padStart(20, '*');
s.at(-1);                  // negative indexing
'2026-10-18'.split('-');
```

## Map and Set

```js
const m = new Map();
m.set('key', 1).set('other', 2);
m.get('key');
m.has('other');

const set = new Set([1, 2, 2, 3]);
[...set]; // [1, 2, 3]
```

`Map` keys can be any value and keep insertion order. Plain objects only support string and symbol keys.

## JSON

```js
const text = JSON.stringify({ id: 1 }, null, 2);
const data = JSON.parse(text, (key, value) =>
  key === 'id' ? value * 10 : value,
);
```

## Others

| Object | Use |
|---|---|
| `Math` | rounding, max, random |
| `Date` | timestamps |
| `Intl` | numbers, dates, collation |
| `RegExp` | pattern matching |
| `URL` / `URLSearchParams` | URL parsing |
| `structuredClone` | deep copy |

```js
new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' })
  .format(1234.5); // $1,234.50
```
