---
title: Control flow
description: Conditionals, loops, optional chaining and logical assignment.
language: javascript
section: Core concepts
order: 4
updated: 2026-10-18
minutes: 6
tags: [core, syntax]
---

Branching in JavaScript is familiar, but the modern sugar removes a lot of boilerplate.

## Conditionals

```js
function grade(score) {
  if (score >= 90) return 'A';
  if (score >= 80) return 'B';
  if (score >= 60) return 'C';
  return 'D';
}

switch (code) {
  case 200:
  case 201:
    return 'success';
  case 404:
    return 'not found';
  default:
    return 'unknown';
}
```

## Four ways to loop

```js
for (let i = 0; i < items.length; i++) {}      // needs the index
for (const item of items) {}                    // supports break
for (const [i, item] of items.entries()) {}     // index and value
items.forEach((item, i) => {});                 // cannot break
```

| Loop | Breakable | Best for |
|---|---|---|
| `for` | yes | precise index control |
| `for...of` | yes | iterables |
| `forEach` | no | simple side effects |
| `for...in` | yes | object keys (never arrays) |

## Short-circuiting and optional chaining

```js
const user = { profile: null };

const name = user.name ?? 'anonymous';       // ?? only falls back on null/undefined
const city = user.profile?.address?.city;    // undefined, no throw

const a = 0 || 10;  // 10
const b = 0 ?? 10;  // 0
```

## Logical assignment

```js
const state = { retries: 0 };

state.retries ??= 3;     // assign if nullish
state.cache ||= 'none';  // assign if falsy
state.flags &&= 'ready'; // assign if truthy
```

> Avoid deeply nested ternaries. With three or more branches use a `switch`, a lookup table, or early returns.
