---
title: Async programming
description: The event loop, callbacks, Promises and async/await explained end to end.
language: javascript
section: Advanced
order: 7
updated: 2026-10-18
minutes: 10
tags: [advanced, async, promises]
notice: The output order example is the heart of this article; run it in a console.
---

JavaScript runs on a single thread. Asynchrony comes from the event loop provided by the host (browser or Node.js).

## The event loop

When the call stack is empty, the loop:

1. Runs one macrotask (a `setTimeout` callback, an I/O callback, rendering).
2. Drains **all** microtasks (`Promise` callbacks, `queueMicrotask`).
3. Picks the next macrotask.

```js
console.log('1 sync');

setTimeout(() => console.log('4 macrotask'), 0);

Promise.resolve().then(() => console.log('3 microtask'));

console.log('2 sync');
// 1 -> 2 -> 3 -> 4
```

> A microtask that schedules more microtasks will starve rendering entirely.

## From callbacks to Promises

```js
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

await delay(100);
console.log('after 100ms');

// states: pending -> fulfilled | rejected, and never back
Promise.reject(new Error('boom')).catch((e) => console.log(e.message));
```

## async / await

```js
async function fetchUser(id) {
  const res = await fetch(`https://api.example.com/users/${id}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

try {
  const user = await fetchUser(1);
  console.log(user.name);
} catch (err) {
  console.error('request failed:', err.message);
}
```

## Concurrent, not serial

```js
// serial: total time is the sum
const a = await fetchUser(1);
const b = await fetchUser(2);

// concurrent: total time is the slowest
const [x, y] = await Promise.all([fetchUser(1), fetchUser(2)]);
```

| API | Behaviour |
|---|---|
| `Promise.all` | rejects as soon as any input rejects |
| `Promise.allSettled` | waits for all, reports each outcome |
| `Promise.race` | settles with the first result or error |
| `Promise.any` | resolves with the first success |

## Timeouts and retries

```js
function withTimeout(promise, ms) {
  const timeout = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('timeout')), ms),
  );
  return Promise.race([promise, timeout]);
}

async function retry(fn, times = 3) {
  for (let i = 1; i <= times; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i === times) throw err;
      await delay(200 * i);
    }
  }
}
```

## Common mistakes

- `await` inside `forEach` does not wait; use `for...of` or `Promise.all`.
- Forgetting `return` makes callers receive `undefined`.
- Long `.then` chains are harder to read than the equivalent `async/await`.
