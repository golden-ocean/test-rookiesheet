---
title: Variables & types
description: let and const, the seven primitives, and the classic coercion traps.
language: javascript
section: Core concepts
order: 3
updated: 2026-10-18
minutes: 8
tags: [core, types]
notice: Run the == vs === examples in a console; seeing the output makes it stick.
---

JavaScript is dynamically typed, but it is far from typeless. Knowing the difference between primitive values and objects avoids most surprises.

## Declarations

```js
var legacy = 'avoid';  // function scoped, hoisted
let counter = 0;       // block scoped, reassignable
const config = { mode: 'dark' }; // block scoped binding

config.mode = 'light'; // legal: the binding is constant, not the object
// config = {};        // TypeError
```

Default to `const`, reach for `let` only when you must reassign, and never use `var`.

## Primitive types

| Type | Examples |
|---|---|
| `number` | `42`, `3.14`, `NaN` |
| `bigint` | `10n` |
| `string` | `'hi'`, `` `hi` `` |
| `boolean` | `true` |
| `undefined` | `let a;` |
| `null` | `null` |
| `symbol` | `Symbol('id')` |

Primitives compare by value; objects and arrays compare by reference.

```js
console.log(0.1 + 0.2);  // 0.30000000000000004
console.log(NaN === NaN); // false
console.log({} === {});   // false
console.log([] == false); // true — hence ===
```

## Detecting types

```js
function typeOf(v) {
  if (v === null) return 'null'; // typeof null is 'object'
  if (Array.isArray(v)) return 'array';
  return typeof v;
}

console.log(typeOf([]), typeOf(null), typeOf(() => {})); // array null function
```

## Conversion

```js
Number('42');        // 42
Number('');          // 0
Number('4px');       // NaN
parseInt('4px', 10); // 4
Boolean('0');        // true — any non-empty string is truthy
```

Only these are falsy: `false`, `0`, `-0`, `0n`, `''`, `null`, `undefined`, `NaN`.

## Copying

```js
const nested = { user: { name: 'Ada' } };
const shallow = { ...nested };  // first level only
shallow.user.name = 'Bob';
console.log(nested.user.name);  // Bob

const deep = structuredClone(nested);
deep.user.name = 'Cara';
console.log(nested.user.name);  // Bob
```

> `JSON.parse(JSON.stringify(x))` also deep copies, but drops functions, `undefined` and `Date` types. Prefer `structuredClone`.
