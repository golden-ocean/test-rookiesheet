---
title: Object orientation
description: Prototypes, class syntax, inheritance and private fields.
language: javascript
section: Core concepts
order: 6
updated: 2026-10-18
minutes: 8
tags: [core, prototypes, class]
---

JavaScript is prototype-based. The `class` keyword is syntax over prototypes, and knowing the underlying model explains a lot of library code.

## Constructors and prototypes

```js
function Animal(name) {
  this.name = name;
}

Animal.prototype.speak = function () {
  return `${this.name} makes a sound`;
};

const cat = new Animal('cat');
console.log(cat.speak());
console.log(Object.getPrototypeOf(cat) === Animal.prototype); // true
```

Property lookup walks up the prototype chain until it reaches `Object.prototype`.

## Classes

```js
class Animal {
  #energy = 100; // truly private field

  constructor(name) {
    this.name = name;
  }

  speak() {
    return `${this.name} makes a sound`;
  }

  get energy() {
    return this.#energy;
  }

  static create(name) {
    return new this(name);
  }
}

class Dog extends Animal {
  speak() {
    return `${super.speak()}: woof!`;
  }
}

const d = Dog.create('Rex');
console.log(d.speak(), d.energy); // Rex makes a sound: woof! 100
```

| Feature | Syntax |
|---|---|
| Private field | `#field` |
| Private method | `#method()` |
| Static member | `static` |
| Parent call | `super.method()` |

## Composition over inheritance

```js
const canFly = { fly() { return `${this.name} flies`; } };
const canSwim = { swim() { return `${this.name} swims`; } };

class Duck {
  constructor(name) {
    this.name = name;
  }
}

Object.assign(Duck.prototype, canFly, canSwim);

const duck = new Duck('Donald');
console.log(duck.fly(), duck.swim());
```

## Object utilities

```js
Object.keys(obj);
Object.values(obj);
Object.entries(obj);
Object.freeze(obj);
Object.hasOwn(obj, 'key');
```

> Use classes for stateful things with identity; use plain objects and functions for data.
