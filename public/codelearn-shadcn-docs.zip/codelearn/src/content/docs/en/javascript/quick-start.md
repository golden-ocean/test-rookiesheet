---
title: Quick start
description: Output, template strings and array methods in one small program.
language: javascript
section: Getting started
order: 2
updated: 2026-10-18
minutes: 7
tags: [beginner, syntax]
---

A short script that counts words in a sentence, using only the syntax you will need every day.

## Output and arithmetic

```js
console.log('Hello, JavaScript');
console.table([{ a: 1 }, { a: 2 }]); // tabular debug output

const price = 39.9;
const count = 3;
console.log(`total: ${(price * count).toFixed(2)}`);
```

## Chaining array methods

```js
const words = 'the quick brown fox jumps over the lazy dog'.split(' ');

const longWords = words
  .filter((w) => w.length > 3)
  .map((w) => w.toUpperCase());

const totalLength = longWords.reduce((sum, w) => sum + w.length, 0);

console.log(longWords);   // ['QUICK', 'BROWN', ...]
console.log(totalLength); // 24
```

`filter`, `map` and `reduce` all return new values and leave the original array untouched.

## Objects and destructuring

```js
const user = { name: 'Ada', age: 36, lang: ['js', 'ts'] };

const { name, age: years = 18, lang } = user;
console.log(`${name} knows ${lang.join(', ')} and is ${years}`);

const updated = { ...user, age: 37 }; // new object, original unchanged
console.log(user.age, updated.age);   // 36 37
```

> Prefer immutable updates: building a new object avoids a whole class of "why did this value change?" bugs.

## Reading arguments

```js
// node sum.js 1 2 3
const nums = process.argv.slice(2).map(Number);

if (nums.some(Number.isNaN)) {
  console.error('arguments must be numbers');
  process.exit(1);
}

console.log(nums.reduce((a, n) => a + n, 0));
```

| Concept | Syntax |
|---|---|
| Declarations | `const` / `let` |
| Template strings | `` `hi ${name}` `` |
| Iteration | `for...of`, `map`, `filter` |
| Copying | `{ ...obj }` |
| Debugging | `console.log`, `debugger` |
