---
title: Functions
description: Declarations, arrow functions, closures and how this is bound.
language: javascript
section: Core concepts
order: 5
updated: 2026-10-18
minutes: 9
tags: [core, functions, closures]
notice: Closures and this come up in every interview; rewrite the examples in your own domain.
---

Functions are the core abstraction in JavaScript. Understanding closures and `this` covers half the language.

## Forms

```js
function add(a, b) { return a + b; }          // hoisted

const sub = function (a, b) { return a - b; }; // not hoisted

const mul = (a, b) => a * b;                   // no own this

const greet = (name = 'stranger', ...titles) =>
  `${titles.join(' ')}${name}`;
```

## Closures

A closure is a function together with the lexical scope it captured.

```js
function createCounter(start = 0) {
  let count = start; // captured, not exposed
  return {
    inc: () => ++count,
    get value() {
      return count;
    },
  };
}

const c = createCounter(10);
c.inc();
c.inc();
console.log(c.value); // 12
```

Closures power private state, currying and debouncing.

## this

```js
const timer = {
  seconds: 0,
  start() {
    setInterval(() => this.seconds++, 1000); // arrow keeps outer this
  },
};

function whoAmI() {
  console.log(this?.tag);
}

whoAmI.call({ tag: 'a' });        // a
const bound = whoAmI.bind({ tag: 'b' });
bound();                          // b
```

> Rule of thumb: `this` is whatever sits left of the dot at call time. Arrow functions inherit `this` from where they are defined.

## Higher-order functions

```js
const add3 = (a) => (b) => (c) => a + b + c;

function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

const search = debounce((q) => console.log('searching', q), 300);
search('js');
search('javascript'); // only this call fires
```

## Arguments

Primitives are passed by value; objects are passed by reference value.

```js
function mutate(obj, num) {
  obj.n = 1;
  num = 100;
}

const data = { n: 0 };
let x = 1;
mutate(data, x);
console.log(data.n, x); // 1 1
```
