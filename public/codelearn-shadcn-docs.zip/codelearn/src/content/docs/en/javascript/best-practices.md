---
title: Best practices
description: Scope, immutability, error handling and tooling conventions.
language: javascript
section: Advanced
order: 9
updated: 2026-10-18
minutes: 9
tags: [advanced, engineering]
notice: Most of these rules can be enforced automatically with ESLint.
---

JavaScript's flexibility is also its risk. These conventions are widely adopted because they reduce maintenance cost.

## Language conventions

```js
// strict equality only
if (value === null) { /* ... */ }

// named exports are easier to refactor
export function parseConfig() { /* ... */ }

// early returns beat nesting
function check(user) {
  if (!user) return 'missing user';
  if (!user.active) return 'inactive';
  return 'OK';
}

const ONE_DAY_MS = 24 * 60 * 60 * 1000;
```

## Immutability

```js
// bad: mutates the argument
function addTagBad(post, tag) {
  post.tags.push(tag);
  return post;
}

// good: returns a new object
function addTag(post, tag) {
  return { ...post, tags: [...post.tags, tag] };
}
```

Pure functions are easy to test and safe to cache.

## Errors

```js
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
  }
}

async function request(url) {
  const res = await fetch(url);
  if (!res.ok) throw new HttpError(res.status, res.statusText);
  return res.json();
}

try {
  await request('/api/data');
} catch (err) {
  if (err instanceof HttpError && err.status === 404) {
    // expected branch
  } else {
    throw err;
  }
}
```

| Anti-pattern | Consequence |
|---|---|
| empty `catch {}` | bugs disappear silently |
| `catch (e) { console.log(e) }` | caller thinks it succeeded |
| `throw 'error'` | no stack trace |

## Tooling

```json
{
  "type": "module",
  "engines": { "node": ">=20" },
  "scripts": {
    "lint": "eslint .",
    "format": "prettier --write .",
    "test": "node --test"
  }
}
```

Enable `no-var`, `eqeqeq` and `no-unused-vars` in ESLint, and let Prettier settle formatting.

> New projects should consider TypeScript, or at least `// @ts-check`, to catch type errors before runtime.
