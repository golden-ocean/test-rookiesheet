---
title: Object orientation
description: Classes, inheritance, dunder methods and dataclasses.
language: python
section: Core concepts
order: 6
updated: 2026-10-18
minutes: 11
tags: [Core concepts, OOP]
---

## Defining a class

```python
class User:
    def __init__(self, name: str, age: int) -> None:
        self.name = name
        self.age = age

    def greet(self) -> str:
        return f"Hi, I'm {self.name}"
```

## Inheritance and polymorphism

```python
class Admin(User):
    def __init__(self, name: str, age: int, level: int) -> None:
        super().__init__(name, age)
        self.level = level

    def greet(self) -> str:
        return f"{super().greet()} (admin Lv.{self.level})"
```

## Dataclasses

```python
from dataclasses import dataclass

@dataclass
class Point:
    x: float
    y: float
```

> For plain data holders, `@dataclass` beats hand-writing `__init__`.

## Common dunder methods

| Method | Triggered by |
| --- | --- |
| `__init__` | Instantiation |
| `__repr__` | `repr()` / debug printing |
| `__len__` | `len(obj)` |
| `__iter__` | `for ... in obj` |
