---
title: Functions
description: Define functions, pass arguments and understand scope.
language: python
section: Core concepts
order: 5
updated: 2026-10-18
minutes: 10
tags: [Core concepts, Functions]
---

## Defining functions

```python
def greet(name: str, greeting: str = "Hello") -> str:
    return f"{greeting}, {name}!"
```

## Argument kinds

```python
def demo(a, b=2, *args, **kwargs):
    print(a, b, args, kwargs)

demo(1, 3, 4, 5, key="value")
```

- Positional, default, `*args` variadic positional, `**kwargs` variadic keyword arguments

## Scope

Python follows **LEGB**: Local → Enclosing → Global → Built-in.

```python
count = 0

def increase():
    global count
    count += 1
```

> Avoid `global` where possible — pass state via arguments or return values.

## Decorators

```python
import time

def timer(fn):
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = fn(*args, **kwargs)
        print(f"{fn.__name__} took {time.perf_counter() - start:.4f}s")
        return result
    return wrapper

@timer
def slow_task():
    time.sleep(1)
```

## Summary

- Keep functions small and single-purpose
- Type hints make signatures self-documenting
- Decorators suit cross-cutting concerns (logging, caching, auth)
