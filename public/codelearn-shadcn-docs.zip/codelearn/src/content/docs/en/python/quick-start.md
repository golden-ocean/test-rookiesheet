---
title: Quick start
description: Write your first Python program and learn the basic syntax.
language: python
section: Getting started
order: 2
updated: 2026-10-18
minutes: 8
tags: [Getting started, Syntax]
notice: This guide assumes Python 3.12+. Run python --version to check.
---

In this section you will write your first program and learn the most basic syntax. Python's readable style makes it an excellent first language.

## Your first program

Create `hello.py`:

```python
# hello.py
print("Hello, World!")
```

Run it:

```bash
python hello.py
# Output: Hello, World!
```

## Ways to run Python

1. **Script file**: `python hello.py` — for real programs
2. **Interactive REPL**: type `python` in your terminal and run lines one by one
3. **Notebook**: Jupyter cells, great for data analysis

## Common questions

<details>
<summary>Why does Python not need semicolons?</summary>

Python uses newlines as statement terminators. Semicolons are optional — part of its minimalist style.
</details>

<details>
<summary>I get "python: command not found"</summary>

On Windows try `py` or `python3`; on macOS / Linux usually `python3`. If none work, the installer did not add Python to PATH.
</details>

## Next

Continue with [Variables & types](/en/docs/python/variables) to go deeper into the type system.
