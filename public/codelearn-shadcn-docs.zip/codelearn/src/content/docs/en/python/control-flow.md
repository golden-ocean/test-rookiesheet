---
title: Control flow
description: Control execution with if / for / while.
language: python
section: Core concepts
order: 4
updated: 2026-10-18
minutes: 9
tags: [Core concepts, Control flow]
---

## Conditionals

```python
score = 85

if score >= 90:
    level = "excellent"
elif score >= 60:
    level = "pass"
else:
    level = "fail"
```

> Python uses **indentation** to define blocks — indent 4 spaces after a colon.

## Loops

```python
# for: iterate over any iterable
for lang in ["Python", "Go", "Rust"]:
    print(lang)

# while: repeat while a condition holds
count = 3
while count > 0:
    print(count)
    count -= 1
```

## Control statements

| Statement | Purpose |
| --- | --- |
| `break` | Exit the loop |
| `continue` | Skip to the next iteration |
| `pass` | Do nothing (placeholder) |
| `for ... else` | Runs if the loop was not broken |

## Summary

- Prefer `elif` chains over deep nesting
- Use `for` instead of manual counters
- Reach for `enumerate()` and `zip()` to simplify loops
