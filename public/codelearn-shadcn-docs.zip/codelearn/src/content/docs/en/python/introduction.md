---
title: Introduction
description: Get to know Python and set up your local environment.
language: python
section: Getting started
order: 1
updated: 2026-10-18
minutes: 6
tags: [Getting started, Install]
notice: This guide assumes basic command-line familiarity.
---

## What is Python

Python is a general-purpose language famous for its **simple, readable syntax**, widely used for data analysis, web development, automation and AI.

> The Zen of Python: beautiful is better than ugly, explicit is better than implicit.

## Install Python

Python 3.12 or newer is recommended:

- **Windows / macOS**: download the installer from [python.org](https://www.python.org/downloads/)
- **Linux**: `sudo apt install python3`
- **Version management**: use `pyenv` or `uv` to manage multiple versions

## Verify the install

```bash
python --version
# Python 3.12.6
```

## Pick an editor

| Editor | Rating | Notes |
| --- | --- | --- |
| VS Code | ⭐⭐⭐⭐⭐ | Rich extension ecosystem, free |
| PyCharm | ⭐⭐⭐⭐ | Full-featured IDE |
| Neovim | ⭐⭐⭐ | Lightweight, steeper setup |

## Next

Once your environment is ready, head to [Quick start](/en/docs/python/quick-start) to write your first program.
