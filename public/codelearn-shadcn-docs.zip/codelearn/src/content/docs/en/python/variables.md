---
title: Variables & types
description: Understand Python's dynamic type system and built-in data structures.
language: python
section: Core concepts
order: 3
updated: 2026-10-18
minutes: 10
tags: [Core concepts, Types]
---

## Variables and assignment

A Python variable is a **reference to an object**:

```python
x = 10          # creates an int and binds it to x
x = "hello"     # x can be rebound to any type
```

## Type hints

Python is dynamically typed, but type hints are strongly recommended for readability:

```python
def add(a: int, b: int) -> int:
    return a + b
```

## Built-in types

```python
age = 25                        # int
price = 9.99                    # float
name = "Alice"                  # str
tags = ["python", "dev"]        # list
point = (3, 4)                  # tuple
user = {"name": "Alice"}        # dict
unique = {1, 2, 3}              # set
```

## Lists and comprehensions

```python
nums = [1, 2, 3]
nums.append(4)
squares = [n ** 2 for n in nums]  # [1, 4, 9, 16]
```

## Summary

- Variables are references; types belong to objects
- Prefer type hints and comprehensions
- Choose structures by need: list keeps order, dict gives fast lookup, set deduplicates
