---
title: Best practices
description: Project layout, type checking and code style.
language: python
section: Advanced
order: 9
updated: 2026-10-18
minutes: 10
tags: [Advanced, Engineering]
---

## Project layout

```
myproject/
├── pyproject.toml
├── src/
│   └── myproject/
│       ├── __init__.py
│       └── main.py
└── tests/
    └── test_main.py
```

## Tooling

| Tool | Purpose |
| --- | --- |
| `uv` / `poetry` | Dependencies and virtualenvs |
| `ruff` | Formatter + linter |
| `mypy` / `pyright` | Static type checking |
| `pytest` | Testing |

## Style essentials

1. Follow **PEP 8**, 88- or 100-column lines
2. Use `with` for resource management
3. Catch specific exceptions — never a bare `except:`
4. Document public functions with docstrings and type hints

```python
def read_config(path: str) -> dict:
    """Read a JSON config file, returning {} if it does not exist."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
```

## Next

You've finished the Python track. Try [learning Go](/en/docs/go/introduction) next.
