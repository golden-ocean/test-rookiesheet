---
title: Standard library
description: A cheat sheet of the Python standard library modules you'll use most.
language: python
section: Advanced
order: 8
updated: 2026-10-18
minutes: 9
tags: [Advanced, Stdlib]
---

## Paths and files

```python
from pathlib import Path

root = Path.cwd()
for p in root.glob("**/*.py"):
    print(p.name)
```

## Dates and times

```python
from datetime import datetime, timedelta

now = datetime.now()
tomorrow = now + timedelta(days=1)
```

## Data structures

```python
from collections import Counter, defaultdict, deque

Counter(["a", "b", "a"])        # Counter({'a': 2, 'b': 1})
defaultdict(list)                # auto-initialises missing keys
deque(maxlen=3)                  # double-ended queue
```

## Module cheat sheet

| Module | Purpose |
| --- | --- |
| `json` | Serialise / deserialise |
| `re` | Regular expressions |
| `itertools` | Iterator utilities |
| `functools` | Higher-order helpers |
| `logging` | Logging |

> Prefer the standard library: `pathlib` over `os.path`, `json` over hand-rolled parsing.
