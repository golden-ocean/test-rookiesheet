---
title: Async programming
description: asyncio event loop, coroutines and concurrent tasks.
language: python
section: Advanced
order: 7
updated: 2026-10-18
minutes: 12
tags: [Advanced, Async]
---

## Why async

I/O-bound work (network, database) spends most of its time waiting. Async lets a single thread switch to other work while waiting.

## Coroutine basics

```python
import asyncio

async def fetch(url: str) -> str:
    async with httpx.AsyncClient() as client:
        res = await client.get(url)
        return res.text

async def main():
    html = await fetch("https://example.com")
    print(len(html))

asyncio.run(main())
```

## Running tasks concurrently

```python
async def main():
    results = await asyncio.gather(
        fetch("https://a.com"),
        fetch("https://b.com"),
        fetch("https://c.com"),
    )
```

> **Pitfall**: calling a blocking function inside `async def` stalls the whole event loop — wrap it with `asyncio.to_thread()`.

## When not to use async

- CPU-bound work → use `multiprocessing`
- Simple scripts without concurrency → synchronous code is clearer
