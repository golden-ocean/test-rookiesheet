---
title: 变量与类型
description: 深入理解 Python 的动态类型系统与常用数据结构。
language: python
section: 核心概念
order: 3
updated: 2026-10-18
minutes: 10
tags: [核心概念, 类型系统]
---

## 变量与赋值

Python 的变量本质是**指向对象的引用**：

```python
x = 10          # 创建 int 对象并绑定到 x
x = "hello"     # x 可以重新绑定到任意类型
```

## 类型标注

虽然 Python 是动态类型语言，但推荐使用类型标注提升可读性：

```python
def add(a: int, b: int) -> int:
    return a + b
```

## 常用内置类型

```python
age = 25                # int
price = 9.99            # float
name = "Alice"          # str
tags = ["python", "dev"]        # list
point = (3, 4)                  # tuple
user = {"name": "Alice"}        # dict
unique = {1, 2, 3}              # set
```

## 列表与推导式

```python
nums = [1, 2, 3]
nums.append(4)
squares = [n ** 2 for n in nums]  # [1, 4, 9, 16]
```

## 小结

- 变量是引用，类型属于对象而非变量
- 优先使用类型标注与列表推导式
- 选择合适的数据结构：list 保序、dict 查找快、set 去重
