---
title: 面向对象
description: 类、继承、魔术方法与数据类。
language: python
section: 核心概念
order: 6
updated: 2026-10-18
minutes: 11
tags: [核心概念, OOP]
---

## 定义类

```python
class User:
    def __init__(self, name: str, age: int) -> None:
        self.name = name
        self.age = age

    def greet(self) -> str:
        return f"Hi, I'm {self.name}"
```

## 继承与多态

```python
class Admin(User):
    def __init__(self, name: str, age: int, level: int) -> None:
        super().__init__(name, age)
        self.level = level

    def greet(self) -> str:
        return f"{super().greet()} (admin Lv.{self.level})"
```

## 数据类

```python
from dataclasses import dataclass

@dataclass
class Point:
    x: float
    y: float
```

> 只承载数据、不需要自定义方法时，`@dataclass` 比手写 `__init__` 更简洁。

## 常用魔术方法

| 方法 | 触发时机 |
| --- | --- |
| `__init__` | 实例化 |
| `__repr__` | `repr()` / 调试打印 |
| `__len__` | `len(obj)` |
| `__iter__` | `for ... in obj` |
