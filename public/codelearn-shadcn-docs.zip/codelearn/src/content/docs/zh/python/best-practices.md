---
title: 最佳实践
description: 工程化项目结构、类型检查与代码规范。
language: python
section: 进阶
order: 9
updated: 2026-10-18
minutes: 10
tags: [进阶, 工程化]
---

## 项目结构

```
myproject/
├── pyproject.toml
├── src/
│   └── myproject/
│       ├── __init__.py
│       └── main.py
└── tests/
    └── test_main.py
```

## 工具链

| 工具 | 作用 |
| --- | --- |
| `uv` / `poetry` | 依赖与虚拟环境管理 |
| `ruff` | 格式化 + Lint（替代 black/flake8） |
| `mypy` / `pyright` | 静态类型检查 |
| `pytest` | 测试框架 |

## 编码规范要点

1. 遵循 **PEP 8**，行宽 88 / 100
2. 使用 `with` 管理资源，避免手动 `close()`
3. 异常捕获要具体，不要裸 `except:`
4. 公开函数写 docstring 与类型标注

```python
def read_config(path: str) -> dict:
    """读取 JSON 配置，文件不存在时返回空字典。"""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
```

## 下一步

你已经完成 Python 教程，可以尝试[学习 Go](/docs/go/introduction) 拓宽技术栈。
