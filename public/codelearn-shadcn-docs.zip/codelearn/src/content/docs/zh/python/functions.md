---
title: 函数
description: 定义函数、参数传递与作用域规则。
language: python
section: 核心概念
order: 5
updated: 2026-10-18
minutes: 10
tags: [核心概念, 函数]
---

## 定义函数

```python
def greet(name: str, greeting: str = "Hello") -> str:
    return f"{greeting}, {name}!"
```

## 参数类型

```python
def demo(a, b=2, *args, **kwargs):
    print(a, b, args, kwargs)

demo(1, 3, 4, 5, key="value")
```

- 位置参数、默认参数、`*args` 可变位置参数、`**kwargs` 可变关键字参数

## 作用域

Python 遵循 **LEGB** 规则：Local → Enclosing → Global → Built-in。

```python
count = 0

def increase():
    global count
    count += 1
```

> 尽量避免使用 `global`，优先通过返回值或参数传递状态。

## 装饰器入门

```python
import time

def timer(fn):
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = fn(*args, **kwargs)
        print(f"{fn.__name__} 耗时 {time.perf_counter() - start:.4f}s")
        return result
    return wrapper

@timer
def slow_task():
    time.sleep(1)
```

## 小结

- 函数保持单一职责，参数控制在 3 个以内
- 用类型标注自解释接口
- 装饰器适合横切逻辑（日志、缓存、鉴权）
