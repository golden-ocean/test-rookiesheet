---
title: 异步编程
description: asyncio 事件循环、协程与并发任务。
language: python
section: 进阶
order: 7
updated: 2026-10-18
minutes: 12
tags: [进阶, 异步]
---

## 为什么需要异步

I/O 密集型任务（网络请求、数据库查询）大部分时间在等待。异步让单线程在等待期间切换去处理其他任务。

## 协程基础

```python
import asyncio

async def fetch(url: str) -> str:
    async with httpx.AsyncClient() as client:
        res = await client.get(url)
        return res.text

async def main():
    html = await fetch("https://example.com")
    print(len(html))

asyncio.run(main())
```

## 并发执行多个任务

```python
async def main():
    results = await asyncio.gather(
        fetch("https://a.com"),
        fetch("https://b.com"),
        fetch("https://c.com"),
    )
```

> **常见误区**：在 `async def` 里调用同步阻塞函数会卡住整个事件循环，需用 `asyncio.to_thread()` 包装。

## 何时不该用异步

- CPU 密集型计算 → 用多进程 `multiprocessing`
- 没有并发需求的小脚本 → 同步代码更简单
