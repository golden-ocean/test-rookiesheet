---
title: 流程控制
description: 用 if / for / while 控制程序执行流程。
language: python
section: 核心概念
order: 4
updated: 2026-10-18
minutes: 9
tags: [核心概念, 流程控制]
---

## 条件判断

```python
score = 85

if score >= 90:
    level = "优秀"
elif score >= 60:
    level = "及格"
else:
    level = "不及格"
```

> Python 用**缩进**表示代码块，冒号后换行并缩进 4 个空格。

## 循环

```python
# for：遍历可迭代对象
for lang in ["Python", "Go", "Rust"]:
    print(lang)

# while：条件成立时反复执行
count = 3
while count > 0:
    print(count)
    count -= 1
```

## 常用控制语句

| 语句 | 作用 |
| --- | --- |
| `break` | 跳出当前循环 |
| `continue` | 跳过本次迭代 |
| `pass` | 空语句占位 |
| `for ... else` | 循环未被 break 时执行 |

## 小结

- 条件优先用 `elif` 链而非嵌套
- 能用 `for` 就不要手写 `while` 计数
- 善用 `enumerate()` 与 `zip()` 简化遍历
