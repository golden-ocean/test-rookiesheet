---
title: 简介与安装
description: 了解 Python 的特点，并在本机搭建开发环境。
language: python
section: 入门
order: 1
updated: 2026-10-18
minutes: 6
tags: [入门, 安装]
notice: 本文假设你了解基本的命令行操作，若不确定可先阅读终端入门。
---

## 什么是 Python

Python 是一门以**简洁易读**著称的通用编程语言，广泛用于数据分析、Web 开发、自动化脚本和人工智能领域。

> Python 的设计哲学：优雅、明确、简单。

## 安装 Python

推荐安装 Python 3.12 或更高版本：

- **Windows / macOS**：从 [python.org](https://www.python.org/downloads/) 下载安装包
- **Linux**：使用包管理器 `sudo apt install python3`
- **版本管理**：推荐使用 `pyenv` 或 `uv` 管理多版本

## 验证安装

```bash
python --version
# Python 3.12.6
```

## 选择编辑器

| 编辑器 | 推荐度 | 说明 |
| --- | --- | --- |
| VS Code | ⭐⭐⭐⭐⭐ | 插件生态丰富，免费 |
| PyCharm | ⭐⭐⭐⭐ | 专业 IDE，功能全面 |
| Neovim | ⭐⭐⭐ | 轻量高效，配置门槛高 |

## 下一步

环境就绪后，前往[快速开始](/docs/python/quick-start)写下你的第一个程序。
