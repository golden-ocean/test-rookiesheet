---
title: 标准库
description: 高频使用的 Python 标准库模块速查。
language: python
section: 进阶
order: 8
updated: 2026-10-18
minutes: 9
tags: [进阶, 标准库]
---

## 路径与文件

```python
from pathlib import Path

root = Path.cwd()
for p in root.glob("**/*.py"):
    print(p.name)
```

## 时间与日期

```python
from datetime import datetime, timedelta

now = datetime.now()
tomorrow = now + timedelta(days=1)
```

## 数据结构

```python
from collections import Counter, defaultdict, deque

Counter(["a", "b", "a"])        # Counter({'a': 2, 'b': 1})
defaultdict(list)                # 不存在的 key 自动初始化
deque(maxlen=3)                  # 双端队列
```

## 常用模块一览

| 模块 | 用途 |
| --- | --- |
| `json` | 序列化与反序列化 |
| `re` | 正则表达式 |
| `itertools` | 迭代器工具 |
| `functools` | 高阶函数工具 |
| `logging` | 日志记录 |

> 标准库优先于第三方包：先用 `pathlib` 而非 `os.path`，先用 `json` 而非手写解析。
