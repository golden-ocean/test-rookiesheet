---
title: 快速开始
description: 写出第一个 Python 程序，掌握最基本的语法结构。
language: python
section: 入门
order: 2
updated: 2026-10-18
minutes: 8
tags: [入门, 基础语法]
notice: 本文假设你已安装 Python 3.12+，运行 python --version 检查。
---

本节将带你写出第一个程序，并了解最基本的语法结构。Python 以简洁易读著称，非常适合作为第一门语言。

## 第一个程序

创建 `hello.py`：

```python
# hello.py
print("Hello, World!")
```

运行方式：

```bash
python hello.py
# 输出：Hello, World!
```

## 运行方式

Python 代码有三种执行方式，按场景选择：

1. **脚本文件**：`python hello.py`，适合正式程序
2. **交互式 REPL**：终端输入 `python` 后逐行执行，适合验证语法
3. **Notebook**：Jupyter 单元格执行，适合数据分析

## 常见问题

<details>
<summary>为什么 Python 不需要分号？</summary>

Python 以换行作为语句结束符，分号是可选的。这是它简洁风格的一部分。
</details>

<details>
<summary>报错「python: command not found」怎么办？</summary>

Windows 尝试 `py` 或 `python3`，macOS / Linux 通常用 `python3`。若都没有，说明安装时未加入 PATH。
</details>

## 下一步

继续学习[变量与类型](/docs/python/variables)深入了解类型系统。
