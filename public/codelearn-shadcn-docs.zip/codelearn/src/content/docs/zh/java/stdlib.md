---
title: 标准库
description: 集合框架、异常体系、时间 API 与常用工具类速查。
language: java
section: 进阶
order: 8
updated: 2026-10-18
minutes: 10
tags: [进阶, 标准库, 集合框架]
---

## 集合框架选型

Java 集合分为 `Collection`（单个元素）与 `Map`（键值对）两大体系。选型建议如下：

| 结构 | 特点 | 典型用途 |
|---|---|---|
| `ArrayList` | 数组实现，随机访问 O(1)，中间插入 O(n) | 绝大多数列表场景 |
| `LinkedList` | 双向链表，头尾操作 O(1) | 当 `Deque` 用作队列/栈 |
| `HashMap` | 哈希表，平均 O(1) | 最常用 Map |
| `LinkedHashMap` | 保留插入顺序 | 需要有序遍历或实现 LRU |
| `TreeMap` | 红黑树，按键有序 | 范围查询、排序输出 |
| `ArrayDeque` | 环形数组 | 栈与队列首选 |

```java
import java.util.*;

public class Collections {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("b", "a", "c"));
        list.sort(Comparator.naturalOrder());
        System.out.println(list);

        Map<String, List<Integer>> byFirstChar = new HashMap<>();
        for (String s : List.of("apple", "avocado", "banana")) {
            // computeIfAbsent 替代冗长的 get + null 判断
            byFirstChar.computeIfAbsent(s.substring(0, 1), k -> new ArrayList<>()).add(s.length());
        }
        System.out.println(byFirstChar);

        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(1);
        stack.push(2);
        System.out.println(stack.pop()); // 2
    }
}
```

## Map 常用 API

```java
Map<String, Integer> stock = new HashMap<>();
stock.put("apple", 10);
stock.merge("apple", 5, Integer::sum);          // 存在则合并
stock.putIfAbsent("pear", 3);                    // 不存在才放入
stock.computeIfPresent("pear", (k, v) -> v + 1);
stock.remove("pear", 4);                         // 值匹配才删除
System.out.println(stock);                       // {apple=15, pear=4}
```

这些方法把"检查—修改"合为一个原子操作，代码更短，且在 `ConcurrentHashMap` 上是线程安全的。

## 异常体系

`Throwable` 下分为 `Error` 与 `Exception`，`Exception` 又分为受检（checked）与非受检（runtime）异常：

| 类型 | 是否需要处理 | 举例 |
|---|---|---|
| `Error` | 否，通常是 JVM 问题 | `OutOfMemoryError` |
| 受检异常 | 必须 `try/catch` 或声明 `throws` | `IOException`、`SQLException` |
| 非受检异常 | 否，多为编程错误 | `NullPointerException`、`IllegalArgumentException` |

```java
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Exceptions {
    static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("不是数字: " + s, e); // 保留原始原因
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println(parse("42"));
        for (String line : Files.readAllLines(Path.of("pom.xml"))) {
            if (line.contains("<artifactId>")) {
                System.out.println(line.trim());
            }
        }
    }
}
```

> 捕获异常时不要写空的 `catch`，也不要用 `catch (Exception e)` 吞掉一切。要么处理，要么包装后继续抛出，并把原始异常作为 `cause` 传入。

## 时间 API

`java.time` 是不可变、线程安全的时间库，替代了旧的 `Date` / `Calendar`：

```java
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimeDemo {
    public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusWeeks(1);
        System.out.println(nextWeek);

        LocalDateTime ts = LocalDateTime.parse("2026-10-18T09:30:00");
        String formatted = ts.format(DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH:mm"));
        System.out.println(formatted);

        Duration d = Duration.between(ts, ts.plusHours(3));
        System.out.println(d.toMinutes()); // 180
    }
}
```

- 只关心日期用 `LocalDate`，带时区用 `ZonedDateTime`，机器间传输用 `Instant`
- 存数据库用 `LocalDateTime` 或 `Instant`，不要用字符串
- 跨时区计算一定显式指定 `ZoneId`，避免依赖服务器默认时区

## 其它常用工具

- `java.util.Objects`：`requireNonNull`、`equals`、`hash`
- `java.util.Optional`：返回值可空时的替代
- `java.nio.file.Files`：读写文件、遍历目录
- `java.util.regex.Pattern`：预编译正则，避免在循环中重复编译
