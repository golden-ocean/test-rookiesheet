---
title: 变量与类型
description: Java 的基本类型、引用类型、装箱与字符串。
language: java
section: 核心概念
order: 3
updated: 2026-10-18
minutes: 9
tags: [核心概念, 类型, 字符串]
---

## 基本类型与引用类型

Java 的类型分为两类：8 种**基本类型**直接存值，其余都是**引用类型**，变量保存的是对象引用。

| 基本类型 | 大小 | 包装类 | 默认值 |
|---|---|---|---|
| `byte` | 8 位 | `Byte` | 0 |
| `short` / `int` / `long` | 16 / 32 / 64 位 | `Short` / `Integer` / `Long` | 0 |
| `float` / `double` | 32 / 64 位 | `Float` / `Double` | 0.0 |
| `char` | 16 位 | `Character` | `\u0000` |
| `boolean` | 1 位语义 | `Boolean` | `false` |

成员变量有默认值，**局部变量必须显式初始化**后才能使用。

```java
public class Types {
    int count;          // 成员变量默认 0
    static double rate; // 默认 0.0

    public static void main(String[] args) {
        int x = 42;
        long big = 9_000_000_000L; // long 字面量要加 L
        float f = 0.5f;            // float 字面量要加 f
        char ch = '中';
        var t = new Types();
        System.out.println(x + " " + big + " " + f + " " + ch + " " + t.count);
    }
}
```

## 自动装箱与相等性

基本类型与包装类之间会自动装箱/拆箱，但 `==` 比较的是**引用**，所以包装类必须用 `equals`：

```java
public class Boxing {
    public static void main(String[] args) {
        Integer a = 1000;
        Integer b = 1000;
        System.out.println(a == b);      // false：不同的对象
        System.out.println(a.equals(b)); // true

        Integer c = 127, d = 127;
        System.out.println(c == d);      // true：缓存范围 -128..127

        int sum = a + b; // 自动拆箱
        System.out.println(sum);
    }
}
```

> 包装类若为 `null`，一参与运算就会抛 `NullPointerException`。集合与泛型中必须使用包装类，这时要特别注意空值。

## 字符串

`String` 是不可变对象，每次拼接都会创建新对象；大量拼接应使用 `StringBuilder`：

```java
public class Strings {
    public static void main(String[] args) {
        String s = "Hello";
        s += ", Java";                 // 实际是新建一个 String
        System.out.println(s.length()); // 11
        System.out.println(s.substring(7));
        System.out.println(s.toUpperCase());

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(i).append(',');
        }
        System.out.println(sb); // 0,1,2,3,4,

        // 文本块（JDK 15+）
        String json = """
                {"name": "Ada", "lang": "Java"}
                """;
        System.out.println(json.isBlank());
    }
}
```

字符串不可变的直接好处是线程安全、可安全作为 `HashMap` 的键。

## 类型转换与数值精度

```java
public class Casting {
    public static void main(String[] args) {
        double d = 3.99;
        int i = (int) d;          // 强制转换：截断，结果为 3
        System.out.println(i);

        System.out.println(0.1 + 0.2); // 0.30000000000000004
        var exact = java.math.BigDecimal.valueOf(0.1)
                .add(java.math.BigDecimal.valueOf(0.2));
        System.out.println(exact);     // 0.3

        int max = Integer.MAX_VALUE;
        System.out.println(max + 1);   // 溢出为负数，不会报错
    }
}
```

金额等需要精确计算的场景应使用 `BigDecimal`，构造时优先用字符串或 `valueOf`，避免传入 `double` 引入误差。

## 判空与 Optional

传统写法用 `null` 检查，但更推荐用 `Optional` 明确表达"可能没有值"：

```java
import java.util.Optional;

public class OptionalDemo {
    static Optional<String> findName(int id) {
        return id == 1 ? Optional.of("Ada") : Optional.empty();
    }

    public static void main(String[] args) {
        String name = findName(1).orElse("匿名");
        int len = findName(2).map(String::length).orElse(0);
        System.out.println(name + " " + len);
    }
}
```

注意：字段和方法参数一般仍用 `null`，`Optional` 主要用作**返回值**。
