---
title: 最佳实践
description: 编码约定、不可变设计、异常规范、测试与构建工具实践。
language: java
section: 进阶
order: 9
updated: 2026-10-18
minutes: 10
tags: [进阶, 最佳实践, 测试]
---

## 不可变优先

不可变对象天然线程安全、可作为 Map 的键、也更容易推理。能用 `final` 就用 `final`，构造完成后的状态尽量不再变动：

```java
import java.util.List;

public record Money(long cents, String currency) {
    public Money {
        if (cents < 0) {
            throw new IllegalArgumentException("金额不能为负");
        }
        // compact constructor：可以校验但不能重新赋值参数名之外的字段
    }

    public Money plus(Money other) {
        if (!currency.equals(other.currency)) {
            throw new IllegalArgumentException("币种不一致");
        }
        return new Money(cents + other.cents, currency); // 返回新对象
    }

    public static void main(String[] args) {
        var a = new Money(1000, "CNY");
        System.out.println(a.plus(new Money(500, "CNY")));
        System.out.println(List.of(a).get(0));
    }
}
```

`record` 自动生成 `equals`、`hashCode`、`toString`，比手写或 Lombok 更透明。

## 命名与结构

- 类名用大驼峰 `OrderService`，方法与变量用小驼峰 `calculateTotal`
- 常量全大写 `MAX_RETRIES`，包名全小写且为反向域名
- 一个类只承担一个职责，超过 300 行或超过 7 个字段时考虑拆分
- 包按功能划分（`order`、`payment`），而不是按技术层划分（`dao`、`service`）

## 异常使用规范

| 场景 | 做法 |
|---|---|
| 编程错误 | 抛 `IllegalArgumentException` / `IllegalStateException` |
| 可恢复的业务失败 | 自定义受检异常，或在返回类型中表达 |
| 底层资源错误 | 包装为领域异常，保留 cause |
| 捕获后无事可做 | 不要捕获 |

```java
public class Retry {
    static int attempts = 0;

    static String fetch() {
        attempts++;
        if (attempts < 3) {
            throw new IllegalStateException("临时故障");
        }
        return "ok";
    }

    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            try {
                System.out.println(fetch());
                break;
            } catch (IllegalStateException e) {
                System.err.println("第 " + (i + 1) + " 次失败：" + e.getMessage());
            }
        }
    }
}
```

## 测试

JUnit 5 是事实标准，配合断言库与 Mock 框架：

```java
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class MoneyTest {
    @Test
    void adds_same_currency() {
        var result = new Money(100, "CNY").plus(new Money(50, "CNY"));
        assertEquals(150, result.cents());
    }

    @Test
    void rejects_mixed_currency() {
        assertThrows(IllegalArgumentException.class,
                () -> new Money(100, "CNY").plus(new Money(1, "USD")));
    }
}
```

- 测试名描述行为，而不是描述方法名
- 一个测试只验证一件事，失败时能直接定位原因
- 优先测试纯逻辑，I/O 与网络用接口隔离

## 构建与运行

> CI 中固定 JDK 版本并执行 `mvn -B verify`（或 `gradle build`），让编译警告、静态检查与测试一起通过。

- Maven 用 `dependencyManagement` 统一版本，避免依赖冲突
- Gradle 优先使用 Kotlin DSL 与版本目录（`libs.versions.toml`）
- 用 `jlink` / `jpackage` 裁剪运行时镜像，减小容器体积
- 启动参数加 `-XX:+UseG1GC`（默认即可）与合理的 `-Xmx`，避免容器内存超限被杀

## 常见陷阱清单

- `equals` 与 `hashCode` 必须成对重写，否则 `HashMap` 行为异常
- 浮点数比较不要用 `==`，金额用 `BigDecimal`
- 不要用 `String` 拼接 SQL，使用 `PreparedStatement`
- 大对象不要长期持有静态引用，容易造成内存泄漏
