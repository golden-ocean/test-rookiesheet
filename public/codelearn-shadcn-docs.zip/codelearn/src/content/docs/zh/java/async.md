---
title: 异步编程
description: 线程池、CompletableFuture 与虚拟线程的实战用法。
language: java
section: 进阶
order: 7
updated: 2026-10-18
minutes: 11
tags: [进阶, 并发, completablefuture]
notice: 虚拟线程需要 JDK 21 及以上版本，低版本请只使用线程池部分。
---

## 线程基础

Java 的并发单位是 `Thread`，每个线程对应操作系统线程（虚拟线程除外）。直接 `new Thread` 创建线程开销大、数量不可控，生产中一律使用线程池：

```java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class PoolDemo {
    public static void main(String[] args) throws InterruptedException {
        // 固定大小线程池：适合 CPU 密集型任务
        ExecutorService pool = Executors.newFixedThreadPool(4);
        try {
            for (int i = 0; i < 8; i++) {
                int id = i;
                pool.submit(() -> System.out.println("任务 " + id));
            }
        } finally {
            pool.shutdown();                        // 不再接收新任务
            pool.awaitTermination(1, TimeUnit.SECONDS);
        }
    }
}
```

| 线程池 | 适用场景 | 风险 |
|---|---|---|
| `newFixedThreadPool` | CPU 密集 | 无界队列可能堆积任务 |
| `newCachedThreadPool` | 大量短任务 | 线程数无上限 |
| `newVirtualThreadPerTaskExecutor` | 大量 I/O 阻塞 | 需 JDK 21+ |

## CompletableFuture

`CompletableFuture` 用链式方式组合异步任务，避免回调地狱：

```java
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CfDemo {
    static String fetchUser(long id) throws InterruptedException {
        Thread.sleep(100); // 模拟远程调用
        return "user-" + id;
    }

    public static void main(String[] args) {
        ExecutorService io = Executors.newFixedThreadPool(8);

        CompletableFuture<String> future = CompletableFuture
                .supplyAsync(() -> {
                    try { return fetchUser(7); }
                    catch (InterruptedException e) { throw new RuntimeException(e); }
                }, io)
                .thenApply(String::toUpperCase)          // 转换结果
                .exceptionally(ex -> "fallback");        // 兜底

        System.out.println(future.join()); // 阻塞等待结果
        io.shutdown();
    }
}
```

常用方法区分清楚很重要：

- `thenApply`：同步转换，不切线程
- `thenApplyAsync`：把后续步骤提交到线程池
- `thenCompose`：串联另一个异步任务（避免嵌套 `CompletableFuture<CompletableFuture<T>>`）
- `thenCombine`：合并两个独立任务的结果
- `allOf` / `anyOf`：等待全部 / 任一完成

```java
var a = CompletableFuture.supplyAsync(() -> 1);
var b = CompletableFuture.supplyAsync(() -> 2);
System.out.println(CompletableFuture.allOf(a, b).thenApply(v -> a.join() + b.join()).join());
```

> 不要在 `CompletableFuture` 链里调用 `join()` 等待另一个 Future，容易造成线程池饥饿。要串联请用 `thenCompose`。

## 虚拟线程

JDK 21 正式引入虚拟线程：由 JVM 调度、挂起时释放载体线程，因此可以用"一请求一线程"的直观写法处理大量阻塞 I/O：

```java
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class VirtualThreads {
    public static void main(String[] args) throws Exception {
        var start = Instant.now();
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            IntStream.range(0, 10_000).forEach(i ->
                    executor.submit(() -> {
                        Thread.sleep(Duration.ofMillis(10)); // 阻塞不会占住平台线程
                        return i;
                    }));
        } // close 会等待所有任务结束
        System.out.println("耗时 " + Duration.between(start, Instant.now()).toMillis() + "ms");
    }
}
```

创建一万个虚拟线程几乎不耗内存，而同样数量的平台线程早已耗尽堆栈空间。

## 并发安全

- 共享可变状态优先用 `java.util.concurrent` 包中的容器（`ConcurrentHashMap`、`CopyOnWriteArrayList`）
- 简单计数用 `AtomicInteger` / `LongAdder`，比加锁便宜
- 需要临界区时用 `ReentrantLock` 或 `synchronized`，锁粒度尽量小
- 虚拟线程中不要用 `synchronized` 长时间阻塞，JDK 21 建议改用 `ReentrantLock`
