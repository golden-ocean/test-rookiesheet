---
title: 简介与安装
description: 认识 Java、JVM 生态与 JDK 的安装配置。
language: java
section: 入门
order: 1
updated: 2026-10-18
minutes: 7
tags: [入门, 安装, JVM]
---

## Java 与 JVM

Java 是一门面向对象的静态类型语言。它的核心思路是"一次编写，到处运行"：源码先被编译成字节码（`.class`），再由 JVM（Java 虚拟机）执行。JVM 负责内存管理、垃圾回收与即时编译（JIT），因此同一份字节码可以在 Windows、Linux、macOS 上直接运行。

Java 目前长期支持（LTS）的版本包括 8、11、17、21。新项目建议直接使用 **JDK 21** 或更高版本，可以享受到记录类（record）、模式匹配与虚拟线程等特性。

| 组件 | 作用 |
|---|---|
| JVM | 执行字节码，负责 GC 与 JIT |
| JRE | JVM + 标准类库，仅够运行程序 |
| JDK | JRE + `javac` 编译器 + 调试工具 |

## 安装 JDK

推荐使用发行版提供的包管理器，或采用 Eclipse Temurin、Amazon Corretto 等开源发行版：

```bash
# macOS (Homebrew)
brew install --cask temurin@21

# Ubuntu / Debian
sudo apt install openjdk-21-jdk

# 检查版本
java -version
javac -version
```

`java -version` 输出的第一行会包含版本号，例如 `openjdk version "21.0.4"`。`javac` 找不到说明安装的是 JRE 而不是 JDK。

## 第一个程序

创建 `Hello.java`（文件名必须与 public 类名一致）：

```java
public class Hello {
    public static void main(String[] args) {
        String name = args.length > 0 ? args[0] : "Java";
        System.out.println("你好，" + name + "！");
    }
}
```

编译并运行：

```bash
javac Hello.java   # 生成 Hello.class
java Hello 世界     # 不要加 .class 后缀
```

也可以用 JDK 11 起支持的单文件模式直接执行：`java Hello.java`。

## 构建工具与生态

真实项目不会手动调用 `javac`，而是使用构建工具管理依赖与生命周期：

| 工具 | 配置文件 | 特点 |
|---|---|---|
| Maven | `pom.xml` | 约定优于配置，生态成熟 |
| Gradle | `build.gradle(.kts)` | 增量构建快，DSL 灵活 |

Maven 的最小 `pom.xml`：

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.example</groupId>
  <artifactId>hello</artifactId>
  <version>1.0.0</version>
  <properties>
    <maven.compiler.release>21</maven.compiler.release>
  </properties>
</project>
```

> 团队中务必统一 JDK 版本。可以在 `pom.xml` 中用 `maven.compiler.release` 或 `--release` 参数固定，避免在更高版本上编译、却运行在旧 JVM 上。

## 常见问题

- 类名与文件名不一致：`javac` 会报错，public 类必须同名
- `UnsupportedClassVersionError`：编译版本高于运行版本，降低 `--release` 或升级 JRE
- 中文乱码：确认源文件使用 UTF-8，必要时加 `-encoding UTF-8`

接下来阅读《快速开始》，写一个带输入输出的完整小程序。
