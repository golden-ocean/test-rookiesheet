---
title: 流程控制
description: if、switch 表达式、循环与增强 for 的正确用法。
language: java
section: 核心概念
order: 4
updated: 2026-10-18
minutes: 8
tags: [核心概念, 控制流, switch]
---

## 条件语句

```java
public class Conditions {
    static String grade(int score) {
        if (score >= 90) {
            return "A";
        } else if (score >= 60) {
            return "B";
        }
        return "C"; // 保证所有路径都有返回值
    }

    public static void main(String[] args) {
        System.out.println(grade(85));
        String level = grade(95).equals("A") ? "优秀" : "继续加油";
        System.out.println(level);
    }
}
```

条件必须是 `boolean`，Java 不接受 `int` 作为真假值，这一点与 C 不同。

## switch 表达式

JDK 14 起的 `switch` 表达式使用箭头语法，**不会贯穿**（fall-through），并且可以被赋值：

```java
public class SwitchDemo {
    enum Level { LOW, MEDIUM, HIGH }

    static int weight(Level level) {
        return switch (level) {
            case LOW -> 1;
            case MEDIUM -> 5;
            case HIGH -> 10;
        };
    }

    static String describe(Object o) {
        return switch (o) {
            case Integer i when i < 0 -> "负整数 " + i;
            case Integer i -> "整数 " + i;
            case String s -> "字符串 " + s;
            case null -> "null";
            default -> "其他";
        };
    }

    public static void main(String[] args) {
        System.out.println(weight(Level.HIGH));
        System.out.println(describe(-3));
        System.out.println(describe("hi"));
    }
}
```

`default` 在枚举全覆盖时可以省略，其余情况编译器会要求你处理所有分支。

## 循环

Java 提供 `for`、`while`、`do-while` 与增强 `for` 四种循环：

```java
import java.util.List;

public class Loops {
    public static void main(String[] args) {
        var names = List.of("Ada", "Linus", "Grace");

        for (int i = 0; i < 3; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (String name : names) { // 增强 for，只读遍历
            System.out.print(name + " ");
        }
        System.out.println();

        int n = 3;
        while (n > 0) {
            n--;
        }
        do {
            n++;
        } while (n < 3);

        outer:
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (i * j > 2) {
                    break outer; // 带标签跳出外层循环
                }
            }
        }
        System.out.println("n=" + n);
    }
}
```

带标签的 `break`/`continue` 应尽量少用，若能通过提前返回或抽取方法表达，可读性更好。

## 集合遍历与删除

在增强 `for` 中直接 `remove` 会抛 `ConcurrentModificationException`，应使用 `Iterator`：

```java
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class RemoveWhileIterating {
    public static void main(String[] args) {
        var nums = new ArrayList<>(List.of(1, 2, 3, 4, 5));

        for (Iterator<Integer> it = nums.iterator(); it.hasNext(); ) {
            if (it.next() % 2 == 0) {
                it.remove(); // 安全删除
            }
        }
        System.out.println(nums); // [1, 3, 5]

        // JDK 8+ 的替代写法
        nums.removeIf(x -> x > 3);
        System.out.println(nums); // [1, 3]
    }
}
```

> `List.of(...)` 返回的是**不可变列表**，对它调用 `add`/`remove` 会抛 `UnsupportedOperationException`，需要可变集合时用 `new ArrayList<>(List.of(...))`。

## 小结

- 判断用 `if`，多分支且需要返回值用 `switch` 表达式
- 遍历集合优先用增强 `for` 或 Stream，删除元素用 `Iterator` 或 `removeIf`
- 标签跳转尽量改为方法提取，降低认知负担
