---
title: 函数
description: 方法签名、重载、可变参数、Lambda 与函数式接口。
language: java
section: 核心概念
order: 5
updated: 2026-10-18
minutes: 9
tags: [核心概念, 方法, lambda]
---

## 方法基础

Java 中的"函数"以方法形式存在，必须属于某个类。一个方法由访问修饰符、返回类型、名称和参数列表组成：

```java
public class Calc {
    // 静态方法：属于类，不需要实例
    public static int add(int a, int b) {
        return a + b;
    }

    // 实例方法：可以访问对象状态
    private int base;
    public Calc(int base) {
        this.base = base;
    }
    public int addToBase(int x) {
        return this.base + x;
    }

    // void 方法：没有返回值
    public static void log(String msg) {
        System.out.println("[log] " + msg);
        return; // 可选的提前返回
    }

    public static void main(String[] args) {
        var c = new Calc(10);
        log("result = " + Calc.add(c.addToBase(5), 1));
    }
}
```

## 重载与可变参数

**重载**指同名但参数列表不同的多个方法，编译期按参数类型选择。**可变参数**必须放在参数列表最后：

```java
public class Overload {
    static String join(String sep, String... parts) {
        return String.join(sep, parts);
    }

    static void print(int x) {
        System.out.println("int " + x);
    }

    static void print(long x) {
        System.out.println("long " + x);
    }

    public static void main(String[] args) {
        System.out.println(join("-", "a", "b", "c"));
        print(1);        // 选 int 版本
        print(1L);       // 选 long 版本
        print(new short[0].length); // int 是默认的整数字面量类型
    }
}
```

> 重载过多会让调用可读性变差。参数含义不明显的布尔参数尤其危险，考虑改用枚举或独立方法名。

## Lambda 与函数式接口

只有一个抽象方法的接口称为**函数式接口**，可以用 Lambda 简化实现：

```java
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Lambdas {
    public static void main(String[] args) {
        Function<Integer, Integer> square = x -> x * x;
        Predicate<String> notBlank = s -> !s.isBlank();

        var words = List.of("rust", "", " java ", "go");
        words.stream()
                .filter(notBlank)
                .map(String::trim)         // 方法引用
                .map(String::toUpperCase)
                .map(square::apply)        // 无法适配时可以显式调用
                .forEach(System.out::println);
    }
}
```

常用内置函数式接口：`Function<T,R>`、`Predicate<T>`、`Supplier<T>`、`Consumer<T>`、`BiFunction<T,U,R>`。

## Stream 的常用操作

```java
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

record Order(String customer, int amount) {}

public class Streams {
    public static void main(String[] args) {
        var orders = List.of(
                new Order("Ada", 120),
                new Order("Ada", 80),
                new Order("Bob", 200));

        Map<String, Integer> totals = orders.stream()
                .collect(Collectors.groupingBy(
                        Order::customer,
                        Collectors.summingInt(Order::amount)));
        System.out.println(totals); // {Bob=200, Ada=200}

        int big = orders.stream()
                .mapToInt(Order::amount)
                .filter(a -> a > 100)
                .sum();
        System.out.println("大于 100 的总额 " + big);
    }
}
```

Stream 适合"转换 + 聚合"的声明式写法；如果循环里有复杂的控制流、需要提前退出（Stream 不支持 `break`），普通 `for` 反而更清楚。

## 方法设计建议

- 单个方法控制在 20~30 行以内，超出时考虑拆分
- 参数不超过 4 个，多了封装成对象
- 明确返回值：没有结果时返回 `Optional` 或空集合，而不是 `null`
- 工具方法用 `static`，有状态的行为才放实例方法
