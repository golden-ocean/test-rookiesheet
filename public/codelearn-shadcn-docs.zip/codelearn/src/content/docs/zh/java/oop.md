---
title: 面向对象
description: 类、接口、继承、多态、泛型与组合优于继承。
language: java
section: 核心概念
order: 6
updated: 2026-10-18
minutes: 11
tags: [核心概念, 面向对象, 泛型]
notice: 示例使用 Sealed 接口与 record，需要 JDK 17 及以上版本。
---

## 类与对象

类是对象的模板，包含字段、构造器与方法。构造器与类同名且无返回类型：

```java
public class Account {
    private final String owner;   // final：构造后不可改
    private long balance;         // 单位：分

    public Account(String owner, long balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public String getOwner() { return owner; }
    public long getBalance() { return balance; }

    public void deposit(long amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("金额必须为正");
        }
        balance += amount;
    }

    @Override
    public String toString() {
        return "Account(" + owner + ", " + balance + ")";
    }
}
```

`private` 字段只能通过方法访问，这是 Java 的封装基础。`final` 字段必须在构造器结束前赋值。

## 继承与多态

Java 支持类的单继承与接口的多实现，运行时通过**动态分派**选择实际类型的方法：

```java
abstract class Shape {
    abstract double area();

    String describe() { // 模板方法：复用公共逻辑
        return getClass().getSimpleName() + " 面积 " + String.format("%.2f", area());
    }
}

class Circle extends Shape {
    private final double r;
    Circle(double r) { this.r = r; }
    @Override double area() { return Math.PI * r * r; }
}

class Rect extends Shape {
    private final double w, h;
    Rect(double w, double h) { this.w = w; this.h = h; }
    @Override double area() { return w * h; }
}

public class Shapes {
    public static void main(String[] args) {
        Shape[] shapes = { new Circle(1), new Rect(2, 3) };
        for (Shape s : shapes) {
            System.out.println(s.describe()); // 调用各自重写的 area
        }
    }
}
```

`@Override` 不是必需的，但它能让编译器帮你检查方法签名是否真的覆盖了父类方法。

## 接口与默认方法

接口描述"能做什么"，从 Java 8 起可以有 `default` 方法（但不保存状态）：

```java
interface Payable {
    long amount();

    default String receipt() {
        return "需支付 " + amount() + " 分";
    }

    static Payable fixed(long v) { // 静态工厂
        return () -> v;            // 接口只有一个抽象方法时可写成 Lambda
    }
}

public class DefaultDemo {
    public static void main(String[] args) {
        Payable p = Payable.fixed(1999);
        System.out.println(p.receipt());
    }
}
```

接口可以多实现，因此"一个类兼具多种能力"应该用接口而非继承表达。

## sealed 与 record

JDK 17 引入 `sealed`，限制谁能实现某个接口，配合 `switch` 可以做穷尽匹配；`record` 则用于不可变数据：

```java
sealed interface Result permits Ok, Err {}
record Ok<T>(T value) implements Result {}
record Err(String message) implements Result {}

public class SealedDemo {
    static String render(Result r) {
        return switch (r) {
            case Ok<?> ok -> "OK: " + ok.value();
            case Err err -> "ERR: " + err.message();
        };
    }

    public static void main(String[] args) {
        System.out.println(render(new Ok<>(42)));
        System.out.println(render(new Err("超时")));
    }
}
```

## 泛型

泛型在编译期提供类型检查，运行时会被擦除（type erasure），因此不能 `new T[]`，也不能对泛型做 `instanceof`：

```java
import java.util.ArrayList;
import java.util.List;

public class GenericBox<T> {
    private final List<T> items = new ArrayList<>();

    public void add(T item) { items.add(item); }

    public <R> List<R> map(java.util.function.Function<? super T, ? extends R> fn) {
        var out = new ArrayList<R>();
        for (T item : items) {
            out.add(fn.apply(item));
        }
        return out;
    }

    public static void main(String[] args) {
        var box = new GenericBox<String>();
        box.add("a");
        box.add("bc");
        System.out.println(box.map(String::length));
    }
}
```

`? super T` 与 `? extends R` 是 PECS 原则（Producer Extends, Consumer Super）的体现：读数据用 `extends`，写数据用 `super`。

> 继承适合表达稳定的 "is-a" 关系；仅仅是复用代码时，优先用组合并依赖接口，避免形成过深的类层次。
