---
title: 快速开始
description: 从零写一个带输入输出的 Java 程序，并了解 Maven 工程结构。
language: java
section: 入门
order: 2
updated: 2026-10-18
minutes: 8
tags: [入门, 基础语法]
notice: 示例使用 JDK 17 及以上版本，旧版本请去掉 record 与 var 的用法。
---

## Maven 标准目录

```
hello/
├── pom.xml
└── src/
    ├── main/java/com/example/App.java
    └── test/java/com/example/AppTest.java
```

Maven 约定源码放在 `src/main/java`，测试放在 `src/test/java`，包名与目录层级一一对应。执行 `mvn compile` 编译，`mvn package` 打出 jar。

## 一个完整的程序

```java
package com.example;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        try (Scanner in = new Scanner(System.in)) { // try-with-resources 自动关闭
            System.out.print("请输入名字：");
            String name = in.nextLine();
            System.out.printf("你好，%s！%n", name);
        }
    }
}
```

`System.out.println` 会自动换行，`printf` 使用格式化占位符：`%s` 字符串、`%d` 整数、`%f` 浮点、`%n` 换行。

## 输入与类型转换

`Scanner` 读取的是文本，需要自行转换类型：

```java
import java.util.Scanner;

public class Sum {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("两个整数：");
        int a = Integer.parseInt(in.next());
        int b = in.nextInt(); // nextInt 直接解析整数
        System.out.println("和 = " + (a + b));
    }
}
```

输入不是数字时 `nextInt` 会抛出 `InputMismatchException`，生产代码中应当校验或用 `hasNextInt()` 判断。

## 命令行参数与退出码

```java
public class ExitCode {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("用法: ExitCode <文件名>");
            System.exit(2); // 非零表示失败
        }
        System.out.println("处理 " + args[0]);
    }
}
```

`System.err` 输出到标准错误流，CI 与脚本通常只检查退出码。

## var 与 record

JDK 10 起可以用 `var` 做局部变量类型推断，JDK 16 起可以使用 `record` 定义不可变数据载体：

```java
record Point(int x, int y) {
    // 自动生成构造器、访问器、equals、hashCode、toString
    double distance() {
        return Math.hypot(x, y);
    }
}

public class Demo {
    public static void main(String[] args) {
        var p = new Point(3, 4);
        System.out.println(p);              // Point[x=3, y=4]
        System.out.println(p.distance());   // 5.0
    }
}
```

> `var` 只能用于局部变量，且必须在声明时初始化。不要为了少打几个字而牺牲可读性，右侧类型不明确时仍应写出完整类型。

## 运行与调试

- `mvn exec:java -Dexec.mainClass=com.example.App`：运行主类
- `java -jar target/hello-1.0.0.jar`：运行打包后的 jar（需配置 `maven-jar-plugin` 或 `spring-boot-maven-plugin` 的 mainClass）
- `java -Xmx512m -jar app.jar`：限制最大堆内存
- `jps` / `jstack`：查看进程与线程栈

下一步进入《变量与类型》。
