---
title: 简介与安装
description: 认识 JavaScript 的运行环境，安装 Node.js 并跑起第一个脚本。
language: javascript
section: 入门
order: 1
updated: 2026-10-18
minutes: 6
tags: [入门, 安装, 环境]
notice: 本文基于 Node.js 20+ 与 ES2023 语法，浏览器与 Node 均可运行示例。
---

JavaScript 诞生于 1995 年，最初只用来给网页加一点交互。如今它同时运行在浏览器、服务器（Node.js）、桌面端（Electron）和边缘函数中，是生态最庞大的编程语言之一。

## 语言特性一览

| 特性 | 说明 |
|---|---|
| 动态类型 | 变量无类型标注，运行时才确定 |
| 单线程 + 事件循环 | 主线程不阻塞，异步任务由回调队列驱动 |
| 原型继承 | 对象之间通过原型链共享行为 |
| 函数是一等公民 | 函数可赋值、传参、返回 |
| 多范式 | 支持过程式、面向对象与函数式 |

> JavaScript 与 Java 只是名字相似，设计理念完全不同。JS 的标准化名称是 ECMAScript（ES）。

## 安装运行环境

浏览器里直接按 F12 打开控制台就能写代码。要在本地运行脚本，需要 Node.js：

```bash
# 使用 nvm 管理多个 Node 版本（推荐）
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
nvm install 20
nvm use 20

node -v   # v20.x.x
npm -v    # 10.x.x
```

## 第一个脚本

```js
// hello.js
const name = process.argv[2] ?? 'World';

// 模板字符串用反引号，支持插值
console.log(`Hello, ${name}!`);
```

```bash
node hello.js 开发者
# Hello, 开发者!
```

## 模块的两种形式

现代项目优先使用 ES Module（ESM），在 `package.json` 里加上 `"type": "module"` 即可：

```js
// math.js —— 命名导出
export function add(a, b) {
  return a + b;
}

export const PI = 3.14159;
```

```js
// main.js —— 引用
import { add, PI } from './math.js';

console.log(add(1, 2), PI.toFixed(2));
```

老项目常见 CommonJS 写法 `const { add } = require('./math')`，两者不要在同一文件混用。

## 下一步

建议按顺序阅读：快速开始 → 变量与类型 → 流程控制 → 函数，把基础语法打通后再看异步编程。
