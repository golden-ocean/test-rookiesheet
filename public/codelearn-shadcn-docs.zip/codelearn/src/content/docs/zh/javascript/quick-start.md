---
title: 快速开始
description: 用一个小例子掌握输入输出、模板字符串与数组方法。
language: javascript
section: 入门
order: 2
updated: 2026-10-18
minutes: 7
tags: [入门, 基础语法]
---

本文用一段统计文本的小程序，把最常用的语法串起来。所有代码都可以直接在 Node 或浏览器控制台运行。

## 输出与基本运算

```js
// 基本输出
console.log('Hello, JavaScript');
console.table([{ a: 1 }, { a: 2 }]); // 表格化输出，调试很方便

const price = 39.9;
const count = 3;
const total = price * count;
console.log(`总价：${total.toFixed(2)} 元`); // 总价：119.70 元
```

## 处理一组数据

```js
const words = 'the quick brown fox jumps over the lazy dog'.split(' ');

// 链式调用数组方法：filter -> map -> reduce
const longWords = words
  .filter((w) => w.length > 3)
  .map((w) => w.toUpperCase());

const totalLength = longWords.reduce((sum, w) => sum + w.length, 0);

console.log(longWords);    // [ 'QUICK', 'BROWN', 'JUMPS', 'OVER', 'LAZY' ]
console.log(totalLength);  // 24
```

数组方法不修改原数组（`sort`、`splice` 除外），这让代码更容易推理。

## 对象与解构

```js
const user = { name: 'Ada', age: 36, lang: ['js', 'ts'] };

// 解构 + 默认值 + 重命名
const { name, age: years = 18, lang } = user;
console.log(`${name} 会 ${lang.join('、')}，${years} 岁`);

// 展开运算符创建新对象，而不是修改原对象
const updated = { ...user, age: 37 };
console.log(user.age, updated.age); // 36 37
```

> 优先写不可变代码：创建新对象而不是直接改原对象，能避免很多“值莫名变了”的 bug。

## 从命令行读参数

```js
// sum.js —— node sum.js 1 2 3
const nums = process.argv.slice(2).map(Number);

if (nums.some(Number.isNaN)) {
  console.error('参数必须是数字');
  process.exit(1);
}

const sum = nums.reduce((acc, n) => acc + n, 0);
console.log(`共 ${nums.length} 个数字，和是 ${sum}`);
```

## 小结

| 概念 | 写法 |
|---|---|
| 声明变量 | `const` / `let` |
| 模板字符串 | `` `你好 ${name}` `` |
| 数组遍历 | `for...of`、`map`、`filter` |
| 对象拷贝 | `{ ...obj }` |
| 调试 | `console.log` / `console.table` / `debugger` |
