---
title: 最佳实践
description: 作用域、不可变数据、错误处理与工程化配置的建议。
language: javascript
section: 进阶
order: 9
updated: 2026-10-18
minutes: 9
tags: [进阶, 工程化]
notice: 本文的规则大多可以通过 ESLint 自动检查，建议在项目里一次性配置好。
---

JavaScript 的灵活既是优点也是陷阱。下面这些约定能显著降低维护成本，也是主流团队的事实标准。

## 语言层面的约定

```js
// 1. 严格相等，避免类型转换
if (value === null) { /* ... */ }

// 2. 默认导出少用，具名导出更利于重构与 tree-shaking
export function parseConfig() { /* ... */ }

// 3. 早返回减少嵌套
function check(user) {
  if (!user) return '缺少用户';
  if (!user.active) return '用户已停用';
  return 'OK';
}

// 4. 避免魔法数字
const ONE_DAY_MS = 24 * 60 * 60 * 1000;
```

## 不可变与纯函数

```js
// 反例：修改入参，调用方难以察觉
function addTagBad(post, tag) {
  post.tags.push(tag);
  return post;
}

// 正例：返回新对象
function addTag(post, tag) {
  return { ...post, tags: [...post.tags, tag] };
}

const post = { id: 1, tags: [] };
const next = addTag(post, 'js');
console.log(post.tags.length, next.tags.length); // 0 1
```

纯函数（同样输入必得同样输出、无副作用）最好测试，也最容易被缓存与并行化。

## 错误处理

```js
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
  }
}

async function request(url) {
  const res = await fetch(url);
  if (!res.ok) throw new HttpError(res.status, res.statusText);
  return res.json();
}

// 不要吞掉错误
try {
  await request('/api/data');
} catch (err) {
  if (err instanceof HttpError && err.status === 404) {
    // 可预期的分支
  } else {
    throw err;
  }
}
```

| 错误 | 后果 |
|---|---|
| 空的 `catch {}` | 问题被隐藏，排查困难 |
| 只 `catch (e) { console.log(e) }` | 调用方以为成功 |
| 抛字符串 `throw 'error'` | 丢失堆栈 |

## 工程化配置

```json
{
  "type": "module",
  "engines": { "node": ">=20" },
  "scripts": {
    "lint": "eslint .",
    "format": "prettier --write .",
    "test": "node --test"
  }
}
```

结合 ESLint（`no-var`、`eqeqeq`、`no-unused-vars`）与 Prettier，能自动拦截大部分低级问题。团队里统一工具比统一个人风格更现实。

> 新项目建议直接使用 TypeScript 或 `// @ts-check`，类型检查能发现大量运行期才能暴露的 bug。
