---
title: 流程控制
description: 条件分支、循环、可选链与逻辑赋值的实用写法。
language: javascript
section: 核心概念
order: 4
updated: 2026-10-18
minutes: 6
tags: [核心概念, 基础语法]
---

JavaScript 的分支与循环和其他语言相似，但多了不少现代语法糖，用好能显著减少样板代码。

## 条件分支

```js
function grade(score) {
  if (score >= 90) return 'A';
  if (score >= 80) return 'B';
  if (score >= 60) return 'C';
  return 'D';
}

// switch 用严格相等比较
function label(code) {
  switch (code) {
    case 200:
    case 201:
      return '成功';
    case 404:
      return '未找到';
    default:
      return '未知';
  }
}
```

## 循环的四种写法

```js
const items = ['a', 'b', 'c'];

for (let i = 0; i < items.length; i++) {
  // 需要下标时使用
}

for (const item of items) {
  // 最推荐的数组遍历方式，支持 break/continue
}

for (const [index, item] of items.entries()) {
  console.log(index, item);
}

items.forEach((item, index) => {
  // 不能用 break，适合纯副作用操作
});
```

| 循环 | 可中断 | 适合 |
|---|---|---|
| `for` | 是 | 需要精确控制下标 |
| `for...of` | 是 | 遍历可迭代对象 |
| `forEach` | 否 | 简单遍历，语义清晰 |
| `for...in` | 是 | 遍历对象**键**（不要用于数组） |

## 短路与可选链

```js
const user = { profile: null };

// ?? 只在 null/undefined 时回退（0 和 '' 会被保留）
const name = user.name ?? '匿名';

// ?. 安全访问，链中途为 null/undefined 就返回 undefined
const city = user.profile?.address?.city;

// || 会在所有 falsy 值时回退，注意和 ?? 的区别
const limit = 0 || 10;  // 10
const limit2 = 0 ?? 10; // 0

console.log(name, city); // 匿名 undefined
```

## 逻辑赋值运算符

```js
const state = { retries: 0 };

state.retries ??= 3;      // 仅当为 null/undefined 时赋值
state.cache ||= 'none';   // falsy 时赋值
state.flags &&= 'ready';  // truthy 时赋值

console.log(state); // { retries: 0, cache: 'none', flags: 0 }
```

> 不要用三元表达式层层嵌套。三个以上分支时，改用 `switch`、映射表或提前 `return`。
