---
title: 面向对象
description: 原型链、class 语法、继承与私有字段的正确用法。
language: javascript
section: 核心概念
order: 6
updated: 2026-10-18
minutes: 8
tags: [核心概念, 原型, class]
---

JavaScript 的对象模型基于原型而非类。`class` 只是原型继承的语法糖，理解底层机制才能看懂很多库的写法。

## 构造函数与原型

```js
function Animal(name) {
  this.name = name;
}

// 方法挂在原型上，所有实例共享，节省内存
Animal.prototype.speak = function () {
  return `${this.name} 发出声音`;
};

const cat = new Animal('猫');
console.log(cat.speak());              // 猫 发出声音
console.log(Object.getPrototypeOf(cat) === Animal.prototype); // true
```

原型链查找规则：先在自身找，找不到就沿 `__proto__` 逐级向上，直到 `Object.prototype`。

## class 语法

```js
class Animal {
  #energy = 100; // 私有字段，只能在类内部访问

  constructor(name) {
    this.name = name;
  }

  speak() {
    return `${this.name} 发出声音`;
  }

  get energy() {
    return this.#energy;
  }

  static create(name) {
    return new this(name);
  }
}

class Dog extends Animal {
  speak() {
    return `${super.speak()}：汪！`;
  }
}

const d = Dog.create('旺财');
console.log(d.speak(), d.energy, d instanceof Animal); // 旺财 发出声音：汪！ 100 true
```

| 特性 | class 写法 |
|---|---|
| 私有字段 | `#field` |
| 私有方法 | `#method()` |
| 静态成员 | `static` |
| 调用父类 | `super.method()` |

## 组合优于继承

继承层次一深就容易僵化。社区更推荐用组合与混入：

```js
const canFly = {
  fly() {
    return `${this.name} 飞起来了`;
  },
};

const canSwim = {
  swim() {
    return `${this.name} 游泳中`;
  },
};

class Duck {
  constructor(name) {
    this.name = name;
  }
}

// 把行为混入到原型上
Object.assign(Duck.prototype, canFly, canSwim);

const duck = new Duck('唐老鸭');
console.log(duck.fly(), duck.swim());
```

## 常用对象工具

```js
const obj = { a: 1, b: 2, c: 3 };

Object.keys(obj);    // ['a', 'b', 'c']
Object.values(obj);  // [1, 2, 3]
Object.entries(obj); // [['a',1], ['b',2], ['c',3]]
Object.freeze(obj);  // 冻结后无法修改
Object.hasOwn(obj, 'a'); // true
```

> `class` 适合表示有状态、有明确身份的事物；纯数据处理优先用普通对象与函数。
