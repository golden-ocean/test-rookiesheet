---
title: 变量与类型
description: let/const 的作用域、七种原始类型与类型转换的陷阱。
language: javascript
section: 核心概念
order: 3
updated: 2026-10-18
minutes: 8
tags: [核心概念, 类型]
notice: 本文的 == 与 === 示例建议亲手在控制台跑一遍，印象会更深。
---

JavaScript 是动态类型语言，但并非“没有类型”。理解原始类型与对象类型的差异，能避开绝大多数坑。

## 声明变量

```js
var legacy = '不推荐'; // 函数作用域，存在变量提升
let counter = 0;       // 块级作用域，可重新赋值
const config = { mode: 'dark' }; // 块级作用域，不可重新绑定

counter += 1;
config.mode = 'light'; // 合法：const 限制的是绑定，不是对象内容
// config = {};        // TypeError
```

规则很简单：默认用 `const`，需要重新赋值时再用 `let`，永远不要用 `var`。

## 原始类型

| 类型 | 示例 | 说明 |
|---|---|---|
| `number` | `42`, `3.14`, `NaN` | 双精度浮点，没有整数类型 |
| `bigint` | `10n` | 任意精度整数 |
| `string` | `'hi'`, `` `hi` `` | UTF-16 序列，不可变 |
| `boolean` | `true` | |
| `undefined` | `let a;` | 未赋值 |
| `null` | `null` | 人为表示“空” |
| `symbol` | `Symbol('id')` | 唯一标识 |

原始类型按值比较；对象（含数组、函数）按引用比较：

```js
console.log(0.1 + 0.2);        // 0.30000000000000004
console.log(NaN === NaN);      // false
console.log({} === {});        // false
console.log([] == false);      // true —— 所以用 ===
```

## 类型检测

```js
function typeOf(v) {
  if (v === null) return 'null';            // typeof null 是历史遗留的 'object'
  if (Array.isArray(v)) return 'array';
  return typeof v;
}

console.log(typeOf([]), typeOf(null), typeOf(() => {})); // array null function
```

## 显式转换

```js
Number('42');        // 42
Number('');          // 0
Number('4px');       // NaN
parseInt('4px', 10); // 4
String(123);         // '123'
Boolean('0');        // true —— 非空字符串都为真

// 只有这些值是 falsy：false, 0, -0, 0n, '', null, undefined, NaN
```

## 深拷贝与浅拷贝

```js
const nested = { user: { name: 'Ada' } };
const shallow = { ...nested };        // 只复制第一层
shallow.user.name = 'Bob';
console.log(nested.user.name);        // Bob

// 现代环境可用 structuredClone 做深拷贝
const deep = structuredClone(nested);
deep.user.name = 'Cara';
console.log(nested.user.name);        // Bob
```

> `JSON.parse(JSON.stringify(x))` 也能深拷贝，但会丢失 `undefined`、函数、`Date` 对象类型，优先用 `structuredClone`。
