---
title: 函数
description: 函数声明、箭头函数、默认参数、闭包与 this 的绑定规则。
language: javascript
section: 核心概念
order: 5
updated: 2026-10-18
minutes: 9
tags: [核心概念, 函数, 闭包]
notice: 闭包与 this 是面试高频点，建议把示例改成自己的场景再跑一遍。
---

函数是 JavaScript 的核心抽象单位。理解闭包与 `this`，几乎就理解了 JS 的一半。

## 声明方式

```js
// 函数声明：会提升，可在定义前调用
function add(a, b) {
  return a + b;
}

// 函数表达式：不会被提升
const sub = function (a, b) {
  return a - b;
};

// 箭头函数：没有自己的 this 和 arguments
const mul = (a, b) => a * b;

// 默认参数与剩余参数
const greet = (name = '陌生人', ...titles) =>
  `${titles.join(' ')}${name}`;

console.log(add(1, 2), greet('李雷', 'Dr.')); // 3 Dr.李雷
```

## 闭包

闭包是函数与其词法作用域的组合。外层函数返回后，内部函数依然能访问外层变量：

```js
function createCounter(start = 0) {
  let count = start; // 被闭包捕获，外部无法直接访问
  return {
    inc: () => ++count,
    get value() {
      return count;
    },
  };
}

const c = createCounter(10);
c.inc();
c.inc();
console.log(c.value); // 12
```

闭包常用来实现私有状态、柯里化与防抖节流。

## this 的绑定

```js
const timer = {
  seconds: 0,
  start() {
    // 箭头函数沿用外层 this，因此指向 timer
    setInterval(() => {
      this.seconds++;
    }, 1000);
  },
};

function whoAmI() {
  console.log(this?.tag);
}

whoAmI();              // undefined（严格模式下）
whoAmI.call({ tag: 'a' }); // a
const bound = whoAmI.bind({ tag: 'b' });
bound();               // b
```

> 判断 this 的简单方法：看函数**调用时**点号左边是谁；箭头函数则看定义位置的外层。

## 高阶函数

```js
// 柯里化
const add3 = (a) => (b) => (c) => a + b + c;
console.log(add3(1)(2)(3)); // 6

// 防抖：最后一次调用后 delay 毫秒才执行
function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

const onSearch = debounce((q) => console.log('搜索', q), 300);
onSearch('js');
onSearch('javascript'); // 只有这次会真正触发
```

## 参数传递

原始类型按值传递，对象按“引用的值”传递：

```js
function mutate(obj, num) {
  obj.n = 1;   // 影响外部对象
  num = 100;   // 只改本地副本
}

const data = { n: 0 };
let x = 1;
mutate(data, x);
console.log(data.n, x); // 1 1
```
