---
title: 异步编程
description: 事件循环、回调队列、Promise 与 async/await 的完整脉络。
language: javascript
section: 进阶
order: 7
updated: 2026-10-18
minutes: 10
tags: [进阶, 异步, Promise]
notice: 事件循环的输出顺序是本篇重点，建议把代码复制到控制台按顺序观察。
---

JavaScript 在单线程上运行，异步能力来自宿主环境（浏览器 / Node）提供的事件循环。理解它，才能写出不阻塞、不串行化的代码。

## 事件循环模型

调用栈为空时，事件循环会：

1. 执行一个宏任务（`setTimeout`、I/O 回调、UI 渲染）。
2. 清空**所有**微任务（Promise 回调、`queueMicrotask`）。
3. 再取下一个宏任务。

```js
console.log('1 同步');

setTimeout(() => console.log('4 宏任务'), 0);

Promise.resolve().then(() => console.log('3 微任务'));

console.log('2 同步');
// 输出：1 -> 2 -> 3 -> 4
```

> 微任务会在当前宏任务结束后立即全部执行，因此死循环的微任务会彻底卡死页面。

## 回调到 Promise

```js
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

delay(100).then(() => console.log('100ms 后'));

// Promise 状态：pending -> fulfilled / rejected，且不可逆
const p = Promise.reject(new Error('失败'));
p.catch((err) => console.log('捕获到', err.message));
```

## async / await

`await` 让异步代码看起来像同步，但不要忘记错误处理：

```js
async function fetchUser(id) {
  const res = await fetch(`https://api.example.com/users/${id}`);
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }
  return res.json();
}

async function main() {
  try {
    const user = await fetchUser(1);
    console.log(user.name);
  } catch (err) {
    console.error('请求失败:', err.message);
  }
}
```

## 并发而不是串行

```js
// 反例：串行执行，总耗时是两者之和
async function slow() {
  const a = await fetchUser(1);
  const b = await fetchUser(2);
  return [a, b];
}

// 正例：互不依赖的任务并发执行
async function fast() {
  const [a, b] = await Promise.all([fetchUser(1), fetchUser(2)]);
  return [a, b];
}
```

| API | 行为 |
|---|---|
| `Promise.all` | 全部成功才成功，任一失败即失败 |
| `Promise.allSettled` | 等到全部结束，返回每个结果状态 |
| `Promise.race` | 第一个结束的（成功或失败）决定结果 |
| `Promise.any` | 第一个成功的决定结果，全部失败才失败 |

## 带超时与重试

```js
function withTimeout(promise, ms) {
  const timeout = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('超时')), ms),
  );
  return Promise.race([promise, timeout]);
}

async function retry(fn, times = 3) {
  for (let i = 1; i <= times; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i === times) throw err;
      await delay(200 * i); // 指数退避
    }
  }
}
```

## 常见误区

- `forEach` 中 `await` 不会等待：它会立刻启动所有回调，用 `for...of` 或 `Promise.all`。
- 忘记 `return` Promise 导致调用方拿不到结果。
- 在顶层之外大量使用 `.then` 链，可读性远不如 `async/await`。
