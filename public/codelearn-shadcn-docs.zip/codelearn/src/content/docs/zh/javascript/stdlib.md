---
title: 标准库
description: 内置对象速查：Array、Object、String、Map、Set、JSON、Intl。
language: javascript
section: 进阶
order: 8
updated: 2026-10-18
minutes: 8
tags: [进阶, 标准库]
---

JavaScript 没有传统意义的“标准库”，而是内置了一组全局对象。下面按常用程度整理最该掌握的部分。

## Array

```js
const nums = [1, 2, 3, 4, 5];

nums.map((n) => n * 2);              // [2, 4, 6, 8, 10]
nums.filter((n) => n % 2 === 1);     // [1, 3, 5]
nums.find((n) => n > 3);             // 4
nums.some((n) => n > 4);             // true
nums.every((n) => n > 0);            // true
nums.flatMap((n) => [n, n]);         // 摊平一层
nums.reduce((sum, n) => sum + n, 0); // 15
Array.from({ length: 3 }, (_, i) => i); // [0, 1, 2]
Array.from('abc');                   // ['a', 'b', 'c']
```

> ES2023 新增 `toSorted`、`toReversed`、`toSpliced`、`with`，它们返回新数组，不修改原数组。

## Object

```js
const scores = { alice: 90, bob: 75 };

Object.entries(scores).sort(([, a], [, b]) => b - a); // 按分数降序
Object.assign({}, scores, { carol: 88 });
Object.fromEntries([['x', 1], ['y', 2]]); // { x: 1, y: 2 }
Object.create(null); // 无原型的干净字典
```

## String

```js
const s = '  Hello World  ';

s.trim();                  // 'Hello World'
s.startsWith('  He');      // true
s.replaceAll('l', 'L');    // '  HeLLo WorLd  '
s.padStart(20, '*');       // 左填充
s.at(-1);                  // ' ' 支持负索引
'2026-10-18'.split('-');   // ['2026', '10', '18']
```

## Map 与 Set

```js
const m = new Map();
m.set('key', 1).set('other', 2);
m.get('key');       // 1
m.size;             // 2
m.has('other');     // true

const set = new Set([1, 2, 2, 3]);
[...set];           // [1, 2, 3] 去重
set.union?.(new Set([3, 4])); // ES2025 set 运算，较新环境才支持
```

`Map` 的键可以是任意类型，且保留插入顺序；对象作为字典时键只能是字符串/符号。

## JSON

```js
const text = JSON.stringify({ id: 1, tags: ['a'] }, null, 2);
const data = JSON.parse(text, (key, value) =>
  key === 'id' ? value * 10 : value,
);
console.log(data.id); // 10，reviver 可以自定义解析逻辑
```

## 其他常用

| 对象 | 用途 |
|---|---|
| `Math` | `Math.round`、`Math.max`、`Math.random` |
| `Date` | 时间戳与格式化，复杂处理建议用库 |
| `Intl` | 国际化数字、日期、排序 |
| `RegExp` | 正则匹配 |
| `URL` `URLSearchParams` | 解析与构造 URL |
| `structuredClone` | 深拷贝 |

```js
new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' })
  .format(1234.5); // ¥1,234.50

const url = new URL('https://example.com/path?q=js');
url.searchParams.set('page', '2');
console.log(url.toString());
```
