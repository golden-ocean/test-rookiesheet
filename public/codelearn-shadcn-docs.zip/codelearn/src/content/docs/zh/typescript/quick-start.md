---
title: 快速开始
description: 用类型标注、接口与联合类型写出第一个可靠的 TS 模块。
language: typescript
section: 入门
order: 2
updated: 2026-10-18
minutes: 8
tags: [入门, 基础语法]
---

本文用一个订单计算的小例子，把类型标注、接口、联合类型与类型收窄串起来。

## 基础类型标注

```ts
// 变量注解
const title: string = 'TypeScript 入门';
let count: number = 0;
let enabled: boolean = true;

// 数组与元组
const tags: string[] = ['ts', 'types'];
const pair: [string, number] = ['age', 30];

// 函数签名
function formatPrice(amount: number, currency = 'CNY'): string {
  return `${amount.toFixed(2)} ${currency}`;
}

// 不写返回类型时，编译器会自动推断
const double = (n: number) => n * 2;
```

> 能推断出来的类型就不要手写。显式标注更应该用在函数参数、公共 API 与复杂返回值上。

## 接口与联合类型

```ts
interface Product {
  id: string;
  name: string;
  price: number;
}

type OrderStatus = 'pending' | 'paid' | 'shipped' | 'cancelled';

interface Order {
  id: string;
  status: OrderStatus;
  items: Array<{ product: Product; qty: number }>;
}
```

联合字面量类型让非法状态在编译期就不可能存在。

## 类型收窄

```ts
function total(order: Order): number {
  // filter 返回新数组，reduce 累加金额
  return order.items.reduce(
    (sum, { product, qty }) => sum + product.price * qty,
    0,
  );
}

function statusLabel(status: OrderStatus): string {
  switch (status) {
    case 'pending':
      return '待支付';
    case 'paid':
      return '已支付';
    case 'shipped':
      return '已发货';
    case 'cancelled':
      return '已取消';
  }
}

const order: Order = {
  id: 'o1',
  status: 'paid',
  items: [{ product: { id: 'p1', name: '键盘', price: 199 }, qty: 2 }],
};

console.log(total(order), statusLabel(order.status)); // 398 已支付
```

## unknown 与 any

```ts
function parse(input: unknown) {
  // unknown 必须先收窄才能使用
  if (typeof input === 'string') {
    return input.trim();
  }
  throw new Error('需要字符串');
}

// any 会关闭类型检查，尽量避免
let loose: any = 'abc';
loose.not.exist(); // 编译通过，运行时崩溃
```

## 小结

| 概念 | 写法 |
|---|---|
| 接口 | `interface User { id: string }` |
| 联合 | `'a' \| 'b'` |
| 可选属性 | `name?: string` |
| 只读 | `readonly id: string` |
| 安全外部输入 | `unknown` + 类型收窄 |
