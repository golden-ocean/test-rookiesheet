---
title: 变量与类型
description: 类型推断、字面量类型、类型别名与严格模式的取舍。
language: typescript
section: 核心概念
order: 3
updated: 2026-10-18
minutes: 9
tags: [核心概念, 类型]
notice: 本篇假设 tsconfig 已开启 strict，未开启时部分报错不会出现。
---

TypeScript 的类型系统是结构化的：只要形状匹配就能赋值，不需要显式实现接口。

## 类型推断

```ts
let a = 1;            // number
const b = 1;          // 1（字面量类型）
const c = [1, 2];     // number[]
const obj = { x: 1 }; // { x: number }
let mixed = 'a';      // string，之后可赋任意字符串
```

`const` 会保留字面量类型，这对联合类型很关键：

```ts
// as const 让对象所有属性变成只读字面量
const ROUTES = {
  home: '/',
  about: '/about',
} as const;

type RouteKey = keyof typeof ROUTES; // 'home' | 'about'
```

## type 与 interface

```ts
// interface 可声明合并，适合描述对象
interface User {
  id: string;
  name: string;
}

// type 能表达联合、条件、映射等复杂类型
type ID = string | number;
type Point = { x: number; y: number };

// 两者都能扩展
interface Admin extends User {
  permissions: string[];
}

type Named = User & { nickname?: string };
```

| 对比 | interface | type |
|---|---|---|
| 扩展 | `extends` | `&` 交叉 |
| 声明合并 | 支持 | 不支持 |
| 联合/条件类型 | 不支持 | 支持 |

## 联合与交叉

```ts
type Result<T> =
  | { ok: true; value: T }
  | { ok: false; error: string };

function unwrap<T>(r: Result<T>): T {
  if (r.ok) return r.value; // 收窄为成功分支
  throw new Error(r.error);
}

type A = { a: string };
type B = { b: number };
type AB = A & B; // 必须同时具备 a 和 b
```

## 类型断言与守卫

```ts
function isUser(v: unknown): v is User {
  return (
    typeof v === 'object' &&
    v !== null &&
    'id' in v &&
    'name' in v
  );
}

const input: unknown = JSON.parse('{"id":"1","name":"Ada"}');
if (isUser(input)) {
  console.log(input.name.toUpperCase()); // 类型安全
}

// 断言比守卫危险：编译期信任你，运行时不检查
const len = (input as string).length;
```

## 严格模式的关键选项

```json
{
  "strict": true,
  "noUncheckedIndexedAccess": true,
  "exactOptionalPropertyTypes": true
}
```

- `strictNullChecks`：`null` 与 `undefined` 不再默认可赋值。
- `noUncheckedIndexedAccess`：数组下标访问返回值可能为 `undefined`。
- `noImplicitAny`：禁止隐式 `any`。

> 类型越精确，重构越安全。宁可多写几行类型守卫，也不要随便 `as any` 绕过检查。
