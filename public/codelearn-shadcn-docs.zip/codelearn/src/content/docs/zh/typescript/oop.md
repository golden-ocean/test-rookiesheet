---
title: 面向对象
description: 类、访问修饰符、抽象类、implements 与结构化类型系统。
language: typescript
section: 核心概念
order: 6
updated: 2026-10-18
minutes: 8
tags: [核心概念, class, 接口]
notice: 本篇不会涉及装饰器，那属于框架层的用法。
---

TypeScript 的类在 JavaScript 类的基础上增加了访问修饰符、参数属性和抽象类，类型检查在编译期完成。

## 类与成员修饰符

```ts
class Account {
  // 参数属性：在构造函数参数前加修饰符会自动生成字段
  constructor(
    public readonly id: string,
    private balance: number = 0,
    protected currency: string = 'CNY',
  ) {}

  deposit(amount: number): void {
    if (amount <= 0) throw new RangeError('金额必须为正');
    this.balance += amount;
  }

  get amount(): number {
    return this.balance;
  }

  static zero(id: string): Account {
    return new Account(id);
  }
}

const acc = Account.zero('A1');
acc.deposit(100);
console.log(acc.amount, acc.id); // 100 A1
```

| 修饰符 | 可见范围 |
|---|---|
| `public` | 默认，任何位置 |
| `protected` | 自身与子类 |
| `private` | 仅自身 |
| `readonly` | 初始化后不可改 |
| `#field` | 运行时真正私有 |

## 继承与抽象类

```ts
abstract class Shape {
  abstract area(): number;

  describe(): string {
    return `面积 ${this.area().toFixed(2)}`;
  }
}

class Circle extends Shape {
  constructor(private radius: number) {
    super();
  }

  area(): number {
    return Math.PI * this.radius ** 2;
  }
}

new Circle(2).describe(); // 面积 12.57
// new Shape(); // 编译错误：抽象类不能实例化
```

## implements 与结构化类型

TypeScript 是结构类型系统：只要形状满足，不需要显式声明继承关系。

```ts
interface Serializable {
  toJSON(): unknown;
}

class Point {
  constructor(
    public x: number,
    public y: number,
  ) {}

  toJSON() {
    return { x: this.x, y: this.y };
  }
}

// Point 声明了 implements，缺失方法会报错
class TypedPoint implements Serializable {
  constructor(private x: number) {}

  toJSON() {
    return { x: this.x };
  }
}

// 普通对象也能满足接口
const obj: Serializable = { toJSON: () => ({}) };
```

> `implements` 只是编译期检查，不会增加任何运行时行为。需要复用的实现请用抽象类或组合。

## 何时不用类

- 纯数据用 `interface` + 普通对象，便于序列化。
- 只有函数时，导出函数而非 `export class Utils`。
- 状态与行为紧密相关、需要封装不变量时，类才合适。
