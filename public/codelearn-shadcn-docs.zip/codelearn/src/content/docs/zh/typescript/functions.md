---
title: 函数
description: 函数签名、重载、泛型与高阶函数的类型写法。
language: typescript
section: 核心概念
order: 5
updated: 2026-10-18
minutes: 9
tags: [核心概念, 函数, 泛型]
---

给函数写类型是 TypeScript 最日常的工作。好的签名能让调用方无需查看实现就知道怎么用。

## 签名与可选参数

```ts
// 参数类型、可选参数、返回类型
function createUser(
  name: string,
  age?: number,
  role: 'admin' | 'member' = 'member',
): { name: string; age: number | null; role: string } {
  return { name, age: age ?? null, role };
}

// 函数类型别名
type Comparator<T> = (a: T, b: T) => number;

const byLength: Comparator<string> = (a, b) => a.length - b.length;
```

## 泛型

泛型让函数在保持类型安全的同时复用逻辑：

```ts
function first<T>(arr: readonly T[]): T | undefined {
  return arr[0];
}

// 约束：T 必须拥有 length 属性
function longest<T extends { length: number }>(a: T, b: T): T {
  return a.length >= b.length ? a : b;
}

console.log(longest('abc', 'de'));  // abc
console.log(longest([1, 2], [3]));  // [1, 2]

// 键名约束：K 必须是 T 的键
function get<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

const user = { id: '1', age: 30 };
const age = get(user, 'age'); // number
```

> 泛型参数有名字有含义时用完整单词（`TValue`），仅在极短的辅助函数里用单字母。

## 函数重载

当同一个函数根据入参返回不同结果时，用重载签名描述：

```ts
function parseInput(input: string): string[];
function parseInput(input: number): number;
function parseInput(input: string | number): string[] | number {
  return typeof input === 'string' ? input.split(',') : input;
}

const a = parseInput('x,y'); // string[]
const b = parseInput(1);     // number
```

现代写法更推荐“条件返回类型 + 对象映射”的组合，重载只用于外部 API 兼容。

## 高阶函数

```ts
function debounce<A extends unknown[]>(
  fn: (...args: A) => void,
  delay: number,
): (...args: A) => void {
  let timer: ReturnType<typeof setTimeout> | undefined;
  return (...args: A) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

const search = debounce((q: string) => console.log(q), 300);
search('typescript');
```

## 参数与返回值工具

| 写法 | 含义 |
|---|---|
| `(...args: string[])` | 不定长参数 |
| `args: readonly T[]` | 只读数组 |
| `fn?: () => void` | 可选回调 |
| `never` | 永不正常返回 |
| `Promise<void>` | 异步无返回值 |

```ts
type Handler = (event: { type: string }) => void;

function on(type: string, handler: Handler): void {
  handler({ type });
}

on('click', (e) => console.log(e.type));
```
