---
title: 流程控制
description: 类型收窄机制、可辨识联合与 switch 的穷尽性检查。
language: typescript
section: 核心概念
order: 4
updated: 2026-10-18
minutes: 8
tags: [核心概念, 类型收窄]
---

TypeScript 的流程控制本身与 JavaScript 一致，差别在于编译器会跟踪每个分支里的类型。掌握收窄，写出的代码既安全又少断言。

## 常见收窄手段

```ts
function describe(value: string | number | null): string {
  if (value === null) {
    return '空值';             // 此处 value: null
  }
  if (typeof value === 'number') {
    return `数字 ${value.toFixed(2)}`; // value: number
  }
  return `字符串 ${value.trim()}`;     // value: string
}
```

| 收窄方式 | 示例 |
|---|---|
| `typeof` | `typeof x === 'string'` |
| 真值判断 | `if (x)` 排除 `null`/`undefined` |
| 等值判断 | `if (status === 'paid')` |
| `in` 运算符 | `'id' in obj` |
| `instanceof` | `err instanceof Error` |
| 自定义守卫 | `function isX(v): v is X` |

## 可辨识联合

给联合类型的每个成员加一个字面量字段，switch 就能自动收窄：

```ts
type Shape =
  | { kind: 'circle'; radius: number }
  | { kind: 'rect'; width: number; height: number }
  | { kind: 'triangle'; base: number; height: number };

function area(shape: Shape): number {
  switch (shape.kind) {
    case 'circle':
      return Math.PI * shape.radius ** 2;
    case 'rect':
      return shape.width * shape.height;
    case 'triangle':
      return (shape.base * shape.height) / 2;
    default:
      // 永远不会走到这里，但能让新增成员时报错
      return assertNever(shape);
  }
}

function assertNever(x: never): never {
  throw new Error(`未处理的分支: ${JSON.stringify(x)}`);
}
```

> 有了 `assertNever`，将来给 `Shape` 增加成员而忘记处理时，编译器会立即报错。

## 循环中的类型

```ts
const entries: Array<[string, number]> = [['a', 1], ['b', 2]];

for (const [key, value] of entries) {
  console.log(key, value.toFixed(0));
}

// for...in 的 key 是 string，遍历数组容易出问题
const nums = [10, 20];
for (const i of nums.keys()) {
  console.log(nums[i]); // 带 noUncheckedIndexedAccess 时是 number | undefined
}
```

## 迭代与提前返回

```ts
function firstPositive(nums: readonly number[]): number | undefined {
  for (const n of nums) {
    if (n > 0) return n; // 提前返回让类型更清晰
  }
  return undefined;
}

console.log(firstPositive([-1, -2, 3])); // 3
```

用 `readonly number[]` 声明参数，可以防止函数意外修改调用方的数组。
