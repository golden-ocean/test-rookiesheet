---
title: 最佳实践
description: 严格配置、类型即文档、避免 any 与模块组织的经验规则。
language: typescript
section: 进阶
order: 9
updated: 2026-10-18
minutes: 9
tags: [进阶, 工程化]
notice: 这些约定配合 ESLint 的 typescript-eslint 规则可以自动执行。
---

TypeScript 用得对不对，往往不在于会不会写类型，而在于是否让类型承担起“拦截错误”的职责。

## 配置先行

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noFallthroughCasesInSwitch": true,
    "verbatimModuleSyntax": true
  }
}
```

| 选项 | 解决的问题 |
|---|---|
| `strict` | 开启全套严格检查 |
| `noUncheckedIndexedAccess` | 下标访问可能越界 |
| `noImplicitOverride` | 覆盖父类方法必须写 `override` |
| `verbatimModuleSyntax` | 类型导入必须在运行时擦除 |

## 远离 any

```ts
// 反例：any 会污染整条调用链
function parseBad(json: string): any {
  return JSON.parse(json);
}

// 正例：unknown + 校验
function parseConfig(json: string): { port: number } {
  const raw: unknown = JSON.parse(json);
  if (
    typeof raw !== 'object' ||
    raw === null ||
    typeof (raw as { port?: unknown }).port !== 'number'
  ) {
    throw new Error('配置格式错误');
  }
  return raw as { port: number };
}

console.log(parseConfig('{"port":8080}').port);
```

`as` 断言也一样：只在你能证明它安全时使用，并在断言前做运行时检查。

## 类型要表达领域

```ts
// 反例：所有东西都是 string，容易传错
function transferBad(from: string, to: string, amount: number) {}

// 正例：用 branded type 区分语义
type AccountId = string & { readonly __brand: 'AccountId' };
type Money = number & { readonly __brand: 'Money' };

function asAccountId(v: string): AccountId {
  if (!/^A\d{6}$/.test(v)) throw new Error('非法账号');
  return v as AccountId;
}

function transfer(from: AccountId, to: AccountId, amount: Money) {
  console.log(from, '->', to, amount);
}

transfer(asAccountId('A000001'), asAccountId('A000002'), 100 as Money);
```

## 模块与导出

- 用具名导出，避免默认导出带来的重命名混乱。
- 类型导入写 `import type { User } from './types'`，不会生成运行时引用。
- 根据业务边界拆分文件，而不是按 `types.ts` / `utils.ts` 大杂烩。

```ts
// types.ts
export type Status = 'idle' | 'loading' | 'success' | 'error';

// api.ts
import type { Status } from './types.js';

export function label(s: Status): string {
  return { idle: '就绪', loading: '加载中', success: '完成', error: '失败' }[s];
}
```

## 提交前的检查

1. `npx tsc --noEmit` 无错误。
2. `npx eslint .` 无警告。
3. 全仓搜索 `as any`、`@ts-ignore`，确认每一处都有注释说明原因。
