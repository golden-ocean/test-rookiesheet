---
title: 标准库
description: 全局类型、ES 内置 API 与 TypeScript 自带工具类型的速查。
language: typescript
section: 进阶
order: 8
updated: 2026-10-18
minutes: 9
tags: [进阶, 标准库, 工具类型]
---

TypeScript 的“标准库”由两部分组成：`lib` 中声明的 ES 与 DOM 内置 API，以及编译器内置的工具类型。

## lib 配置

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"]
  }
}
```

- 只写后端代码时去掉 `DOM`，可以避免误用浏览器 API。
- `@types/node` 提供 `process`、`Buffer`、`fs` 等 Node 类型。

## 内置工具类型

```ts
interface User {
  id: string;
  name: string;
  email?: string;
}

type PartialUser = Partial<User>;            // 全部可选
type RequiredUser = Required<User>;          // 全部必填
type ReadonlyUser = Readonly<User>;          // 全部只读
type PublicUser = Pick<User, 'id' | 'name'>; // 挑选字段
type Contact = Omit<User, 'id'>;             // 排除字段
type Dict = Record<string, number>;          // 键值映射
type Name = NonNullable<User['email']>;      // 去掉 null/undefined
```

| 工具类型 | 用途 |
|---|---|
| `ReturnType<F>` | 函数返回值类型 |
| `Parameters<F>` | 函数参数元组 |
| `Awaited<T>` | 展开 Promise 内部类型 |
| `InstanceType<C>` | 类的实例类型 |
| `Exclude<T, U>` | 联合中排除 |
| `Extract<T, U>` | 联合中提取 |

## 常用数组与对象 API

```ts
const nums = [3, 1, 2];

nums.toSorted((a, b) => a - b); // ES2023，返回新数组
nums.includes(2);
nums.find((n) => n > 1);        // number | undefined

const scores = new Map<string, number>([['alice', 90]]);
scores.set('bob', 75);
scores.forEach((value, key) => console.log(key, value));

const uniq = [...new Set([1, 1, 2])]; // number[]
```

## 字符串与格式化

```ts
const now = new Date();
const fmt = new Intl.DateTimeFormat('zh-CN', {
  dateStyle: 'medium',
  timeStyle: 'short',
});
console.log(fmt.format(now));

const price = new Intl.NumberFormat('zh-CN', {
  style: 'currency',
  currency: 'CNY',
}).format(1234.5);

const rtf = new Intl.RelativeTimeFormat('zh-CN', { numeric: 'auto' });
console.log(rtf.format(-2, 'day')); // 前天
```

## Node 常用模块

```ts
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

async function readJson<T>(name: string): Promise<T> {
  const text = await readFile(path.join(here, name), 'utf8');
  return JSON.parse(text) as T; // 外部数据仍建议做运行时校验
}

readJson<{ version: string }>('package.json').then((p) => {
  console.log(p.version);
});
```

> 引用 Node 内置模块时加 `node:` 前缀，能避免与第三方同名包冲突，也更明确。
