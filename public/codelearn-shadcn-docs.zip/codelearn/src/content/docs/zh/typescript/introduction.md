---
title: 简介与安装
description: 理解 TypeScript 与 JavaScript 的关系，搭好第一个类型化项目。
language: typescript
section: 入门
order: 1
updated: 2026-10-18
minutes: 7
tags: [入门, 安装, 环境]
notice: 示例使用 TypeScript 5.4 与 strict 模式，tsc 版本过低时部分语法不可用。
---

TypeScript 是 JavaScript 的超集：所有合法的 JS 都是合法的 TS，在此之上增加了静态类型系统。类型只在编译期存在，运行时会完全擦除。

## 为什么用 TypeScript

| 能力 | 带来的收益 |
|---|---|
| 静态类型检查 | 在编辑器里提前发现拼写错误、类型不匹配 |
| 类型推断 | 大多数情况不用手写类型 |
| 自动补全与重构 | IDE 能精确知道对象结构 |
| 接口即文档 | 类型定义本身就是可执行的文档 |

> TypeScript 不能替代测试。它能保证“形状正确”，但不能保证“逻辑正确”。

## 安装与初始化

```bash
mkdir ts-demo && cd ts-demo
npm init -y
npm install -D typescript tsx @types/node
npx tsc --init
```

生成的 `tsconfig.json` 建议开启严格模式：

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "outDir": "dist"
  },
  "include": ["src"]
}
```

## 第一个程序

```ts
// src/hello.ts
interface Greeting {
  name: string;
  times?: number; // 可选属性
}

function greet({ name, times = 1 }: Greeting): string {
  return `Hello, ${name}!`.repeat(times);
}

console.log(greet({ name: 'TypeScript', times: 2 }));
// Hello, TypeScript!Hello, TypeScript!
```

运行与编译：

```bash
npx tsx src/hello.ts      # 开发时直接运行
npx tsc                   # 编译到 dist/
```

## 类型即契约

给函数参数标注类型，就等于写下了调用契约。调用方传错时，错误在编辑器里就会暴露：

```ts
greet({ name: 'Ada' });   // OK
greet({ name: 42 });      // 编译错误：number 不能赋给 string
greet({});                // 编译错误：缺少 name
```

下一步建议阅读快速开始，把类型标注、推断与常见类型一次过一遍。
