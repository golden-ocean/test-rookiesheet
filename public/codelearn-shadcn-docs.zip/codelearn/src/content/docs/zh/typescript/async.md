---
title: 异步编程
description: Promise 的类型、async/await 与错误处理的类型细节。
language: typescript
section: 进阶
order: 7
updated: 2026-10-18
minutes: 9
tags: [进阶, 异步, Promise]
notice: 本篇聚焦类型层面，事件循环机制请先阅读 JavaScript 的异步编程一篇。
---

TypeScript 不会改变 JavaScript 的异步模型，但可以精确描述异步函数的返回值和错误分支，避免漏掉 `await`。

## Promise 类型

```ts
// Promise<T> 表示最终会得到 T 的异步结果
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function loadConfig(): Promise<Record<string, string>> {
  await delay(100);
  return { env: 'production' };
}

// 工具类型提取 Promise 内部类型
type ResultOf<T> = T extends Promise<infer U> ? U : T;
type Config = ResultOf<ReturnType<typeof loadConfig>>; // Record<string, string>
```

## async / await 与类型

```ts
interface User {
  id: number;
  name: string;
}

async function fetchUser(id: number): Promise<User> {
  const res = await fetch(`https://api.example.com/users/${id}`);

  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  // fetch 的 json() 返回 Promise<any>，必须自行校验
  const data: unknown = await res.json();
  if (!isUser(data)) throw new Error('响应格式不正确');

  return data;
}

function isUser(v: unknown): v is User {
  const u = v as User;
  return typeof u?.id === 'number' && typeof u?.name === 'string';
}
```

> `unknown` 加类型守卫是处理外部数据（API、`JSON.parse`、`localStorage`）的标准姿势。

## 并发与结果联合

```ts
type Settled<T> =
  | { status: 'fulfilled'; value: T }
  | { status: 'rejected'; reason: unknown };

async function loadAll(ids: number[]): Promise<Settled<User>[]> {
  const results = await Promise.allSettled(ids.map(fetchUser));

  return results.map((r) =>
    r.status === 'fulfilled'
      ? { status: 'fulfilled', value: r.value }
      : { status: 'rejected', reason: r.reason },
  );
}

async function main(): Promise<void> {
  const users = await loadAll([1, 2, 3]);
  for (const u of users) {
    if (u.status === 'fulfilled') {
      console.log(u.value.name); // 收窄后可直接访问
    }
  }
}
```

## 并发限制

```ts
async function pool<T>(
  tasks: Array<() => Promise<T>>,
  limit = 5,
): Promise<T[]> {
  const results: T[] = [];
  let cursor = 0;

  async function run(): Promise<void> {
    while (cursor < tasks.length) {
      const index = cursor++;
      results[index] = await tasks[index]();
    }
  }

  await Promise.all(Array.from({ length: limit }, () => run()));
  return results;
}
```

## 容易踩的坑

- **忘记 return**：`async` 函数里 `return promise` 与 `await promise` 结果相似，但在 `try/catch` 中差别很大。
- **`any` 化 JSON**：`res.json()` 返回 `any`，会静默关闭整条链的类型检查。
- **忽略 rejected**：`void somethingAsync()` 可能产生未处理的 rejection，需显式 `catch`。
