---
title: 标准库
description: 集合、字符串、I/O、迭代器与常用 trait 速查。
language: rust
section: 进阶
order: 8
updated: 2026-10-18
minutes: 9
tags: [进阶, 标准库, 集合]
---

## 模块地图

Rust 标准库按模块组织，常用模块如下：

| 模块 | 常用条目 | 用途 |
|---|---|---|
| `std::collections` | `Vec`、`HashMap`、`BTreeMap`、`HashSet` | 动态集合 |
| `std::string` | `String`、`str` | UTF-8 字符串 |
| `std::fs` / `std::io` | `File`、`BufReader`、`Read`/`Write` | 文件与 I/O |
| `std::path` | `Path`、`PathBuf` | 跨平台路径 |
| `std::thread` / `std::sync` | `spawn`、`Mutex`、`Arc`、`mpsc` | 线程与同步 |
| `std::time` | `Duration`、`Instant` | 时间测量 |

## 集合

```rust
use std::collections::{HashMap, HashSet};

fn main() {
    let mut scores: HashMap<String, u32> = HashMap::new();
    scores.insert("小明".into(), 90);
    scores.entry("小红".into()).or_insert(80); // 不存在才插入
    for (name, score) in &scores {
        println!("{name}: {score}");
    }

    let tags: HashSet<&str> = ["a", "b", "a"].into_iter().collect();
    println!("去重后 {} 个", tags.len());
}
```

`Vec` 的常见方法包括 `push`、`pop`、`iter`、`retain`、`sort_by_key`；`HashMap` 的 `entry` API 能避免两次查找，是统计类代码的标准写法。

## 字符串处理

Rust 的 `String` 是 UTF-8 字节序列，因此**不能按索引取字符**：

```rust
fn main() {
    let s = String::from("Hello, 世界");
    println!("字节数 {}", s.len());           // 12
    println!("字符数 {}", s.chars().count());  // 9

    let upper = s.to_uppercase();
    let parts: Vec<&str> = upper.split(", ").collect();
    println!("{parts:?}");
    println!("{}", s.contains("世界"));
}
```

需要随机访问字符时，用 `.chars().nth(i)` 或先收集成 `Vec<char>`；需要处理字节级数据时用 `&[u8]`。

## 迭代器

迭代器是 Rust 风格的"for 循环替代品"，惰性求值、可链式组合，且与手写循环性能相当：

```rust
fn main() {
    let nums = vec![1, 2, 3, 4, 5, 6];

    let sum_of_squares: i32 = nums
        .iter()
        .filter(|n| *n % 2 == 0)
        .map(|n| n * n)
        .sum();
    println!("偶数平方和 {sum_of_squares}");

    let grouped: Vec<_> = nums.chunks(2).collect();
    println!("{:?}", grouped);
}
```

常用适配器：`map`、`filter`、`fold`、`take`、`skip`、`zip`、`enumerate`、`flat_map`；消耗它们的终结器有 `collect`、`sum`、`count`、`any`、`all`。

## 文件与路径

```rust
use std::fs;
use std::io::{self, BufRead};
use std::path::Path;

fn read_lines(path: &Path) -> io::Result<Vec<String>> {
    let file = fs::File::open(path)?;
    let reader = io::BufReader::new(file);
    reader.lines().collect() // 收集为 Result<Vec<String>, io::Error>
}

fn main() -> io::Result<()> {
    let lines = read_lines(Path::new("Cargo.toml"))?;
    println!("{} 行", lines.len());
    Ok(())
}
```

> 处理路径一律用 `Path` / `PathBuf`，不要自己拼 `/`，否则在 Windows 上会出错。
