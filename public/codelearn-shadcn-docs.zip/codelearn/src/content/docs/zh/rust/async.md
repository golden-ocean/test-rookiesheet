---
title: 异步编程
description: async/await、Future 模型与 Tokio 运行时。
language: rust
section: 进阶
order: 7
updated: 2026-10-18
minutes: 11
tags: [进阶, 异步, tokio]
---

## 异步模型概览

Rust 的 `async fn` 返回一个实现了 `Future` 的值，**但 Future 本身不会执行**——它需要被运行时轮询（poll）推进。因此 Rust 标准库只提供 `Future` trait，不绑定具体运行时，社区最常用的是 Tokio。

| 组件 | 提供方 | 作用 |
|---|---|---|
| `Future` / `async` / `await` | 标准库 | 语言层的异步语法与契约 |
| 运行时、定时器、I/O | Tokio | 真正驱动 Future 执行 |
| 组合工具 | `futures` / `tokio` | `join!`、`select!`、超时等 |

```toml
[dependencies]
tokio = { version = "1", features = ["full"] }
```

## 第一个异步程序

```rust
use tokio::time::{sleep, Duration};

async fn fetch_user(id: u32) -> String {
    sleep(Duration::from_millis(50)).await; // 模拟网络延迟
    format!("user-{id}")
}

#[tokio::main]
async fn main() {
    let name = fetch_user(7).await; // .await 只在 async 上下文中可用
    println!("{name}");
}
```

`#[tokio::main]` 只是把 `main` 包装成"创建运行时 + 阻塞等待 Future 完成"的便捷宏。

## 并发执行多个任务

顺序 `await` 会让任务一个接一个执行；需要同时进行时用 `join!`：

```rust
use tokio::time::{sleep, Duration, Instant};

async fn task(name: &str, ms: u64) -> String {
    sleep(Duration::from_millis(ms)).await;
    format!("{name} done after {ms}ms")
}

#[tokio::main]
async fn main() {
    let start = Instant::now();
    let (a, b) = tokio::join!(task("A", 100), task("B", 100));
    println!("{a} / {b} in {:?}", start.elapsed());
    // 输出接近 100ms，而不是 200ms
}
```

`try_join!` 用于全部返回 `Result` 的场景，任一失败即提前返回。

## 在任务间共享状态

多任务共享可变状态需要同步原语，最常用的是 `Arc<Mutex<T>>`：

```rust
use std::sync::Arc;
use tokio::sync::Mutex;

#[tokio::main]
async fn main() {
    let counter = Arc::new(Mutex::new(0));
    let mut handles = Vec::new();

    for _ in 0..10 {
        let c = Arc::clone(&counter);
        handles.push(tokio::spawn(async move {
            let mut guard = c.lock().await; // 异步锁，await 时不阻塞线程
            *guard += 1;
        }));
    }

    for h in handles {
        h.await.unwrap();
    }
    println!("{}", *counter.lock().await);
}
```

`tokio::spawn` 要求 Future 是 `Send + 'static`，因此通常要配合 `move` 与 `Arc`，不能用裸的 `&mut` 跨任务共享。

> `std::sync::Mutex` 在持锁期间不要跨 `.await`，否则容易阻塞运行时线程甚至死锁；涉及 await 的场景优先用 `tokio::sync::Mutex`。

## 超时与取消

```rust
use tokio::time::{timeout, Duration};

async fn slow() -> &'static str {
    tokio::time::sleep(Duration::from_secs(5)).await;
    "finished"
}

#[tokio::main]
async fn main() {
    match timeout(Duration::from_millis(100), slow()).await {
        Ok(v) => println!("{v}"),
        Err(_) => println!("超时，任务已被取消"),
    }
}
```

Rust 的取消是"丢弃 Future"：一旦不再 `await`，任务就在下一个挂起点停止，不需要显式的 cancel 调用，但要注意资源清理应放在 `Drop` 或 guard 中。
