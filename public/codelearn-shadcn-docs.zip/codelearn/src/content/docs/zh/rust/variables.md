---
title: 变量与类型
description: Rust 的类型系统、所有权、引用与 Option。
language: rust
section: 核心概念
order: 3
updated: 2026-10-18
minutes: 9
tags: [核心概念, 类型, 所有权]
---

## 基本类型

Rust 的类型在编译期完全确定，没有隐式数值转换。

| 类别 | 类型 | 说明 |
|---|---|---|
| 整数 | `i8`…`i128`、`u8`…`u128`、`isize`、`usize` | 默认 `i32`，索引使用 `usize` |
| 浮点 | `f32`、`f64` | 默认 `f64` |
| 布尔 | `bool` | 只有 `true` / `false` |
| 字符 | `char` | 4 字节 Unicode 标量值 |
| 字符串 | `&str`、`String` | 切片引用与可增长的堆字符串 |

```rust
fn main() {
    let n: i64 = 42;
    let ratio: f64 = n as f64 / 4.0; // 必须显式 as 转换
    let flag = true;
    let ch = '中';
    println!("{n} {ratio} {flag} {ch}");
}
```

## 绑定、可变性与遮蔽

`let` 创建的是绑定，`const` 与 `static` 用于常量。遮蔽（shadowing）会新建一个绑定，可以改变类型：

```rust
fn main() {
    let x = 5;
    let x = x * 2;      // 新的绑定，不是赋值
    let x = x.to_string(); // 类型从整数变成 String
    println!("{x}");

    const MAX: u32 = 1_000;
    println!("{MAX}");
}
```

注意 `const` 必须标注类型，且值在编译期可计算。

## 复合类型

元组与数组是固定长度的值类型：

```rust
fn main() {
    let pair: (i32, &str) = (1, "one");
    let (num, name) = pair; // 解构
    println!("{num} -> {name}");

    let arr = [10, 20, 30];
    let slice = &arr[1..]; // 切片借用了数组的一段
    println!("{:?}", slice);
}
```

需要动态长度时使用 `Vec<T>`，它是堆上的可增长数组。

## 所有权与借用

所有权是 Rust 最核心的规则：每个值有唯一的所有者，所有者离开作用域时值被释放。

```rust
fn main() {
    let s1 = String::from("hello");
    let s2 = s1; // 移动：s1 之后不可再用
    println!("{s2}");

    let s3 = s2.clone(); // 克隆：两份独立的堆数据
    borrow(&s3);         // 只借出不可变引用
    println!("{s2} {s3}");
}

fn borrow(s: &String) -> usize {
    s.len()
}
```

- `&T` 不可变借用可以同时存在多个
- `&mut T` 可变借用同一时刻只能有一个，且不能与不可变借用共存
- 规则由编译器静态检查，因此没有运行时锁开销

> 如果一个函数只需读取数据，参数写成 `&str` 比 `&String` 更通用，因为 `String` 与字面量都能自动解引用为 `&str`。

## Option 与显式的空值

Rust 没有 `null`，可能缺失的值用 `Option<T>` 表达：

```rust
fn find_first_even(nums: &[i32]) -> Option<i32> {
    nums.iter().copied().find(|n| n % 2 == 0)
}

fn main() {
    let v = vec![1, 3, 6, 8];
    if let Some(n) = find_first_even(&v) {
        println!("第一个偶数：{n}");
    } else {
        println!("没有偶数");
    }
    println!("{}", find_first_even(&v).unwrap_or(0));
}
```

`Option` 强制你在使用前处理 `None` 的情况，从而在类型层面消除空指针异常。
