---
title: 简介与安装
description: 认识 Rust 的设计目标、工具链与安装方式。
language: rust
section: 入门
order: 1
updated: 2026-10-18
minutes: 7
tags: [入门, 安装, 工具链]
notice: 安装完成后请运行 rustc --version 与 cargo --version 确认工具链可用。
---

## Rust 是什么

Rust 是一门系统级编程语言，强调**内存安全**、**零成本抽象**与**无数据竞争的并发**。它不依赖垃圾回收器，而是通过编译期的所有权与借用检查，把大量运行时错误提前到编译阶段。

Rust 的典型应用场景包括：

- 命令行工具与系统程序
- 网络服务与代理（如 Tokio 生态）
- WebAssembly
- 嵌入式与操作系统组件

> 当你第一次被借用检查器"拒绝"时不要气馁。编译器给出的错误信息是 Rust 最有价值的学习资源之一。

## 发行版与工具链

Rust 的版本按"每六周一个小版本"的方式发布，语言本身保持向后兼容。社区常用三套工具链：

| 工具链 | 定位 | 适用场景 |
|---|---|---|
| stable | 稳定版，默认 | 生产环境、日常开发 |
| beta | 下一版的候选 | 提前验证升级影响 |
| nightly | 每日构建 | 使用尚未稳定的特性 |

推荐使用 `rustup` 管理工具链，它同时负责安装 `rustc`、`cargo`、`clippy`、`rustfmt` 等组件。

## 安装步骤

在 Linux / macOS 上执行：

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

Windows 用户可下载 `rustup-init.exe` 运行，或使用 Winget。安装完成后重新打开终端，验证版本：

```bash
rustc --version
cargo --version
rustup show
```

`cargo` 是随工具链一起分发的构建与包管理工具，绝大多数项目只需要它，不必直接调用 `rustc`。

## 第一个程序

创建项目并运行：

```bash
cargo new hello_rust
cd hello_rust
cargo run
```

生成的 `src/main.rs` 内容如下：

```rust
fn main() {
    // println! 是宏而不是函数，末尾的感叹号不能省略
    let name = "Rust";
    println!("你好，{}!", name);
}
```

输出为 `你好，Rust!`。`cargo run` 会先编译再执行，`cargo build --release` 则生成开启优化后的可执行文件。

## 常用命令速查

- `cargo check`：只做类型检查，速度最快，适合开发中频繁执行
- `cargo fmt`：按官方风格格式化代码
- `cargo clippy`：静态检查，能发现不少常见笔误
- `cargo doc --open`：生成并打开文档

接下来可以进入《快速开始》，了解变量、函数与模块的基本写法。
