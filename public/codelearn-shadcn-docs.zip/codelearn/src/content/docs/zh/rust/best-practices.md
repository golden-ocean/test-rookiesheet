---
title: 最佳实践
description: 错误处理、API 设计、测试与工程化约定。
language: rust
section: 进阶
order: 9
updated: 2026-10-18
minutes: 10
tags: [进阶, 最佳实践, 工程化]
notice: 本文给出的是社区广泛认可的做法，不是强制规则，请结合团队规范取舍。
---

## 错误处理分层

Rust 的错误分为两类，决定了你该用 `Result` 还是 `panic!`：

| 错误类型 | 处理方式 | 例子 |
|---|---|---|
| 可预期、可恢复 | 返回 `Result<T, E>` | 文件不存在、解析失败、网络超时 |
| 程序缺陷 | `panic!` / `assert!` | 数组越界、违反不变量 |

```rust
use std::num::ParseIntError;

#[derive(Debug)]
pub enum ConfigError {
    Missing(&'static str),
    InvalidPort(ParseIntError),
}

// From 实现让 ? 自动转换错误类型
impl From<ParseIntError> for ConfigError {
    fn from(e: ParseIntError) -> Self {
        ConfigError::InvalidPort(e)
    }
}

pub fn parse_port(raw: &str) -> Result<u16, ConfigError> {
    let port: u16 = raw.trim().parse()?;
    Ok(port)
}

fn main() {
    println!("{:?}", parse_port("8080"));
    println!("{:?}", parse_port("abc"));
}
```

库应定义自己的错误枚举，应用层可以统一使用 `anyhow`，测试和脚本用 `expect` 给出清晰信息。

## API 设计约定

- 参数用 `&str` / `&[T]` 而不是 `&String` / `&Vec<T>`，对调用的要求最少
- 只读访问用 `&self`，修改状态用 `&mut self`，消耗所有权用 `self`
- 实现 `impl Into<String>` 之类的转换 trait 让调用者更顺手
- 公开类型实现 `Debug`；用于比较或作为集合键的类型实现 `PartialEq`、`Eq`、`Hash`
- 用新类型（newtype）包裹原始类型，避免"把用户 ID 当成订单 ID"这类错误

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct UserId(u64);

pub fn find_user(ids: &[UserId], target: UserId) -> Option<UserId> {
    ids.iter().copied().find(|id| *id == target)
}

fn main() {
    let ids = [UserId(1), UserId(2)];
    println!("{:?}", find_user(&ids, UserId(2)));
}
```

## 测试

单元测试与代码放在同一文件，集成测试放在 `tests/` 目录：

```rust
#[cfg(test)]
mod tests {
    fn add(a: i32, b: i32) -> i32 { a + b }

    #[test]
    fn adds_positive_numbers() {
        assert_eq!(add(2, 3), 5);
    }

    #[test]
    #[should_panic(expected = "division by zero")]
    fn panics_on_zero() {
        let d = 0;
        assert!(d != 0, "division by zero");
    }
}
```

`cargo test` 运行全部测试，`cargo test -- --nocapture` 可以看到 `println!` 输出。

## 工程化清单

> 提交前跑一遍 `cargo fmt && cargo clippy -- -D warnings && cargo test`，把格式、静态检查和测试固化进 CI，能拦住大多数低级问题。

- 用 `#![deny(unsafe_code)]` 明确"本 crate 不使用 unsafe"
- 依赖尽量少，定期用 `cargo tree` 与 `cargo audit` 检查
- 为公开 API 写文档注释 `///`，`cargo doc` 会一并生成示例
- 二进制项目拆分 `lib.rs`（可测试的逻辑）与 `main.rs`（薄入口）
