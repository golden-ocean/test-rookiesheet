---
title: 快速开始
description: 写出第一个 Rust 程序，理解 cargo 项目结构。
language: rust
section: 入门
order: 2
updated: 2026-10-18
minutes: 8
tags: [入门, 基础语法]
notice: 本文假设你已安装 Rust 1.80+，运行 rustc --version 检查。
---

## 项目结构

`cargo new` 会生成如下布局：

```
hello_rust/
├── Cargo.toml
├── Cargo.lock
└── src/
    └── main.rs
```

- `Cargo.toml`：包的元信息与依赖清单
- `Cargo.lock`：锁定实际解析到的依赖版本，应纳入版本控制
- `src/main.rs`：二进制程序入口

一个最简单的 `Cargo.toml`：

```toml
[package]
name = "hello_rust"
version = "0.1.0"
edition = "2021"

[dependencies]
```

`edition` 代表语言版本（2015 / 2018 / 2021），新项目默认使用 2021。

## 可变性、打印与格式化

Rust 变量默认不可变，需要修改时加 `mut`：

```rust
fn main() {
    let mut count = 0;
    count += 1; // 没有 mut 时这里会编译失败
    println!("count = {count}"); // 支持直接内联变量名

    let pi = 3.14159;
    println!("pi ≈ {pi:.2}"); // 保留两位小数
}
```

`println!` 的占位符 `{}` 使用 `Display` 实现，`{:?}` 使用 `Debug` 实现，后者常用于调试输出结构体。

## 用 Result 处理错误

Rust 没有异常，可预期的错误通过返回值表达。`main` 可以返回 `Result`：

```rust
use std::fs;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let text = fs::read_to_string("Cargo.toml")?; // ? 出错时提前返回
    let lines = text.lines().count();
    println!("Cargo.toml 共 {lines} 行");
    Ok(())
}
```

`?` 运算符会在遇到 `Err` 时把它转换为函数返回的错误类型并立即返回，代码因此保持线性。

## 模块与依赖

在同一 crate 内用 `mod` 组织代码：

```rust
mod math {
    pub fn square(x: i32) -> i32 {
        x * x
    }
}

fn main() {
    println!("{}", math::square(7));
}
```

引入外部依赖只需在 `Cargo.toml` 中添加，然后 `cargo build` 自动下载：

```toml
[dependencies]
serde = { version = "1", features = ["derive"] }
```

> 依赖版本建议写在 `Cargo.toml`，但具体的解析结果由 `Cargo.lock` 固定，这样团队与 CI 环境才能得到完全一致的构建。

## 小结

到这里你已经完成了项目创建、变量修改、错误处理与模块划分。下一步深入《变量与类型》。
