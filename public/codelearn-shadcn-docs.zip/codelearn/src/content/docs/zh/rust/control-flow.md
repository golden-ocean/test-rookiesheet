---
title: 流程控制
description: if 表达式、match 与三种循环的用法与取舍。
language: rust
section: 核心概念
order: 4
updated: 2026-10-18
minutes: 8
tags: [核心概念, 控制流, match]
---

## if 是表达式

Rust 中几乎所有东西都是表达式，`if` 会给出一块的值，因此没有三元运算符：

```rust
fn grade(score: u32) -> &'static str {
    if score >= 90 {
        "A"
    } else if score >= 60 {
        "B"
    } else {
        "C"
    } // 注意：这里没有分号，整个 if 就是返回值
}

fn main() {
    println!("{}", grade(95));
}
```

条件必须是 `bool`，Rust 不会把非零整数当作真值。

## match 与模式匹配

`match` 要求穷尽所有可能，编译器会检查遗漏：

```rust
fn describe(code: u16) -> String {
    match code {
        200 => "OK".to_string(),
        301 | 302 => "重定向".to_string(),
        400..=499 => "客户端错误".to_string(),
        500..=599 => "服务端错误".to_string(),
        other => format!("未知状态码 {other}"),
    }
}

fn main() {
    println!("{}", describe(404));
    println!("{}", describe(999));
}
```

可以用来解构枚举、元组和结构体：

```rust
#[derive(Debug)]
enum Shape {
    Circle(f64),
    Rect { w: f64, h: f64 },
}

fn area(s: &Shape) -> f64 {
    match s {
        Shape::Circle(r) => std::f64::consts::PI * r * r,
        Shape::Rect { w, h } => w * h,
    }
}

fn main() {
    println!("{:.2}", area(&Shape::Rect { w: 3.0, h: 4.0 }));
}
```

## 循环

三种循环各有用途：

| 写法 | 适用场景 |
|---|---|
| `loop` | 无限循环，用 `break` 带出值 |
| `while` | 条件驱动的循环 |
| `for` | 遍历迭代器或区间，最常用 |

```rust
fn main() {
    let mut attempts = 0;
    let result = loop {
        attempts += 1;
        if attempts == 3 {
            break attempts * 10; // break 可以返回值
        }
    };
    println!("尝试 {attempts} 次，结果 {result}");

    let mut n = 3;
    while n > 0 {
        n -= 1;
    }

    for i in 0..3 {
        print!("{i} ");
    }
    println!();
}
```

`for i in 0..3` 使用的是 `Range` 迭代器，注意 `0..3` 不含右端点，`0..=3` 才包含。

## 提前返回与 guard 子句

在函数开头用 `if` + `return` 排除异常情况（guard 子句），可以显著减少嵌套层数：

```rust
fn safe_div(a: i32, b: i32) -> Option<i32> {
    if b == 0 {
        return None; // 先处理边界，再写主逻辑
    }
    Some(a / b)
}

fn main() {
    assert_eq!(safe_div(10, 2), Some(5));
    assert_eq!(safe_div(1, 0), None);
}
```

> `while let Some(x) = iter.next()` 这种写法现在通常直接用 `for` 更好，`for` 不会忘记推进迭代器。
