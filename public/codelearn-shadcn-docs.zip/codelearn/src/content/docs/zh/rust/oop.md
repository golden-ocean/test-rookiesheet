---
title: 面向对象
description: Rust 没有继承，用 struct 与 trait 组合出面向对象式设计。
language: rust
section: 核心概念
order: 6
updated: 2026-10-18
minutes: 10
tags: [核心概念, trait, 面向对象]
notice: Rust 不支持类继承，本节的重点是"组合优于继承"，请不要照搬其他语言的写法。
---

## Rust 如何看待"面向对象"

Rust 的官方文档承认：可以用 struct 封装数据、用 `impl` 提供方法、用 `trait` 定义接口，但**没有类继承**。它用两个概念分拆传统 OOP 的职责：

| 传统 OOP 概念 | Rust 对应 | 说明 |
|---|---|---|
| 类字段 + 方法 | `struct` + `impl` | 数据与实现分开声明 |
| 接口 / 抽象类 | `trait` | 只描述行为，可提供默认实现 |
| 继承 | 无 | 用组合和 trait 对象替代 |
| 多态 | `dyn Trait` 或泛型 | 动态分派或静态分派 |

## 用 struct 与 impl 封装

```rust
pub struct Account {
    owner: String,
    balance: i64, // 单位：分
}

impl Account {
    pub fn new(owner: impl Into<String>, balance: i64) -> Self {
        Self { owner: owner.into(), balance }
    }

    pub fn deposit(&mut self, amount: i64) -> Result<(), String> {
        if amount <= 0 {
            return Err("金额必须为正".into());
        }
        self.balance += amount;
        Ok(())
    }

    pub fn balance(&self) -> i64 {
        self.balance
    }
}

fn main() {
    let mut acc = Account::new("小明", 0);
    acc.deposit(1000).unwrap();
    println!("{} 余额 {}", acc.owner, acc.balance());
}
```

私有字段只允许在同模块内访问，外部调用者只能通过公开方法修改状态，这天然实现了封装（getter/setter 也是构造方法 `Self { .. }`）。

## 用 trait 定义接口

```rust
trait Shape {
    fn area(&self) -> f64;
    fn name(&self) -> &'static str;

    // 默认实现：实现者可以覆盖
    fn describe(&self) -> String {
        format!("{} 面积 {:.2}", self.name(), self.area())
    }
}

struct Circle { r: f64 }
struct Rect { w: f64, h: f64 }

impl Shape for Circle {
    fn area(&self) -> f64 { std::f64::consts::PI * self.r * self.r }
    fn name(&self) -> &'static str { "圆" }
}

impl Shape for Rect {
    fn area(&self) -> f64 { self.w * self.h }
    fn name(&self) -> &'static str { "矩形" }
}

fn main() {
    let shapes: Vec<Box<dyn Shape>> = vec![
        Box::new(Circle { r: 1.0 }),
        Box::new(Rect { w: 2.0, h: 3.0 }),
    ];
    for s in &shapes {
        println!("{}", s.describe());
    }
}
```

`dyn Shape` 是 trait 对象，运行时通过虚表分派；泛型 `T: Shape` 则在编译期单态化，性能更好但不允许同一个集合混装不同类型。

## 与继承的区别

继承是"is-a"关系，容易产生深层、脆弱的类层次；Rust 鼓励"has-a"组合：

```rust
trait Renderer {
    fn render(&self, text: &str) -> String;
}

struct Markdown;
impl Renderer for Markdown {
    fn render(&self, text: &str) -> String { format!("<p>{text}</p>") }
}

struct Page<R: Renderer> {
    renderer: R,
    title: String,
}

impl<R: Renderer> Page<R> {
    fn html(&self) -> String {
        self.renderer.render(&self.title)
    }
}

fn main() {
    let page = Page { renderer: Markdown, title: "hello".into() };
    println!("{}", page.html());
}
```

`Page` 不需要继承 `Markdown`，而是持有一个可替换的 `Renderer`，测试时可以注入一个假实现。

> 经验法则：当你想"复用父类代码"时，先看看能否抽出一个小 trait 或独立结构体。Rust 里很少出现继承带来的菱形问题，因为根本不存在继承。
