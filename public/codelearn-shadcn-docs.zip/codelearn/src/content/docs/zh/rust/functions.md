---
title: 函数
description: 函数签名、泛型、闭包与生命周期标注。
language: rust
section: 核心概念
order: 5
updated: 2026-10-18
minutes: 9
tags: [核心概念, 函数, 泛型]
notice: 本节示例涉及生命周期标注，建议先读《变量与类型》中的借用部分。
---

## 基本签名

函数使用 `fn` 声明，参数与返回值都必须标注类型。最后一个表达式就是返回值：

```rust
fn add(a: i32, b: i32) -> i32 {
    a + b // 没有分号，表达式作为返回值
}

fn log(msg: &str) {
    // 返回 ()，可以省略 -> ()
    println!("[log] {msg}");
}

fn main() {
    log(&add(1, 2).to_string());
}
```

如果函数体末尾写了分号，它就返回 `()`，若签名声明了返回值则会编译报错，这是初学者最常遇到的错误之一。

## 泛型函数

泛型让同一份逻辑适用于多种类型，但必须通过 trait 约束说明"参数能做什么"：

```rust
use std::fmt::Display;

fn largest<T: PartialOrd + Copy>(items: &[T]) -> Option<T> {
    let mut max = *items.first()?;
    for &item in items.iter().skip(1) {
        if item > max {
            max = item;
        }
    }
    Some(max)
}

fn show<T: Display>(label: &str, value: T) {
    println!("{label}: {value}");
}

fn main() {
    show("max", largest(&[3, 9, 4]).unwrap());
    show("max", largest(&['a', 'z']).unwrap_or('a'));
}
```

单个约束可以直接内联，多个约束可以用 `where` 子句，超过三四个时用 `where` 更易读。

## 闭包

闭包是可以捕获环境变量的匿名函数，编译器会根据使用方式推断捕获方式（`Fn` / `FnMut` / `FnOnce`）：

```rust
fn main() {
    let factor = 3;
    let triple = |x: i32| x * factor; // 按引用捕获 factor

    let nums = vec![1, 2, 3];
    let doubled: Vec<i32> = nums.iter().map(|n| triple(*n)).collect();
    println!("{:?}", doubled);
}
```

如果需要把闭包跨线程或长期保存，通常会配合 `move` 关键字把捕获的值移入闭包，再交给 `thread::spawn` 或异步任务。

## 生命周期标注

生命周期用来告诉编译器"返回的引用和哪个输入活得一样久"。最常见的是省略规则就能处理的情况，只有返回引用时往往需要显式标注：

```rust
// 返回较长的那一句：返回值至少和两个参数一样长寿
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() >= y.len() { x } else { y }
}

fn main() {
    let a = String::from("abc");
    let b = "defgh";
    println!("{}", longest(&a, b));
}
```

> 生命周期标注不改变运行时代码，它只是借用检查器用于验证的约束。遇到报错时，先问"这个引用真正需要活多久"，再考虑加标注。

## 函数项与错误处理约定

- 函数只做一件事，返回 `Result<T, E>` 而不是在内部 `println!` 然后吞掉错误
- 库函数用具体错误类型，应用入口用 `Box<dyn Error>` 或 `anyhow::Error`
- 参数数量超过四五个时，考虑合并为一个配置结构体
