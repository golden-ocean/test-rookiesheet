---
title: 快速开始
description: 写出第一个 Go 程序，了解包、函数与错误处理的写法。
language: go
section: 入门
order: 2
updated: 2026-10-18
minutes: 8
tags: [入门, 基础语法]
notice: 本文假设你已安装 Go 1.22+，运行 go version 检查。
---

这篇用一个命令行小工具，把 Go 程序的基本结构串起来：包声明、导入、函数、错误处理。

## 程序结构

每个 Go 文件都以 `package` 开头。可执行程序必须位于 `package main` 并包含 `main` 函数。

```go
// main.go
package main

import (
	"fmt"
	"os"
)

func main() {
	// os.Args[0] 是可执行文件名，参数从下标 1 开始
	args := os.Args[1:]
	if len(args) == 0 {
		fmt.Println("用法: hello <名字>")
		os.Exit(1)
	}
	fmt.Printf("Hello, %s!\n", args[0])
}
```

运行：

```bash
go run main.go 世界
# Hello, 世界!
```

## 短变量声明与类型推断

`:=` 声明并赋值，类型由右侧推断；`var` 用于需要显式声明或后续赋值的场景。

```go
package main

import "fmt"

func main() {
	name := "Gopher" // 推断为 string
	var age int32 = 12
	var score float64 // 零值 0

	fmt.Println(name, age, score)
}
```

> Go 没有隐式类型转换。`int32` 与 `int` 相加必须显式转换，这是刻意设计，避免精度丢失。

## 错误处理

Go 用返回值表达失败，调用方必须显式判断：

```go
package main

import (
	"fmt"
	"strconv"
)

func parsePort(s string) (int, error) {
	port, err := strconv.Atoi(s)
	if err != nil {
		// 用 %w 包装，保留原始错误链
		return 0, fmt.Errorf("解析端口失败: %w", err)
	}
	if port <= 0 || port > 65535 {
		return 0, fmt.Errorf("端口 %d 超出范围", port)
	}
	return port, nil
}

func main() {
	port, err := parsePort("8080")
	if err != nil {
		fmt.Println("出错了:", err)
		return
	}
	fmt.Println("端口:", port)
}
```

## 一次学到位的习惯

1. 错误一律就近处理，不要攒着最后统一判断。
2. 只返回需要的值，不要用 `error` 报告正常分支。
3. 用 `%w` 包装错误，方便上层 `errors.Is` / `errors.As` 判断。

```bash
go run main.go
# 端口: 8080
```
