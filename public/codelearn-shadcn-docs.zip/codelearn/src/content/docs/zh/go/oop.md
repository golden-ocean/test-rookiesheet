---
title: 面向对象
description: 用结构体、方法与接口实现组合式的面向对象设计。
language: go
section: 核心概念
order: 6
updated: 2026-10-18
minutes: 9
tags: [核心概念, 接口]
notice: Go 没有 class 与继承，本文展示的是它自己的抽象方式。
---

Go 不是传统面向对象语言，但用结构体 + 方法 + 接口同样能写出清晰的抽象。核心思想是**组合优于继承**。

## 结构体与方法

```go
package main

import "fmt"

type Account struct {
	ID      string
	Balance float64
}

// 值接收者：不修改原值，适合小对象或只读操作
func (a Account) Describe() string {
	return fmt.Sprintf("账户 %s 余额 %.2f", a.ID, a.Balance)
}

// 指针接收者：可以修改字段，避免复制
func (a *Account) Deposit(amount float64) error {
	if amount <= 0 {
		return fmt.Errorf("存款金额必须为正数: %v", amount)
	}
	a.Balance += amount
	return nil
}

func main() {
	acc := &Account{ID: "A001"}
	_ = acc.Deposit(100)
	fmt.Println(acc.Describe()) // 账户 A001 余额 100.00
}
```

> 经验法则：同一个类型的方法接收者要么全用指针，要么全用值，保持一致性。

## 接口与隐式实现

接口只声明行为，类型只要实现了全部方法就自动满足接口，无需 `implements`：

```go
type Depositor interface {
	Deposit(float64) error
}

type Payer interface {
	Pay(float64) error
}

// 接口组合
type Wallet interface {
	Depositor
	Payer
	Describe() string
}

func transfer(from Depositor, to Depositor, amount float64) error {
	return to.Deposit(amount)
}
```

## 嵌入与组合

```go
type Logger struct{}

func (Logger) Log(msg string) { fmt.Println("[log]", msg) }

type Service struct {
	Logger // 匿名嵌入，Service 直接获得 Log 方法
	Name   string
}

func main() {
	s := Service{Name: "user-service"}
	s.Log("启动") // 等价于 s.Logger.Log("启动")
}
```

嵌入不是继承：`Service` 并没有变成 `Logger` 的子类，只是把方法提升了一层。

## 接口断言与空接口

```go
var w Wallet = &Account{ID: "A002", Balance: 50}

// 类型断言：带 ok 的形式不会 panic
if d, ok := w.(Depositor); ok {
	fmt.Println("支持存款", d != nil)
}

// 类型 switch
switch v := any(w).(type) {
case *Account:
	fmt.Println("账户类型，余额", v.Balance)
case nil:
	fmt.Println("nil 接口")
default:
	fmt.Printf("其他类型 %T\n", v)
}
```

优先返回接口、接收接口，但**不要**为了让接口而接口：只有存在两种以上实现或确实需要解耦时，才引入接口。
