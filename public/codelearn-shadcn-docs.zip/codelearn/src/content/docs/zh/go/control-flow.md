---
title: 流程控制
description: if、for、switch 与 defer 的惯用写法。
language: go
section: 核心概念
order: 4
updated: 2026-10-18
minutes: 7
tags: [核心概念, 基础语法]
notice: 本文示例可在任何 Go 1.22+ 环境直接运行。
---

Go 的控制流关键字很少：`if`、`for`、`switch`、`defer`、`go`、`select`。没有 `while`，也没有三元运算符。

## if 与提前返回

`if` 支持初始化语句，非常适合把错误处理前置：

```go
package main

import (
	"errors"
	"fmt"
)

func divide(a, b float64) (float64, error) {
	if b == 0 {
		return 0, errors.New("除数不能为零")
	}
	return a / b, nil
}

func main() {
	// 初始化语句中的变量作用域限于 if/else
	if result, err := divide(10, 2); err != nil {
		fmt.Println("失败:", err)
	} else {
		fmt.Println("结果:", result) // 结果: 5
	}
}
```

## for 的三种形态

`for` 是 Go 唯一的循环结构：

```go
package main

import "fmt"

func main() {
	// 1. 经典三段式
	for i := 0; i < 3; i++ {
		fmt.Print(i, " ")
	}
	fmt.Println()

	// 2. 当 while 用
	n := 3
	for n > 0 {
		n--
	}

	// 3. 遍历集合
	items := []string{"a", "b"}
	for idx, item := range items {
		fmt.Println(idx, item)
	}

	// 用 break 跳出并带标签
outer:
	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			if i*j == 2 {
				break outer
			}
		}
	}
}
```

## switch

Go 的 `switch` 默认不穿透（不需要 `break`），且分支可以是任意表达式：

```go
package main

import "fmt"

func weekdayComment(day string) string {
	switch day {
	case "sat", "sun":
		return "周末"
	case "mon":
		return "周一综合症"
	default:
		return "工作日"
	}
}

func main() {
	fmt.Println(weekdayComment("sat")) // 周末

	// 无表达式的 switch，等价于 if/else if 链
	score := 85
	switch {
	case score >= 90:
		fmt.Println("A")
	case score >= 80:
		fmt.Println("B")
	default:
		fmt.Println("C")
	}
}
```

## defer

`defer` 注册的函数在当前函数返回前执行，后进先出，常用于资源释放：

```go
package main

import (
	"fmt"
	"os"
)

func writeLog(path, msg string) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close() // 无论后面是否出错都会关闭

	_, err = fmt.Fprintln(f, msg)
	return err
}

func main() {
	// 输出顺序：third -> second -> first
	for i := 1; i <= 3; i++ {
		defer fmt.Println(i)
	}
	_ = writeLog("/tmp/demo.log", "hello")
}
```

注意：`defer` 的参数在注册时求值，循环中要小心变量捕获。
