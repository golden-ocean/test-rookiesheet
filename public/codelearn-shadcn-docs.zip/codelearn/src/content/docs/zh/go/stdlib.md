---
title: 标准库
description: 常用标准库速查：strings、strconv、time、os、encoding/json、sort 等。
language: go
section: 进阶
order: 8
updated: 2026-10-18
minutes: 9
tags: [进阶, 标准库]
---

Go 标准库以“够用就好”著称，很多项目不需要任何第三方依赖就能跑起来。下面按用途整理最常用的几个包。

## 字符串与转换

```go
package main

import (
	"fmt"
	"strconv"
	"strings"
)

func main() {
	s := "  Go, Is, Fun  "
	fmt.Println(strings.TrimSpace(s))             // "Go, Is, Fun"
	fmt.Println(strings.Split("a,b,c", ","))      // [a b c]
	fmt.Println(strings.Contains("gopher", "go")) // true
	fmt.Println(strings.ToUpper("go"))            // GO
	fmt.Println(strings.Repeat("-", 10))

	// 数字与字符串互转
	n, err := strconv.Atoi("42")
	if err != nil {
		panic(err)
	}
	fmt.Println(strconv.Itoa(n * 2), strconv.FormatFloat(1.5, 'f', 2, 64))
}
```

## 时间

```go
now := time.Now()
fmt.Println(now.Format("2006-01-02 15:04:05"))
fmt.Println(now.Add(48 * time.Hour))
fmt.Println(now.Before(now.Add(time.Minute))) // true
```

> Go 的时间格式化不用 `yyyy-MM-dd`，而是用固定的参考时间 `2006-01-02 15:04:05`。

## 文件与 IO

```go
func readAll(path string) (string, error) {
	data, err := os.ReadFile(path) // Go 1.16+ 推荐写法
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func writeAll(path, content string) error {
	return os.WriteFile(path, []byte(content), 0o644)
}
```

## JSON

```go
type User struct {
	Name  string `json:"name"`
	Email string `json:"email,omitempty"` // 空值时不输出
	Age   int    `json:"-"`
}

func main() {
	b, _ := json.Marshal(User{Name: "Tom"})
	fmt.Println(string(b)) // {"name":"Tom"}

	var u User
	_ = json.Unmarshal(b, &u)

	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(u)
}
```

## 排序

```go
nums := []int{3, 1, 2}
sort.Ints(nums) // [1 2 3]
sort.Slice(nums, func(i, j int) bool { return nums[i] > nums[j] }) // 降序
```

## 速查表

| 包 | 常见用途 |
|---|---|
| `fmt` | 格式化输出 `Printf` / `Sprintf` / `Errorf` |
| `strings` `bytes` | 字符串/字节处理 |
| `strconv` | 数值与字符串互转 |
| `time` | 时间、定时器、格式化 |
| `os` `io` `bufio` | 文件与流式读写 |
| `encoding/json` | JSON 编解码 |
| `sort` `slices` | 排序与切片工具 |
| `errors` | `Is`、`As`、`Join` 错误处理 |
| `sync` `context` | 并发控制 |
| `net/http` | HTTP 服务与客户端 |
| `testing` | 单元测试与基准测试 |
