---
title: 函数
description: 多返回值、可变参数、闭包与函数作为值。
language: go
section: 核心概念
order: 5
updated: 2026-10-18
minutes: 8
tags: [核心概念, 函数]
---

函数是 Go 的唯一代码复用单位，没有方法重载，也没有默认参数。看起来简陋，但配合多返回值与函数类型足够表达绝大多数需求。

## 签名与多返回值

```go
package main

import (
	"errors"
	"fmt"
	"strconv"
)

// 参数类型相同可合并书写，结果类型写在参数之后
func divmod(a, b int) (int, int) {
	return a / b, a % b
}

// 带名字的返回值，可在函数开头直接使用零值
func parsePositive(s string) (n int, err error) {
	n, err = strconv.Atoi(s)
	if err != nil {
		return 0, fmt.Errorf("非法数字: %w", err)
	}
	if n <= 0 {
		return 0, errors.New("必须是正数")
	}
	return n, nil
}

func main() {
	q, r := divmod(7, 2)
	fmt.Println(q, r) // 3 1

	if v, err := parsePositive("42"); err == nil {
		fmt.Println(v)
	}
}
```

> 除非意图非常明确，否则不建议滥用命名返回值，它会和 `:=` 产生意外的遮蔽问题。

## 可变参数

```go
func sum(nums ...int) int {
	total := 0
	for _, n := range nums {
		total += n
	}
	return total
}

func main() {
	fmt.Println(sum(1, 2, 3))
	nums := []int{4, 5}
	fmt.Println(sum(nums...)) // 用 ... 展开切片
}
```

## 函数作为值与闭包

```go
package main

import "fmt"

// 函数类型可以像普通类型一样声明
type Operator func(int, int) int

func newCounter() func() int {
	count := 0
	// 闭包捕获 count，每次调用都会修改同一个变量
	return func() int {
		count++
		return count
	}
}

func apply(op Operator, a, b int) int {
	return op(a, b)
}

func main() {
	c := newCounter()
	fmt.Println(c(), c()) // 1 2

	fmt.Println(apply(func(a, b int) int { return a * b }, 3, 4)) // 12
}
```

## 常用内置函数

| 函数 | 说明 |
|---|---|
| `len` `cap` | 长度与容量 |
| `append` | 追加元素到切片 |
| `make` | 创建切片、map、channel |
| `new` | 分配零值指针 |
| `delete` | 删除 map 键 |
| `panic` `recover` | 严重错误与恢复，仅用于不可恢复场景 |

```go
func safeRun(fn func()) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("panic: %v", r)
		}
	}()
	fn()
	return nil
}
```
