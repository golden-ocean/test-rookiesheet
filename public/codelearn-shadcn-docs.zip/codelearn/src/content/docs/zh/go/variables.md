---
title: 变量与类型
description: 掌握 Go 的变量声明、基本类型、复合类型与零值机制。
language: go
section: 核心概念
order: 3
updated: 2026-10-18
minutes: 9
tags: [核心概念, 类型]
---

Go 是静态类型语言，但不要求到处写类型：编译器能从右侧推断。理解零值和值语义，是写好 Go 的前提。

## 声明方式

```go
package main

import "fmt"

// 包级变量
var appName = "codelearn"

func main() {
	var a int        // 零值 0
	var b = 3.14     // 推断 float64
	c := "hello"     // 短声明，只能在函数内使用
	var d, e = 1, 2  // 多变量声明

	// 常量：编译期确定，可用 iota 生成序列
	const (
		StatusOK = iota // 0
		StatusErr       // 1
	)

	fmt.Println(a, b, c, d, e, appName, StatusOK, StatusErr)
}
```

## 基本类型

| 类型 | 说明 | 零值 |
|---|---|---|
| `bool` | 布尔 | `false` |
| `int` `int64` | 整数，`int` 宽度与平台相关 | `0` |
| `float64` | 浮点 | `0` |
| `string` | 不可变字节序列（UTF-8） | `""` |
| `byte` | `uint8` 别名 | `0` |
| `rune` | `int32` 别名，表示一个 Unicode 码点 | `0` |

```go
s := "你好"
fmt.Println(len(s))         // 6：字节数
fmt.Println(len([]rune(s))) // 2：字符数
```

> 处理中文等非 ASCII 文本时，遍历字符串请用 `for _, r := range s`，得到的是 `rune` 而不是字节。

## 复合类型

```go
package main

import "fmt"

func main() {
	// 切片：动态数组，底层是数组 + 长度 + 容量
	nums := []int{1, 2, 3}
	nums = append(nums, 4)

	// 数组：长度是类型的一部分
	var grid [2][2]int
	grid[0][0] = 1

	// map：必须先用 make 初始化才能写入
	scores := make(map[string]int)
	scores["go"] = 100
	value, ok := scores["rust"]
	if !ok {
		fmt.Println("没有找到 rust，值为零值", value)
	}

	// 结构体：值类型，赋值会复制
	type Point struct{ X, Y int }
	p := Point{X: 1, Y: 2}
	q := p
	q.X = 100
	fmt.Println(p.X, q.X) // 1 100
}
```

## 指针与值语义

Go 的函数参数默认按值传递。需要修改调用方的数据，或者避免复制大结构体时，使用指针。

```go
func inc(n *int) {
	*n++ // 解引用后自增
}

func main() {
	x := 1
	inc(&x)
	fmt.Println(x) // 2
}
```

切片、map、channel 本身包含指针，传入函数后修改其内容对调用方可见，但重新赋值不会影响外部变量。
