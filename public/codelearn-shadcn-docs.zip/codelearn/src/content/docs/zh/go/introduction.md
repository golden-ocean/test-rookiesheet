---
title: 简介与安装
description: 认识 Go 语言的设计哲学，安装工具链并验证环境。
language: go
section: 入门
order: 1
updated: 2026-10-18
minutes: 7
tags: [入门, 安装, 环境]
notice: 本文使用 Go 1.22 及以上版本，部分示例依赖新版循环变量语义。
---

Go 是 Google 于 2009 年开源的静态类型编译型语言，目标是用尽量少的语法写出高并发、易维护的服务端程序。它被广泛应用于云原生基础设施（Docker、Kubernetes、etcd 都用 Go 编写）。

## 设计哲学

Go 的取舍非常明确，理解这几点能少走很多弯路：

- **简单优先**：语言特性克制，没有继承、没有方法重载、没有异常。
- **显式错误处理**：用返回值 `error` 表达失败，而不是抛出异常。
- **并发内建**：`goroutine` 和 `channel` 是语言级原语，而不是库。
- **工具链统一**：`gofmt`、`go test`、`go mod` 都是官方标配。

> “少即是多”是 Go 社区的口头禅。当你觉得某个写法很绕时，通常说明它不是 Go 的惯用法。

## 安装

各平台安装方式：

| 平台 | 方式 | 命令 |
|---|---|---|
| macOS | Homebrew | `brew install go` |
| Linux | 官方压缩包 | 解压到 `/usr/local` 并加入 PATH |
| Windows | 官方 MSI | 下载安装包双击安装 |
| 任意 | 版本管理 | `go install golang.org/dl/go1.22.0@latest` |

验证安装：

```bash
go version
# go version go1.22.0 linux/amd64
```

## 第一个模块

Go 1.11 之后用模块（module）管理依赖，不再需要配置 `GOPATH`：

```bash
mkdir hello && cd hello
go mod init example.com/hello
```

这会生成 `go.mod`，声明模块路径与 Go 版本。之后所有依赖都会记录在这里。

```go
// main.go
package main

import "fmt"

func main() {
	fmt.Println("Hello, Go")
}
```

运行程序：

```bash
go run main.go
# Hello, Go
```

## 常用命令速查

```bash
go run .        # 编译并运行当前包
go build -o app . # 编译成二进制
go test ./...   # 运行所有测试
go vet ./...    # 静态检查
gofmt -w .      # 格式化代码
go mod tidy     # 整理依赖
```

建议把编辑器配置成保存时自动执行 `gofmt` 与 `goimports`，这是 Go 社区的事实标准。
