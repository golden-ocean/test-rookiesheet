---
title: 最佳实践
description: 项目结构、错误处理、测试与性能方面的惯用做法。
language: go
section: 进阶
order: 9
updated: 2026-10-18
minutes: 10
tags: [进阶, 工程化]
notice: 这些约定大多来自官方文档与社区共识，而非编译器强制。
---

Go 的代码风格高度统一，正是因为有大量“唯一正确写法”的共识。本文列出最容易踩坑的几条。

## 项目结构

```text
myapp/
├── go.mod
├── cmd/
│   └── server/main.go      # 唯一入口
├── internal/
│   └── user/service.go     # 不对外暴露
├── pkg/                    # 可选，明确供外部使用
└── Makefile
```

- `internal/` 被编译器强制限制：外部模块无法导入。
- 包名小写、简短、无下划线，避免 `util`、`common` 这类含糊名字。

## 错误处理惯例

```go
var ErrNotFound = errors.New("not found")

func (s *Store) Get(id string) (*User, error) {
	u, ok := s.data[id]
	if !ok {
		return nil, fmt.Errorf("get user %s: %w", id, ErrNotFound)
	}
	return u, nil
}

// 调用方用 errors.Is 判断哨兵错误
if err := s.Get("x"); errors.Is(err, ErrNotFound) {
	// 处理不存在
}
```

| 场景 | 做法 |
|---|---|
| 预期内的失败 | 返回 `error`，不要 panic |
| 包装错误 | `fmt.Errorf("上下文: %w", err)` |
| 判断错误类型 | `errors.Is` / `errors.As` |
| 不可恢复的程序错误 | `panic`，仅在初始化阶段 |

## 测试

测试文件与被测文件同包，命名为 `*_test.go`：

```go
func TestParsePort(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		want    int
		wantErr bool
	}{
		{"正常", "8080", 8080, false},
		{"越界", "70000", 0, true},
		{"非数字", "abc", 0, true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := parsePort(tt.input)
			if (err != nil) != tt.wantErr {
				t.Fatalf("err = %v, wantErr %v", err, tt.wantErr)
			}
			if got != tt.want {
				t.Errorf("got %d, want %d", got, tt.want)
			}
		})
	}
}
```

## 性能与资源

```go
// 预先分配容量，减少扩容
result := make([]int, 0, len(input))

// 拼接大量字符串用 Builder
var sb strings.Builder
for _, s := range parts {
	sb.WriteString(s)
}
fmt.Println(sb.String())

// 限制 goroutine 数量，避免无界并发
sem := make(chan struct{}, 10)
for _, task := range tasks {
	sem <- struct{}{}
	go func(t Task) {
		defer func() { <-sem }()
		run(t)
	}(task)
}
```

> 优化前先测量。用 `go test -bench . -benchmem` 拿数据，再决定是否要改代码。

## 提交前的检查清单

- [ ] `gofmt -l .` 无输出
- [ ] `go vet ./...` 通过
- [ ] `go test -race ./...` 通过
- [ ] `go mod tidy` 后 `go.mod` 无多余依赖
