---
title: 异步编程
description: 用 goroutine、channel 与 context 编写并发程序。
language: go
section: 进阶
order: 7
updated: 2026-10-18
minutes: 11
tags: [进阶, 并发, goroutine]
notice: 并发不等于并行，本文重点讲如何安全地在 goroutine 之间传递数据。
---

Go 的并发模型来自 CSP（通信顺序进程）：**不要通过共享内存来通信，而要通过通信来共享内存**。

## goroutine

`go` 关键字启动一个轻量级协程，调度由运行时负责，初始栈仅几 KB：

```go
package main

import (
	"fmt"
	"sync"
	"time"
)

func worker(id int, wg *sync.WaitGroup) {
	defer wg.Done() // 完成时减一
	time.Sleep(100 * time.Millisecond)
	fmt.Printf("worker %d 完成\n", id)
}

func main() {
	var wg sync.WaitGroup
	for i := 1; i <= 3; i++ {
		wg.Add(1)
		go worker(i, &wg)
	}
	wg.Wait() // 阻塞直到计数归零
	fmt.Println("全部完成")
}
```

> 如果 main 函数返回，所有未完成的 goroutine 会被直接终止。一定要用 `WaitGroup`、channel 或 `context` 等待它们。

## channel

channel 是 goroutine 之间的类型化管道，默认无缓冲（发送与接收必须同时就绪）：

```go
func producer(ch chan<- int, n int) {
	for i := 0; i < n; i++ {
		ch <- i // 只发送
	}
	close(ch) // 由发送方关闭
}

func consumer(ch <-chan int) int {
	total := 0
	for v := range ch { // 通道关闭后自动结束循环
		total += v
	}
	return total
}

func main() {
	ch := make(chan int, 4) // 有缓冲，容量 4
	go producer(ch, 10)
	fmt.Println("总和:", consumer(ch))
}
```

| 操作 | nil channel | 已关闭 channel |
|---|---|---|
| 发送 | 永久阻塞 | panic |
| 接收 | 永久阻塞 | 立即返回零值 |

## select 与超时

`select` 同时等待多个 channel，可实现超时、取消与多路复用：

```go
func fetchWithTimeout(job chan string, timeout time.Duration) (string, error) {
	select {
	case result := <-job:
		return result, nil
	case <-time.After(timeout):
		return "", fmt.Errorf("等待超时: %v", timeout)
	}
}
```

## context 控制生命周期

```go
func watch(ctx context.Context, ticks <-chan int) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err() // context.Canceled 或 DeadlineExceeded
		case t := <-ticks:
			fmt.Println("tick", t)
		}
	}
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 300*time.Millisecond)
	defer cancel()

	ticks := make(chan int)
	go func() {
		for i := 0; ; i++ {
			select {
			case ticks <- i:
				time.Sleep(100 * time.Millisecond)
			case <-ctx.Done():
				return
			}
		}
	}()

	_ = watch(ctx, ticks)
}
```

## 用 mutex 保护共享状态

不是所有场景都适合 channel。多个 goroutine 读写同一个 map 时，用互斥锁更直观：

```go
type Counter struct {
	mu sync.Mutex
	n  int
}

func (c *Counter) Inc() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.n++
}
```

## 排查数据竞争

```bash
go test -race ./...
go run -race main.go
```

只要出现共享变量，就应跑一次 race detector。它能直接指出冲突的读写位置。
