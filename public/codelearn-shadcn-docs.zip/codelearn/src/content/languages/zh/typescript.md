---
name: TypeScript
emoji: 🔷
color: bg-sky-100
description: 带类型的 JavaScript 超集
order: 6
featured: true
---

TypeScript 在 JavaScript 之上加入**静态类型系统**，让大型前端项目也能获得可靠的编辑器智能提示与重构能力。

## 适合人群

- 有一定 JavaScript 基础的前端开发者
- 追求工程化与可维护性的团队
