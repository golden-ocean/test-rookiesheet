---
name: Rust
emoji: 🦀
color: bg-orange-100
description: 内存安全的高性能系统语言
order: 4
featured: true
---

Rust 通过**所有权与借用检查器**在编译期消灭数据竞争与空指针，性能媲美 C/C++，连续多年被评为最受开发者喜爱的语言。

## 适合人群

- 系统编程、嵌入式方向开发者
- 追求极致性能与内存安全的工程师
