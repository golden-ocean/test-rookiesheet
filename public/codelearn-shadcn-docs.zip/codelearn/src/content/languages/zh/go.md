---
name: Go
emoji: 🐹
color: bg-emerald-100
description: 云原生时代的并发利器
order: 3
featured: true
---

Go 是 Google 推出的静态编译型语言，以**部署简单、并发原生支持**著称，Docker、Kubernetes 均由 Go 编写。

## 适合人群

- 后端与云原生方向开发者
- 追求部署简单、性能可靠的工程师

## 课程路线

| 阶段 | 内容 |
| --- | --- |
| 入门 | 简介与安装、快速开始 |
| 核心概念 | 变量与类型、流程控制、函数、面向对象 |
| 进阶 | 异步编程、标准库、最佳实践 |
