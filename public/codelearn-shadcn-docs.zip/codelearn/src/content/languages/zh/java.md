---
name: Java
emoji: ☕
color: bg-red-100
description: 企业级后端的中流砥柱
order: 5
featured: true
---

Java 凭借**JVM 跨平台能力**与成熟的生态，长期主导企业级后端与 Android 开发。

## 适合人群

- 企业后端与 Android 方向开发者
- 需要扎实面向对象功底的学习者
