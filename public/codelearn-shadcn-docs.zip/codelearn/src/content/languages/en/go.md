---
name: Go
emoji: 🐹
color: bg-emerald-100
description: The concurrency workhorse of cloud-native
order: 3
featured: true
---

Go 是 Google 推出的静态编译型语言，以**部署简单、并发原生支持**著称，Docker、Kubernetes 均由 Go 编写。
---

Go is a statically compiled language from Google, known for **simple deployment and first-class concurrency**. Docker and Kubernetes are written in Go.

## Who is it for

- Backend and cloud-native developers
- Engineers who value simple, reliable deployments

## Roadmap

| Stage | Topics |
| --- | --- |
| Getting started | Introduction, Quick start |
| Core | Variables, Control flow, Functions, OOP |
| Advanced | Async, Standard library, Best practices |
