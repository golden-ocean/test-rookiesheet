---
name: Java
emoji: ☕
color: bg-red-100
description: The backbone of enterprise backends
order: 5
featured: true
---

Java 凭借**JVM 跨平台能力**与成熟的生态，长期主导企业级后端与 Android 开发。
---

Java dominates enterprise backends and Android thanks to the **cross-platform JVM** and its mature ecosystem.

## Who is it for

- Enterprise backend and Android developers
- Learners who want solid OOP fundamentals
