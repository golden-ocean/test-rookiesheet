---
name: JavaScript
emoji: 🟨
color: bg-blue-100
description: The only native language of the web
order: 2
featured: true
---

JavaScript 是**浏览器唯一的原生语言**，如今也通过 Node.js 运行在服务端，配合 TypeScript 可获得完整的静态类型体验。
---

JavaScript is the **only native language of the browser**, and now runs on the server via Node.js. Pair it with TypeScript for full static typing.

## Who is it for

- Web and frontend developers
- Full-stack engineers

## Roadmap

| Stage | Topics |
| --- | --- |
| Getting started | Introduction, Quick start |
| Core | Variables, Control flow, Functions, OOP |
| Advanced | Async, Standard library, Best practices |
