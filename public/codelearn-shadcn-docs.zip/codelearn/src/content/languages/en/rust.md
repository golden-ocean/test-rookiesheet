---
name: Rust
emoji: 🦀
color: bg-orange-100
description: A fast systems language with memory safety
order: 4
featured: true
---

Rust 通过**所有权与借用检查器**在编译期消灭数据竞争与空指针，性能媲美 C/C++，连续多年被评为最受开发者喜爱的语言。
---

Rust uses **ownership and the borrow checker** to eliminate data races and null pointers at compile time, with C/C++-level performance.

## Who is it for

- Systems and embedded developers
- Engineers who need memory safety without a GC
