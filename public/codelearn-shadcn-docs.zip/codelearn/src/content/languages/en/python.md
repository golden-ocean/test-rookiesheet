---
name: Python
emoji: 🐍
color: bg-amber-100
description: The go-to language for data, AI and automation
order: 1
featured: true
hot: true
---
---

Python is a general-purpose language famous for its **simple, readable syntax**. It is widely regarded as the most beginner-friendly first language.

## Who is it for

- Complete beginners
- Data and AI practitioners
- Anyone writing automation scripts

## Roadmap

| Stage | Topics |
| --- | --- |
| Getting started | Introduction, Quick start |
| Core | Variables, Control flow, Functions, OOP |
| Advanced | Async, Standard library, Best practices |
