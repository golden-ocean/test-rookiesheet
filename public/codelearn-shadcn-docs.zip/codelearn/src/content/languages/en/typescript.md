---
name: TypeScript
emoji: 🔷
color: bg-sky-100
description: A typed superset of JavaScript
order: 6
featured: true
---

TypeScript 在 JavaScript 之上加入**静态类型系统**，让大型前端项目也能获得可靠的编辑器智能提示与重构能力。
---

TypeScript adds a **static type system** on top of JavaScript, giving large frontend codebases reliable editor tooling and refactoring.

## Who is it for

- Frontend developers with JavaScript experience
- Teams that care about maintainability
