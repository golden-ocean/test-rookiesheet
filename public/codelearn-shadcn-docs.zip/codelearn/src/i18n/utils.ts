import { ui, defaultLang, type Lang, type UIKey } from "./ui";

/** 从 URL 中判断当前语言（默认语言无前缀） */
export function getLangFromUrl(url: URL): Lang {
  const [, first] = url.pathname.split("/");
  if (first in ui) return first as Lang;
  return defaultLang;
}

/** 返回翻译函数，缺失 key 时回退默认语言 */
export function useTranslations(lang: Lang) {
  return function t(key: UIKey, vars?: Record<string, string | number>): string {
    const dict = ui[lang] as Record<string, string>;
    const fallback = ui[defaultLang] as Record<string, string>;
    let text: string = dict[key] ?? fallback[key] ?? key;
    if (vars) {
      for (const [k, v] of Object.entries(vars)) text = text.replace(`{${k}}`, String(v));
    }
    return text;
  };
}

/** 根据语言生成路径：默认语言不带前缀 */
export function useTranslatedPath(lang: Lang) {
  return function translatePath(path: string): string {
    const normalized = path.startsWith("/") ? path : `/${path}`;
    return lang === defaultLang ? normalized : `/${lang}${normalized}`;
  };
}

/** 秒级便捷函数（需要逻辑：Astro 页面内直接调用上面两个） */
export function tFor(lang: Lang) {
  return { t: useTranslations(lang), path: useTranslatedPath(lang) };
}
