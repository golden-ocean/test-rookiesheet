import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

/**
 * docs 内容集合（参考 Astro 官方 i18n recipe）
 * 目录结构：src/content/docs/<lang>/<programming-language>/<slug>.md
 *   e.g. src/content/docs/zh/python/quick-start.md
 *         src/content/docs/en/python/quick-start.md
 * entry.id 形如 "zh/python/quick-start"
 */
const docs = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/docs' }),
  schema: z.object({
    title: z.string(),
    description: z.string().optional(),
    /** 所属编程语言 key，需与 languages 集合的 id 一致 */
    language: z.string(),
    /** 章节分组（对应预览图 sidebar 的「入门 / 核心概念 / 进阶」） */
    section: z.string().default('入门'),
    /** 章节内排序 */
    order: z.number().default(0),
    updated: z.coerce.date(),
    minutes: z.number().default(8),
    tags: z.array(z.string()).default([]),
    /** 顶部提示条（对应预览图 .callout） */
    notice: z.string().optional(),
    draft: z.boolean().default(false),
  }),
});

/**
 * languages 内容集合：编程语言元信息（与 docs 一样按语言分目录）
 * 目录结构：src/content/languages/<lang>/<language>.md
 */
const languages = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/languages' }),
  schema: z.object({
    name: z.string(),
    emoji: z.string().default('📘'),
    /** 卡片配色（tailwind 类名） */
    color: z.string().default('bg-zinc-100'),
    description: z.string(),
    order: z.number().default(0),
    /** 是否展示在首页与 Hero 标签栏 */
    featured: z.boolean().default(true),
    /** Hero 标签栏高亮 */
    hot: z.boolean().default(false),
  }),
});

export const collections = { docs, languages };
