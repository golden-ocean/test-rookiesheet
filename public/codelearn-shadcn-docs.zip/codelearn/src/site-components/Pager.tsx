import { Item, ItemContent, ItemDescription, ItemMedia, ItemTitle } from "@/components/ui/item";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PagerProps {
  prev?: { title: string; href: string };
  next?: { title: string; href: string };
  t: (key: any) => string;
}

/** 上一篇 / 下一篇：用 shadcn Item 承载，整体可点击 */
export function Pager({ prev, next, t }: PagerProps) {
  if (!prev && !next) return null;

  return (
    <nav aria-label="pager" className="mt-12 grid gap-3 border-t border-border pt-8 sm:grid-cols-2">
      {prev ? (
        <Button asChild variant="outline" className="h-auto w-full p-0">
          <a href={prev.href}>
            <Item size="sm" className="w-full text-left">
              <ItemMedia variant="icon">
                <ChevronLeft className="size-4" />
              </ItemMedia>
              <ItemContent>
                <ItemDescription className="text-xs">{t("doc.prev")}</ItemDescription>
                <ItemTitle className="text-sm">{prev.title}</ItemTitle>
              </ItemContent>
            </Item>
          </a>
        </Button>
      ) : (
        <span className="hidden sm:block" />
      )}

      {next ? (
        <Button asChild variant="outline" className="h-auto w-full p-0">
          <a href={next.href}>
            <Item size="sm" className="w-full flex-row-reverse text-right">
              <ItemMedia variant="icon">
                <ChevronRight className="size-4" />
              </ItemMedia>
              <ItemContent className="items-end">
                <ItemDescription className="text-xs">{t("doc.next")}</ItemDescription>
                <ItemTitle className="text-sm">{next.title}</ItemTitle>
              </ItemContent>
            </Item>
          </a>
        </Button>
      ) : (
        <span className="hidden sm:block" />
      )}
    </nav>
  );
}

export default Pager;
