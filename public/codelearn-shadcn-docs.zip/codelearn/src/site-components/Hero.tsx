import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface HeroProps {
  title: string;
  highlight?: string;
  subtitle: string;
  badge?: string;
  langs: { key: string; label: string; href: string; emoji?: string }[];
  activeLang?: string;
  ctaLabel?: string;
  ctaHref?: string;
}

/** Hero：标题 + 副标题 + 语言胶囊（用 Badge/Button 变体承载，颜色全部走 token） */
export function Hero({
  title,
  highlight,
  subtitle,
  badge,
  langs,
  activeLang,
  ctaLabel,
  ctaHref,
}: HeroProps) {
  return (
    <section className="border-b border-border bg-gradient-to-b from-muted/60 to-background">
      <div className="mx-auto max-w-3xl px-6 py-16 text-center">
        {badge && (
          <Badge variant="outline" className="mb-4">
            {badge}
          </Badge>
        )}
        <h1 className="text-balance text-3xl font-extrabold tracking-tight md:text-[2.6rem] md:leading-tight">
          {title}
          {highlight && <span className="text-primary">{highlight}</span>}
        </h1>
        <p className="mt-3 text-pretty text-base text-muted-foreground">{subtitle}</p>

        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {langs.map((l) => (
            <Button
              key={l.key}
              asChild
              size="sm"
              variant={l.key === activeLang ? "default" : "outline"}
              className="h-7 rounded-full px-3 text-[13px]"
            >
              <a href={l.href}>
                {l.emoji && <span className="mr-1">{l.emoji}</span>}
                {l.label}
              </a>
            </Button>
          ))}
        </div>

        {ctaHref && ctaLabel && (
          <Button asChild size="lg" className="mt-7">
            <a href={ctaHref}>{ctaLabel}</a>
          </Button>
        )}
      </div>
    </section>
  );
}

export default Hero;
