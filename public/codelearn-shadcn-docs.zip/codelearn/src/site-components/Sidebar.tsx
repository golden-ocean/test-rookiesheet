import {
  Sidebar as ShadSidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";

export interface SidebarGroupData {
  title: string;
  items: { title: string; href: string; isActive?: boolean }[];
}

interface DocsSidebarProps {
  /** 当前编程语言名称 */
  heading: string;
  headingHref?: string;
  groups: SidebarGroupData[];
  /** 语言列表（顶部切换） */
  languages: { key: string; name: string; href: string; emoji?: string }[];
  currentLanguage: string;
  t: (key: any) => string;
}

/** 左栏：复用 shadcn 官方 Sidebar（可折叠 / 移动端抽屉 / ⌘B 快捷键） */
export function DocsSidebar({
  heading,
  headingHref = "#",
  groups,
  languages,
  currentLanguage,
  t,
}: DocsSidebarProps) {
  const current = languages.find((l) => l.key === currentLanguage);

  return (
    <ShadSidebar collapsible="offcanvas">
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <a href={headingHref}>
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sm text-sidebar-primary-foreground">
                  {current?.emoji ?? "📘"}
                </div>
                <div className="flex flex-col gap-0.5 leading-none">
                  <span className="truncate font-semibold">{heading}</span>
                  <span className="text-xs text-muted-foreground">{t("sidebar.label")}</span>
                </div>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>{t("sidebar.languages")}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {languages.map((l) => (
                <SidebarMenuItem key={l.key}>
                  <SidebarMenuButton isActive={l.key === currentLanguage} asChild>
                    <a href={l.href}>
                      <span className="text-sm">{l.emoji}</span>
                      <span>{l.name}</span>
                      {l.key === currentLanguage && (
                        <Badge variant="secondary" className="ml-auto px-1.5 text-[10px]">
                          {t("sidebar.current")}
                        </Badge>
                      )}
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {groups.map((group) => (
          <SidebarGroup key={group.title}>
            <SidebarGroupLabel>{group.title}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton isActive={item.isActive} asChild>
                      <a href={item.href}>
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarRail />
    </ShadSidebar>
  );
}

export default DocsSidebar;
