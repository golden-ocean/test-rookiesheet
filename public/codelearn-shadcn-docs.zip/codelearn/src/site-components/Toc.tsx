import { Separator } from "@/components/ui/separator";

export interface TocItem {
  depth: number;
  slug: string;
  text: string;
}

interface TocProps {
  headings: TocItem[];
  t: (key: any) => string;
}

/** 右栏目录：使用主题 token（border / muted-foreground / primary）而非硬编码颜色 */
export function Toc({ headings, t }: TocProps) {
  const items = headings.filter((h) => h.depth <= 3);
  if (items.length === 0) return null;

  return (
    <aside className="hidden w-[220px] shrink-0 xl:block">
      <div className="sticky top-[5.5rem] max-h-[calc(100vh-7rem)] overflow-y-auto pb-10">
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {t("doc.toc")}
        </p>
        <Separator className="mb-2" />
        <nav className="border-l border-border">
          {items.map((h) => (
            <a
              key={h.slug}
              href={`#${h.slug}`}
              data-toc-link
              className={
                "block border-l-2 border-transparent py-1 text-[13px] leading-6 text-muted-foreground transition-colors hover:text-foreground " +
                (h.depth === 2 ? "pl-3.5" : "pl-7")
              }
            >
              {h.text}
            </a>
          ))}
        </nav>
      </div>
    </aside>
  );
}

export default Toc;
