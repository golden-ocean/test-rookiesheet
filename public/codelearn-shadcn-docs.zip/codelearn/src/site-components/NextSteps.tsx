import { Item, ItemContent, ItemDescription, ItemTitle } from "@/components/ui/item";
import { ArrowRight } from "lucide-react";

export interface NextCard {
  title: string;
  desc?: string;
  href: string;
}

interface NextStepsProps {
  title: string;
  cards: NextCard[];
}

/** 文末「下一步」卡片：用 shadcn Item + Card 语义 token */
export function NextSteps({ title, cards }: NextStepsProps) {
  if (cards.length === 0) return null;

  return (
    <section className="mt-10">
      <h2 id="next-steps" className="mb-3 scroll-mt-24 text-xl font-bold">
        {title}
      </h2>
      <div className="grid gap-3 sm:grid-cols-2">
        {cards.map((c) => (
          <a key={c.href} href={c.href} className="group block">
            <Item variant="outline" className="transition-colors hover:bg-muted/50">
              <ItemContent>
                <ItemTitle>{c.title}</ItemTitle>
                {c.desc && <ItemDescription>{c.desc}</ItemDescription>}
              </ItemContent>
              <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
            </Item>
          </a>
        ))}
      </div>
    </section>
  );
}

export default NextSteps;
