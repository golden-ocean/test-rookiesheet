import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { languageList, type Lang } from "@/i18n/ui";

interface Props {
  lang: Lang;
  /** 当前页面在另一语言下的对应路径（可选），点击时跳转到此 */
  alternatePath?: string;
}

/** 界面语言切换：中文 ⇄ English */
export function LanguageSwitcher({ lang, alternatePath }: Props) {
  const others = languageList.filter((l) => l.code !== lang);
  const target = others[0];

  // 目标路径：优先使用传入的对应页面，否则回退到该语言的首页
  const href = alternatePath ?? (target.code === "zh" ? "/" : `/${target.code}/`);

  return (
    <Button asChild variant="ghost" size="sm" className="gap-1.5 px-2 text-xs">
      <a href={href} hreflang={target.code} title={target.label}>
        <Languages className="size-4" />
        <span className="hidden sm:inline">{target.short}</span>
      </a>
    </Button>
  );
}

export default LanguageSwitcher;
