import { createPortal } from "react-dom";
import { useEffect, useRef, useState } from "react";
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { DocsSidebar, type SidebarGroupData } from "@/site-components/Sidebar";
import { Button } from "@/components/ui/button";
import { Code2, PanelLeft } from "lucide-react";
import type { Lang } from "@/i18n/ui";
import type React from "react";

interface DocsShellProps {
  sidebar: {
    heading: string;
    headingHref: string;
    groups: SidebarGroupData[];
    languages: { key: string; name: string; href: string; emoji?: string }[];
    currentLanguage: string;
    t: (key: any) => string;
  };
  t: (key: any) => string;
  lang: Lang;
  children?: React.ReactNode;
}

/**
 * 文档页外壳：shadcn Sidebar block 的标准组合
 *   SidebarProvider > (Sidebar + SidebarInset)
 *
 * Sidebar 依赖 React Context 与移动端抽屉状态，必须与 SidebarTrigger 处于同一 Provider。
 * Header 在服务端渲染（SSR），其中预留 #sidebar-trigger-slot 占位，
 * 由本组件在挂载后把官方 SidebarTrigger 以 Portal 方式注入该槽位。
 */
export function DocsShell({ sidebar, t, lang, children }: DocsShellProps) {
  const homeHref = lang === "zh" ? "/" : `/${lang}/`;
  const [slot, setSlot] = useState<HTMLElement | null>(null);
  const mounted = useRef(false);

  useEffect(() => {
    if (mounted.current) return;
    mounted.current = true;
    const el = document.getElementById("sidebar-trigger-slot");
    if (el) setSlot(el);
  }, []);

  return (
    <SidebarProvider>
      <DocsSidebar {...sidebar} />

      <SidebarInset className="min-h-svh">
        {/* 把官方 SidebarTrigger 投送到 SSR 出来的 Header 槽位中 */}
        {slot && createPortal(<SidebarTrigger className="-ml-1" />, slot)}

        {children}
      </SidebarInset>
    </SidebarProvider>
  );
}

export default DocsShell;
