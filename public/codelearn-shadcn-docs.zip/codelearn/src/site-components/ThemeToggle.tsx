import { Moon, Sun, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";

type Theme = "light" | "dark" | "system";
const ORDER: Theme[] = ["light", "dark", "system"];

interface Props {
  /** 已翻译文案：theme.toggle / theme.light / theme.dark / theme.system */
  t?: (key: any) => string;
}

export function ThemeToggle({ t }: Props) {
  const label = (k: string) => (t ? t(k) : k);

  return (
    <Button
      variant="ghost"
      size="icon"
      className="size-9"
      aria-label={label("theme.toggle")}
      title={label("theme.toggle")}
      onClick={(e) => {
        const el = e.currentTarget;
        const current = (document.documentElement.dataset.theme as Theme) ?? "system";
        const next = ORDER[(ORDER.indexOf(current) + 1) % ORDER.length];
        const isDark =
          next === "dark" || (next === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
        document.documentElement.classList.toggle("dark", isDark);
        document.documentElement.dataset.theme = next;
        localStorage.setItem("theme", next);
        el.querySelectorAll<HTMLElement>("[data-icon]").forEach((i) => {
          i.style.display = i.dataset.icon === next ? "" : "none";
        });
      }}
    >
      <Sun data-icon="light" className="hidden size-4" />
      <Moon data-icon="dark" className="hidden size-4" />
      <Monitor data-icon="system" className="size-4" />
    </Button>
  );
}

export default ThemeToggle;
