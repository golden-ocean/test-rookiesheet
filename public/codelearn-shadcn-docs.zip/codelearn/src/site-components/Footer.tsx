import { Separator } from "@/components/ui/separator";

interface FooterProps {
  t: (key: any) => string;
}

export function Footer({ t }: FooterProps) {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-[1400px] flex-col items-center gap-3 px-6 py-6 text-[13px] text-muted-foreground sm:flex-row sm:justify-between">
        <span>
          {t("site.name")} · {t("footer.tagline")}
        </span>
        <div className="flex items-center gap-3">
          <a href="#" className="hover:text-foreground">{t("footer.about")}</a>
          <Separator orientation="vertical" className="h-3" />
          <a href="#" className="hover:text-foreground">{t("footer.github")}</a>
          <Separator orientation="vertical" className="h-3" />
          <a href="#" className="hover:text-foreground">{t("footer.rss")}</a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
