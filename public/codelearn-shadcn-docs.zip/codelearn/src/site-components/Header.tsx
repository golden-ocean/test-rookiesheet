import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "@/components/ui/separator";
import { Kbd } from "@/components/ui/kbd";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { InputGroup, InputGroupAddon, InputGroupInput } from "@/components/ui/input-group";
import { ThemeToggle } from "@/site-components/ThemeToggle";
import { LanguageSwitcher } from "@/site-components/LanguageSwitcher";
import { Code2, Search } from "lucide-react";
import type { Lang } from "@/i18n/ui";

export interface Crumb {
  label: string;
  href?: string;
}

interface HeaderProps {
  lang: Lang;
  t: (key: any, vars?: Record<string, string | number>) => string;
  /** 面包屑路径（不含首页） */
  crumbs?: Crumb[];
  languages?: { key: string; label: string; href: string }[];
  currentLang?: string;
  alternatePath?: string;
}

export function Header({
  lang,
  t,
  crumbs = [],
  languages = [],
  currentLang,
  alternatePath,
}: HeaderProps) {
  const homeHref = lang === "zh" ? "/" : `/${lang}/`;
  const homeLabel = t("nav.home");

  return (
    <header className="sticky top-0 z-50 flex h-16 shrink-0 items-center gap-2 border-b border-border bg-background/85 backdrop-blur">
      <div className="flex w-full items-center gap-2 px-4">
        {/* Sidebar 折叠按钮由 DocsShell 提供（需处于 SidebarProvider 内） */}
        <div id="sidebar-trigger-slot" className="-ml-1 flex items-center" />

        <a href={homeHref} className="flex items-center gap-2 font-semibold">
          <span className="grid size-6 place-items-center rounded-md bg-primary text-primary-foreground">
            <Code2 className="size-3.5" />
          </span>
          <span className="hidden sm:inline">{t("site.name")}</span>
        </a>

        <Separator orientation="vertical" className="mx-1 hidden h-4 sm:block" />

        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem className="hidden md:block">
              <BreadcrumbLink href={homeHref}>{homeLabel}</BreadcrumbLink>
            </BreadcrumbItem>
            {crumbs.map((c, i) => (
              <div key={i} className="contents">
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  {i === crumbs.length - 1 || !c.href ? (
                    <BreadcrumbPage>{c.label}</BreadcrumbPage>
                  ) : (
                    <BreadcrumbLink href={c.href}>{c.label}</BreadcrumbLink>
                  )}
                </BreadcrumbItem>
              </div>
            ))}
          </BreadcrumbList>
        </Breadcrumb>

        <div className="ml-auto flex items-center gap-2">
          {languages.length > 0 && (
            <ToggleGroup
              type="single"
              variant="outline"
              size="sm"
              value={currentLang ?? ""}
              className="hidden lg:flex"
            >
              {languages.map((l) => (
                <ToggleGroupItem key={l.key} value={l.key} asChild>
                  <a href={l.href}>{l.label}</a>
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          )}

          <InputGroup className="hidden h-8 w-52 md:flex">
            <InputGroupInput placeholder={t("nav.search")} className="h-8 text-[13px]" />
            <InputGroupAddon align="inline-end">
              <Search className="size-3.5" />
            </InputGroupAddon>
            <InputGroupAddon align="inline-end" className="hidden xl:flex">
              <Kbd className="text-[10px]">⌘K</Kbd>
            </InputGroupAddon>
          </InputGroup>

          <LanguageSwitcher lang={lang} alternatePath={alternatePath} />
          <ThemeToggle t={t} />
        </div>
      </div>
    </header>
  );
}

export default Header;
