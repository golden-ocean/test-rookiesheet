import { useState } from "react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarRail,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Moon, Sun, BookOpen, GitBranch, Search, ChevronsUpDown, LogOut } from "lucide-react"
import { useTheme } from "@/components/theme-provider"
import { navGroups, type PageId } from "@/lib/data"
import { OverviewPage } from "@/pages/overview"
import { GettingStartedPage } from "@/pages/getting-started"
import { ComponentsPage } from "@/pages/components"
import { TutorialPage } from "@/pages/tutorial"
import { DocDetailPage } from "@/pages/doc-detail"
import { FaqPage } from "@/pages/faq"

export function App() {
  const [page, setPage] = useState<PageId>("overview")
  const { theme, setTheme } = useTheme()

  const currentItem = navGroups
    .flatMap((g) => g.items)
    .find((i) => i.id === page)

  const navigate = (id: PageId) => setPage(id)

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <div className="flex items-center gap-2 px-2 py-1.5">
            <div className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <BookOpen className="size-4" />
            </div>
            <div className="flex flex-col">
              <span className="font-heading text-sm font-semibold leading-tight">Nebula Docs</span>
              <span className="text-xs text-muted-foreground">学习文档平台</span>
            </div>
          </div>
        </SidebarHeader>
        <SidebarContent>
          {navGroups.map((group) => (
            <SidebarGroup key={group.label}>
              <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {group.items.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        isActive={page === item.id}
                        onClick={() => navigate(item.id)}
                        tooltip={item.title}
                      >
                        <item.icon />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}
        </SidebarContent>
        <SidebarFooter>
          <div className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
            <p className="font-medium text-foreground">需要帮助？</p>
            <p className="mt-1 leading-relaxed">查看 FAQ 或加入社区获取支持。</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-2 w-full"
              onClick={() => navigate("faq")}
            >
              查看 FAQ
            </Button>
          </div>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset>
        {/* Top bar */}
        <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <SidebarTrigger />
          <Separator orientation="vertical" className="h-5" />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink onClick={() => navigate("overview")}>文档</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{currentItem?.title ?? "概览"}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>

          <div className="ml-auto flex items-center gap-2">
            <Button variant="ghost" size="icon-sm" className="text-muted-foreground">
              <Search className="size-4" />
              <span className="sr-only">搜索</span>
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              className="text-muted-foreground"
              nativeButton={false}
              render={<a href="#" aria-label="GitHub" />}
            >
              <GitBranch className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              className="text-muted-foreground"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              aria-label="切换主题"
            >
              {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger
                render={
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Avatar className="size-6">
                      <AvatarFallback className="text-xs">ND</AvatarFallback>
                    </Avatar>
                    <ChevronsUpDown className="size-3 text-muted-foreground" />
                  </Button>
                }
              />
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>我的账户</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>个人设置</DropdownMenuItem>
                <DropdownMenuItem>学习记录</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">
                  <LogOut className="size-4" />
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <div className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 md:px-8 md:py-10">
          {page === "overview" && <OverviewPage onNavigate={navigate} />}
          {page === "getting-started" && <GettingStartedPage onNavigate={navigate} />}
          {page === "components" && <ComponentsPage />}
          {page === "tutorial" && <TutorialPage />}
          {page === "doc-detail" && <DocDetailPage />}
          {page === "faq" && <FaqPage />}
        </div>
      </SidebarInset>
      <SidebarRail />
    </SidebarProvider>
  )
}

export default App
