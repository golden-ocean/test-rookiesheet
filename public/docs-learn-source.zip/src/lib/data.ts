import type { LucideIcon } from "lucide-react"
import {
  BookOpen,
  Rocket,
  LayoutGrid,
  GraduationCap,
  HelpCircle,
  Sparkles,
  Layers,
  Palette,
  ShieldCheck,
  Zap,
  Boxes,
  Settings2,
  Puzzle,
  FileText,
  Blocks,
  GitBranch,
  MessageSquare,
  Lightbulb,
  Pencil,
  MousePointerClick,
  PanelLeft,
  Calendar,
  CheckCircle2,
  Table2,
} from "lucide-react"

export type PageId =
  | "overview"
  | "getting-started"
  | "components"
  | "tutorial"
  | "doc-detail"
  | "faq"

export type NavItem = {
  id: PageId
  title: string
  icon: LucideIcon
  description: string
}

export type NavGroup = {
  label: string
  items: NavItem[]
}

export const navGroups: NavGroup[] = [
  {
    label: "开始使用",
    items: [
      {
        id: "overview",
        title: "概览",
        icon: BookOpen,
        description: "了解 Nebula 文档平台的核心能力与学习路径",
      },
      {
        id: "getting-started",
        title: "快速开始",
        icon: Rocket,
        description: "从零开始，5 分钟搭建你的第一个文档站点",
      },
    ],
  },
  {
    label: "深入学习",
    items: [
      {
        id: "components",
        title: "组件库",
        icon: Layers,
        description: "浏览全部可用组件及其用法示例",
      },
      {
        id: "tutorial",
        title: "实战教程",
        icon: GraduationCap,
        description: "跟随步骤构建一个完整的项目案例",
      },
      {
        id: "doc-detail",
        title: "文档详情",
        icon: FileText,
        description: "阅读一篇完整的技术文档示例",
      },
      {
        id: "faq",
        title: "常见问题",
        icon: HelpCircle,
        description: "开发者最常遇到的问题与解答",
      },
    ],
  },
]

export const features = [
  {
    icon: Sparkles,
    title: "即开即用",
    description: "预置 50+ 高质量组件，复制粘贴即可落地，无需从零搭建。",
  },
  {
    icon: Palette,
    title: "主题可定制",
    description: "基于 CSS 变量的设计令牌，一键切换品牌色与暗色模式。",
  },
  {
    icon: ShieldCheck,
    title: "无障碍优先",
    description: "遵循 WAI-ARIA 规范，键盘操作与屏幕阅读器全面支持。",
  },
  {
    icon: Zap,
    title: "极致性能",
    description: "按需加载、零运行时依赖，首屏加载体积小于 10KB。",
  },
]

export const stats = [
  { label: "组件数量", value: "58" },
  { label: "每周下载", value: "240k" },
  { label: "GitHub Star", value: "62.4k" },
  { label: "贡献者", value: "1.2k" },
]

export const learningPath = [
  { step: "01", title: "安装与配置", desc: "使用 CLI 一键初始化项目", done: true },
  { step: "02", title: "核心概念", desc: "理解设计令牌与组件变体", done: true },
  { step: "03", title: "组件实战", desc: "组合组件构建完整页面", done: false },
  { step: "04", title: "主题定制", desc: "打造属于你的品牌视觉", done: false },
  { step: "05", title: "发布上线", desc: "构建优化并部署到生产环境", done: false },
]

export type ComponentCategory = {
  name: string
  icon: LucideIcon
  items: { name: string; desc: string; icon: LucideIcon }[]
}

export const componentCategories: ComponentCategory[] = [
  {
    name: "通用",
    icon: Boxes,
    items: [
      { name: "Button 按钮", desc: "触发操作的可点击元素", icon: MousePointerClick },
      { name: "Icon 图标", desc: "语义化的矢量图标集合", icon: Sparkles },
      { name: "Typography 排版", desc: "标题、正文与代码样式", icon: FileText },
    ],
  },
  {
    name: "布局",
    icon: LayoutGrid,
    items: [
      { name: "Grid 栅格", desc: "响应式网格布局系统", icon: LayoutGrid },
      { name: "Divider 分割线", desc: "区分内容的视觉分隔", icon: GitBranch },
      { name: "Space 间距", desc: "统一的留白与间距规范", icon: Puzzle },
    ],
  },
  {
    name: "导航",
    icon: PanelLeft,
    items: [
      { name: "Breadcrumb 面包屑", desc: "显示当前页面层级位置", icon: Layers },
      { name: "Sidebar 侧边栏", desc: "可折叠的侧边导航面板", icon: PanelLeft },
      { name: "Pagination 分页", desc: "数据列表的分页控件", icon: Calendar },
    ],
  },
  {
    name: "数据录入",
    icon: Pencil,
    items: [
      { name: "Input 输入框", desc: "基础文本输入组件", icon: Pencil },
      { name: "Select 选择器", desc: "下拉选择菜单", icon: Settings2 },
      { name: "Checkbox 复选框", desc: "多选状态切换", icon: CheckCircle2 },
    ],
  },
  {
    name: "数据展示",
    icon: Blocks,
    items: [
      { name: "Card 卡片", desc: "信息聚合与展示容器", icon: Boxes },
      { name: "Table 表格", desc: "结构化数据展示", icon: Table2 },
      { name: "Badge 徽章", desc: "状态与数量标记", icon: MessageSquare },
    ],
  },
  {
    name: "反馈",
    icon: Lightbulb,
    items: [
      { name: "Alert 提示", desc: "重要信息的醒目提示", icon: Lightbulb },
      { name: "Progress 进度", desc: "操作进度可视化", icon: Zap },
      { name: "Tooltip 气泡", desc: "悬浮提示信息", icon: MessageSquare },
    ],
  },
]

export const tutorialSteps = [
  {
    step: 1,
    title: "初始化项目",
    desc: "使用官方脚手架创建一个基础工程。",
  },
  {
    step: 2,
    title: "引入组件库",
    desc: "通过 CLI 添加所需的 UI 组件。",
  },
  {
    step: 3,
    title: "组合页面",
    desc: "利用布局与数据组件搭建完整界面。",
  },
  {
    step: 4,
    title: "主题定制",
    desc: "修改设计令牌适配品牌视觉。",
  },
  {
    step: 5,
    title: "构建发布",
    desc: "执行构建命令并部署到静态托管。",
  },
]

export const codeExamples = {
  install: `# 使用 npm 初始化项目
npm create nebula@latest my-docs
cd my-docs

# 添加所需组件
npx nebula add button card sidebar`,
  usage: `import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle } from "@/components/ui/card"

export function Example() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>欢迎使用 Nebula</CardTitle>
      </CardHeader>
      <Button>开始体验</Button>
    </Card>
  )
}`,
  theme: `:root {
  --primary: oklch(0.55 0.22 260);
  --primary-foreground: oklch(0.98 0 0);
  --radius: 0.75rem;
}`,
}

export const faqs = [
  {
    q: "Nebula 与其他组件库有什么区别？",
    a: "Nebula 采用源码分发模式，组件直接复制到你的项目中，你拥有完全的控制权。同时基于设计令牌构建，主题定制极其灵活。",
  },
  {
    q: "是否支持 TypeScript？",
    a: "完全支持。所有组件都提供完整的类型定义，并且默认使用 TypeScript 编写，享受最佳的类型提示与开发体验。",
  },
  {
    q: "如何自定义主题颜色？",
    a: "只需修改全局 CSS 中的 --primary 等设计令牌变量，所有组件会自动响应变化。也可以通过 CLI 切换预设主题。",
  },
  {
    q: "组件库的体积大吗？",
    a: "采用按需引入策略，每个组件独立分发。实际打包体积取决于你使用的组件，基础页面通常小于 30KB（gzip）。",
  },
  {
    q: "是否支持服务端渲染（SSR）？",
    a: "支持。组件默认兼容 Next.js App Router、Vite SSR 等环境，无障碍属性在服务端即可正确输出。",
  },
  {
    q: "如何贡献组件？",
    a: "欢迎提交 PR！请先阅读贡献指南，确保组件遵循设计令牌规范、通过无障碍测试，并附带使用示例。",
  },
]
