import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Clock,
  Calendar,
  FileText,
  Tag,
  ThumbsUp,
  ThumbsDown,
  GitBranch,
  ArrowLeft,
  ArrowRight,
  Lightbulb,
  AlertTriangle,
  Info,
  CheckCircle2,
  Copy,
  List,
  Hash,
} from "lucide-react"

const toc = [
  { id: "intro", label: "简介", level: 2 },
  { id: "install", label: "安装与配置", level: 2 },
  { id: "basic", label: "基础用法", level: 2 },
  { id: "props", label: "属性与事件", level: 3 },
  { id: "advanced", label: "高级技巧", level: 2 },
  { id: "faq", label: "常见问题", level: 2 },
  { id: "summary", label: "总结", level: 2 },
]

const meta = {
  author: "林晓",
  date: "2026 年 10 月 15 日",
  readTime: "约 12 分钟",
  words: "3,842 字",
  tags: ["组件库", "前端", "React", "TypeScript"],
}

const codeNpm = `# 使用 npm 安装
npm install @nebula-ui/react

# 或使用 pnpm
pnpm add @nebula-ui/react

# 或使用 yarn
yarn add @nebula-ui/react`

const codeUsage = `import { Button } from "@nebula-ui/react"
import "@nebula-ui/react/styles.css"

export function App() {
  return (
    <Button variant="primary" size="lg">
      点击我
    </Button>
  )
}`

export function DocDetailPage() {
  const [progress, setProgress] = useState(0)
  const [activeId, setActiveId] = useState("intro")

  useEffect(() => {
    const onScroll = () => {
      const el = document.documentElement
      const scrollTop = el.scrollTop
      const scrollHeight = el.scrollHeight - el.clientHeight
      const pct = scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0
      setProgress(pct)

      // determine active section
      const offsets = toc.map((t) => {
        const node = document.getElementById(t.id)
        return { id: t.id, top: node ? node.getBoundingClientRect().top : Infinity }
      })
      const visible = offsets.filter((o) => o.top <= 120)
      if (visible.length) {
        setActiveId(visible[visible.length - 1].id)
      }
    }
    window.addEventListener("scroll", onScroll, { passive: true })
    onScroll()
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  const scrollTo = (id: string) => {
    const node = document.getElementById(id)
    if (node) {
      const y = node.getBoundingClientRect().top + window.scrollY - 80
      window.scrollTo({ top: y, behavior: "smooth" })
    }
  }

  return (
    <div className="flex flex-col">
      {/* Reading progress */}
      <div className="sticky top-14 z-20 h-0.5 w-full bg-transparent">
        <div
          className="h-full bg-primary transition-[width] duration-150 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_220px]">
        {/* Main article */}
        <article className="min-w-0">
          {/* Header */}
          <header className="flex flex-col gap-5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">指南</Badge>
              <Badge variant="outline">React</Badge>
              <Badge variant="outline">v3.0</Badge>
            </div>
            <h1 className="font-heading text-4xl font-bold leading-tight tracking-tight">
              构建可复用的 React 组件库
            </h1>
            <p className="text-lg leading-relaxed text-muted-foreground">
              本文将带你从零开始，使用 TypeScript 与 Tailwind CSS 构建一套类型安全、主题可定制、可按需加载的 React 组件库，涵盖工程化、文档站与发布全流程。
            </p>

            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Avatar className="size-7">
                  <AvatarFallback className="text-xs">LX</AvatarFallback>
                </Avatar>
                <span>{meta.author}</span>
              </div>
              <span className="flex items-center gap-1.5">
                <Calendar className="size-3.5" />
                {meta.date}
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="size-3.5" />
                {meta.readTime}
              </span>
              <span className="flex items-center gap-1.5">
                <FileText className="size-3.5" />
                {meta.words}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Tag className="size-3.5 text-muted-foreground" />
              {meta.tags.map((t) => (
                <span
                  key={t}
                  className="rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground"
                >
                  {t}
                </span>
              ))}
            </div>
          </header>

          <Separator className="my-8" />

          {/* Body */}
          <div className="flex flex-col gap-8 text-[15px] leading-7">
            <section id="intro" className="flex flex-col gap-4 scroll-mt-24">
              <p>
                组件库是现代前端工程化的重要基础设施。一套优秀的组件库不仅能提升团队开发效率，还能保证产品视觉与交互的一致性。
                本文将以 <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">Nebula UI</code> 为例，
                讲解从工程搭建到组件实现的完整思路。
              </p>
              <p>
                在开始之前，你需要熟悉 React 与 TypeScript 的基本用法，并对 CSS 变量有一定了解。
                如果你是第一次接触组件库开发，建议先阅读<a className="text-primary hover:underline" href="#">快速开始</a>章节。
              </p>
              <blockquote className="border-l-4 border-primary/40 bg-muted/40 py-3 pl-4 italic text-muted-foreground">
                "好的组件库应当让使用者忘记它的存在——它只是自然地解决问题。"
                <footer className="mt-1 text-sm not-italic">— Nebula UI 设计原则</footer>
              </blockquote>
            </section>

            <section id="install" className="flex flex-col gap-4 scroll-mt-24">
              <h2 className="font-heading text-2xl font-semibold tracking-tight">安装与配置</h2>
              <p>
                Nebula UI 提供多种包管理器的安装方式。推荐使用 <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">pnpm</code> 以获得更优的依赖管理体验。
              </p>

              <Tabs defaultValue="npm">
                <TabsList variant="line">
                  <TabsTrigger value="npm">npm</TabsTrigger>
                  <TabsTrigger value="pnpm">pnpm</TabsTrigger>
                  <TabsTrigger value="yarn">yarn</TabsTrigger>
                </TabsList>
                <TabsContent value="npm" className="mt-4">
                  <CodeBlock code={codeNpm} lang="bash" />
                </TabsContent>
                <TabsContent value="pnpm" className="mt-4">
                  <CodeBlock code={codeNpm} lang="bash" />
                </TabsContent>
                <TabsContent value="yarn" className="mt-4">
                  <CodeBlock code={codeNpm} lang="bash" />
                </TabsContent>
              </Tabs>

              <Alert>
                <Info className="size-4" />
                <AlertTitle>需要 React 18+</AlertTitle>
                <AlertDescription>
                  Nebula UI 依赖 React 18 及以上版本，同时需要 TypeScript 5.0+ 以获得完整的类型支持。
                </AlertDescription>
              </Alert>
            </section>

            <section id="basic" className="flex flex-col gap-4 scroll-mt-24">
              <h2 className="font-heading text-2xl font-semibold tracking-tight">基础用法</h2>
              <p>
                安装完成后，在入口文件中引入样式，即可在组件中直接使用。所有组件都遵循一致的命名与 API 规范。
              </p>
              <CodeBlock code={codeUsage} lang="tsx" />

              <h3 id="props" className="font-heading text-xl font-semibold scroll-mt-24">属性与事件</h3>
              <p>
                组件通过 <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">variant</code>、
                <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">size</code> 等属性控制外观，
                通过标准的 React 事件处理交互。
              </p>

              <div className="overflow-hidden rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr className="text-left">
                      <th className="px-4 py-2.5 font-medium">属性</th>
                      <th className="px-4 py-2.5 font-medium">类型</th>
                      <th className="px-4 py-2.5 font-medium">默认值</th>
                      <th className="px-4 py-2.5 font-medium">说明</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {[
                      ["variant", `"default" | "primary" | "ghost"`, `"default"`, "按钮的视觉风格"],
                      ["size", `"sm" | "md" | "lg"`, `"md"`, "按钮尺寸"],
                      ["disabled", `boolean`, `false`, "是否禁用"],
                      ["onClick", `(e) => void`, `-`, "点击事件回调"],
                    ].map((row) => (
                      <tr key={row[0]} className="hover:bg-muted/30">
                        <td className="px-4 py-2.5 font-mono text-primary">{row[0]}</td>
                        <td className="px-4 py-2.5 font-mono text-muted-foreground">{row[1]}</td>
                        <td className="px-4 py-2.5 font-mono">{row[2]}</td>
                        <td className="px-4 py-2.5">{row[3]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section id="advanced" className="flex flex-col gap-4 scroll-mt-24">
              <h2 className="font-heading text-2xl font-semibold tracking-tight">高级技巧</h2>

              <Alert variant="default" className="border-amber-500/30 bg-amber-500/5">
                <Lightbulb className="size-4 text-amber-600 dark:text-amber-400" />
                <AlertTitle>性能提示</AlertTitle>
                <AlertDescription>
                  使用按需导入而非全量引入，可显著减小打包体积。配合 Tree Shaking 与代码分割，首屏加载可减少 60% 以上。
                </AlertDescription>
              </Alert>

              <p>组件库的进阶能力包括：</p>
              <ul className="ml-5 flex list-disc flex-col gap-2">
                <li>基于 CSS 变量的主题系统，支持运行时切换</li>
                <li>通过 <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">render</code> 属性自定义渲染元素</li>
                <li>组合式组件 API，灵活控制子元素行为</li>
                <li>服务端渲染兼容，无障碍属性开箱即用</li>
              </ul>

              <Alert variant="destructive">
                <AlertTriangle className="size-4" />
                <AlertTitle>避免这些误区</AlertTitle>
                <AlertDescription>
                  不要在组件内部直接操作 DOM；不要混用受控与非受控模式；不要为了灵活性牺牲类型安全。
                </AlertDescription>
              </Alert>
            </section>

            <section id="faq" className="flex flex-col gap-4 scroll-mt-24">
              <h2 className="font-heading text-2xl font-semibold tracking-tight">常见问题</h2>
              <div className="flex flex-col gap-3">
                {[
                  {
                    q: "是否支持 Vue 或其他框架？",
                    a: "目前仅提供 React 版本。框架无关的 Web Components 版本正在规划中。",
                  },
                  {
                    q: "如何参与贡献？",
                    a: "欢迎在 GitHub 提交 Issue 与 PR。贡献前请阅读贡献指南并确保通过 CI 检查。",
                  },
                ].map((item) => (
                  <div key={item.q} className="rounded-lg border p-4">
                    <p className="font-medium">{item.q}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{item.a}</p>
                  </div>
                ))}
              </div>
            </section>

            <section id="summary" className="flex flex-col gap-4 scroll-mt-24">
              <h2 className="font-heading text-2xl font-semibold tracking-tight">总结</h2>
              <Alert>
                <CheckCircle2 className="size-4" />
                <AlertTitle>你已掌握</AlertTitle>
                <AlertDescription>
                  恭喜！你已经了解了 Nebula UI 的安装、基础用法、属性配置与高级技巧。
                  接下来可以阅读组件库文档，探索更多组件的详细用法。
                </AlertDescription>
              </Alert>
            </section>
          </div>

          <Separator className="my-8" />

          {/* Footer actions */}
          <footer className="flex flex-col gap-5">
            <div className="flex items-center justify-between rounded-lg border bg-muted/30 p-4">
              <div>
                <p className="font-medium">这篇文档对你有帮助吗？</p>
                <p className="text-sm text-muted-foreground">你的反馈将帮助我们持续改进</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <ThumbsUp className="size-4" />
                  有帮助
                </Button>
                <Button variant="outline" size="sm">
                  <ThumbsDown className="size-4" />
                  待改进
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <a className="inline-flex items-center gap-1.5 hover:text-foreground" href="#">
                <GitBranch className="size-3.5" />
                在 GitHub 上编辑此页
              </a>
              <span>最后更新：{meta.date}</span>
            </div>

            {/* Prev / Next */}
            <div className="grid gap-4 sm:grid-cols-2">
              <a href="#" className="group rounded-lg border p-4 transition-colors hover:border-primary/50 hover:bg-muted/30">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <ArrowLeft className="size-3.5" />
                  上一篇
                </div>
                <p className="mt-1 font-medium">快速开始</p>
              </a>
              <a href="#" className="group rounded-lg border p-4 text-right transition-colors hover:border-primary/50 hover:bg-muted/30">
                <div className="flex items-center justify-end gap-1.5 text-xs text-muted-foreground">
                  下一篇
                  <ArrowRight className="size-3.5" />
                </div>
                <p className="mt-1 font-medium">组件库详解</p>
              </a>
            </div>
          </footer>
        </article>

        {/* TOC sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-24 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <List className="size-4 text-muted-foreground" />
              本页目录
            </div>
            <nav className="flex flex-col gap-0.5 border-l">
              {toc.map((t) => (
                <button
                  key={t.id}
                  onClick={() => scrollTo(t.id)}
                  className={`flex items-center gap-1.5 py-1.5 text-left text-sm transition-colors ${
                    activeId === t.id
                      ? "border-l-2 border-primary -ml-px pl-3 text-primary"
                      : "pl-4 text-muted-foreground hover:text-foreground"
                  } ${t.level === 3 ? "pl-7 text-xs" : ""}`}
                >
                  {t.level === 3 && <Hash className="size-3 opacity-50" />}
                  {t.label}
                </button>
              ))}
            </nav>
          </div>
        </aside>
      </div>
    </div>
  )
}

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  return (
    <div className="overflow-hidden rounded-lg bg-zinc-950 text-zinc-100">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2">
        <span className="text-xs font-medium text-zinc-400">{lang}</span>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 gap-1 px-2 text-xs text-zinc-400 hover:bg-white/5 hover:text-zinc-100"
          onClick={() => navigator.clipboard?.writeText(code)}
        >
          <Copy className="size-3.5" />
          复制
        </Button>
      </div>
      <pre className="overflow-x-auto p-4 text-sm leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  )
}
