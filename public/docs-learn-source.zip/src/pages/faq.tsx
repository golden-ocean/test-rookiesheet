import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Separator } from "@/components/ui/separator"
import { MessageSquare, HelpCircle, Search } from "lucide-react"
import { faqs } from "@/lib/data"
import { Input } from "@/components/ui/input"
import { useState } from "react"

export function FaqPage() {
  const [query, setQuery] = useState("")
  const filtered = faqs.filter(
    (f) =>
      f.q.toLowerCase().includes(query.toLowerCase()) ||
      f.a.toLowerCase().includes(query.toLowerCase()),
  )

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-col gap-3">
        <Badge variant="secondary" className="w-fit">支持中心</Badge>
        <h1 className="font-heading text-4xl font-bold tracking-tight">常见问题</h1>
        <p className="max-w-2xl text-lg text-muted-foreground">
          汇集开发者最常遇到的问题与解答。如果没有找到答案，欢迎在社区发起讨论。
        </p>
      </header>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="搜索问题关键词…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_280px]">
        {/* FAQ list */}
        <Card>
          <CardContent className="pt-6">
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-12 text-center">
                <HelpCircle className="size-10 text-muted-foreground" />
                <p className="text-muted-foreground">没有找到相关问题</p>
              </div>
            ) : (
              <Accordion defaultValue={["item-0"]}>
                {filtered.map((f, idx) => (
                  <AccordionItem key={f.q} value={`item-${idx}`}>
                    <AccordionTrigger className="text-left text-base">
                      {f.q}
                    </AccordionTrigger>
                    <AccordionContent>
                      <p className="leading-relaxed text-muted-foreground">{f.a}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </CardContent>
        </Card>

        {/* Sidebar: contact */}
        <aside className="flex flex-col gap-4">
          <Card>
            <CardHeader>
              <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <MessageSquare className="size-5" />
              </div>
              <CardTitle>没有找到答案？</CardTitle>
              <CardDescription>
                我们的社区与核心团队随时为你提供帮助。
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-2">
              <a className="text-sm text-primary hover:underline" href="#">查看 GitHub Issues →</a>
              <a className="text-sm text-primary hover:underline" href="#">加入 Discord 讨论 →</a>
              <a className="text-sm text-primary hover:underline" href="#">发送邮件给团队 →</a>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">状态</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">系统运行</span>
                <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">正常</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">API 响应</span>
                <span className="text-sm font-medium tabular-nums">42ms</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">CDN 节点</span>
                <span className="text-sm font-medium tabular-nums">12 个</span>
              </div>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  )
}
