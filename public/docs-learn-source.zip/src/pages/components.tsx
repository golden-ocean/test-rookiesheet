import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { ArrowRight, Search } from "lucide-react"
import { componentCategories } from "@/lib/data"
import { Input } from "@/components/ui/input"
import { useState } from "react"

export function ComponentsPage() {
  const [query, setQuery] = useState("")

  const filtered = componentCategories
    .map((cat) => ({
      ...cat,
      items: cat.items.filter(
        (i) =>
          i.name.toLowerCase().includes(query.toLowerCase()) ||
          i.desc.toLowerCase().includes(query.toLowerCase()),
      ),
    }))
    .filter((cat) => cat.items.length > 0)

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-col gap-3">
        <Badge variant="secondary" className="w-fit">参考文档</Badge>
        <h1 className="font-heading text-4xl font-bold tracking-tight">组件库</h1>
        <p className="max-w-2xl text-lg text-muted-foreground">
          浏览全部 58 个组件，按分类查看用法与示例。每个组件都附带可复制的代码片段。
        </p>
      </header>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="搜索组件名称或描述…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Tabs */}
      <Tabs defaultValue="all">
        <TabsList variant="line">
          <TabsTrigger value="all">全部</TabsTrigger>
          {componentCategories.map((c) => (
            <TabsTrigger key={c.name} value={c.name}>
              {c.name}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="flex flex-col gap-8">
            {filtered.map((cat) => (
              <section key={cat.name} className="flex flex-col gap-4">
                <div className="flex items-center gap-2">
                  <cat.icon className="size-5 text-primary" />
                  <h2 className="font-heading text-xl font-semibold">{cat.name}</h2>
                  <Badge variant="outline" className="ml-1">
                    {cat.items.length}
                  </Badge>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {cat.items.map((item) => (
                    <Card
                      key={item.name}
                      className="cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-md"
                    >
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                            <item.icon className="size-5" />
                          </div>
                          <Button variant="ghost" size="icon-sm" className="text-muted-foreground">
                            <ArrowRight className="size-4" />
                          </Button>
                        </div>
                        <CardTitle className="mt-2 text-base">{item.name}</CardTitle>
                        <CardDescription>{item.desc}</CardDescription>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
                <Separator />
              </section>
            ))}
          </div>
        </TabsContent>

        {componentCategories.map((cat) => (
          <TabsContent key={cat.name} value={cat.name} className="mt-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {cat.items.map((item) => (
                <Card key={item.name} className="transition-shadow hover:shadow-md">
                  <CardHeader>
                    <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <item.icon className="size-5" />
                    </div>
                    <CardTitle className="mt-2 text-base">{item.name}</CardTitle>
                    <CardDescription>{item.desc}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" size="sm">
                      查看文档
                      <ArrowRight data-icon="inline-end" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
