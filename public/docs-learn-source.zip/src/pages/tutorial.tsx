import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  CheckCircle2,
  Circle,
  Lightbulb,
  ArrowRight,
  ArrowLeft,
  Copy,
} from "lucide-react"
import { tutorialSteps, codeExamples } from "@/lib/data"
import { useState } from "react"

const tabCode: Record<string, { code: string; lang: string }> = {
  install: { code: codeExamples.install, lang: "bash" },
  usage: { code: codeExamples.usage, lang: "tsx" },
  theme: { code: codeExamples.theme, lang: "css" },
}

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  return (
    <div className="overflow-hidden rounded-lg bg-zinc-950 text-zinc-100">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2">
        <span className="text-xs font-medium text-zinc-400">{lang}</span>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 gap-1 px-2 text-xs text-zinc-400 hover:bg-white/5 hover:text-zinc-100"
          onClick={() => navigator.clipboard?.writeText(code)}
        >
          <Copy className="size-3.5" />
          复制
        </Button>
      </div>
      <pre className="overflow-x-auto p-4 text-sm leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  )
}

export function TutorialPage() {
  const [current, setCurrent] = useState(1)
  const step = tutorialSteps[current - 1]

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-col gap-3">
        <Badge variant="secondary" className="w-fit">实战教程</Badge>
        <h1 className="font-heading text-4xl font-bold tracking-tight">从零构建文档站</h1>
        <p className="max-w-2xl text-lg text-muted-foreground">
          跟随 5 个步骤，完成一个完整的文档站点项目。每一步都附有可运行的代码示例。
        </p>
      </header>

      <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
        {/* Step list */}
        <aside className="lg:sticky lg:top-6 lg:self-start">
          <Card>
            <CardContent className="flex flex-col gap-1 pt-6">
              {tutorialSteps.map((s) => {
                const isDone = s.step < current
                const isActive = s.step === current
                return (
                  <button
                    key={s.step}
                    onClick={() => setCurrent(s.step)}
                    className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors ${
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-accent"
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="size-5 shrink-0" />
                    ) : isActive ? (
                      <Circle className="size-5 shrink-0 fill-primary text-primary" />
                    ) : (
                      <Circle className="size-5 shrink-0 text-muted-foreground/40" />
                    )}
                    <div className="min-w-0">
                      <div className="text-xs text-muted-foreground">步骤 {s.step}</div>
                      <div className="truncate text-sm font-medium">{s.title}</div>
                    </div>
                  </button>
                )
              })}
            </CardContent>
          </Card>
        </aside>

        {/* Step content */}
        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Badge variant="outline">步骤 {step.step} / {tutorialSteps.length}</Badge>
              </div>
              <CardTitle className="text-2xl">{step.title}</CardTitle>
              <CardDescription className="text-base">{step.desc}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-5">
              <p className="leading-relaxed">
                在这一步中，我们将完成「{step.title}」。请仔细阅读说明，并在本地环境中跟随操作。
                遇到问题可以随时回到前一步骤重新查看。
              </p>

              <Tabs defaultValue="install">
                <TabsList variant="line">
                  <TabsTrigger value="install">安装命令</TabsTrigger>
                  <TabsTrigger value="usage">组件用法</TabsTrigger>
                  <TabsTrigger value="theme">主题配置</TabsTrigger>
                </TabsList>
                <TabsContent value="install" className="mt-4">
                  <CodeBlock code={tabCode.install.code} lang={tabCode.install.lang} />
                </TabsContent>
                <TabsContent value="usage" className="mt-4">
                  <CodeBlock code={tabCode.usage.code} lang={tabCode.usage.lang} />
                </TabsContent>
                <TabsContent value="theme" className="mt-4">
                  <CodeBlock code={tabCode.theme.code} lang={tabCode.theme.lang} />
                </TabsContent>
              </Tabs>

              <Alert>
                <Lightbulb className="size-4" />
                <AlertTitle>小贴士</AlertTitle>
                <AlertDescription>
                  建议每完成一个步骤就在浏览器中预览效果，及时发现问题并调整。
                </AlertDescription>
              </Alert>

              <Separator />

              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={() => setCurrent((c) => Math.max(1, c - 1))}
                  disabled={current === 1}
                >
                  <ArrowLeft data-icon="inline-start" />
                  上一步
                </Button>
                <Button
                  onClick={() =>
                    setCurrent((c) => Math.min(tutorialSteps.length, c + 1))
                  }
                  disabled={current === tutorialSteps.length}
                >
                  下一步
                  <ArrowRight data-icon="inline-end" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {current === tutorialSteps.length && (
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader>
                <div className="flex items-center gap-2 text-primary">
                  <CheckCircle2 className="size-6" />
                  <CardTitle className="text-xl">恭喜完成全部教程！</CardTitle>
                </div>
                <CardDescription>
                  你已经掌握了 Nebula 的核心用法。接下来可以探索更多组件，或阅读 FAQ 解决常见疑问。
                </CardDescription>
              </CardHeader>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
