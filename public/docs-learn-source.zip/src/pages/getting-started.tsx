import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import {
  Terminal,
  CheckCircle2,
  AlertCircle,
  Info,
  ArrowRight,
  Package,
  FileCode,
  Palette,
} from "lucide-react"
import { codeExamples } from "@/lib/data"
import type { PageId } from "@/lib/data"

const prerequisites = [
  { name: "Node.js", version: ">= 18.0" },
  { name: "npm / pnpm / yarn", version: "任意包管理器" },
  { name: "React", version: ">= 18.0" },
]

const installSteps = [
  {
    icon: Package,
    title: "1. 初始化项目",
    desc: "运行脚手架命令，交互式选择框架与样式方案。",
  },
  {
    icon: FileCode,
    title: "2. 添加组件",
    desc: "使用 add 命令按需引入组件到你的工程。",
  },
  {
    icon: Palette,
    title: "3. 配置主题",
    desc: "修改设计令牌，适配你的品牌视觉规范。",
  },
]

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  return (
    <div className="overflow-hidden rounded-lg bg-zinc-950 text-zinc-100">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2">
        <span className="text-xs font-medium text-zinc-400">{lang}</span>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs text-zinc-400 hover:bg-white/5 hover:text-zinc-100"
          onClick={() => navigator.clipboard?.writeText(code)}
        >
          复制
        </Button>
      </div>
      <pre className="overflow-x-auto p-4 text-sm leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  )
}

export function GettingStartedPage({ onNavigate }: { onNavigate: (id: PageId) => void }) {
  return (
    <div className="flex flex-col gap-10">
      <header className="flex flex-col gap-3">
        <Badge variant="secondary" className="w-fit">入门指南</Badge>
        <h1 className="font-heading text-4xl font-bold tracking-tight">快速开始</h1>
        <p className="max-w-2xl text-lg text-muted-foreground">
          按照以下步骤，你将在 5 分钟内搭建起一个可运行的 Nebula 项目。
        </p>
      </header>

      {/* Prerequisites */}
      <section className="flex flex-col gap-4">
        <h2 className="font-heading text-xl font-semibold">环境要求</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          {prerequisites.map((p) => (
            <Card key={p.name}>
              <CardContent className="flex items-center justify-between pt-6">
                <div>
                  <div className="font-medium">{p.name}</div>
                  <div className="text-sm text-muted-foreground">{p.version}</div>
                </div>
                <CheckCircle2 className="size-5 text-primary" />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Install steps */}
      <section className="flex flex-col gap-4">
        <h2 className="font-heading text-xl font-semibold">安装步骤</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {installSteps.map((s) => (
            <Card key={s.title}>
              <CardHeader>
                <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <s.icon className="size-5" />
                </div>
                <CardTitle className="text-lg">{s.title}</CardTitle>
                <CardDescription>{s.desc}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>

      {/* CLI install */}
      <section className="flex flex-col gap-4">
        <h2 className="font-heading text-xl font-semibold">命令行安装</h2>
        <CodeBlock code={codeExamples.install} lang="bash" />
        <Alert>
          <Terminal className="size-4" />
          <AlertTitle>提示</AlertTitle>
          <AlertDescription>
            CLI 会自动检测项目类型并写入 components.json 配置文件。
          </AlertDescription>
        </Alert>
      </section>

      {/* Usage */}
      <section className="flex flex-col gap-4">
        <h2 className="font-heading text-xl font-semibold">第一个组件</h2>
        <p className="text-muted-foreground">
          安装完成后，即可在代码中导入并使用组件。所有组件都遵循一致的 API 风格。
        </p>
        <CodeBlock code={codeExamples.usage} lang="tsx" />
      </section>

      {/* Theme */}
      <section className="flex flex-col gap-4">
        <h2 className="font-heading text-xl font-semibold">主题定制</h2>
        <p className="text-muted-foreground">
          所有视觉属性都通过 CSS 变量（设计令牌）控制，修改一处即可全局生效。
        </p>
        <CodeBlock code={codeExamples.theme} lang="css" />
        <Alert variant="destructive">
          <AlertCircle className="size-4" />
          <AlertTitle>注意</AlertTitle>
          <AlertDescription>
            修改设计令牌后，请确保同时更新对应的 oklch 色彩空间值，以保持视觉一致性。
          </AlertDescription>
        </Alert>
      </section>

      <Separator />

      {/* Next */}
      <section className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <Info className="mt-0.5 size-5 text-primary" />
          <div>
            <h3 className="font-medium">准备好深入了吗？</h3>
            <p className="text-sm text-muted-foreground">继续阅读组件库文档，了解全部可用组件。</p>
          </div>
        </div>
        <Button onClick={() => onNavigate("components")}>
          浏览组件库
          <ArrowRight data-icon="inline-end" />
        </Button>
      </section>
    </div>
  )
}
