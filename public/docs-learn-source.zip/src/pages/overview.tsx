import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import {
  ArrowRight,
  CheckCircle2,
  Circle,
  Sparkles,
  Star,
  GitBranch,
  Play,
} from "lucide-react"
import { features, stats, learningPath } from "@/lib/data"
import type { PageId } from "@/lib/data"

export function OverviewPage({ onNavigate }: { onNavigate: (id: PageId) => void }) {
  const completed = learningPath.filter((l) => l.done).length
  const progress = Math.round((completed / learningPath.length) * 100)

  return (
    <div className="flex flex-col gap-10">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/10 via-background to-background p-8 ring-1 ring-border md:p-12">
        <div className="absolute -top-24 -right-24 size-72 rounded-full bg-primary/10 blur-3xl" />
        <div className="relative flex max-w-2xl flex-col gap-5">
          <Badge variant="secondary" className="w-fit gap-1.5">
            <Sparkles className="size-3.5" />
            v3.0 全新发布
          </Badge>
          <h1 className="font-heading text-4xl font-bold tracking-tight md:text-5xl">
            构建令人愉悦的
            <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              {" "}
              文档体验
            </span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Nebula 是一套基于设计令牌的高质量组件库，帮助开发者快速搭建兼具美感与可访问性的文档与学习平台。
          </p>
          <div className="flex flex-wrap gap-3 pt-1">
            <Button size="lg" onClick={() => onNavigate("getting-started")}>
              快速开始
              <ArrowRight data-icon="inline-end" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => onNavigate("components")}>
              <Play data-icon="inline-start" />
              浏览组件
            </Button>
          </div>
          <div className="flex items-center gap-4 pt-2 text-sm text-muted-foreground">
            <a className="inline-flex items-center gap-1.5 hover:text-foreground" href="#">
              <GitBranch className="size-4" />
              GitHub
            </a>
            <a className="inline-flex items-center gap-1.5 hover:text-foreground" href="#">
              <Star className="size-4" />
              62.4k Star
            </a>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="flex flex-col gap-1 pt-6">
              <span className="font-heading text-3xl font-bold tabular-nums">{s.value}</span>
              <span className="text-sm text-muted-foreground">{s.label}</span>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* Features */}
      <section className="flex flex-col gap-5">
        <div className="flex flex-col gap-1">
          <h2 className="font-heading text-2xl font-semibold tracking-tight">为什么选择 Nebula</h2>
          <p className="text-muted-foreground">为开发者与设计师打造的现代化组件方案</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {features.map((f) => (
            <Card key={f.title} className="transition-shadow hover:shadow-md">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <f.icon className="size-5" />
                  </div>
                  <CardTitle>{f.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  {f.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Learning path */}
      <section className="flex flex-col gap-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="flex flex-col gap-1">
            <h2 className="font-heading text-2xl font-semibold tracking-tight">学习路径</h2>
            <p className="text-muted-foreground">按顺序完成，循序渐进掌握全部能力</p>
          </div>
          <Badge variant="outline">已完成 {completed}/{learningPath.length}</Badge>
        </div>
        <Card>
          <CardContent className="flex flex-col gap-5 pt-6">
            <Progress value={progress} />
            <div className="flex flex-col">
              {learningPath.map((item, idx) => (
                <div key={item.step} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    {item.done ? (
                      <CheckCircle2 className="size-6 text-primary" />
                    ) : (
                      <Circle className="size-6 text-muted-foreground/50" />
                    )}
                    {idx < learningPath.length - 1 && (
                      <div className="mt-1 w-px flex-1 bg-border" />
                    )}
                  </div>
                  <div className="pb-6">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{item.step}</span>
                      <h3 className="font-medium">{item.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <Separator />
            <Button variant="outline" className="self-start" onClick={() => onNavigate("tutorial")}>
              查看完整教程
              <ArrowRight data-icon="inline-end" />
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
