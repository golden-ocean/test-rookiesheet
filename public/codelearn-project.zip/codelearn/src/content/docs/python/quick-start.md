---
title: Python 快速开始
description: 写出第一个 Python 程序，掌握基本语法结构。
language: python
order: 2
updated: 2026-10-18
minutes: 8
tags: [入门, 基础语法]
---

## 第一个程序

创建 `hello.py`：

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

print(greet("World"))
# 输出：Hello, World!
```

运行方式：

```bash
python hello.py
```

## 基本语法要点

1. **无需声明类型**（但支持类型注解）
2. **缩进即语法**：使用 4 个空格表示代码块
3. **动态类型**：变量无需预先声明类型

## 常用内置类型

```python
# 数字
age = 25              # int
price = 9.99          # float

# 文本
name = "Alice"        # str

# 集合
tags = ["python", "dev"]        # list
point = (3, 4)                  # tuple
user = {"name": "Alice"}        # dict
unique = {1, 2, 3}              # set
```

<details>
<summary>为什么 Python 不需要分号？</summary>

Python 以换行作为语句结束符，分号是可选的。这是它简洁风格的一部分。
</details>

## 下一步

继续学习[变量与类型](/docs/python/variables)深入了解类型系统。
