---
title: Go 简介与安装
description: 了解 Go 语言特性，搭建开发环境。
language: go
order: 1
updated: 2026-10-18
minutes: 5
tags: [入门, 安装]
---

## 什么是 Go

Go 是 Google 推出的静态编译型语言，以**部署简单、并发原生支持**著称，是云原生领域的主力语言（Docker、Kubernetes 均由 Go 编写）。

## 安装

从 [go.dev](https://go.dev/dl/) 下载安装，或：

```bash
# macOS
brew install go
# Linux
sudo apt install golang-go
```

## 第一个程序

```go
package main

import "fmt"

func main() {
    fmt.Println("Hello, 世界!")
}
```

运行：`go run main.go`

## 下一步

前往[并发编程](/docs/go/concurrency)学习 goroutine 与 channel。
