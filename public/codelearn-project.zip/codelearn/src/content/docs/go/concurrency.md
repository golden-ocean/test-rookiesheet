---
title: Go 并发编程
description: 掌握 goroutine、channel 与常见并发模式。
language: go
order: 2
updated: 2026-10-18
minutes: 12
tags: [核心概念, 并发]
---

## goroutine

goroutine 是 Go 的轻量级线程，启动成本极低：

```go
go doWork() // 用 go 关键字即可并发执行
```

## channel

> 不要通过共享内存来通信，而要通过通信来共享内存。

```go
ch := make(chan string, 1)

go func() {
    ch <- "结果数据"
}()

msg := <-ch // 阻塞直到收到数据
```

## 常见并发模式

### WaitGroup 等待一组任务

```go
var wg sync.WaitGroup
for _, task := range tasks {
    wg.Add(1)
    go func(t Task) {
        defer wg.Done()
        process(t)
    }(task)
}
wg.Wait()
```

### select 多路复用

```go
select {
case msg := <-ch1:
    fmt.Println(msg)
case <-time.After(time.Second):
    fmt.Println("超时")
}
```

## 注意事项

- **避免数据竞争**：并发访问共享变量需加锁或用 channel
- 使用 `go run -race` 检测竞争条件
- channel 关闭后仍可读取（收到零值），发送会 panic
