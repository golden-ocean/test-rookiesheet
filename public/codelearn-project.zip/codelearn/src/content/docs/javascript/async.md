---
title: JavaScript 异步编程
description: 掌握 Promise、async/await 与事件循环。
language: javascript
order: 2
updated: 2026-10-18
minutes: 12
tags: [核心概念, 异步]
---

## 为什么需要异步

JavaScript 是**单线程**语言，所有耗时 I/O 都通过异步模型避免阻塞。

## Promise

```javascript
fetch("/api/user")
  .then((res) => res.json())
  .then((data) => console.log(data))
  .catch((err) => console.error(err));
```

## async / await

```javascript
async function loadUser() {
  try {
    const res = await fetch("/api/user");
    return await res.json();
  } catch (err) {
    console.error("加载失败", err);
  }
}
```

## 事件循环要点

1. 同步代码先执行
2. 微任务（Promise.then）优先于宏任务（setTimeout）
3. `await` 之后的代码相当于放入微任务队列

> **常见误区**：在循环中串行 `await` 会显著变慢，可并行时用 `Promise.all`。

```javascript
// 串行 ❌
for (const id of ids) await fetchUser(id);

// 并行 ✅
await Promise.all(ids.map((id) => fetchUser(id)));
```

## 小结

- 优先使用 `async/await`，语义清晰
- 并行任务使用 `Promise.all` / `Promise.allSettled`
- 理解微任务与宏任务的执行顺序
