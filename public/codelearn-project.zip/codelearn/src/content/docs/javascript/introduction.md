---
title: JavaScript 简介与安装
description: 了解 JavaScript 生态，配置 Node.js 开发环境。
language: javascript
order: 1
updated: 2026-10-18
minutes: 6
tags: [入门, 安装]
---

## 什么是 JavaScript

JavaScript 是**浏览器唯一的原生语言**，如今也通过 Node.js 运行在服务端。配合 TypeScript 可以获得完整的静态类型体验。

## 安装 Node.js

推荐使用 [nvm](https://github.com/nvm-sh/nvm) 安装管理 Node.js：

```bash
nvm install --lts
node -v
# v22.x.x
```

## 第一个脚本

```javascript
// hello.js
const greet = (name) => `Hello, ${name}!`;

console.log(greet("World"));
```

运行：`node hello.js`

## 生态速览

| 工具 | 用途 |
| --- | --- |
| npm / pnpm | 包管理 |
| Vite | 构建工具 |
| Vitest | 测试框架 |

## 下一步

前往[异步编程](/docs/javascript/async)了解 JS 最核心的事件循环模型。
