import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

/**
 * docs 内容集合
 * 目录结构：src/content/docs/<language>/<slug>.md
 */
const docs = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/docs' }),
  schema: z.object({
    title: z.string(),
    description: z.string().optional(),
    // 所属语言（用于侧边栏分组）
    language: z.string(),
    // 侧边栏排序，越小越靠前
    order: z.number().default(0),
    updated: z.coerce.date(),
    // 预计阅读分钟数
    minutes: z.number().default(8),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

export const collections = { docs };
