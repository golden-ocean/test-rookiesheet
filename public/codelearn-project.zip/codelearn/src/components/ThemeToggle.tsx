import { Button } from "@/components/ui/button";
import { Moon, Sun, Monitor } from "lucide-react";

/**
 * 主题切换：light → dark → system 循环
 * 逻辑与 Layout.astro 中的防闪烁脚本约定一致（localStorage key: theme）
 */
type Theme = "light" | "dark" | "system";
const ORDER: Theme[] = ["light", "dark", "system"];
const LABEL: Record<Theme, string> = { light: "浅色", dark: "深色", system: "跟随系统" };

function apply(theme: Theme) {
  const isDark =
    theme === "dark" ||
    (theme === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", isDark);
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("theme", theme);
}

export function ThemeToggle() {
  return (
    <Button
      variant="ghost"
      size="icon"
      className="size-9"
      aria-label="切换主题"
      title="切换主题（浅色 / 深色 / 系统）"
      // @ts-expect-error — 使用原生事件处理，避免引入额外的客户端框架开销
      onClick={(e: MouseEvent) => {
        const el = e.currentTarget as HTMLElement;
        const current = (document.documentElement.dataset.theme as Theme) ?? "system";
        const next = ORDER[(ORDER.indexOf(current) + 1) % ORDER.length];
        apply(next);
        // 切换图标显示
        el.querySelectorAll("[data-icon]").forEach((i) => {
          (i as HTMLElement).style.display = i.getAttribute("data-icon") === next ? "" : "none";
        });
        el.setAttribute("title", `当前：${LABEL[next]}`);
      }}
    >
      <Sun data-icon="light" className="hidden size-4" />
      <Moon data-icon="dark" className="hidden size-4" />
      <Monitor data-icon="system" className="size-4" />
    </Button>
  );
}

export default ThemeToggle;
