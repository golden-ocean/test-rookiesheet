import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PagerProps {
  prev?: { title: string; href: string };
  next?: { title: string; href: string };
}

export function Pager({ prev, next }: PagerProps) {
  if (!prev && !next) return null;

  return (
    <nav aria-label="翻页" className="mt-12 flex items-stretch justify-between gap-4 border-t border-border pt-8">
      {prev ? (
        <Button asChild variant="outline" className="h-auto min-w-44 flex-col items-start gap-0.5 px-4 py-3 text-left">
          <a href={prev.href}>
            <span className="flex items-center text-xs text-muted-foreground">
              <ChevronLeft className="size-3.5" /> 上一篇
            </span>
            <span className="text-sm font-medium text-foreground">{prev.title}</span>
          </a>
        </Button>
      ) : (
        <span />
      )}

      {next ? (
        <Button asChild variant="outline" className="h-auto min-w-44 flex-col items-end gap-0.5 px-4 py-3 text-right">
          <a href={next.href}>
            <span className="flex items-center text-xs text-muted-foreground">
              下一篇 <ChevronRight className="size-3.5" />
            </span>
            <span className="text-sm font-medium text-foreground">{next.title}</span>
          </a>
        </Button>
      ) : (
        <span />
      )}
    </nav>
  );
}

export default Pager;
