export interface TocItem {
  depth: number;
  slug: string;
  text: string;
}

interface TocProps {
  headings: TocItem[];
}

export function Toc({ headings }: TocProps) {
  if (headings.length === 0) return null;

  return (
    <aside className="hidden w-56 shrink-0 xl:block">
      <div className="sticky top-24 h-[calc(100vh-8rem)] overflow-y-auto pb-8">
        <p className="mb-3 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          本页目录
        </p>
        <nav className="border-l border-border">
          {headings
            .filter((h) => h.depth <= 3)
            .map((h) => (
              <a
                key={h.slug}
                href={`#${h.slug}`}
                className={
                  "block border-l-2 border-transparent py-1 text-sm leading-6 text-muted-foreground transition-colors hover:text-foreground " +
                  (h.depth === 2 ? "pl-3" : "pl-6 text-[13px]")
                }
              >
                {h.text}
              </a>
            ))}
        </nav>
      </div>
    </aside>
  );
}

export default Toc;
