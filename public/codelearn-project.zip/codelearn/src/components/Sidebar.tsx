import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { ChevronRight } from "lucide-react";

export interface SidebarGroup {
  title: string;
  items: { title: string; href: string; isActive?: boolean }[];
}

interface SidebarProps {
  groups: SidebarGroup[];
  currentLanguage: string;
}

const LANG_LABEL: Record<string, string> = {
  python: "Python 教程",
  javascript: "JavaScript 教程",
  go: "Go 教程",
};

export function Sidebar({ groups, currentLanguage }: SidebarProps) {
  return (
    <aside className="hidden w-64 shrink-0 md:block">
      <ScrollArea className="h-[calc(100vh-8rem)] pe-2">
        <div className="pb-8">
          <div className="mb-3 flex items-center gap-1.5 px-2 text-sm font-semibold">
            {LANG_LABEL[currentLanguage] ?? currentLanguage}
            <ChevronRight className="size-3.5 text-muted-foreground" />
          </div>
          {groups.map((group, i) => (
            <div key={group.title}>
              {i > 0 && <Separator className="my-3" />}
              <h4 className="mb-1.5 px-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {group.title}
              </h4>
              <nav className="space-y-0.5">
                {group.items.map((item) => (
                  <a
                    key={item.href}
                    href={item.href}
                    aria-current={item.isActive ? "page" : undefined}
                    className={
                      "block rounded-md px-2 py-1.5 text-sm transition-colors " +
                      (item.isActive
                        ? "bg-accent font-medium text-accent-foreground"
                        : "text-muted-foreground hover:bg-accent/50 hover:text-foreground")
                    }
                  >
                    {item.title}
                  </a>
                ))}
              </nav>
            </div>
          ))}
        </div>
      </ScrollArea>
    </aside>
  );
}

export default Sidebar;
