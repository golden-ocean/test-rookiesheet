import { Code2 } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-3 px-6 py-8 text-sm text-muted-foreground md:flex-row">
        <div className="flex items-center gap-2">
          <span className="grid size-5 place-items-center rounded bg-primary text-primary-foreground">
            <Code2 className="size-3" />
          </span>
          CodeLearn
        </div>
        <p>基于 Astro + shadcn/ui 构建 · © 2026 CodeLearn</p>
        <div className="flex gap-4">
          <a href="#" className="transition-colors hover:text-foreground">关于</a>
          <a href="#" className="transition-colors hover:text-foreground">GitHub</a>
          <a href="#" className="transition-colors hover:text-foreground">RSS</a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
