import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Code2, Search } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";

interface HeaderProps {
  currentLang?: string;
  /** 语言切换项（来自 languages 内容集合） */
  languages?: { key: string; label: string }[];
}

const fallbackLanguages = [
  { key: "python", label: "Python" },
  { key: "javascript", label: "JavaScript" },
  { key: "go", label: "Go" },
];

export function Header({ currentLang, languages = fallbackLanguages }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center gap-6 px-6">
        <a href="/" className="flex items-center gap-2 font-bold tracking-tight">
          <span className="grid size-7 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Code2 className="size-4" />
          </span>
          CodeLearn
        </a>

        <nav className="hidden items-center gap-5 text-sm text-muted-foreground md:flex">
          <a href="/" className="transition-colors hover:text-foreground">首页</a>
          <a href="/docs/python/quick-start" className="font-medium text-foreground">文档</a>
          <a href="#" className="transition-colors hover:text-foreground">练习</a>
          <a href="#" className="transition-colors hover:text-foreground">社区</a>
        </nav>

        <div className="relative ml-auto hidden w-56 md:block">
          <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="搜索文档…" className="h-9 pl-8" />
        </div>

        <div className="ml-auto flex items-center gap-2 md:ml-0">
          {languages.map((lang) => (
            <Button
              key={lang.key}
              asChild
              variant={currentLang === lang.key ? "default" : "ghost"}
              size="sm"
              className="hidden lg:inline-flex"
            >
              <a href={`/docs/${lang.key}/introduction`}>{lang.label}</a>
            </Button>
          ))}
          <Badge variant="secondary" className="hidden xl:inline-flex">v3</Badge>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}

export default Header;
