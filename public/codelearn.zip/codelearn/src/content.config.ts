import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

/**
 * docs 内容集合
 * 目录结构：src/content/docs/<language>/<slug>.md
 */
const docs = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/docs' }),
  schema: z.object({
    title: z.string(),
    description: z.string().optional(),
    // 所属语言（用于侧边栏分组）
    language: z.string(),
    // 侧边栏排序，越小越靠前
    order: z.number().default(0),
    updated: z.coerce.date(),
    // 预计阅读分钟数
    minutes: z.number().default(8),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

/**
 * languages 内容集合：编程语言元信息
 * 目录结构：src/content/languages/<key>.md（slug 即语言 key）
 * 新增一门语言：添加本文件 + 在 docs/ 下新增对应文章即可，站点自动更新
 */
const languages = defineCollection({
  loader: glob({ pattern: '*.md', base: './src/content/languages' }),
  schema: z.object({
    name: z.string(), // 展示名，如 "Python"
    emoji: z.string().default("📘"),
    // 卡片配色（tailwind 类名）
    color: z.string().default("bg-zinc-100"),
    description: z.string(),
    // 首页卡片排序
    order: z.number().default(0),
    // 是否在首页/Header 中展示
    featured: z.boolean().default(true),
  }),
});

export const collections = { docs, languages };
