---
name: Go
emoji: 🐹
color: bg-emerald-100
description: 云原生时代的并发利器
order: 3
featured: true
---

Go 是 Google 推出的静态编译型语言，以**部署简单、并发原生支持**著称，Docker、Kubernetes 均由 Go 编写。

## 适合人群

- 后端与云原生方向开发者
- 追求部署简单、性能可靠的工程师

## 本教程路线

1. **入门**：简介与安装
2. **核心概念**：并发编程
