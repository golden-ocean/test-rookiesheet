---
name: JavaScript
emoji: 🟨
color: bg-blue-100
description: Web 世界唯一的原生语言
order: 2
featured: true
---

JavaScript 是**浏览器唯一的原生语言**，如今也通过 Node.js 运行在服务端，配合 TypeScript 可获得完整的静态类型体验。

## 适合人群

- 想做网页与前端开发的学习者
- 全栈方向的开发者

## 本教程路线

1. **入门**：简介与安装
2. **核心概念**：异步编程、原型与闭包
