import { ArticleHero } from "@/components/article-hero"
import { BackToTop } from "@/components/back-to-top"
import { CommandPalette } from "@/components/command-palette"
import { DocsSidebar } from "@/components/docs-sidebar"
import { ReadingProgress } from "@/components/reading-progress"
import { SectionSpy } from "@/components/section-spy"
import { SiteFooter } from "@/components/site-footer"
import { SiteHeader } from "@/components/site-header"
import { TableOfContents } from "@/components/table-of-contents"
import { Pager } from "@/components/ui/pager"

import { Concurrency } from "@/components/sections/concurrency"
import { ControlFlow } from "@/components/sections/control-flow"
import { DataStructures } from "@/components/sections/data-structures"
import { ErrorHandling } from "@/components/sections/error-handling"
import { Functions } from "@/components/sections/functions"
import { Modules } from "@/components/sections/modules"
import { Oop } from "@/components/sections/oop"
import { Overview } from "@/components/sections/overview"
import { Performance } from "@/components/sections/performance"
import { Pitfalls } from "@/components/sections/pitfalls"
import { Resources } from "@/components/sections/resources"
import { Roadmap } from "@/components/sections/roadmap"
import { Usage } from "@/components/sections/usage"
import { Variables } from "@/components/sections/variables"

/**
 * 页面只做三件事：搭版式、放章节、挂全局 UI。
 * 正文排版统一交给 .typeset（app/typeset.css），
 * 章节内容在 components/sections/* 里各自成文件。
 */
export default function Page() {
  return (
    <>
      <ReadingProgress />
      <SiteHeader />

      <div className="lg:grid lg:grid-cols-[268px_minmax(0,1fr)]">
        <DocsSidebar />

        <div className="min-w-0">
          <div className="mx-auto grid max-w-[1320px] grid-cols-1 gap-12 px-4 pt-6 pb-20 lg:grid-cols-[minmax(0,1fr)_208px] lg:px-8 lg:pt-10 lg:pb-30 xl:gap-15 xl:px-12">
            <article id="top" className="typeset max-w-[760px] min-w-0">
              <ArticleHero />

              <Overview />
              <Usage />
              <Variables />
              <ControlFlow />
              <Functions />
              <DataStructures />
              <Oop />
              <ErrorHandling />
              <Concurrency />
              <Modules />
              <Performance />
              <Pitfalls />
              <Roadmap />
              <Resources />

              <Pager
                prev={{ href: "#top", dir: "回到顶部", title: "阅读进度与标记" }}
                next={{ href: "#pitfalls", dir: "下一节", title: "常见陷阱" }}
              />
            </article>

            <TableOfContents />
          </div>

          <SiteFooter />
        </div>
      </div>

      <CommandPalette />
      <BackToTop />
      <SectionSpy />
    </>
  )
}
