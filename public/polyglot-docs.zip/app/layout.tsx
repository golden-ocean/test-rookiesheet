import type { Metadata } from "next"

import { Providers } from "@/components/providers"
import "./globals.css"

export const metadata: Metadata = {
  title: "Polyglot · 编程语言学习文档",
  description:
    "一份面向现代编程语言的系统学习文档：类型系统、并发模型、工程实践与学习路线。",
}

/** 在首屏渲染前决定主题，避免深色偏好下的白闪。 */
const themeScript = `(function(){try{var s=localStorage.getItem("polyglot.theme");var dark=s?s==="dark":window.matchMedia("(prefers-color-scheme: dark)").matches;if(dark)document.documentElement.classList.add("dark")}catch(e){}})()`

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
