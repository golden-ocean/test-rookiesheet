"use client"

import { useEffect } from "react"

import { useShell } from "@/components/providers/shell-provider"
import { sectionIds, type SectionId } from "@/lib/docs"

/** 用 IntersectionObserver 把「当前读到哪一节」同步给侧栏与目录。 */
export function SectionSpy() {
  const { setActiveSection } = useShell()

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) setActiveSection(entry.target.id as SectionId)
        }
      },
      { rootMargin: "-88px 0px -70% 0px", threshold: 0 },
    )

    for (const id of sectionIds) {
      const element = document.getElementById(id)
      if (element) observer.observe(element)
    }

    return () => observer.disconnect()
  }, [setActiveSection])

  return null
}
