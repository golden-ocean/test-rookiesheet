"use client"

import { useProgress } from "@/components/providers/progress-provider"

export function ProgressCard() {
  const { done, total, percent } = useProgress()

  return (
    <div data-slot="progress-card" data-block className="rounded-lg border bg-card p-4.5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <strong className="text-[14.5px]">你的学习进度</strong>
        <span className="text-[13px] text-muted-foreground">
          {done.size} / {total} 个章节已掌握
        </span>
      </div>
      <div className="h-[7px] overflow-hidden rounded-full bg-muted">
        <i
          className="block h-full rounded-full bg-foreground transition-[width] duration-300 ease-out"
          style={{ width: `${percent}%` }}
        />
      </div>
      <p className="mt-2.5 text-[12.5px] text-muted-foreground">
        点击每个章节标题右侧的圆圈标记「已掌握」，进度会保存在本地浏览器中。
      </p>
    </div>
  )
}
