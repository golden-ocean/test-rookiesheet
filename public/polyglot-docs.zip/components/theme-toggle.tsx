"use client"

import { Icon } from "@/components/icon"
import { useTheme } from "@/components/providers/theme-provider"

export function ThemeToggle() {
  const { theme, toggle } = useTheme()

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={theme === "dark" ? "切换到浅色主题" : "切换到深色主题"}
      className="grid size-8 cursor-pointer place-items-center rounded-[calc(var(--radius)*0.8)] border border-transparent text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
    >
      <Icon name={theme === "dark" ? "sun" : "moon"} className="size-4" />
    </button>
  )
}
