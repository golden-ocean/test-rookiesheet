"use client"

import { useEffect, useState } from "react"

import { Icon } from "@/components/icon"
import { cn } from "@/lib/cn"

export function BackToTop() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 500)
    window.addEventListener("scroll", onScroll, { passive: true })
    onScroll()
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <button
      type="button"
      aria-label="回到顶部"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={cn(
        "fixed right-5 bottom-5 z-40 grid size-[38px] cursor-pointer place-items-center rounded-full border bg-popover text-muted-foreground shadow-[0_8px_20px_-10px_rgba(0,0,0,0.35)] transition-opacity duration-200 hover:text-foreground",
        visible ? "opacity-100" : "pointer-events-none opacity-0",
      )}
    >
      <Icon name="arrow-up" className="size-4" />
    </button>
  )
}
