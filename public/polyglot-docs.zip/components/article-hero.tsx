import { ProgressCard } from "@/components/progress-card"
import { Badge } from "@/components/ui/badge"
import { Icon } from "@/components/icon"

export function ArticleHero() {
  return (
    <>
      <div className="flex items-center gap-1.5 text-[13px] text-muted-foreground">
        <a href="#overview" className="text-inherit no-underline hover:text-foreground">
          文档
        </a>
        <span className="opacity-50">/</span>
        <a href="#overview" className="text-inherit no-underline hover:text-foreground">
          编程语言
        </a>
        <span className="opacity-50">/</span>
        <span>学习指南</span>
      </div>

      <h1>编程语言学习指南</h1>

      <p className="text-[17px] leading-[1.75] text-muted-foreground">
        一份面向现代编程语言的系统性文档。我们从类型系统讲到内存布局，从并发模型讲到依赖治理，
        用同一组示例对比 TypeScript、Python、Rust 与 Go，帮助你建立可迁移的编程心智模型。
      </p>

      <div className="flex flex-wrap items-center gap-2">
        <Badge>
          <Icon name="sparkles" className="size-3" />
          持续更新
        </Badge>
        <Badge variant="outline">约 45 分钟阅读</Badge>
        <Badge variant="outline">4 种语言对照</Badge>
        <Badge variant="outline">14 个章节</Badge>
      </div>

      <ProgressCard />
    </>
  )
}
