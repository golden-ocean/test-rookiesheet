import { Icon, type IconName } from "@/components/icon"

export interface LinkItem {
  href: string
  icon: IconName
  title: string
  desc: string
}

export function LinkList({ items }: { items: LinkItem[] }) {
  return (
    <div data-slot="link-list" data-block className="grid gap-2.5">
      {items.map((item) => (
        <a
          key={item.title}
          href={item.href}
          target="_blank"
          rel="noreferrer"
          className="group flex items-center gap-3 rounded-lg border bg-card px-4 py-3.5 text-inherit no-underline transition-colors hover:border-ring hover:bg-muted"
        >
          <Icon name={item.icon} className="size-5 flex-none text-muted-foreground" />
          <span className="min-w-0">
            <span className="block text-[14.5px] font-medium">{item.title}</span>
            <span className="block text-[13px] text-muted-foreground">{item.desc}</span>
          </span>
          <Icon
            name="arrow-right"
            className="ml-auto size-4 flex-none text-muted-foreground transition-transform duration-150 group-hover:translate-x-0.5"
          />
        </a>
      ))}
    </div>
  )
}
