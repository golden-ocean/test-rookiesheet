import type { ReactNode } from "react"

import { cn } from "@/lib/cn"

export function Badge({
  children,
  variant = "solid",
}: {
  children: ReactNode
  variant?: "solid" | "outline"
}) {
  return (
    <span
      className={cn(
        "inline-flex h-[22px] items-center gap-1.5 rounded-[calc(var(--radius)*0.7)] border px-2 text-xs leading-none font-medium",
        variant === "solid"
          ? "bg-secondary text-secondary-foreground"
          : "bg-transparent text-foreground",
      )}
    >
      {children}
    </span>
  )
}
