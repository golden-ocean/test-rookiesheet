import type { ReactNode } from "react"

import { Icon, type IconName } from "@/components/icon"
import { cn } from "@/lib/cn"

type CalloutVariant = "info" | "tip" | "warn"

const variants: Record<
  CalloutVariant,
  { icon: IconName; box: string; tone: string }
> = {
  info: { icon: "info", box: "border-border bg-chart-1/40", tone: "text-foreground" },
  tip: { icon: "sparkles", box: "border-border bg-chart-2/20", tone: "text-foreground" },
  warn: {
    icon: "alert",
    box: "border-destructive/35 bg-destructive/10",
    tone: "text-destructive",
  },
}

export function Callout({
  variant = "info",
  title,
  children,
}: {
  variant?: CalloutVariant
  title: string
  children: ReactNode
}) {
  const { icon, box, tone } = variants[variant]

  return (
    <div
      data-slot="callout"
      data-block
      className={cn("flex gap-3 rounded-lg border p-3.5 text-sm leading-relaxed", box)}
    >
      <Icon name={icon} className={cn("mt-[3px] size-4", tone)} />
      <div className="min-w-0">
        <p className="mb-0.5 font-semibold text-foreground">{title}</p>
        <div className="text-muted-foreground [&_p]:m-0">{children}</div>
      </div>
    </div>
  )
}
