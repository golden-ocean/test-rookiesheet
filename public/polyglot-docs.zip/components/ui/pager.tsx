export interface PagerLink {
  href: string
  dir: string
  title: string
}

export function Pager({ prev, next }: { prev: PagerLink; next: PagerLink }) {
  return (
    <nav
      data-slot="pager"
      className="mt-14 grid grid-cols-1 gap-3 border-t pt-6 sm:grid-cols-2"
      aria-label="章节导航"
    >
      {[prev, next].map((item, index) => (
        <a
          key={item.href + item.title}
          href={item.href}
          className={`flex flex-col gap-0.5 rounded-lg border bg-card px-4 py-3.5 text-inherit no-underline transition-colors hover:border-ring ${
            index === 1 ? "text-right" : ""
          }`}
        >
          <span className="text-xs text-muted-foreground">{item.dir}</span>
          <span className="text-[14.5px] font-medium">{item.title}</span>
        </a>
      ))}
    </nav>
  )
}
