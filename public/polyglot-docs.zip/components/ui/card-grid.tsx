import type { ReactNode } from "react"

import { Icon, type IconName } from "@/components/icon"

export function CardGrid({ children }: { children: ReactNode }) {
  return (
    <div
      data-slot="card-grid"
      data-block
      className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(232px,1fr))]"
    >
      {children}
    </div>
  )
}

export function InfoCard({
  icon,
  title,
  children,
}: {
  icon: IconName
  title: string
  children: ReactNode
}) {
  return (
    <div className="rounded-lg border bg-card p-4.5 text-card-foreground transition-[border-color,transform,box-shadow] duration-150 hover:-translate-y-0.5 hover:border-ring hover:shadow-[0_8px_24px_-12px_rgba(0,0,0,0.25)]">
      <div className="mb-3 grid size-[34px] place-items-center rounded-[calc(var(--radius)*0.8)] bg-muted text-foreground">
        <Icon name={icon} className="size-5" />
      </div>
      <div className="mb-1 text-[14.5px] font-semibold">{title}</div>
      <p className="m-0 text-[13.5px] leading-[1.65] text-muted-foreground">{children}</p>
    </div>
  )
}
