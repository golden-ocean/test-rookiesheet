"use client"

import { Icon } from "@/components/icon"
import { useProgress } from "@/components/providers/progress-provider"
import { useToast } from "@/components/providers/toast-provider"
import { cn } from "@/lib/cn"
import type { SectionId } from "@/lib/docs"

/** 章节标题右侧的「已掌握」圆点，单一职责：改一个 id 的完成状态。 */
export function SectionCheck({ id }: { id: SectionId }) {
  const { done, toggle } = useProgress()
  const { toast } = useToast()
  const isDone = done.has(id)

  return (
    <button
      type="button"
      aria-pressed={isDone}
      aria-label={isDone ? "取消标记本节为已掌握" : "标记本节为已掌握"}
      onClick={() => {
        toggle(id)
        toast(isDone ? "已取消标记" : "已标记为掌握")
      }}
      className={cn(
        "ml-auto grid size-[26px] flex-none place-items-center rounded-full border transition-colors duration-150",
        isDone
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border text-muted-foreground hover:border-ring hover:text-foreground",
      )}
    >
      <Icon
        name="check"
        className={cn("size-3.5 transition-opacity", isDone ? "opacity-100" : "opacity-0")}
      />
    </button>
  )
}
