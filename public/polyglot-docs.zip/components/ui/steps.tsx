import type { ReactNode } from "react"

export interface StepItem {
  title: string
  desc: ReactNode
}

/** 时间线式步骤：序号圆点 + 竖线 + 文案，节奏和正文块一致。 */
export function Steps({ items }: { items: StepItem[] }) {
  return (
    <div data-slot="steps" data-block>
      {items.map((item, index) => (
        <div key={item.title} className="relative pb-6.5 pl-11 last:pb-0">
          {index < items.length - 1 && (
            <span className="absolute top-[30px] bottom-0.5 left-[13px] w-px bg-border" />
          )}
          <span className="absolute top-0 left-0 grid size-7 place-items-center rounded-full border bg-muted text-[12.5px] font-semibold">
            {index + 1}
          </span>
          <div className="mb-0.5 text-[15px] font-semibold">{item.title}</div>
          <p className="m-0 text-sm text-muted-foreground">{item.desc}</p>
        </div>
      ))}
    </div>
  )
}
