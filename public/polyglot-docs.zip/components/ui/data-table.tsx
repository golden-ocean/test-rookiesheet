import type { ReactNode } from "react"

/** 表格本身不写任何样式：行列线、内边距、数字对齐全部由 .typeset 提供。 */
export function DataTable({
  head,
  rows,
}: {
  head: ReactNode[]
  rows: ReactNode[][]
}) {
  return (
    <table>
      <thead>
        <tr>
          {head.map((cell, index) => (
            <th key={index} scope="col">
              {cell}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, rowIndex) => (
          <tr key={rowIndex}>
            {row.map((cell, cellIndex) => (
              <td key={cellIndex}>{cell}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  )
}
