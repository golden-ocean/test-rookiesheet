"use client"

import { useState, type ReactNode } from "react"

import { Icon } from "@/components/icon"
import { cn } from "@/lib/cn"

export interface AccordionItem {
  title: string
  body: ReactNode
}

/** 手风琴：同时只展开一项，行为和原页面一致。 */
export function Accordion({ items }: { items: AccordionItem[] }) {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <div data-slot="accordion" data-block className="overflow-hidden rounded-lg border">
      {items.map((item, index) => {
        const isOpen = open === index
        return (
          <div key={item.title} className="border-b last:border-b-0">
            <button
              type="button"
              aria-expanded={isOpen}
              onClick={() => setOpen(isOpen ? null : index)}
              className="flex w-full cursor-pointer items-center gap-2.5 px-4 py-3.5 text-left text-[14.5px] font-medium transition-colors hover:bg-muted"
            >
              <Icon name="alert" className="size-4 flex-none text-muted-foreground" />
              <span className="min-w-0">{item.title}</span>
              <Icon
                name="chevron-right"
                className={cn(
                  "ml-auto size-4 flex-none text-muted-foreground transition-transform duration-200",
                  isOpen && "rotate-90",
                )}
              />
            </button>
            {isOpen && (
              <div className="px-4 pt-0.5 pb-4 text-sm text-muted-foreground [&_p]:m-0 [&_p+p]:mt-2.5">
                {item.body}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
