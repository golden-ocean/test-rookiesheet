"use client"

import { useMemo, useState } from "react"

import { Icon } from "@/components/icon"
import { useLang } from "@/components/providers/lang-provider"
import { useToast } from "@/components/providers/toast-provider"
import { cn } from "@/lib/cn"
import { tokenClassName, tokenize } from "@/lib/highlight"
import { langIds, langLabels, samples, type LangId, type SampleId } from "@/lib/samples"

function copyByFallback(text: string) {
  const area = document.createElement("textarea")
  area.value = text
  area.style.position = "fixed"
  area.style.opacity = "0"
  document.body.appendChild(area)
  area.select()
  document.execCommand("copy")
  document.body.removeChild(area)
}

/**
 * 代码块：共享顶栏语言，但每个块都可以单独切语言（本地覆盖）。
 * 语法着色走自写分词器，避免为一段示例引入 Shiki/Prism。
 */
export function CodeBlock({ group }: { group: SampleId }) {
  const { lang } = useLang()
  const { toast } = useToast()
  const [picked, setPicked] = useState<LangId | null>(null)
  const [copied, setCopied] = useState(false)

  const active = picked ?? lang
  const source = samples[group][active]
  const tokens = useMemo(() => tokenize(source, active), [source, active])

  const copy = async () => {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(source)
      else copyByFallback(source)
      setCopied(true)
      toast("代码已复制到剪贴板")
      setTimeout(() => setCopied(false), 1600)
    } catch {
      toast("复制失败，请手动选择代码")
    }
  }

  return (
    <div data-slot="code-block" data-block className="overflow-hidden rounded-lg border bg-card">
      <div className="flex flex-wrap items-center gap-2 border-b bg-muted/60 py-1.5 pr-2 pl-2.5">
        <div className="flex flex-wrap items-center gap-0.5" role="tablist" aria-label="示例代码语言">
          {langIds.map((id) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={id === active}
              onClick={() => setPicked(id)}
              className={cn(
                "cursor-pointer rounded-[calc(var(--radius)*0.6)] px-2.5 py-1 font-mono text-xs font-medium transition-colors",
                id === active
                  ? "bg-background text-foreground shadow-[inset_0_0_0_1px_var(--border)]"
                  : "text-muted-foreground hover:bg-background hover:text-foreground",
              )}
            >
              {langLabels[id]}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={copy}
          className="ml-auto inline-flex h-6.5 cursor-pointer items-center gap-1.5 rounded-[calc(var(--radius)*0.7)] border bg-background px-2.5 text-xs text-muted-foreground transition-colors hover:border-ring hover:text-foreground"
        >
          <Icon name="copy" className="size-3.5" />
          <span>{copied ? "已复制" : "复制"}</span>
        </button>
      </div>

      <pre className="m-0 overflow-x-auto p-4 font-mono text-[13.2px] leading-[1.75]">
        <code>
          {tokens.map((token, index) =>
            tokenClassName[token.kind] ? (
              <span key={index} className={tokenClassName[token.kind]}>
                {token.text}
              </span>
            ) : (
              <span key={index}>{token.text}</span>
            ),
          )}
        </code>
      </pre>
    </div>
  )
}
