import type { ReactNode } from "react"

/**
 * 行内代码的统一形态。放在 .typeset 里或自定义内容块里长得完全一样，
 * 因此全部用原子类描述，不依赖父级是不是正文。
 */
export function InlineCode({ children }: { children: ReactNode }) {
  return (
    <code className="rounded-[calc(var(--radius)*0.5)] border border-border bg-muted px-[5px] py-[2px] font-mono text-[0.86em] whitespace-nowrap text-foreground">
      {children}
    </code>
  )
}
