import type { ReactNode } from "react"

import { SectionCheck } from "@/components/ui/section-check"
import type { SectionId } from "@/lib/docs"

/**
 * 一个章节 = 带锚点的标题 + 掌握标记 + 正文。
 * 标题以下的排版全部交给 .typeset，组件自身不定义正文样式。
 */
export function Section({
  id,
  title,
  children,
}: {
  id: SectionId
  title: string
  children: ReactNode
}) {
  return (
    <section id={id}>
      <h2 className="group flex items-center gap-2.5">
        <a
          href={`#${id}`}
          aria-label={`链接到${title}`}
          className="cursor-pointer text-[0.78em] font-normal text-muted-foreground no-underline opacity-0 transition-opacity duration-150 group-hover:opacity-70 focus-visible:opacity-70"
        >
          #
        </a>
        {title}
        <SectionCheck id={id} />
      </h2>
      {children}
    </section>
  )
}

/** 章节内部的二级标题，同样带锚点。 */
export function SubHeading({ id, title }: { id: string; title: string }) {
  return (
    <h3 id={id} className="group flex items-center gap-2.5">
      <a
        href={`#${id}`}
        aria-label={`链接到${title}`}
        className="cursor-pointer text-[0.82em] font-normal text-muted-foreground no-underline opacity-0 transition-opacity duration-150 group-hover:opacity-70 focus-visible:opacity-70"
      >
        #
      </a>
      {title}
    </h3>
  )
}
