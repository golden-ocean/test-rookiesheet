import { InlineCode } from "@/components/ui/inline-code"

export function SiteFooter() {
  return (
    <footer className="border-t px-5 py-5.5 text-center text-[13px] text-muted-foreground">
      <p>
        Polyglot Docs · 使用 <InlineCode>shadcn/ui</InlineCode> 默认主题构建 ·{" "}
        <span suppressHydrationWarning>{new Date().getFullYear()}</span>
      </p>
    </footer>
  )
}
