"use client"

import { useShell } from "@/components/providers/shell-provider"
import { cn } from "@/lib/cn"
import { tocItems } from "@/lib/docs"

export function TableOfContents() {
  const { activeSection, setActiveSection } = useShell()

  return (
    <aside className="hidden lg:block">
      <div className="sticky top-[88px] max-h-[calc(100vh-120px)] overflow-y-auto pl-4.5">
        <div className="mb-2.5 text-xs font-semibold tracking-[0.05em] text-muted-foreground uppercase">
          本页目录
        </div>
        <nav>
          {tocItems.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              onClick={() => setActiveSection(item.id)}
              className={cn(
                "block border-l py-1 pl-2.75 text-[13.5px] no-underline transition-colors",
                activeSection === item.id
                  ? "border-foreground font-medium text-foreground"
                  : "border-border text-muted-foreground hover:text-foreground",
              )}
            >
              {item.title}
            </a>
          ))}
        </nav>
      </div>
    </aside>
  )
}
