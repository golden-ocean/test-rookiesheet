"use client"

import { useProgress } from "@/components/providers/progress-provider"

const circumference = 94.2 // 2πr，r = 15

/** 顶栏的学习进度胶囊：一个圆环 + n/total。 */
export function ProgressPill() {
  const { done, total, percent } = useProgress()

  return (
    <div
      title="学习进度"
      className="hidden h-8 items-center gap-1.5 rounded-full border bg-background px-2.5 text-[12.5px] text-muted-foreground sm:inline-flex"
    >
      <svg className="size-[18px] -rotate-90" viewBox="0 0 36 36" aria-hidden="true">
        <circle className="stroke-border" cx="18" cy="18" r="15" fill="none" strokeWidth={3} />
        <circle
          className="stroke-foreground transition-[stroke-dashoffset] duration-300 ease-out"
          cx="18"
          cy="18"
          r="15"
          fill="none"
          strokeWidth={3}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - (circumference * percent) / 100}
        />
      </svg>
      <span>
        {done.size}/{total}
      </span>
    </div>
  )
}
