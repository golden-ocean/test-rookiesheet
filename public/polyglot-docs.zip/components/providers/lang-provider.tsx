"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"

import { langIds, type LangId } from "@/lib/samples"

interface LangContextValue {
  lang: LangId
  setLang: (lang: LangId) => void
}

const LangContext = createContext<LangContextValue | null>(null)
const storageKey = "polyglot.lang"

const isLang = (value: string | null): value is LangId =>
  value !== null && (langIds as string[]).includes(value)

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LangId>("typescript")

  useEffect(() => {
    const stored = window.localStorage.getItem(storageKey)
    if (isLang(stored)) setLangState(stored)
  }, [])

  const setLang = useCallback((next: LangId) => {
    setLangState(next)
    window.localStorage.setItem(storageKey, next)
  }, [])

  return (
    <LangContext.Provider value={{ lang, setLang }}>
      {children}
    </LangContext.Provider>
  )
}

export function useLang() {
  const value = useContext(LangContext)
  if (!value) throw new Error("useLang 必须在 LangProvider 内使用")
  return value
}
