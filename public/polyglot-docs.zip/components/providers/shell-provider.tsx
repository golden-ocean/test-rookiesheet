"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"

import { sectionIds, type SectionId } from "@/lib/docs"

interface ShellContextValue {
  activeSection: SectionId
  setActiveSection: (id: SectionId) => void
  goTo: (id: SectionId) => void
  sidebarOpen: boolean
  openSidebar: () => void
  closeSidebar: () => void
  paletteOpen: boolean
  openPalette: () => void
  closePalette: () => void
}

const ShellContext = createContext<ShellContextValue | null>(null)

export function ShellProvider({ children }: { children: ReactNode }) {
  const [activeSection, setActiveSection] = useState<SectionId>(sectionIds[0])
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [paletteOpen, setPaletteOpen] = useState(false)

  const openSidebar = useCallback(() => setSidebarOpen(true), [])
  const closeSidebar = useCallback(() => setSidebarOpen(false), [])
  const openPalette = useCallback(() => setPaletteOpen(true), [])
  const closePalette = useCallback(() => setPaletteOpen(false), [])

  const goTo = useCallback((id: SectionId) => {
    const target = document.getElementById(id)
    if (!target) return
    const top = target.getBoundingClientRect().top + window.scrollY - 84
    window.scrollTo({ top, behavior: "smooth" })
    setActiveSection(id)
  }, [])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSidebarOpen(false)
        setPaletteOpen(false)
        return
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault()
        setPaletteOpen((open) => !open)
      }
    }
    document.addEventListener("keydown", onKeyDown)
    return () => document.removeEventListener("keydown", onKeyDown)
  }, [])

  return (
    <ShellContext.Provider
      value={{
        activeSection,
        setActiveSection,
        goTo,
        sidebarOpen,
        openSidebar,
        closeSidebar,
        paletteOpen,
        openPalette,
        closePalette,
      }}
    >
      {children}
    </ShellContext.Provider>
  )
}

export function useShell() {
  const value = useContext(ShellContext)
  if (!value) throw new Error("useShell 必须在 ShellProvider 内使用")
  return value
}
