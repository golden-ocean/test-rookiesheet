"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"

import { sectionIds, type SectionId } from "@/lib/docs"

interface ProgressContextValue {
  done: ReadonlySet<SectionId>
  total: number
  /** 0–100 的整数百分比 */
  percent: number
  toggle: (id: SectionId) => void
}

const ProgressContext = createContext<ProgressContextValue | null>(null)
const storageKey = "polyglot.progress"

const isSectionId = (value: unknown): value is SectionId =>
  typeof value === "string" && (sectionIds as readonly string[]).includes(value)

export function ProgressProvider({ children }: { children: ReactNode }) {
  const [done, setDone] = useState<ReadonlySet<SectionId>>(new Set())

  useEffect(() => {
    try {
      const stored: unknown = JSON.parse(
        window.localStorage.getItem(storageKey) ?? "[]",
      )
      if (Array.isArray(stored)) {
        setDone(new Set(stored.filter(isSectionId)))
      }
    } catch {
      setDone(new Set())
    }
  }, [])

  const toggle = useCallback((id: SectionId) => {
    setDone((previous) => {
      const next = new Set(previous)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      window.localStorage.setItem(storageKey, JSON.stringify([...next]))
      return next
    })
  }, [])

  const total: number = sectionIds.length
  const percent = Math.round((done.size / total) * 100)

  return (
    <ProgressContext.Provider value={{ done, total, percent, toggle }}>
      {children}
    </ProgressContext.Provider>
  )
}

export function useProgress() {
  const value = useContext(ProgressContext)
  if (!value) throw new Error("useProgress 必须在 ProgressProvider 内使用")
  return value
}
