"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react"

import { Icon } from "@/components/icon"
import { cn } from "@/lib/cn"

interface ToastContextValue {
  toast: (message: string) => void
}

const ToastContext = createContext<ToastContextValue | null>(null)

export function ToastProvider({ children }: { children: ReactNode }) {
  const [message, setMessage] = useState<string | null>(null)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const toast = useCallback((next: string) => {
    setMessage(next)
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => setMessage(null), 1600)
  }, [])

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current)
  }, [])

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div
        aria-live="polite"
        className={cn(
          "pointer-events-none fixed bottom-6 left-1/2 z-80 flex -translate-x-1/2 items-center gap-2 rounded-[calc(var(--radius)*0.9)] bg-primary px-3.5 py-2.5 text-[13.5px] text-primary-foreground shadow-[0_12px_30px_-12px_rgba(0,0,0,0.5)] transition-all duration-200",
          message ? "translate-y-0 opacity-100" : "translate-y-3.5 opacity-0",
        )}
      >
        <Icon name="check" className="size-4" />
        <span>{message ?? ""}</span>
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const value = useContext(ToastContext)
  if (!value) throw new Error("useToast 必须在 ToastProvider 内使用")
  return value
}
