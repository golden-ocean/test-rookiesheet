"use client"

import type { ReactNode } from "react"

import { LangProvider } from "./lang-provider"
import { ProgressProvider } from "./progress-provider"
import { ShellProvider } from "./shell-provider"
import { ThemeProvider } from "./theme-provider"
import { ToastProvider } from "./toast-provider"

/** 所有客户端状态集中在这里装配，page.tsx 只负责摆放版式。 */
export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider>
      <LangProvider>
        <ProgressProvider>
          <ToastProvider>
            <ShellProvider>{children}</ShellProvider>
          </ToastProvider>
        </ProgressProvider>
      </LangProvider>
    </ThemeProvider>
  )
}
