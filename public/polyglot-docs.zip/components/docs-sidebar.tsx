"use client"

import { Icon } from "@/components/icon"
import { useProgress } from "@/components/providers/progress-provider"
import { useShell } from "@/components/providers/shell-provider"
import { cn } from "@/lib/cn"
import { navGroups, sectionTitles } from "@/lib/docs"

export function DocsSidebar() {
  const { sidebarOpen, closeSidebar, activeSection, setActiveSection } = useShell()
  const { done } = useProgress()

  return (
    <>
      <div
        onClick={closeSidebar}
        aria-hidden="true"
        className={cn(
          "fixed inset-0 z-40 bg-black/45 transition-opacity duration-200 lg:hidden",
          sidebarOpen ? "opacity-100" : "pointer-events-none opacity-0",
        )}
      />

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-[45] w-[268px] overflow-y-auto border-r border-sidebar-border bg-sidebar px-3 pt-4 pb-6 transition-transform duration-200 ease-out",
          "lg:sticky lg:top-14 lg:z-30 lg:h-[calc(100vh-3.5rem)] lg:translate-x-0 lg:self-start",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="mb-2 flex items-center justify-between border-b border-sidebar-border px-1 pb-3 pl-2.5 lg:hidden">
          <span className="px-2.5 text-xs font-semibold tracking-[0.04em] text-muted-foreground uppercase">
            文档导航
          </span>
          <button
            type="button"
            onClick={closeSidebar}
            aria-label="关闭导航"
            className="grid size-8 cursor-pointer place-items-center rounded-[calc(var(--radius)*0.8)] text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
          >
            <Icon name="x" className="size-4" />
          </button>
        </div>

        {navGroups.map((group) => (
          <div key={group.title} className="mt-5 first:mt-0">
            <div className="mb-1.5 px-2.5 text-xs font-semibold tracking-[0.04em] text-muted-foreground uppercase">
              {group.title}
            </div>
            {group.items.map((item) => {
              const active = activeSection === item.id
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  onClick={() => {
                    setActiveSection(item.id)
                    closeSidebar()
                  }}
                  className={cn(
                    "flex cursor-pointer items-center gap-2 rounded-[calc(var(--radius)*0.7)] px-2.5 py-1.5 text-sm text-sidebar-foreground no-underline transition-colors",
                    active
                      ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground"
                      : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                  )}
                >
                  <Icon name={item.icon} className="size-[15px] opacity-70" />
                  {sectionTitles[item.id]}
                  <span
                    className={cn(
                      "ml-auto size-1.5 rounded-full bg-foreground transition-opacity",
                      done.has(item.id) ? "opacity-80" : "opacity-0",
                    )}
                  />
                </a>
              )
            })}
          </div>
        ))}

        <div className="mt-6 rounded-[var(--radius)] border border-sidebar-border bg-sidebar-accent/55 p-3 text-[12.5px] text-muted-foreground">
          <strong className="text-foreground">Polyglot Docs</strong>
          <br />
          基于 shadcn/ui 默认主题构建 ·{" "}
          <a
            href="https://ui.shadcn.com"
            target="_blank"
            rel="noreferrer"
            className="font-medium text-foreground hover:underline"
          >
            查看组件库
          </a>
        </div>
      </aside>
    </>
  )
}
