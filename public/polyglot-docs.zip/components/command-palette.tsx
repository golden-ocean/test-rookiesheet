"use client"

import { useEffect, useMemo, useRef, useState } from "react"

import { Icon, type IconName } from "@/components/icon"
import { useShell } from "@/components/providers/shell-provider"
import { useTheme } from "@/components/providers/theme-provider"
import { useToast } from "@/components/providers/toast-provider"
import { cn } from "@/lib/cn"
import { tocItems, type SectionId } from "@/lib/docs"

interface Command {
  id: SectionId | "theme" | "share" | "top"
  title: string
  hint: string
  icon: IconName
  tag: "章节" | "操作"
  run: () => void
}

export function CommandPalette() {
  const { paletteOpen, closePalette, goTo, activeSection } = useShell()
  const { theme, toggle } = useTheme()
  const { toast } = useToast()
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  const commands = useMemo<Command[]>(
    () => [
      ...tocItems.map((item) => ({
        id: item.id,
        title: item.title,
        hint: `${item.id} ${item.keywords}`,
        icon: "book" as IconName,
        tag: "章节" as const,
        run: () => goTo(item.id),
      })),
      {
        id: "theme",
        title: "切换深色 / 浅色主题",
        hint: "theme",
        icon: theme === "dark" ? "sun" : "moon",
        tag: "操作",
        run: toggle,
      },
      {
        id: "share",
        title: "复制当前页面链接",
        hint: "share",
        icon: "copy",
        tag: "操作",
        run: () => {
          const url = `${window.location.origin}${window.location.pathname}#${activeSection}`
          void navigator.clipboard?.writeText(url).then(() => toast("链接已复制"))
        },
      },
      {
        id: "top",
        title: "回到页面顶部",
        hint: "top",
        icon: "arrow-up",
        tag: "操作",
        run: () => window.scrollTo({ top: 0, behavior: "smooth" }),
      },
    ],
    [theme, toggle, goTo, toast, activeSection],
  )

  const keyword = query.trim().toLowerCase()
  const filtered = keyword
    ? commands.filter((command) =>
        `${command.title} ${command.hint}`.toLowerCase().includes(keyword),
      )
    : commands
  const visible = filtered.slice(0, 12)

  useEffect(() => {
    if (!paletteOpen) return
    setQuery("")
    setSelected(0)
    inputRef.current?.focus()
  }, [paletteOpen])

  useEffect(() => {
    setSelected(0)
  }, [keyword])

  if (!paletteOpen) return null

  const execute = (command: Command | undefined) => {
    if (!command) return
    command.run()
    closePalette()
  }

  return (
    <div
      className="fixed inset-0 z-70 bg-black/45 px-4 pt-[12vh] pb-4"
      onClick={(event) => {
        if (event.target === event.currentTarget) closePalette()
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="搜索文档"
        className="animate-palette-in mx-auto max-w-[560px] overflow-hidden rounded-[calc(var(--radius)*1.2)] border bg-popover text-popover-foreground shadow-[0_24px_60px_-18px_rgba(0,0,0,0.45)]"
      >
        <div className="flex items-center gap-2.5 border-b px-3.5 py-3">
          <Icon name="search" className="size-4 text-muted-foreground" />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "ArrowDown") {
                event.preventDefault()
                setSelected((index) => Math.min(index + 1, visible.length - 1))
              } else if (event.key === "ArrowUp") {
                event.preventDefault()
                setSelected((index) => Math.max(index - 1, 0))
              } else if (event.key === "Enter") {
                event.preventDefault()
                execute(visible[selected])
              }
            }}
            placeholder="搜索章节、关键字…"
            autoComplete="off"
            className="flex-1 border-0 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground"
          />
          <kbd className="inline-flex h-5 min-w-5 items-center justify-center rounded-[calc(var(--radius)*0.5)] border bg-muted px-1.5 font-sans text-[11px] font-medium text-muted-foreground">
            ESC
          </kbd>
        </div>

        <div className="max-h-80 overflow-y-auto p-1.5">
          {visible.length === 0 ? (
            <div className="p-6 text-center text-[13.5px] text-muted-foreground">
              没有匹配的结果
            </div>
          ) : (
            visible.map((command, index) => (
              <div
                key={command.id}
                role="option"
                aria-selected={index === selected}
                tabIndex={-1}
                onMouseEnter={() => setSelected(index)}
                onClick={() => execute(command)}
                className={cn(
                  "flex cursor-pointer items-center gap-2.5 rounded-[calc(var(--radius)*0.7)] px-2.5 py-2 text-sm",
                  index === selected && "bg-foreground/8",
                )}
              >
                <Icon
                  name={command.icon}
                  className={cn(
                    "size-4",
                    index === selected ? "text-foreground" : "text-muted-foreground",
                  )}
                />
                <span className="flex-1 truncate">{command.title}</span>
                <span className="text-[11px] text-muted-foreground">{command.tag}</span>
              </div>
            ))
          )}
        </div>

        <div className="flex gap-3.5 border-t px-3.5 py-2 text-[11.5px] text-muted-foreground">
          <span>↑ ↓ 切换</span>
          <span>↵ 跳转</span>
          <span>ESC 关闭</span>
        </div>
      </div>
    </div>
  )
}
