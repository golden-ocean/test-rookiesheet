"use client"

import { useLang } from "@/components/providers/lang-provider"
import { cn } from "@/lib/cn"
import { langIds, langShortLabels } from "@/lib/samples"

/** 顶栏的全局语言开关，一次切换全部代码块。 */
export function LangSwitch() {
  const { lang, setLang } = useLang()

  return (
    <div
      role="group"
      aria-label="示例代码语言"
      className="hidden items-center gap-0.5 rounded-[calc(var(--radius)*0.8)] bg-muted p-0.5 sm:flex"
    >
      {langIds.map((id) => (
        <button
          key={id}
          type="button"
          aria-pressed={id === lang}
          onClick={() => setLang(id)}
          className={cn(
            "cursor-pointer rounded-[calc(var(--radius)*0.6)] px-2.5 py-1 text-[12.5px] font-medium transition-colors",
            id === lang
              ? "bg-background text-foreground shadow-[0_1px_2px_rgba(0,0,0,0.06)]"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {langShortLabels[id]}
        </button>
      ))}
    </div>
  )
}
