import { Callout } from "@/components/ui/callout"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function Usage() {
  return (
    <Section id="usage" title="如何使用本指南">
      <p>
        本页所有代码块都支持 <strong>TypeScript / Python / Rust / Go</strong>{" "}
        四种语言的对照。 你可以用顶栏的 <InlineCode>TS / Py / Rs / Go</InlineCode>
        一次切换全部示例， 也可以点击单个代码块左上角的语言标签，只切换那一个块。
      </p>

      <ul>
        <li>
          按 <InlineCode>⌘K</InlineCode> / <InlineCode>Ctrl + K</InlineCode>{" "}
          打开搜索，快速跳转到任意章节。
        </li>
        <li>代码块右上角的「复制」按钮会复制当前语言的完整代码。</li>
        <li>
          章节标题右侧的圆圈用于标记掌握状态，进度保存在{" "}
          <InlineCode>localStorage</InlineCode>。
        </li>
        <li>右上角图标可切换浅色 / 深色主题，默认跟随系统设置。</li>
      </ul>

      <Callout variant="tip" title="建议的阅读方式">
        <p>
          先通读「概述」与「学习路线」建立全局观，再挑一个你还不熟悉的章节深入。同一概念在四种语言里的差异，往往比单个语言的细节更值得注意。
        </p>
      </Callout>
    </Section>
  )
}
