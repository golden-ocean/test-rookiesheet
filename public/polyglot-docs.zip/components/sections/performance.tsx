import { Callout } from "@/components/ui/callout"
import { CodeBlock } from "@/components/ui/code-block"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function Performance() {
  return (
    <Section id="performance" title="性能与内存">
      <p>
        性能问题 90% 出在算法复杂度与内存分配上，而不是语言本身。
        常见误区是过早优化：先用工具测量，再决定是否优化。
      </p>

      <CodeBlock group="performance" />

      <Callout variant="tip" title="先测量，再优化">
        <p>
          用语言自带的 profiler（<InlineCode>node --prof</InlineCode>、
          <InlineCode>cProfile</InlineCode>、<InlineCode>cargo flamegraph</InlineCode>
          、<InlineCode>go test -bench</InlineCode>）找到真正的热点，再动手改。
        </p>
      </Callout>
    </Section>
  )
}
