import { CodeBlock } from "@/components/ui/code-block"
import { Section } from "@/components/ui/section"

export function Oop() {
  return (
    <Section id="oop" title="面向对象与类型系统">
      <p>
        面向对象的「三大特征」在现代语言里已经分化：继承被组合替代，虚函数表被
        trait/interface 替代， 封装则始终保留。关键差异在于多态的实现方式——Rust 与 Go
        采用<strong>静态分发</strong>， TypeScript 在多数场景下是
        <strong>动态分发</strong>。
      </p>

      <CodeBlock group="oop" />
    </Section>
  )
}
