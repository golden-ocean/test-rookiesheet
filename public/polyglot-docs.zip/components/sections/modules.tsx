import { CodeBlock } from "@/components/ui/code-block"
import { DataTable } from "@/components/ui/data-table"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function Modules() {
  return (
    <Section id="modules" title="模块与依赖管理">
      <p>
        现代语言都在往「统一工具链 + 声明式清单」的方向收敛。区别在于清单文件的名字和解析格式，
        以及生态是否做到了「依赖只有一个版本」（单版本解析）。
      </p>

      <DataTable
        head={["生态", "清单文件", "安装工具", "特点"]}
        rows={[
          [
            "Node.js",
            <InlineCode key="a">package.json</InlineCode>,
            <>
              <InlineCode>pnpm</InlineCode> / <InlineCode>npm</InlineCode>
            </>,
            "lockfile 严格解析，单版本树",
          ],
          [
            "Python",
            <InlineCode key="a">pyproject.toml</InlineCode>,
            <>
              <InlineCode>uv</InlineCode> / <InlineCode>poetry</InlineCode>
            </>,
            "标准库虚拟环境隔离",
          ],
          [
            "Rust",
            <InlineCode key="a">Cargo.toml</InlineCode>,
            <InlineCode key="b">cargo</InlineCode>,
            "内置于工具链，语义化版本严格",
          ],
          [
            "Go",
            <InlineCode key="a">go.mod</InlineCode>,
            <InlineCode key="b">go get</InlineCode>,
            "最小版本选择（MVS），构建极快",
          ],
        ]}
      />

      <CodeBlock group="modules" />
    </Section>
  )
}
