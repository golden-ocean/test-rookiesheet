import { Accordion } from "@/components/ui/accordion"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function Pitfalls() {
  return (
    <Section id="pitfalls" title="常见陷阱">
      <p>下面是跨语言最常踩的几个坑，点击展开查看原因与规避方式。</p>

      <Accordion
        items={[
          {
            title: "Python 可变默认参数被共享",
            body: (
              <>
                <p>
                  默认参数在函数<strong>定义时</strong>
                  求值一次，因此同一个列表会被所有调用共享，反复调用会不断累积元素。
                </p>
                <p>
                  <InlineCode>def f(items=[]):</InlineCode> →{" "}
                  <InlineCode>def f(items=None): items = items or []</InlineCode>
                </p>
              </>
            ),
          },
          {
            title: "Go 循环变量捕获陷阱",
            body: (
              <>
                <p>
                  Go 1.22 之前，循环变量在所有迭代中共享同一个地址，闭包或 goroutine
                  捕获它会导致全部拿到最后一个值。1.22 起每个迭代拥有独立变量，语义与其他语言一致。
                </p>
                <p>
                  显式传参（<InlineCode>go func(v int) {"{...}"}(v)</InlineCode>
                  ）在旧版本中依然是最稳妥写法。
                </p>
              </>
            ),
          },
          {
            title: "JavaScript 的 == 与自动类型转换",
            body: (
              <p>
                <InlineCode>&quot;0&quot; == false</InlineCode> 为{" "}
                <InlineCode>true</InlineCode>，因为字符串会被转换成布尔值。始终使用{" "}
                <InlineCode>===</InlineCode> 与 <InlineCode>!==</InlineCode>，TypeScript
                的严格相等检查能替你避开这类问题。
              </p>
            ),
          },
          {
            title: "Rust 的借用与所有权冲突",
            body: (
              <p>
                同一时刻要么只有一个可变引用，要么可以有多个不可变引用。当借用冲突时，先考虑重排作用域、克隆小数据，或改用{" "}
                <InlineCode>Rc</InlineCode> / <InlineCode>Arc</InlineCode>。
              </p>
            ),
          },
          {
            title: "TypeScript 的 any 扩散",
            body: (
              <p>
                一个 <InlineCode>any</InlineCode>{" "}
                会让整条推导链失去类型保护。优先用 <InlineCode>unknown</InlineCode>
                （需要先收窄才能使用）或具体的泛型参数。
              </p>
            ),
          },
          {
            title: "浮点数不精确",
            body: (
              <p>
                0.1 + 0.2 不等于 0.3 在所有语言中都成立。金额计算请用整数分或十进制定点数类型（如
                Python 的 <InlineCode>decimal.Decimal</InlineCode>）。
              </p>
            ),
          },
        ]}
      />
    </Section>
  )
}
