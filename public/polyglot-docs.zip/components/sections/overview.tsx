import { Callout } from "@/components/ui/callout"
import { CardGrid, InfoCard } from "@/components/ui/card-grid"
import { DataTable } from "@/components/ui/data-table"
import { Section, SubHeading } from "@/components/ui/section"

export function Overview() {
  return (
    <Section id="overview" title="概述">
      <p>
        学习一门编程语言，本质上是学习三件事：<strong>它的表达能力</strong>（能写什么）、
        <strong>它的运行模型</strong>（怎么跑）以及<strong>它的工程约束</strong>
        （如何长期维护）。 只学语法往往意味着只学了三分之一。
      </p>

      <CardGrid>
        <InfoCard icon="layers" title="类型系统">
          静态 vs 动态、结构化 vs 名义化、名义 vs
          结构子类型。类型系统决定了你能把多少错误挡在编译期。
        </InfoCard>
        <InfoCard icon="cpu" title="内存与生命周期">
          栈与堆、所有权、GC 与引用计数。内存布局是理解性能问题的前提。
        </InfoCard>
        <InfoCard icon="git-branch" title="并发模型">
          线程、协程、消息传递与数据竞争。并发决定了你的系统能扛住多少并发。
        </InfoCard>
        <InfoCard icon="package" title="工程化">
          模块边界、包管理、测试与工具链。决定了代码能否活过一年。
        </InfoCard>
      </CardGrid>

      <SubHeading id="overview-compare" title="四种语言的定位对比" />

      <DataTable
        head={["维度", "TypeScript", "Python", "Rust", "Go"]}
        rows={[
          ["类型检查", "静态（渐进式）", "动态（可选注解）", "静态（强类型）", "静态（强类型）"],
          ["执行模型", "编译到 JS", "解释执行（CPython）", "编译为本地码（AOT）", "编译为本地码（AOT）"],
          ["内存管理", "由运行时（GC）", "引用计数 + GC", "所有权 + 借用检查", "并发标记清除 GC"],
          ["并发原语", "事件循环 + Promise", "GIL + asyncio", "线程 + async/await", "Goroutine + Channel"],
          ["泛型", "结构化、类型擦除", "鸭子类型", "单态化、无 trait object", "编译期实例化"],
          ["典型场景", "Web 前端 / Node 服务", "数据科学 / 脚本 / 后端", "系统级 / 高性能服务", "云原生 / 微服务"],
        ]}
      />

      <Callout variant="info" title="不要把语言当信仰">
        <p>
          每种语言都是为特定约束设计的权衡结果。遇到性能问题时，先质疑数据结构与算法，再考虑换语言。
        </p>
      </Callout>
    </Section>
  )
}
