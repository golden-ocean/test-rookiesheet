import { Callout } from "@/components/ui/callout"
import { CodeBlock } from "@/components/ui/code-block"
import { DataTable } from "@/components/ui/data-table"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function DataStructures() {
  return (
    <Section id="data-structures" title="数据结构">
      <p>
        标准库的容器差异是日常开发中最常遇到的「语言手感」来源。
        下面这张表列出了四种语言最常用的集合类型与它们的复杂度特征。
      </p>

      <DataTable
        head={["结构", "TypeScript", "Python", "Rust", "Go"]}
        rows={[
          [
            "动态数组",
            <InlineCode key="ts">Array</InlineCode>,
            <InlineCode key="py">list</InlineCode>,
            <InlineCode key="rs">Vec</InlineCode>,
            <InlineCode key="go">[]T</InlineCode>,
          ],
          [
            "固定长度",
            <InlineCode key="ts">readonly T[]</InlineCode>,
            <InlineCode key="py">tuple</InlineCode>,
            <InlineCode key="rs">[T; N]</InlineCode>,
            <InlineCode key="go">[N]T</InlineCode>,
          ],
          [
            "键值映射",
            <>
              <InlineCode>Map</InlineCode> / <InlineCode>Record</InlineCode>
            </>,
            <InlineCode key="py">dict</InlineCode>,
            <InlineCode key="rs">HashMap</InlineCode>,
            <InlineCode key="go">map[K]V</InlineCode>,
          ],
          [
            "去重集合",
            <InlineCode key="ts">Set</InlineCode>,
            <InlineCode key="py">set</InlineCode>,
            <InlineCode key="rs">HashSet</InlineCode>,
            <InlineCode key="go">map[T]bool</InlineCode>,
          ],
          [
            "栈 / 队列",
            <>
              数组 <InlineCode>push/pop/shift</InlineCode>
            </>,
            <InlineCode key="py">collections.deque</InlineCode>,
            <InlineCode key="rs">Vec</InlineCode>,
            <InlineCode key="go">slice</InlineCode>,
          ],
          [
            "有序映射",
            <>
              <InlineCode>Map</InlineCode>（保持插入序）
            </>,
            <>
              <InlineCode>dict</InlineCode>（保持插入序）
            </>,
            <InlineCode key="rs">BTreeMap</InlineCode>,
            "需第三方库",
          ],
        ]}
      />

      <CodeBlock group="data-structures" />

      <Callout variant="tip" title="复杂度速记">
        <p>
          数组/列表按索引访问均为 O(1)，但 Python <InlineCode>list.insert(0, x)</InlineCode>{" "}
          是 O(n)；哈希表的平均查找是 O(1)，最坏 O(n)；Go 的 map
          在并发写入时必须加锁，而 Rust 与 TS 的 <InlineCode>HashMap</InlineCode>{" "}
          不是线程安全的。
        </p>
      </Callout>
    </Section>
  )
}
