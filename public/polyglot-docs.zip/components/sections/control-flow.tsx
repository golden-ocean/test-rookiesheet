import { Callout } from "@/components/ui/callout"
import { CodeBlock } from "@/components/ui/code-block"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function ControlFlow() {
  return (
    <Section id="control-flow" title="控制流">
      <p>
        四种语言都有 <InlineCode>if</InlineCode> 与循环，但形态差异明显： Python
        依靠缩进而非括号，Rust 的 <InlineCode>match</InlineCode> 必须穷尽所有分支，
        Go 的 <InlineCode>switch</InlineCode> 默认不穿透，Python 的{" "}
        <InlineCode>match</InlineCode> 行为接近它。
      </p>

      <CodeBlock group="control-flow" />

      <Callout variant="info" title="遍历时修改集合">
        <p>
          在四种语言中，遍历期间删除元素都可能是未定义行为或直接报错。安全做法是先收集要处理的项，再统一修改集合。
        </p>
      </Callout>
    </Section>
  )
}
