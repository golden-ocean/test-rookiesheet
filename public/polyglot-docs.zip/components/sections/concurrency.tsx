import { Callout } from "@/components/ui/callout"
import { CodeBlock } from "@/components/ui/code-block"
import { Section } from "@/components/ui/section"

export function Concurrency() {
  return (
    <Section id="concurrency" title="并发模型">
      <p>
        并发的难点从来不是「同时跑几个任务」，而是<strong>共享可变状态</strong>。
        主流解法有两条路：用锁保护共享数据（线程），或用消息传递隔离状态（协程）。
        Go 的 goroutine + channel 是后者的极致，Rust
        的所有权则是「连数据竞争都不让你写」。
      </p>

      <CodeBlock group="concurrency" />

      <Callout variant="info" title="并发 ≠ 并行">
        <p>
          并发是「同时处理多件事」的抽象，并行是「同一时刻真的在多核上跑」。单核也能并发，只是靠时间片轮转切换。写代码时应当以「任务是否相互独立」而非「是否需要多核」来思考并发。
        </p>
      </Callout>
    </Section>
  )
}
