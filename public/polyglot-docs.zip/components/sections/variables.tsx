import { Callout } from "@/components/ui/callout"
import { CodeBlock } from "@/components/ui/code-block"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function Variables() {
  return (
    <Section id="variables" title="变量与类型">
      <p>
        声明变量时是否需要显式标注类型，是四种语言最直观的分水岭：TypeScript
        鼓励标注、 Python 允许标注但不强制、Rust 要求标注、Go
        使用类型推断但不允许函数体内重新声明。
      </p>

      <CodeBlock group="variables" />

      <Callout variant="warn" title="Rust 的字符串不是 String">
        <p>
          <InlineCode>&amp;str</InlineCode> 是不可变切片（借用一段只读内存），
          <InlineCode>String</InlineCode> 是堆上可增长缓冲区。函数参数优先接收{" "}
          <InlineCode>&amp;str</InlineCode>，只有在需要持有时才转成{" "}
          <InlineCode>String</InlineCode>。
        </p>
      </Callout>
    </Section>
  )
}
