import { Callout } from "@/components/ui/callout"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"
import { Steps } from "@/components/ui/steps"

export function Roadmap() {
  return (
    <Section id="roadmap" title="学习路线">
      <p>
        下面是一条为「已掌握一门语言，想理解不同范式」的人准备的 12 周路径。
        每阶段都以可交付的小项目结束，避免陷入「只看书不写代码」。
      </p>

      <Steps
        items={[
          {
            title: "第 1–2 周：类型系统直觉",
            desc: "读懂四种语言的类型声明与推断规则，写一个「JSON 校验 CLI」，对比各自的类型表达能力。",
          },
          {
            title: "第 3–4 周：内存与数据布局",
            desc: (
              <>
                用 <InlineCode>sizeof</InlineCode> / <InlineCode>sys.getsizeof</InlineCode> /{" "}
                <InlineCode>size_of::&lt;T&gt;()</InlineCode>{" "}
                观察结构体大小，理解对齐与 padding。
              </>
            ),
          },
          {
            title: "第 5–7 周：错误处理与边界",
            desc: "实现一个带重试与超时策略的 HTTP 客户端，比较 Result、异常与 error return 三种错误模型的传播路径。",
          },
          {
            title: "第 8–10 周：并发压力",
            desc: "用四种语言各实现一个带超时的并发抓取器，压测到 1000 并发，记录内存与错误率曲线。",
          },
          {
            title: "第 11 周：工具链与工程化",
            desc: "配置格式化、静态检查、测试覆盖率与 CI，让每个项目都能一条命令跑通全部门禁。",
          },
          {
            title: "第 12 周：设计复盘",
            desc: "为同一业务写两份实现（一种动态类型 + 一种静态类型），写一篇对比笔记公开分享。",
          },
        ]}
      />

      <Callout variant="tip" title="刻意练习的两条原则">
        <p>
          一、一次只突破一个舒适区边界；二、练习要处在「略有难度但可完成」的区间。重复阅读文档带来的提升，远小于动手写一个跑通的程序。
        </p>
      </Callout>
    </Section>
  )
}
