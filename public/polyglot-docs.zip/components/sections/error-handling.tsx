import { Callout } from "@/components/ui/callout"
import { CodeBlock } from "@/components/ui/code-block"
import { InlineCode } from "@/components/ui/inline-code"
import { Section } from "@/components/ui/section"

export function ErrorHandling() {
  return (
    <Section id="error-handling" title="错误处理">
      <p>
        错误处理是语言设计哲学差异最大的地方：Go 用显式返回值表达失败，Rust 用{" "}
        <InlineCode>Result</InlineCode>，Python 用异常，TypeScript 两者皆可。
        关键在于<strong>错误是不可恢复的业务分支，还是意料之外的崩溃</strong>。
      </p>

      <CodeBlock group="error-handling" />

      <Callout variant="warn" title="不要吞掉错误">
        <p>
          空的 <InlineCode>catch</InlineCode> 块、返回 <InlineCode>nil, nil</InlineCode>
          、忽略 <InlineCode>err</InlineCode>{" "}
          都会把问题推迟到更难排查的地方。要么处理它，要么带着上下文继续上抛。
        </p>
      </Callout>
    </Section>
  )
}
