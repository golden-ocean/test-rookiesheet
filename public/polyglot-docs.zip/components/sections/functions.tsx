import { CodeBlock } from "@/components/ui/code-block"
import { Section } from "@/components/ui/section"

export function Functions() {
  return (
    <Section id="functions" title="函数">
      <p>
        函数是一等公民，意味着函数可以作为参数传递、作为返回值返回、存入容器。
        Python 与 TypeScript 直接支持闭包与匿名函数；Rust 通过 trait
        约束实现同样能力；Go 则用函数类型表达。
      </p>

      <CodeBlock group="functions" />
    </Section>
  )
}
