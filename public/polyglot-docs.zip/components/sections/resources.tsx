import { LinkList } from "@/components/ui/link-list"
import { Section } from "@/components/ui/section"

export function Resources() {
  return (
    <Section id="resources" title="学习资源">
      <p>精选各语言的一手资料，优先阅读官方文档与规范，其次才是二手教程。</p>

      <LinkList
        items={[
          {
            href: "https://www.typescriptlang.org/docs/",
            icon: "code",
            title: "TypeScript Handbook",
            desc: "官方手册，类型系统部分写得最清楚",
          },
          {
            href: "https://docs.python.org/3/",
            icon: "code",
            title: "Python 官方文档",
            desc: "含 Library Reference 与 asyncio 章节",
          },
          {
            href: "https://doc.rust-lang.org/book/",
            icon: "code",
            title: "The Rust Book",
            desc: "所有权与借用章节是入门关键",
          },
          {
            href: "https://go.dev/doc/effective_go",
            icon: "code",
            title: "Effective Go",
            desc: "Go 社区的惯用法与风格指南",
          },
          {
            href: "https://github.com",
            icon: "terminal",
            title: "动手实践仓库",
            desc: "跟随示例代码逐节实现，全部语言覆盖",
          },
          {
            href: "https://github.com",
            icon: "file",
            title: "离线阅读 / 打印",
            desc: "把本页保存为 PDF，保留代码高亮与目录结构",
          },
        ]}
      />
    </Section>
  )
}
