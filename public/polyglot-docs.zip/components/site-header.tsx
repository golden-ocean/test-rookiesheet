"use client"

import { Icon } from "@/components/icon"
import { LangSwitch } from "@/components/lang-switch"
import { ProgressPill } from "@/components/progress-pill"
import { useShell } from "@/components/providers/shell-provider"
import { ThemeToggle } from "@/components/theme-toggle"

const headerLinks = [
  { id: "overview", label: "文档" },
  { id: "roadmap", label: "学习路线" },
  { id: "resources", label: "资源" },
  { id: "pitfalls", label: "速查" },
] as const

export function SiteHeader() {
  const { openSidebar, openPalette } = useShell()

  return (
    <header className="sticky top-0 z-50 flex h-14 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur-md backdrop-saturate-150">
      <button
        type="button"
        onClick={openSidebar}
        aria-label="打开导航"
        className="grid size-8 cursor-pointer place-items-center rounded-[calc(var(--radius)*0.8)] text-muted-foreground hover:bg-accent hover:text-foreground lg:hidden"
      >
        <Icon name="menu" className="size-4" />
      </button>

      <a href="#top" className="flex items-center gap-2.5 font-semibold tracking-[-0.01em] text-inherit no-underline">
        <span className="grid size-7 place-items-center rounded-[calc(var(--radius)*0.7)] bg-primary text-[15px] font-bold text-primary-foreground">
          P
        </span>
        <span className="text-[15px]">
          Polyglot{" "}
          <span className="hidden font-medium text-muted-foreground sm:inline">
            · 编程语言学习文档
          </span>
        </span>
      </a>

      <div className="hidden h-5 w-px bg-border sm:block" />

      <nav className="ml-2 hidden items-center gap-0.5 sm:flex">
        {headerLinks.map((link, index) => (
          <a
            key={link.id}
            href={`#${link.id}`}
            aria-current={index === 0 ? "page" : undefined}
            className="rounded-[calc(var(--radius)*0.7)] px-2.5 py-1.5 text-sm text-muted-foreground no-underline transition-colors hover:bg-accent hover:text-foreground aria-[current=page]:font-medium aria-[current=page]:text-foreground"
          >
            {link.label}
          </a>
        ))}
      </nav>

      <div className="flex-1" />

      <button
        type="button"
        onClick={openPalette}
        aria-label="搜索文档"
        className="inline-flex h-8 cursor-pointer items-center gap-2 rounded-[calc(var(--radius)*0.8)] border border-input bg-background pl-2.5 pr-2 text-[13.5px] text-muted-foreground transition-colors hover:border-ring hover:bg-muted md:min-w-[190px]"
      >
        <Icon name="search" className="size-4" />
        <span className="hidden flex-1 text-left md:inline">搜索文档…</span>
        <kbd className="hidden h-5 min-w-5 items-center justify-center rounded-[calc(var(--radius)*0.5)] border bg-muted px-1.5 font-sans text-[11px] font-medium md:inline-flex">
          ⌘K
        </kbd>
      </button>

      <LangSwitch />
      <ProgressPill />

      <a
        href="https://github.com"
        target="_blank"
        rel="noreferrer"
        aria-label="GitHub"
        className="grid size-8 place-items-center rounded-[calc(var(--radius)*0.8)] text-muted-foreground no-underline transition-colors hover:bg-accent hover:text-foreground"
      >
        <Icon name="github" className="size-4" />
      </a>

      <ThemeToggle />
    </header>
  )
}
