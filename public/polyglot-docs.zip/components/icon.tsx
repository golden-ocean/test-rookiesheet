import type { ReactNode, SVGProps } from "react"

import { cn } from "@/lib/cn"

const shapes = {
  search: (
    <>
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </>
  ),
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4" />
    </>
  ),
  moon: <path d="M12 3a6.4 6.4 0 0 0 9.9 9.9A9 9 0 1 1 12 3Z" />,
  github: (
    <>
      <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 5.5-5.5a4.4 4.4 0 0 0-1-3.5c.3-1.1.3-2.3 0-3.5 0 0-1 0-3 1.5-2.6-.5-5.3-.5-8 0C6 2 5 2 5 2c-.3 1.2-.3 2.4 0 3.5A4.4 4.4 0 0 0 4 9c-.5 3.5 2.5 5.5 5.5 5.5-.4.5-.7 1-1 1.5v4" />
      <path d="M9 18c-4.5 2-5-2-7-2" />
    </>
  ),
  menu: <path d="M4 6h16M4 12h16M4 18h16" />,
  x: <path d="M18 6 6 18M6 6l12 12" />,
  copy: (
    <>
      <rect width="13" height="13" x="9" y="9" rx="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </>
  ),
  check: <path d="M20 6 9 17l-5-5" />,
  "chevron-right": <path d="m9 18 6-6-6-6" />,
  "arrow-right": <path d="M5 12h14M12 5l7 7-7 7" />,
  "arrow-up": <path d="m5 12 7-7 7 7M12 19V5" />,
  book: (
    <>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 17.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
    </>
  ),
  code: <path d="m16 18 6-6-6-6M8 6l-6 6 6 6" />,
  terminal: <path d="m16 18 6-6-6-6M2 6v12h20" />,
  layers: (
    <>
      <path d="m12.8 2.7 8.1 4a2 2 0 0 1 0 3.5l-8.1 4a2 2 0 0 1-1.7 0l-8.1-4a2 2 0 0 1 0-3.5l8.1-4a2 2 0 0 1 1.7 0Z" />
      <path d="m22 12.5-9.2 4.5a2 2 0 0 1-1.7 0l-9.2-4.5M22 17.5l-9.2 4.5a2 2 0 0 1-1.7 0l-9.2-4.5" />
    </>
  ),
  cpu: (
    <>
      <rect width="16" height="16" x="4" y="4" rx="2" />
      <rect width="6" height="6" x="9" y="9" rx="1" />
      <path d="M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2" />
    </>
  ),
  package: (
    <>
      <path d="M11 21.7a2 2 0 0 0 1.4.6l7.3-4.2a2 2 0 0 0 1-1.7V7.6a2 2 0 0 0-1-1.7l-7.3-4.2a2 2 0 0 0-1.4 0l-7.3 4.2a2 2 0 0 0-1 1.7v8.4a2 2 0 0 0 1 1.7Z" />
      <path d="m7.5 4.3 9 5.2M21 16l-9.5-5.5L2 16M12 22V9.9" />
    </>
  ),
  alert: (
    <>
      <path d="m21.7 18-8-14a2 2 0 0 0-3.4 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3Z" />
      <path d="M12 9v4M12 17h.01" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4M12 8h.01" />
    </>
  ),
  sparkles: (
    <>
      <path d="M9.9 2.1 12 7l4.9 2-4.9 2L12 16l-2.1-4.9L5 9l4.9-2Z" />
      <path d="M19 14.5 20 18l3.5 1-3.5 1-1 3.5-1-3.5L14.5 19l3.5-1Z" />
    </>
  ),
  "git-branch": (
    <>
      <path d="M6 3v12" />
      <circle cx="18" cy="6" r="3" />
      <circle cx="6" cy="18" r="3" />
      <path d="M18 9a9 9 0 0 1-9 9" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </>
  ),
  compass: (
    <>
      <circle cx="12" cy="12" r="10" />
      <path d="m16.2 7.8-2.1 6.3-6.3 2.1 2.1-6.3Z" />
    </>
  ),
  zap: <path d="M13 2 3 14h9l-1 8 10-12h-9l1-8Z" />,
  file: (
    <>
      <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
    </>
  ),
} satisfies Record<string, ReactNode>

export type IconName = keyof typeof shapes

export function Icon({
  name,
  className,
  ...rest
}: { name: IconName; className?: string } & Omit<
  SVGProps<SVGSVGElement>,
  "name"
>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn("shrink-0", className ?? "size-4")}
      aria-hidden="true"
      {...rest}
    >
      {shapes[name]}
    </svg>
  )
}
