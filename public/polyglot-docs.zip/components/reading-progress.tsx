"use client"

import { useEffect, useState } from "react"

/** 顶部阅读进度条：pixel 级的滚动比例，直接用内联 width 控制更平滑。 */
export function ReadingProgress() {
  const [percent, setPercent] = useState(0)

  useEffect(() => {
    let frame = 0
    const update = () => {
      const scrollable = document.documentElement.scrollHeight - window.innerHeight
      setPercent(scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0)
      frame = 0
    }
    const onScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(update)
    }
    window.addEventListener("scroll", onScroll, { passive: true })
    update()
    return () => {
      window.removeEventListener("scroll", onScroll)
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-60 h-0.5">
      <i
        className="block h-full bg-foreground transition-[width] duration-75 ease-linear"
        style={{ width: `${percent}%` }}
      />
    </div>
  )
}
