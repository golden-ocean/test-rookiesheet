import type { IconName } from "@/components/icon"

/** 章节是文档的唯一骨架：侧栏、目录、进度、搜索都从这一份数据派生。 */
export const sectionIds = [
  "overview",
  "usage",
  "variables",
  "control-flow",
  "functions",
  "data-structures",
  "oop",
  "error-handling",
  "concurrency",
  "modules",
  "performance",
  "pitfalls",
  "roadmap",
  "resources",
] as const

export type SectionId = (typeof sectionIds)[number]

export const sectionTitles: Record<SectionId, string> = {
  overview: "概述",
  usage: "如何使用本指南",
  variables: "变量与类型",
  "control-flow": "控制流",
  functions: "函数",
  "data-structures": "数据结构",
  oop: "面向对象与类型系统",
  "error-handling": "错误处理",
  concurrency: "并发模型",
  modules: "模块与依赖管理",
  performance: "性能与内存",
  pitfalls: "常见陷阱",
  roadmap: "学习路线",
  resources: "学习资源",
}

export interface NavGroup {
  title: string
  items: Array<{ id: SectionId; icon: IconName }>
}

export const navGroups: NavGroup[] = [
  {
    title: "开始",
    items: [
      { id: "overview", icon: "compass" },
      { id: "usage", icon: "book" },
    ],
  },
  {
    title: "核心语法",
    items: [
      { id: "variables", icon: "code" },
      { id: "control-flow", icon: "code" },
      { id: "functions", icon: "code" },
      { id: "data-structures", icon: "layers" },
    ],
  },
  {
    title: "类型与设计",
    items: [
      { id: "oop", icon: "layers" },
      { id: "error-handling", icon: "alert" },
    ],
  },
  {
    title: "工程实践",
    items: [
      { id: "concurrency", icon: "cpu" },
      { id: "modules", icon: "package" },
      { id: "performance", icon: "zap" },
    ],
  },
  {
    title: "深入",
    items: [
      { id: "pitfalls", icon: "alert" },
      { id: "roadmap", icon: "target" },
      { id: "resources", icon: "book" },
    ],
  },
]

/** 搜索用的补充关键词：标题是中文，但用户常按概念或语言名检索。 */
const sectionKeywords: Record<SectionId, string> = {
  overview: "类型系统 内存 并发 工程化 语言对比 typescript python rust go",
  usage: "搜索 快捷键 主题 进度 阅读方式",
  variables: "变量 类型标注 联合类型 元组 rust string str mut",
  "control-flow": "if else for while switch match 循环 分支 穷尽",
  functions: "函数 闭包 泛型 高阶 默认参数 lambda trait",
  "data-structures": "数组 list vec map dict set hashmap 集合 队列 复杂度",
  oop: "trait interface 类 继承 组合 多态 静态分发",
  "error-handling": "result 异常 try catch error 错误 nil 传播",
  concurrency: "goroutine channel async await 协程 线程 并发 并行",
  modules: "cargo npm pnpm pyproject go.mod 依赖 模块 包管理",
  performance: "性能 内存 分配 复杂度 优化 profiler 基准",
  pitfalls: "陷阱 踩坑 默认参数 循环变量 浮点数 any 借用",
  roadmap: "路线 12 周 计划 刻意练习",
  resources: "资源 官方文档 书 链接 handbook",
}

export const tocItems = sectionIds.map((id) => ({
  id,
  title: sectionTitles[id],
  keywords: sectionKeywords[id],
}))
