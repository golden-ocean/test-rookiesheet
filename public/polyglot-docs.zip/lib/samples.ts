export type LangId = "typescript" | "python" | "rust" | "go"

export const langIds: LangId[] = ["typescript", "python", "rust", "go"]

export const langLabels: Record<LangId, string> = {
  typescript: "TypeScript",
  python: "Python",
  rust: "Rust",
  go: "Go",
}

/** 顶栏的语言切换只用两个字母，代码块里用全名。 */
export const langShortLabels: Record<LangId, string> = {
  typescript: "TS",
  python: "Py",
  rust: "Rs",
  go: "Go",
}

export type SampleId =
  | "variables"
  | "control-flow"
  | "functions"
  | "data-structures"
  | "oop"
  | "error-handling"
  | "concurrency"
  | "modules"
  | "performance"

/** 每段示例都保持纯文本，缩进与换行即最终渲染结果。 */
export const samples: Record<SampleId, Record<LangId, string>> = {
  variables: {
    typescript: `// 显式类型标注
let name: string = "Ada";
let age: number = 36;
let active: boolean = true;

// 联合类型
type Status = "idle" | "running" | "done";
let status: Status = "running";

// 数组与元组
let tags: string[] = ["math", "cs"];
let point: [number, number] = [3, 4];`,
    python: `# 变量无需声明类型，但推荐用注解表达意图
name: str = "Ada"
age: int = 36
active: bool = True

# 类型别名（3.10+ 使用 Literal）
from typing import Literal

Status = Literal["idle", "running", "done"]
status: Status = "running"

# 容器类型
tags: list[str] = ["math", "cs"]
point: tuple[int, int] = (3, 4)`,
    rust: `// 变量默认不可变，mut 表示可变
let name: &str = "Ada";
let mut age: u8 = 36;
let active: bool = true;

// 枚举即代数数据类型
enum Status {
    Idle,
    Running,
    Done,
}
let status = Status::Running;

let tags: Vec<String> = vec!["math".into(), "cs".into()];
let point: (i32, i32) = (3, 4);`,
    go: `name := "Ada"       // 短变量声明
var age int = 36    // 显式声明
var active bool = true

// 用字符串常量模拟枚举
type Status string

const (
    StatusIdle    Status = "idle"
    StatusRunning Status = "running"
)

var tags = []string{"math", "cs"}
var point = [2]int{3, 4}`,
  },

  "control-flow": {
    typescript: `for (const item of items) {
  if (item.done) continue;
  console.log(item.title);
}

const label = score >= 90 ? "A" : score >= 60 ? "B" : "C";

switch (kind) {
  case "pdf":
    return renderPDF();
  case "csv":
    return renderCSV();
  default:
    throw new Error("未知类型: " + kind);
}`,
    python: `for item in items:
    if item.done:
        continue
    print(item.title)

label = "A" if score >= 90 else ("B" if score >= 60 else "C")

match kind:
    case "pdf":
        return render_pdf()
    case "csv":
        return render_csv()
    case _:
        raise ValueError(f"未知类型: {kind}")`,
    rust: `for item in &items {
    if item.done {
        continue;
    }
    println!("{}", item.title);
}

// if 是表达式，可以直接产生值
let label = if score >= 90 { "A" } else { "B" };

// match 必须穷尽所有可能
match kind {
    Kind::Pdf => render_pdf()?,
    Kind::Csv => render_csv()?,
    other => return Err(Error::Unknown(other)),
}`,
    go: `for _, item := range items {
    if item.Done {
        continue
    }
    fmt.Println(item.Title)
}

label := "C"
if score >= 90 {
    label = "A"
} else if score >= 60 {
    label = "B"
}

// Go 的 switch 默认不穿透
switch kind {
case "pdf":
    return renderPDF()
case "csv":
    return renderCSV()
default:
    return fmt.Errorf("未知类型: %s", kind)
}`,
  },

  functions: {
    typescript: `function sum(nums: number[]): number {
  return nums.reduce((a, b) => a + b, 0);
}

// 默认参数 + 箭头函数
const greet = (name = "世界", greeting = "你好"): string =>
  greeting + ", " + name + "!";

// 泛型高阶函数
function map<T, U>(items: T[], fn: (item: T) => U): U[] {
  return items.map(fn);
}`,
    python: `def sum(nums: list[int]) -> int:
    return sum(nums)

# 默认参数 + 仅关键字参数
def greet(name: str = "世界", *, greeting: str = "你好") -> str:
    return f"{greeting}, {name}!"

# 高阶函数与类型参数
from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")
U = TypeVar("U")

def map(items: list[T], fn: Callable[[T], U]) -> list[U]:
    return [fn(item) for item in items]`,
    rust: `fn sum(nums: &[i32]) -> i32 {
    nums.iter().sum()
}

fn greet(name: &str) -> String {
    format!("你好, {name}!")
}

// 泛型 + 闭包约束
fn map<T, U, F: Fn(T) -> U>(items: &[T], f: F) -> Vec<U> {
    items.iter().map(|item| f(*item)).collect()
}`,
    go: `func sum(nums []int) int {
    total := 0
    for _, n := range nums {
        total += n
    }
    return total
}

func greet(name string) string {
    return fmt.Sprintf("你好, %s!", name)
}

// 泛型函数（Go 1.18+）
func Map[T, U any](items []T, fn func(T) U) []U {
    out := make([]U, 0, len(items))
    for _, it := range items {
        out = append(out, fn(it))
    }
    return out
}`,
  },

  "data-structures": {
    typescript: `const list = [1, 2, 3];          // 动态数组
list.push(4);

const set = new Set([1, 2, 2]);   // 集合自动去重
const map = new Map<string, number>();
map.set("a", 1);

const [first, ...rest] = list;   // 解构
const copy = [...list];          // 浅拷贝`,
    python: `nums = [1, 2, 3]        # list
nums.append(4)

seen = {1, 2}                   # set 自动去重
scores = {"a": 1}               # dict

first, *rest = nums             # 解包
copy = nums[:]                  # 浅拷贝`,
    rust: `let mut v = vec![1, 2, 3];
v.push(4);

use std::collections::{HashMap, HashSet};

let s: HashSet<i32> = HashSet::from([1, 2]);
let mut m: HashMap<String, i32> = HashMap::new();
m.insert("a".to_string(), 1);

let (first, rest) = v.split_first().unwrap();
let copy = v.clone();`,
    go: `nums := []int{1, 2, 3}
nums = append(nums, 4)

seen := map[int]bool{}
scores := map[string]int{}

first, rest := nums[0], nums[1:]
copy := append([]int(nil), nums...)`,
  },

  oop: {
    typescript: `interface Shape {
  area(): number;
}

class Circle implements Shape {
  constructor(private radius: number) {}

  area(): number {
    return Math.PI * this.radius ** 2;
  }
}

// 结构化子类型：鸭子类型 + 编译期检查
function describe(s: Shape): string {
  return "area=" + s.area().toFixed(2);
}`,
    python: `from abc import ABC, abstractmethod
import math


class Shape(ABC):
    @abstractmethod
    def area(self) -> float: ...


class Circle(Shape):
    def __init__(self, radius: float) -> None:
        self.radius = radius

    def area(self) -> float:
        return math.pi * self.radius ** 2`,
    rust: `pub trait Shape {
    fn area(&self) -> f64;
}

pub struct Circle {
    radius: f64,
}

impl Shape for Circle {
    fn area(&self) -> f64 {
        std::f64::consts::PI * self.radius.powi(2)
    }
}

// 静态分发：泛型约束，零开销抽象
fn describe<S: Shape>(s: &S) -> String {
    format!("area={:.2}", s.area())
}`,
    go: `type Shape interface {
    Area() float64
}

type Circle struct {
    Radius float64
}

func (c Circle) Area() float64 {
    return math.Pi * c.Radius * c.Radius
}

// 接口是隐式实现的：只要方法集匹配即可
func Describe(s Shape) string {
    return fmt.Sprintf("area=%.2f", s.Area())
}`,
  },

  "error-handling": {
    typescript: `async function loadUser(id: string) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new HttpError(res.status);
    return await res.json();
  } catch (err) {
    // 只捕获能处理的错误，其余继续上抛
    if (err instanceof HttpError && err.status === 404) return null;
    throw err;
  } finally {
    release();
  }
}`,
    python: `try:
    response = requests.get(url, timeout=5)
    response.raise_for_status()
    return response.json()
except requests.HTTPError as err:
    if err.response is not None and err.response.status_code == 404:
        return None
    raise
except requests.Timeout as err:
    raise DataError("请求超时") from err`,
    rust: `match fetch(url) {
    Ok(res) if res.status() == 404 => Ok(None),
    Ok(res) => res.json().map(Some).map_err(Into::into),
    Err(e) if e.is_timeout() => Err(Error::Timeout),
    Err(e) => Err(e.into()),
}

// 传播错误用 ? 运算符
fn load(id: u64) -> Result<User, AppError> {
    let raw = store.get(id)?;
    let user = serde_json::from_str(&raw)?;
    Ok(user)
}`,
    go: `res, err := fetch(url)
if err != nil {
    // errors.Is 用于判断哨兵错误
    if errors.Is(err, ErrNotFound) {
        return nil, nil
    }
    return nil, fmt.Errorf("fetch %s: %w", url, err)
}
defer res.Body.Close()

return parse(res.Body)`,
  },

  concurrency: {
    typescript: `// 并发执行，失败也返回结果
const results = await Promise.allSettled([
  fetchUser(id),
  fetchOrders(id),
]);

// 超时控制
const controller = new AbortController();
setTimeout(() => controller.abort(), 3000);
const res = await fetch(url, { signal: controller.signal });`,
    python: `import asyncio

# gather 等待全部完成
results = await asyncio.gather(
    fetch_user(uid),
    fetch_orders(uid),
    return_exceptions=True,
)

# 超时控制
async with asyncio.timeout(3):
    await fetch(url)`,
    rust: `// join! 同时轮询多个 future
let (user, orders) = tokio::join!(fetch_user(uid), fetch_orders(uid));

// 超时控制
let res = tokio::time::timeout(
    Duration::from_secs(3),
    fetch(url),
).await;

// 有所有权的数据可以安全地跨线程移动
std::thread::spawn(move || {
    println!("{user:?}");
});`,
    go: `var wg sync.WaitGroup
results := make([]Result, len(tasks))

for i, t := range tasks {
    wg.Add(1)
    go func(i int, t Task) {
        defer wg.Done()
        results[i] = run(t)
    }(i, t)
}
wg.Wait()

// goroutine + channel：消息传递
ch := make(chan int, 1)
go func() { ch <- 42 }()
value := <-ch`,
  },

  modules: {
    typescript: `// package.json
{
  "name": "my-app",
  "type": "module",
  "dependencies": { "zod": "^3.23.0" }
}

// 具名导入 / 默认导入 / 副作用导入
import { z } from "zod";
import fs from "node:fs/promises";
import "./polyfills";

export * from "./types";
export { helper } from "./utils";`,
    python: `# pyproject.toml
[project]
name = "my-app"
version = "0.1.0"
dependencies = ["httpx>=0.27"]

# 包内相对导入
from .core import Engine
from .schemas import User

__all__ = ["Engine", "User"]`,
    rust: `// Cargo.toml
[package]
name = "my-app"
version = "0.1.0"
edition = "2021"

[dependencies]
serde = { version = "1", features = ["derive"] }

use serde::{Deserialize, Serialize};

pub mod engine;
pub use engine::Engine;`,
    go: `// go.mod
module github.com/me/my-app

go 1.22

require (
    github.com/gin-gonic/gin v1.10.0
)

import (
    "github.com/gin-gonic/gin"
    "my-app/internal/store"
)`,
  },

  performance: {
    typescript: `// O(n^2) -> O(n)：用哈希表做记忆化
const seen = new Set<string>();
for (const item of items) {
  if (seen.has(item.id)) continue;
  seen.add(item.id);
  process(item);
}

// 避免在热循环里创建闭包与临时数组
const ids = items.map((i) => i.id);   // 一次遍历`,
    python: `# O(n^2) -> O(n)：用集合做记忆化
seen = set()
for item in items:
    if item.id in seen:
        continue
    seen.add(item.id)
    process(item)

# 列表推导通常比 for 循环更快
ids = [item.id for item in items]`,
    rust: `// 预分配容量，避免多次扩容
let mut ids: Vec<u64> = Vec::with_capacity(items.len());
for item in items {
    ids.push(item.id);
}

// 迭代器惰性求值，无需中间集合
let total: i64 = items.iter().map(|i| i.value).sum();

// 借用而非克隆，避免拷贝开销
fn total(items: &[Item]) -> i64 {
    items.iter().map(|i| i.value).sum()
}`,
    go: `// 预分配容量
ids := make([]uint64, 0, len(items))
for _, item := range items {
    ids = append(ids, item.ID)
}

// 切片避免每次循环都拷贝底层数组
func total(items []Item) int64 {
    var sum int64
    for _, it := range items {
        sum += it.Value
    }
    return sum
}`,
  },
}
