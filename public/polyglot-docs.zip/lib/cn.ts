/** 极简 className 合并，避免为了一个 clsx 引入依赖。 */
export function cn(...values: Array<string | false | null | undefined>) {
  return values.filter(Boolean).join(" ")
}
