import type { LangId } from "./samples"

export type TokenKind =
  | "comment"
  | "string"
  | "number"
  | "keyword"
  | "function"
  | "type"
  | "operator"
  | "plain"

export interface Token {
  text: string
  kind: TokenKind
}

interface Grammar {
  keywords: Set<string>
  types: Set<string>
  comment: RegExp
  string: RegExp
}

const words = (value: string) => new Set(value.split(/\s+/))

const grammars: Record<LangId, Grammar> = {
  typescript: {
    keywords: words(
      "const let var function return if else for while do switch case default break continue new class extends implements interface type enum import export from as async await of in typeof instanceof void null undefined true false this super try catch finally throw yield delete static readonly public private protected satisfies keyof infer never unknown any",
    ),
    types: words(
      "string number boolean object symbol bigint Array Promise Record Partial Readonly Map Set Date Error JSON Math console Uint8Array ReadonlyArray",
    ),
    comment: /^\/\/[^\n]*|^\/\*[\s\S]*?\*\//,
    string: /^`(?:[^`\\]|\\.)*`|^"(?:[^"\\]|\\.)*"|^'(?:[^'\\]|\\.)*'/,
  },
  python: {
    keywords: words(
      "def class return if elif else for while import from as with try except finally raise lambda pass break continue global nonlocal assert yield async await True False None and or not is in del match case",
    ),
    types: words(
      "self cls Exception ValueError TypeError RuntimeError object str int float bool list dict set tuple bytes print len range enumerate",
    ),
    comment: /^#[^\n]*/,
    string: /^f?"(?:[^"\\]|\\.)*"|^f?'(?:[^'\\]|\\.)*'/,
  },
  rust: {
    keywords: words(
      "fn let mut const static struct enum impl trait for while loop if else match return use mod pub crate self as in ref move dyn async await unsafe type where break continue",
    ),
    types: words(
      "String Vec Option Result Box i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 usize isize bool char str Duration HashMap HashSet println format vec panic write writeln Some None Ok Err",
    ),
    comment: /^\/\/[^\n]*|^\/\*[\s\S]*?\*\//,
    string: /^r?"(?:[^"\\]|\\.)*"|^r?'(?:[^'\\]|\\.)*'/,
  },
  go: {
    keywords: words(
      "func package import var const type struct interface map chan go defer if else for range return switch case default break continue select fallthrough true false nil",
    ),
    types: words(
      "string int int8 int16 int32 int64 uint uint8 uint32 uint64 float32 float64 bool byte rune error any fmt errors sync context time",
    ),
    comment: /^\/\/[^\n]*|^\/\*[\s\S]*?\*\//,
    string: /^"(?:[^"\\]|\\.)*"|^`[^`]*`|^'[^']'/,
  },
}

const numberPattern = /^\d[\d_]*(?:\.\d+)?/
const wordPattern = /^[A-Za-z_$][\w$]*/
const operatorPattern = /^[^\s\w$]+/

/**
 * 极简分词器：够用、够小，不引入 Prism/Shiki 这类重型依赖。
 * 顺序很关键——注释 > 字符串 > 数字 > 标识符 > 符号 > 空白。
 */
export function tokenize(source: string, lang: LangId): Token[] {
  const grammar = grammars[lang] ?? grammars.typescript
  const tokens: Token[] = []
  let index = 0

  const push = (text: string, kind: TokenKind) => {
    const last = tokens[tokens.length - 1]
    if (last && last.kind === kind) last.text += text
    else tokens.push({ text, kind })
  }

  while (index < source.length) {
    const rest = source.slice(index)
    let match: RegExpExecArray | null

    if ((match = grammar.comment.exec(rest))) {
      push(match[0], "comment")
      index += match[0].length
      continue
    }

    if ((match = grammar.string.exec(rest))) {
      push(match[0], "string")
      index += match[0].length
      continue
    }

    if ((match = numberPattern.exec(rest))) {
      push(match[0], "number")
      index += match[0].length
      continue
    }

    if ((match = wordPattern.exec(rest))) {
      const word = match[0]
      const after = source.slice(index + word.length)
      if (grammar.keywords.has(word)) push(word, "keyword")
      else if (/^\s*\(/.test(after)) push(word, "function")
      else if (grammar.types.has(word)) push(word, "type")
      else if (/^[A-Z]/.test(word)) push(word, "type")
      else push(word, "plain")
      index += word.length
      continue
    }

    if ((match = operatorPattern.exec(rest))) {
      push(match[0], "operator")
      index += match[0].length
      continue
    }

    push(source[index], "plain")
    index += 1
  }

  return tokens
}

export const tokenClassName: Record<TokenKind, string> = {
  comment: "tok-com",
  string: "tok-str",
  number: "tok-num",
  keyword: "tok-kw",
  function: "tok-fn",
  type: "tok-type",
  operator: "tok-op",
  plain: "",
}
